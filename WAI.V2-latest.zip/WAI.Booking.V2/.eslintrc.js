const path = require('path');

module.exports = {
  parser: 'babel-eslint',
  extends: ['airbnb'],
  env: {
    browser: true,
    node: true
  },
  rules: {
    "no-console": "off",
    "comma-dangle": "off"
  },
  settings: {
    'import/resolver': {
      node: {
        paths: path.resolve(__dirname, 'src', 'client')
      }
    }
  }
};
