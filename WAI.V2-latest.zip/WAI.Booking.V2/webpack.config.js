const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CleanWebpackPlugin = require('clean-webpack-plugin');

const outputDirectoryName = 'dist';

const outputDirectory = path.join(__dirname, outputDirectoryName);
const srcDirectory = path.join(__dirname, 'src');
const publicDirectory = path.join(__dirname, 'public');

const clientDirectory = path.join(srcDirectory, 'client');

module.exports = {
  entry: {
    main: ['babel-polyfill', path.join(clientDirectory, 'customer/index.jsx')],
    company: ['babel-polyfill', path.join(clientDirectory, 'company/index.jsx')],  
    p: ['babel-polyfill', path.join(clientDirectory, 'p/index.jsx')],   
  },
  output: {
    path: outputDirectory,
    filename: '[name].bundle.js'
  },
  resolve: {
    extensions: ['.js', '.jsx'],
    modules: [clientDirectory, 'node_modules']
  },
  module: {
    rules: [
      {
        test: /\.(js|jsx)$/,
        exclude: /node_modules/,
        use: {
          loader: 'babel-loader'
        }
      },
      {
        test: /\.css$/,
        use: ['style-loader', 'css-loader']
      },
      {
        test: /\.(jpg|png|woff|woff2|eot|ttf|svg)$/,
        loader: 'url-loader?limit=100000'
      }
    ]
  },
  devServer: {
    port: 3000,
    open: true,
    proxy: {
      '/api': 'http://localhost:8080'
    }
  },
  plugins: [
    new CleanWebpackPlugin([outputDirectory]),
    new HtmlWebpackPlugin({
      template: path.join(publicDirectory, 'index.html'),
      favicon: path.join(publicDirectory, 'favicon.ico'),
      chunks: ['main'],
      filename: path.join(outputDirectory, 'index.html')
    }),
    new HtmlWebpackPlugin({
      template: path.join(publicDirectory, 'company/index.html'),
      favicon: path.join(publicDirectory, 'company/favicon.ico'),
      chunks: ['company'],
      filename: path.join(outputDirectory, 'company', 'index.html')
    }),
    new HtmlWebpackPlugin({
      template: path.join(publicDirectory, 'p/index.html'),
      favicon: path.join(publicDirectory, 'p/favicon.ico'),
      chunks: ['p'],
      filename: path.join(outputDirectory, 'p', 'index.html')
    }),  
  ]
};
