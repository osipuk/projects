/*
SQLyog Enterprise - MySQL GUI v8.12 
MySQL - 5.5.5-10.1.34-MariaDB : Database - hair
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`hair` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `hair`;

/*Table structure for table `about` */

DROP TABLE IF EXISTS `about`;

CREATE TABLE `about` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `company_id` int(10) DEFAULT NULL,
  `language_id` int(5) DEFAULT NULL,
  `about` text,
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `about` */

insert  into `about`(`id`,`company_id`,`language_id`,`about`) values (2,1,2,'Hos Overgaard er kvalitet, personlig rådgivning og økologi i højsædet. Salonen forbinder velvære og skønhed i en afslappet atmosfære.\n\nIndehaveren er udlært hos Palma salon og spa i København K og efteruddannet ved blandt andet Sassoon Academy i London.'),(4,1,1,'It is the test for the English \nHos Overgaard er kvalitet, personlig rådgivning og økologi i højsædet. Salonen forbinder velvære og skønhed i en afslappet atmosfære.\n\nIndehaveren er udlært hos Palma salon og spa i København K og efteruddannet ved blandt andet Sassoon Academy i London.');

/*Table structure for table `booking` */

DROP TABLE IF EXISTS `booking`;

CREATE TABLE `booking` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `version_id` int(10) DEFAULT NULL,
  `root_id` int(10) DEFAULT NULL,
  `customer_id` int(10) unsigned NOT NULL,
  `company_id` int(10) unsigned NOT NULL,
  `discount_id` int(10) DEFAULT NULL COMMENT 'discount_card id',
  `recipe` text,
  `note` text,
  `book_from` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `book_to` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `duration` varchar(100) DEFAULT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `approved_on` timestamp NULL DEFAULT NULL,
  `status` enum('AWAITING RESPONSE','ACCEPTED','STAYED AWAY','COMPLETED','CANCELLED BY COMPANY','REJECTED','CANCELLED BY CUSTOMER') DEFAULT 'AWAITING RESPONSE',
  `paid` int(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `version_id` (`version_id`),
  KEY `root_id` (`root_id`),
  KEY `customer_id` (`customer_id`),
  KEY `company_id` (`company_id`),
  CONSTRAINT `booking_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`),
  CONSTRAINT `booking_ibfk_5` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/*Data for the table `booking` */

/*Table structure for table `booking_discount_cards_relation` */

DROP TABLE IF EXISTS `booking_discount_cards_relation`;

CREATE TABLE `booking_discount_cards_relation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `booking_id` int(10) DEFAULT NULL,
  `discount_card_user_relation_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `booking_discount_cards_relation` */

/*Table structure for table `booking_extra` */

DROP TABLE IF EXISTS `booking_extra`;

CREATE TABLE `booking_extra` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` int(10) unsigned NOT NULL,
  `service_id` int(10) DEFAULT NULL,
  `service_extra_id` int(10) unsigned NOT NULL,
  `customer_id` int(10) unsigned NOT NULL,
  `employee_id` int(10) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `booking_id` (`booking_id`),
  KEY `service_extra_id` (`service_extra_id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `booking_extra_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `booking` (`id`),
  CONSTRAINT `booking_extra_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `booking_extra` */

/*Table structure for table `booking_gift_cards_relation` */

DROP TABLE IF EXISTS `booking_gift_cards_relation`;

CREATE TABLE `booking_gift_cards_relation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `booking_id` int(10) DEFAULT NULL,
  `gift_card_id` int(10) DEFAULT NULL,
  `gift_card_amount_used` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

/*Data for the table `booking_gift_cards_relation` */

/*Table structure for table `booking_hours` */

DROP TABLE IF EXISTS `booking_hours`;

CREATE TABLE `booking_hours` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned NOT NULL,
  `employee_id` int(10) unsigned NOT NULL,
  `monday_is_open` tinyint(1) NOT NULL DEFAULT '0',
  `tuesday_is_open` tinyint(1) NOT NULL DEFAULT '0',
  `wednesday_is_open` tinyint(1) NOT NULL DEFAULT '0',
  `thursday_is_open` tinyint(1) NOT NULL DEFAULT '0',
  `friday_is_open` tinyint(1) NOT NULL DEFAULT '0',
  `saturday_is_open` tinyint(1) NOT NULL DEFAULT '0',
  `sunday_is_open` tinyint(1) NOT NULL DEFAULT '0',
  `monday_open_at` time DEFAULT NULL,
  `tuesday_open_at` time DEFAULT NULL,
  `wednesday_open_at` time DEFAULT NULL,
  `thursday_open_at` time DEFAULT NULL,
  `friday_open_at` time DEFAULT NULL,
  `saturday_open_at` time DEFAULT NULL,
  `sunday_open_at` time DEFAULT NULL,
  `monday_close_at` time DEFAULT NULL,
  `tuesday_close_at` time DEFAULT NULL,
  `wednesday_close_at` time DEFAULT NULL,
  `thursday_close_at` time DEFAULT NULL,
  `friday_close_at` time DEFAULT NULL,
  `saturday_close_at` time DEFAULT NULL,
  `sunday_close_at` time DEFAULT NULL,
  `vacation_open_at` date DEFAULT NULL,
  `vacation_cloase_at` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `employee_id` (`employee_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

/*Data for the table `booking_hours` */

insert  into `booking_hours`(`id`,`company_id`,`employee_id`,`monday_is_open`,`tuesday_is_open`,`wednesday_is_open`,`thursday_is_open`,`friday_is_open`,`saturday_is_open`,`sunday_is_open`,`monday_open_at`,`tuesday_open_at`,`wednesday_open_at`,`thursday_open_at`,`friday_open_at`,`saturday_open_at`,`sunday_open_at`,`monday_close_at`,`tuesday_close_at`,`wednesday_close_at`,`thursday_close_at`,`friday_close_at`,`saturday_close_at`,`sunday_close_at`,`vacation_open_at`,`vacation_cloase_at`) values (16,1,0,1,1,1,0,1,0,0,'10:00:00','10:00:00','10:00:00','10:00:00','10:00:00','10:00:00','10:00:00','16:00:00','16:00:00','16:00:00','16:00:00','16:00:00','16:00:00','16:00:00',NULL,NULL),(17,1,11,1,0,0,1,1,1,0,'10:00:00','10:00:00','10:00:00','10:00:00','10:00:00','10:00:00','10:00:00','15:15:00','16:00:00','16:00:00','15:30:00','17:10:00','16:00:00','16:00:00',NULL,NULL);

/*Table structure for table `booking_item` */

DROP TABLE IF EXISTS `booking_item`;

CREATE TABLE `booking_item` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `booking_id` int(10) DEFAULT NULL,
  `employee_id` int(10) DEFAULT NULL,
  `service_id` int(10) DEFAULT NULL,
  `extra_id` int(10) DEFAULT NULL,
  `is_service_extra` tinyint(1) DEFAULT '1' COMMENT '1-service,0-extra',
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `booking_item` */

/*Table structure for table `booking_notify` */

DROP TABLE IF EXISTS `booking_notify`;

CREATE TABLE `booking_notify` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `company_id` int(10) DEFAULT NULL,
  `booking_id` int(10) DEFAULT NULL,
  `customer_id` int(10) DEFAULT NULL,
  `event_type` varchar(50) DEFAULT NULL COMMENT 'Created booking',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `seen` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Data for the table `booking_notify` */

insert  into `booking_notify`(`id`,`company_id`,`booking_id`,`customer_id`,`event_type`,`created_at`,`seen`) values (1,1,50,20,'New booking','2019-05-04 09:54:30',0),(2,1,4,20,'New booking','2019-05-06 22:34:17',0),(3,1,5,20,'New booking','2019-05-06 22:37:54',0);

/*Table structure for table `booking_product_relations` */

DROP TABLE IF EXISTS `booking_product_relations`;

CREATE TABLE `booking_product_relations` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `booking_id` int(10) NOT NULL,
  `products_id` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Data for the table `booking_product_relations` */

insert  into `booking_product_relations`(`id`,`booking_id`,`products_id`) values (1,37,9);

/*Table structure for table `booking_service` */

DROP TABLE IF EXISTS `booking_service`;

CREATE TABLE `booking_service` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` int(10) unsigned NOT NULL,
  `service_id` int(10) unsigned NOT NULL,
  `customer_id` int(10) unsigned NOT NULL,
  `employee_id` int(10) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `booking_id` (`booking_id`),
  KEY `service_id` (`service_id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `booking_service_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `booking` (`id`),
  CONSTRAINT `booking_service_ibfk_2` FOREIGN KEY (`service_id`) REFERENCES `service` (`id`),
  CONSTRAINT `booking_service_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `booking_service` */

/*Table structure for table `booking_version` */

DROP TABLE IF EXISTS `booking_version`;

CREATE TABLE `booking_version` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` int(10) DEFAULT NULL,
  `version_id` int(10) DEFAULT NULL,
  `root_id` int(10) DEFAULT NULL,
  `employee_id` int(10) unsigned NOT NULL,
  `customer_id` int(10) unsigned NOT NULL,
  `company_id` int(10) unsigned NOT NULL,
  `service_id` int(10) DEFAULT NULL,
  `recipe` text,
  `note` text,
  `book_from` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `book_to` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `duration` varchar(100) DEFAULT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `approved_on` timestamp NULL DEFAULT NULL,
  `status` enum('AWAITING RESPONSE','REJECTED','ACCEPTED','STAYED AWAY','COMPLETED','CANCELLED') DEFAULT 'AWAITING RESPONSE',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `paid` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

/*Data for the table `booking_version` */

insert  into `booking_version`(`id`,`booking_id`,`version_id`,`root_id`,`employee_id`,`customer_id`,`company_id`,`service_id`,`recipe`,`note`,`book_from`,`book_to`,`duration`,`created_on`,`approved_on`,`status`,`updated_at`,`paid`) values (1,47,NULL,NULL,0,20,1,NULL,NULL,NULL,'2019-04-25 10:15:00','2019-04-25 12:57:00','177','2019-04-19 09:20:11',NULL,'AWAITING RESPONSE','2019-04-19 09:36:46',0),(2,47,NULL,47,0,20,1,NULL,NULL,NULL,'2019-04-25 10:15:00','2019-04-25 12:57:00','177','2019-04-19 09:20:11',NULL,'AWAITING RESPONSE','2019-04-20 21:55:08',0),(3,48,NULL,NULL,0,43,1,NULL,NULL,NULL,'2019-04-25 13:30:00','2019-04-25 15:05:00','110','2019-04-19 10:03:59',NULL,'AWAITING RESPONSE','2019-04-20 21:55:08',0),(4,49,NULL,NULL,0,20,1,NULL,NULL,NULL,'2019-04-25 12:00:00','2019-04-25 13:24:00','84','2019-04-25 12:30:41',NULL,'AWAITING RESPONSE','2019-04-26 00:07:37',0),(5,49,NULL,49,0,20,1,NULL,NULL,NULL,'2019-04-25 12:00:00','2019-04-25 13:24:00','84','2019-04-25 12:30:41','2019-04-26 00:07:37','ACCEPTED','2019-04-26 09:39:51',0),(6,49,NULL,49,0,20,1,NULL,NULL,NULL,'2019-04-25 12:00:00','2019-04-25 13:24:00','84','2019-04-25 12:30:41','2019-04-26 00:07:37','AWAITING RESPONSE','2019-04-26 13:15:58',0),(7,49,NULL,49,0,20,1,NULL,NULL,NULL,'2019-04-25 12:00:00','2019-04-25 13:24:00','84','2019-04-25 12:30:41','2019-04-26 13:15:58','AWAITING RESPONSE','2019-04-26 22:03:56',0),(8,49,NULL,49,0,20,1,NULL,NULL,NULL,'2019-04-25 12:00:00','2019-04-25 13:24:00','84','2019-04-25 12:30:41','2019-04-26 22:03:56','AWAITING RESPONSE','2019-04-26 22:18:20',0),(9,49,NULL,49,0,20,1,NULL,NULL,NULL,'2019-04-25 12:00:00','2019-04-25 13:24:00','84','2019-04-25 12:30:41','2019-04-26 22:18:20','AWAITING RESPONSE','2019-04-26 22:23:36',0),(10,49,NULL,49,0,20,1,NULL,NULL,NULL,'2019-04-25 12:00:00','2019-04-25 13:24:00','84','2019-04-25 12:30:41','2019-04-26 22:23:36','AWAITING RESPONSE','2019-04-26 22:33:30',0),(11,49,NULL,49,0,20,1,NULL,NULL,NULL,'2019-04-25 12:00:00','2019-04-25 13:24:00','84','2019-04-25 12:30:41','2019-04-26 22:23:36','AWAITING RESPONSE','2019-04-26 22:56:28',0),(12,49,NULL,49,0,20,1,NULL,NULL,NULL,'2019-04-25 12:00:00','2019-04-25 13:24:00','84','2019-04-25 12:30:41','2019-04-26 22:56:28','AWAITING RESPONSE','2019-04-26 23:14:58',0),(13,49,NULL,49,0,20,1,NULL,NULL,NULL,'2019-04-25 12:00:00','2019-04-25 13:24:00','84','2019-04-25 12:30:41','2019-04-26 23:14:58','AWAITING RESPONSE','2019-04-26 23:16:30',0);

/*Table structure for table `comment` */

DROP TABLE IF EXISTS `comment`;

CREATE TABLE `comment` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) DEFAULT NULL,
  `company_id` int(10) DEFAULT NULL,
  `comment` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

/*Data for the table `comment` */

insert  into `comment`(`id`,`customer_id`,`company_id`,`comment`,`created_at`,`modified_at`) values (7,20,1,'errterer32','2019-03-02 07:37:22','2019-03-02 10:01:53'),(8,20,1,'3333312','2019-03-02 08:23:35','2019-03-02 10:01:53'),(11,34,1,'444','2019-03-02 10:16:41','2019-03-15 10:19:22'),(12,34,1,'this is comments for test','2019-03-15 10:19:22','2019-03-15 10:19:22'),(13,43,1,'eeee','2019-04-21 06:07:35','2019-04-21 06:07:35');

/*Table structure for table `company` */

DROP TABLE IF EXISTS `company`;

CREATE TABLE `company` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `version_id` int(10) unsigned DEFAULT NULL,
  `root_id` int(10) unsigned DEFAULT NULL,
  `cvr` varchar(64) DEFAULT NULL,
  `company_name` varchar(64) NOT NULL,
  `zip_code` varchar(10) NOT NULL,
  `city` varchar(64) NOT NULL,
  `address` varchar(255) NOT NULL,
  `accept_booking_automatically` tinyint(1) DEFAULT '0',
  `lock_booking_xhour_before` int(10) unsigned NOT NULL DEFAULT '2',
  `book_latest_xhour_before` int(10) unsigned NOT NULL DEFAULT '2',
  `payment_upfront` tinyint(1) DEFAULT '0',
  `sms_sender_name` varchar(11) NOT NULL DEFAULT 'companyname',
  `country_id` int(10) NOT NULL,
  `interval` int(10) DEFAULT '30',
  `custom_url` varchar(30) DEFAULT NULL,
  `description` text,
  `facebook` varchar(300) DEFAULT NULL,
  `instagram` varchar(300) DEFAULT NULL,
  `twitter` varchar(300) DEFAULT NULL,
  `website` varchar(300) DEFAULT NULL,
  `lng` double DEFAULT NULL,
  `lat` double DEFAULT NULL,
  `bussiness_email` varchar(255) DEFAULT NULL,
  `vat_report_type_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `version_id` (`version_id`),
  KEY `root_id` (`root_id`),
  CONSTRAINT `company_ibfk_1` FOREIGN KEY (`version_id`) REFERENCES `company` (`id`),
  CONSTRAINT `company_ibfk_2` FOREIGN KEY (`root_id`) REFERENCES `company` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;

/*Data for the table `company` */

insert  into `company`(`id`,`version_id`,`root_id`,`cvr`,`company_name`,`zip_code`,`city`,`address`,`accept_booking_automatically`,`lock_booking_xhour_before`,`book_latest_xhour_before`,`payment_upfront`,`sms_sender_name`,`country_id`,`interval`,`custom_url`,`description`,`facebook`,`instagram`,`twitter`,`website`,`lng`,`lat`,`bussiness_email`,`vat_report_type_id`) values (1,NULL,NULL,'112343123','Overgaard Organic Hair','111052','city1','Willemoesgade 7b, 2100 København Ø, Danmark',0,24,2,0,'11123411',1,15,'1wxs23ecvbf56y445f90hhf','descr\ntionsss','fff','sss','ddd','eee',12.5806305,55.6974447,'nikorel@bussiness.com1',NULL),(41,NULL,NULL,NULL,'','','','',0,2,2,0,'companyname',1,30,'f83e2da3a109ee6d2531519b56fef9',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);

/*Table structure for table `company_version` */

DROP TABLE IF EXISTS `company_version`;

CREATE TABLE `company_version` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `version_id` int(10) unsigned DEFAULT NULL,
  `root_id` int(10) unsigned DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` binary(60) NOT NULL,
  `phone` varchar(64) NOT NULL,
  `cvr` varchar(64) DEFAULT NULL,
  `company_name` varchar(64) NOT NULL,
  `first_name` varchar(64) NOT NULL,
  `last_name` varchar(64) NOT NULL,
  `zip_code` varchar(10) NOT NULL,
  `city` varchar(64) NOT NULL,
  `address` varchar(255) NOT NULL,
  `accept_booking_automatically` tinyint(1) DEFAULT '0',
  `lock_booking_xhour_before` int(10) unsigned NOT NULL,
  `book_latest_xhour_before` int(10) unsigned NOT NULL,
  `payment_upfront` tinyint(1) DEFAULT '0',
  `sms_sender_name` varchar(11) NOT NULL,
  `country_id` int(10) NOT NULL,
  `company_id` varchar(10) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `interval` int(10) DEFAULT '30',
  `custom_url` varchar(30) DEFAULT NULL,
  `email_veryfied` tinyint(1) DEFAULT '0',
  `description` text,
  `facebook` varchar(300) DEFAULT NULL,
  `instagram` varchar(300) DEFAULT NULL,
  `twitter` varchar(300) DEFAULT NULL,
  `website` varchar(300) DEFAULT NULL,
  `verify_code` varchar(10) DEFAULT NULL,
  `phone_veryfied` tinyint(1) DEFAULT '0',
  `email_token` text,
  `lat` double DEFAULT NULL,
  `lng` double DEFAULT NULL,
  `bussiness_email` varchar(255) DEFAULT NULL,
  `vat_report_type_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `version_id` (`version_id`),
  KEY `root_id` (`root_id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8;

/*Data for the table `company_version` */

insert  into `company_version`(`id`,`version_id`,`root_id`,`email`,`password`,`phone`,`cvr`,`company_name`,`first_name`,`last_name`,`zip_code`,`city`,`address`,`accept_booking_automatically`,`lock_booking_xhour_before`,`book_latest_xhour_before`,`payment_upfront`,`sms_sender_name`,`country_id`,`company_id`,`updated_at`,`interval`,`custom_url`,`email_veryfied`,`description`,`facebook`,`instagram`,`twitter`,`website`,`verify_code`,`phone_veryfied`,`email_token`,`lat`,`lng`,`bussiness_email`,`vat_report_type_id`) values (62,NULL,NULL,'','\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','','112343123','Overgaard Organic Hair','','','111052','city1','Willemoesgade 7b, 2100 København Ø, Danmark',0,24,2,0,'11123',1,'1','2019-04-17 14:49:14',15,'1wxs23ecvbf56y445f90hhf',0,'descr\ntionsss','fff','sss','ddd','eee',NULL,0,NULL,55.6974447,12.5806305,'nikorel@bussiness.com1',NULL),(63,NULL,NULL,'','\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','','112343123','Overgaard Organic Hair','','','111052','city1','Willemoesgade 7b, 2100 København Ø, Danmark',0,24,2,0,'11123',1,'1','2019-04-17 14:51:08',15,'1wxs23ecvbf56y445f90hhf',0,'descr\ntionsss','fff','sss','ddd','eee',NULL,0,NULL,55.6974447,12.5806305,'nikorel@bussiness.com1',NULL),(64,NULL,NULL,'','\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','','112343123','Overgaard Organic Hair','','','111052','city1','Willemoesgade 7b, 2100 København Ø, Danmark',0,24,2,0,'11123411',1,'1','2019-04-17 14:51:52',15,'1wxs23ecvbf56y445f90hhf',0,'descr\ntionsss','fff','sss','ddd','eee',NULL,0,NULL,55.6974447,12.5806305,'nikorel@bussiness.com1',NULL),(65,NULL,NULL,'','\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','','112343123','Overgaard Organic Hair','','','111052','city1','Willemoesgade 7b, 2100 København Ø, Danmark',0,24,2,0,'11123411',1,'1','2019-04-22 12:36:40',15,'1wxs23ecvbf56y445f90hhf',0,'descr\ntionsss','fff','sss','ddd','eee',NULL,0,NULL,55.6974447,12.5806305,'nikorel@bussiness.com1',NULL),(66,NULL,NULL,'','\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','','112343123','Overgaard Organic Hair','','','111052','city1','Willemoesgade 7b, 2100 København Ø, Danmark',0,24,2,0,'11123411',1,'1','2019-04-22 22:41:52',15,'1wxs23ecvbf56y445f90hhf',0,'descr\ntionsss','fff','sss','ddd','eee',NULL,0,NULL,55.6974447,12.5806305,'nikorel@bussiness.com1',NULL),(67,NULL,NULL,'','\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','','112343123','Overgaard Organic Hair','','','111052','city1','Willemoesgade 7b, 2100 København Ø, Danmark',0,24,2,0,'11123411',1,'1','2019-04-22 22:41:55',15,'1wxs23ecvbf56y445f90hhf',0,'descr\ntionsss','fff','sss','ddd','eee',NULL,0,NULL,55.6974447,12.5806305,'nikorel@bussiness.com1',NULL);

/*Table structure for table `country` */

DROP TABLE IF EXISTS `country`;

CREATE TABLE `country` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `country_phone_code` varchar(64) NOT NULL,
  `currency_code` varchar(64) NOT NULL,
  `country_prefix` varchar(10) NOT NULL,
  `time_zone` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `country` */

insert  into `country`(`id`,`name`,`country_phone_code`,`currency_code`,`country_prefix`,`time_zone`) values (1,'Danmark','+45','DKK','dk','Europe/Copenhagen'),(2,'Japan','+81','Yen','JPY','Asia/Tokyo');

/*Table structure for table `customer` */

DROP TABLE IF EXISTS `customer`;

CREATE TABLE `customer` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `password` varchar(10) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(8) NOT NULL,
  `country_id` int(10) DEFAULT NULL,
  `first_name` varchar(64) NOT NULL,
  `last_name` varchar(64) NOT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `note` text,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_password_reset` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `zip_code` varchar(64) DEFAULT NULL,
  `city` varchar(64) DEFAULT NULL,
  `address1` varchar(64) DEFAULT NULL,
  `address2` varchar(64) DEFAULT NULL,
  `phone_work` varchar(64) DEFAULT NULL,
  `birthday` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `type` varchar(10) DEFAULT 'customer',
  `anonymously` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone` (`phone`),
  UNIQUE KEY `phone_work` (`phone_work`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

/*Data for the table `customer` */

insert  into `customer`(`id`,`password`,`email`,`phone`,`country_id`,`first_name`,`last_name`,`gender`,`note`,`created_on`,`last_password_reset`,`zip_code`,`city`,`address1`,`address2`,`phone_work`,`birthday`,`type`,`anonymously`) values (1,'asdf','asdf@gmail.com','12233456',1,'kostya','bores','man',NULL,'2019-01-23 02:02:00','2019-01-23 02:02:00','11004','city1','address1','address2','phone work1','2019-01-23 02:02:00','customer',0),(20,'12345677','test@test.com','12345677',1,'tom2','boshe',NULL,NULL,'2019-02-06 10:40:15','2019-02-06 10:40:15','11223','city23','address121','address221',NULL,NULL,'customer',0),(43,NULL,'nikorelpan1090@gmail.com','15478412',1,'ggg','dsf','',NULL,'2019-04-19 10:03:36','2019-04-19 10:03:36','11004',NULL,'1114 sanhoa road',NULL,NULL,'0000-00-00 00:00:00','customer',0);

/*Table structure for table `customer_group` */

DROP TABLE IF EXISTS `customer_group`;

CREATE TABLE `customer_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) unsigned NOT NULL,
  `company_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  KEY `company_id` (`company_id`),
  CONSTRAINT `customer_group_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`),
  CONSTRAINT `customer_group_ibfk_2` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `customer_group` */

/*Table structure for table `customer_version` */

DROP TABLE IF EXISTS `customer_version`;

CREATE TABLE `customer_version` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) DEFAULT NULL,
  `password` varchar(10) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(8) NOT NULL,
  `country_id` int(10) DEFAULT NULL,
  `first_name` varchar(64) NOT NULL,
  `last_name` varchar(64) NOT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `note` text,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_password_reset` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `zip_code` varchar(64) DEFAULT NULL,
  `city` varchar(64) DEFAULT NULL,
  `address1` varchar(64) DEFAULT NULL,
  `address2` varchar(64) DEFAULT NULL,
  `phone_work` varchar(64) DEFAULT NULL,
  `birthday` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `type` varchar(10) DEFAULT 'customer',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `anonymously` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `customer_version` */

/*Table structure for table `discount` */

DROP TABLE IF EXISTS `discount`;

CREATE TABLE `discount` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(100) DEFAULT NULL,
  `business_id` int(10) DEFAULT NULL,
  `type` enum('0','1') DEFAULT NULL,
  `amount` decimal(8,2) DEFAULT NULL,
  `percentage` decimal(8,2) DEFAULT NULL,
  `all_services` tinyint(1) DEFAULT '0',
  `all_service_extras` tinyint(1) DEFAULT '0',
  `valid_from` datetime DEFAULT '0000-00-00 00:00:00',
  `valid_to` datetime DEFAULT '0000-00-00 00:00:00',
  `require_payment_upfront` tinyint(1) DEFAULT '0',
  `used` int(10) DEFAULT NULL,
  `limit` int(10) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

/*Data for the table `discount` */

insert  into `discount`(`id`,`code`,`business_id`,`type`,`amount`,`percentage`,`all_services`,`all_service_extras`,`valid_from`,`valid_to`,`require_payment_upfront`,`used`,`limit`,`created_by`,`created_on`,`active`,`deleted`) values (6,'ccd',1,'','1111.00','0.00',1,1,'2019-05-03 09:50:00','2019-05-07 09:50:00',1,3,3,NULL,'2019-05-03 09:56:34',1,0),(9,'55555',1,'','0.00','10.00',1,1,'2019-05-05 06:08:00','2019-05-06 06:08:00',1,0,2,NULL,'2019-05-05 06:08:36',1,0);

/*Table structure for table `discount_card` */

DROP TABLE IF EXISTS `discount_card`;

CREATE TABLE `discount_card` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `business_id` int(10) DEFAULT NULL,
  `number_of_services` int(10) DEFAULT NULL,
  `price` decimal(4,2) DEFAULT NULL,
  `service_id` int(10) DEFAULT NULL,
  `service_extra_id` int(10) DEFAULT NULL,
  `service_type` enum('0','1') DEFAULT NULL COMMENT '0-service,1-service extra',
  `created_on` datetime DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '0',
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

/*Data for the table `discount_card` */

insert  into `discount_card`(`id`,`business_id`,`number_of_services`,`price`,`service_id`,`service_extra_id`,`service_type`,`created_on`,`created_by`,`active`,`deleted`) values (12,1,4,'33.30',0,13,'1',NULL,NULL,1,0),(13,1,12,'45.70',0,17,'1',NULL,NULL,1,1),(16,1,6,'12.00',20,0,'0',NULL,NULL,1,0);

/*Table structure for table `discount_card_user_relation` */

DROP TABLE IF EXISTS `discount_card_user_relation`;

CREATE TABLE `discount_card_user_relation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `discount_card_id` int(10) DEFAULT NULL,
  `used` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `created_on` datetime DEFAULT '0000-00-00 00:00:00',
  `created_by` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

/*Data for the table `discount_card_user_relation` */

/*Table structure for table `discount_service_extras_relation` */

DROP TABLE IF EXISTS `discount_service_extras_relation`;

CREATE TABLE `discount_service_extras_relation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `service_extra_id` int(10) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Data for the table `discount_service_extras_relation` */

/*Table structure for table `discount_services_relation` */

DROP TABLE IF EXISTS `discount_services_relation`;

CREATE TABLE `discount_services_relation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `service_id` int(10) DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

/*Data for the table `discount_services_relation` */

/*Table structure for table `employee_service_relations` */

DROP TABLE IF EXISTS `employee_service_relations`;

CREATE TABLE `employee_service_relations` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `company_id` int(10) DEFAULT NULL,
  `employee_id` int(10) DEFAULT NULL,
  `service_id` int(10) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

/*Data for the table `employee_service_relations` */

insert  into `employee_service_relations`(`id`,`company_id`,`employee_id`,`service_id`,`deleted`) values (27,1,10,20,1),(28,1,11,20,0),(29,1,12,28,1),(30,1,10,28,0),(31,1,11,29,0),(32,1,12,20,0),(33,1,11,28,1);

/*Table structure for table `extra_service_relations` */

DROP TABLE IF EXISTS `extra_service_relations`;

CREATE TABLE `extra_service_relations` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `service_id` int(10) DEFAULT NULL,
  `extra_id` int(10) DEFAULT NULL,
  `company_id` int(10) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

/*Data for the table `extra_service_relations` */

insert  into `extra_service_relations`(`id`,`service_id`,`extra_id`,`company_id`,`deleted`) values (18,20,13,1,0),(19,20,17,1,0),(20,20,18,1,0),(21,28,18,1,0),(22,28,13,1,0),(23,28,17,1,1),(24,29,13,1,0);

/*Table structure for table `fd_shape` */

DROP TABLE IF EXISTS `fd_shape`;

CREATE TABLE `fd_shape` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `shape_type` varchar(100) NOT NULL DEFAULT 'polygon',
  `points` varchar(500) NOT NULL,
  `preview` varchar(500) NOT NULL,
  `default_setting` varchar(500) NOT NULL,
  `base_price` double NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1001 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

/*Data for the table `fd_shape` */

insert  into `fd_shape`(`id`,`name`,`shape_type`,`points`,`preview`,`default_setting`,`base_price`) values (1,'Triangle','polygon','[200,200,400,200,300,26.7949]','triangle.png','',10),(2,'Rectangle','rectangle','','rectangle.png','{\"x\":200,\"y\":200,\"width\":200,\"height\":200,\"strokeWidth\":2,\"stroke\":\"black\"}',20),(3,'Round Rectangle','roundrect','','round_rect.png','{\"x\":200,\"y\":200,\"width\":200,\"height\":200,\"cornerRadius\":50,\"strokeWidth\":2,\"stroke\":\"black\"}',20),(4,'Pentagon','polygon','[125.47,10,10,210,125.47,410,356.4102,410,471.8802,210,356.4102,10]','pentagon.png','',30),(5,'Hexagon','polygon','[223,115,115,223,115,377,223,485,377,485,485,377,485,223,377,115]','hexagon.png','',30),(6,'Circle','circle','','circle.png','{\"x\":100,\"y\":100,\"radius\":100,\"stroke\":\"black\",\"strokeWidth\":2}',15),(7,'Oval','oval','','oval.png','{\"x\":100,\"y\":100,\"radiusX\":100,\"radiusY\":50,\"gap\":10,\"stroke\":\"black\",\"strokeWidth\":2}',15),(8,'Text','text','','text.png','{\"x\": 150, \"y\": 150, \"text\": \"TEXT HERE\", \"fontSize\": 20, \"fontFamily\": \"Calibri\", \"fill\":\"green\"}',0),(1000,'Draw shape','polygon','[]','draw.png','',20);

/*Table structure for table `gift_card` */

DROP TABLE IF EXISTS `gift_card`;

CREATE TABLE `gift_card` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `code` varchar(100) DEFAULT NULL,
  `business_id` int(10) DEFAULT NULL,
  `start_balance` decimal(4,2) DEFAULT NULL,
  `available_balance` decimal(4,2) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `created_on` timestamp NULL DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `gift_card` */

insert  into `gift_card`(`id`,`code`,`business_id`,`start_balance`,`available_balance`,`created_by`,`created_on`,`active`,`deleted`) values (1,'4455ggg',1,'33.00','33.00',NULL,NULL,1,0),(2,'g2341',1,'44.00','44.00',NULL,NULL,1,0);

/*Table structure for table `holiday` */

DROP TABLE IF EXISTS `holiday`;

CREATE TABLE `holiday` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `day` varchar(200) DEFAULT NULL,
  `date` varchar(15) DEFAULT NULL,
  `holiday_native_name` varchar(200) DEFAULT NULL,
  `holiday_english_name` varchar(200) DEFAULT NULL,
  `national_holiday` tinyint(1) DEFAULT '0',
  `non_public_holiday` tinyint(1) DEFAULT '0',
  `government_holiday` tinyint(1) DEFAULT '0',
  `country_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_holiday` (`country_id`),
  CONSTRAINT `FK_holiday` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/*Data for the table `holiday` */

insert  into `holiday`(`id`,`day`,`date`,`holiday_native_name`,`holiday_english_name`,`national_holiday`,`non_public_holiday`,`government_holiday`,`country_id`) values (1,'Tuesday','January 01','New Year\'s Day','New Year\'s Day',0,0,0,1),(2,'Thursday','April 18','Manudy Thursday','Thursday',0,0,0,1),(3,'Friday','April 19','Good Friday','Good Friday',0,0,0,1),(4,'Thursday','April 22','Easter Monday','Easter Monday',0,0,0,1),(5,'Wednsday','May 01','May Day','May Day',0,0,0,1);

/*Table structure for table `holiday_work` */

DROP TABLE IF EXISTS `holiday_work`;

CREATE TABLE `holiday_work` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `holiday_id` int(10) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `is_work` tinyint(1) DEFAULT '0',
  `company_id` int(10) DEFAULT NULL,
  `employee_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

/*Data for the table `holiday_work` */

insert  into `holiday_work`(`id`,`holiday_id`,`date`,`is_work`,`company_id`,`employee_id`) values (1,5,'May 01',1,1,NULL),(2,2,'April 18',0,1,NULL),(4,4,'April 22',0,1,NULL),(5,3,'April 19',1,1,NULL),(6,1,'January 01',1,1,NULL);

/*Table structure for table `images` */

DROP TABLE IF EXISTS `images`;

CREATE TABLE `images` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `company_id` int(10) DEFAULT NULL,
  `image_1` text,
  `image_2` text,
  `image_3` text,
  `image_4` text,
  `image_5` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `images` */

/*Table structure for table `language` */

DROP TABLE IF EXISTS `language`;

CREATE TABLE `language` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `brief` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `language` */

insert  into `language`(`id`,`name`,`brief`) values (1,'English','en'),(2,'Danish','da');

/*Table structure for table `notifications` */

DROP TABLE IF EXISTS `notifications`;

CREATE TABLE `notifications` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `notify_type` enum('SMS','EMAIL') DEFAULT 'SMS',
  `to_user` varchar(100) DEFAULT NULL,
  `content` text,
  `role_type` varchar(10) DEFAULT NULL COMMENT '0-customer,1-business',
  `status` varchar(10) DEFAULT NULL COMMENT '1-success,0-failed',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;

/*Data for the table `notifications` */

insert  into `notifications`(`id`,`notify_type`,`to_user`,`content`,`role_type`,`status`,`created_at`) values (8,'SMS','+4525474146','Din bookingkode er: mZcR7c','customer','success','2019-04-14 02:07:47'),(9,'SMS','+4512345677','Your booking was accepted.','comapny','success','2019-04-14 03:47:25'),(10,'SMS','+8112345678','Your booking was accepted.','comapny','success','2019-04-14 03:48:57'),(11,'EMAIL','nikorelpan1090@gmail.com','Please verify your email by clicking on the following link :\n\n\n http://localhost:3000/company/#/email_verify/4d0fb6184e9e41e53c3f2c9282b8a4731208899d8579d35716153f63ad48d34ed7c31412e3beefc27cd2275907d637b96a6c02809fe25f9811a9a1a75f30708bb9bcfb97b2afe75af5634cb44cc3dee1f4f9e233864ccce2266af8ff88196409a45c300c','comapny','faild','2019-04-17 06:01:40'),(12,'EMAIL','nikorelpan1090@gmail.com','Please verify your email by clicking on the following link :\n\n\n http://localhost:3000/company/#/email_verify/f347dc2f3a52c5cbb004eb98db33e340e1d601154e0e643ba6511e4776d96962dd0b5aa2904ccfdfce08e5c7aaba1c7c026cb227b207e9b88c00dbcedd15a0478c80d7b327c65d737dcedc686d9901f37b21d25fc4d25657e3c791e03cb7f74b604bac7d','comapny','faild','2019-04-17 06:03:16'),(13,'EMAIL','nikorelpan1090@gmail.com','Please verify your email by clicking on the following link :\n\n\n http://localhost:3000/company/#/email_verify/bb202407b807a7a187a403b79e971e17e0b4080b6e6c90daf6cd34acf845974a641efb3e8276ec82e7de6c136a0e45312e41bbe4dfdaf32ac0b252a7056bfd38c1493d2c8aced42e57fda5e07a7abc3238e05dd91883b9d0e013582ef2687b1a78ee0d5f','comapny','faild','2019-04-17 06:24:14'),(14,'EMAIL','nikorelpan1090@gmail.com','Please verify your email by clicking on the following link :\n\n\n http://localhost:3000/company/#/email_verify/f6891eec11200e827e149642e258603e24901314d9adcb77958cebbf6b478e48485360590f958ba4af160fc27a8aa0e324f97e843ef146acadfb4fc2dabae0164f2eeb9d03e37e18c8d0be5f8bd8ff1d40e709d1317bb47dcd428a9e2f784ce86b6f1171','comapny','faild','2019-04-17 06:25:06'),(15,'SMS','+4525468741','Din bookingkode er: bt4LU6','comapny','success','2019-04-17 06:25:08'),(16,'EMAIL','nikorelpan1090@gmail.com','Please verify your email by clicking on the following link :\n\n\n http://localhost:3000/company/#/email_verify/32eceec806d5263eafd07292ce9cc36fb9df93a6804528d83b9d172e32e6c6a9b67194a983806515fd25c4ed4905da0957cbed962c0df9325c77fcfa9985dc2119b84e928f83716ececc1fa4fb6afbca35b2f4392a3e0470c5b26259cf9cba3c963e866a','comapny','faild','2019-04-17 06:27:52'),(17,'SMS','+4525412365','Din bookingkode er: 8juk0H','comapny','success','2019-04-17 06:27:55'),(18,'EMAIL','nikorelpan1090@gmail.com','Please verify your email by clicking on the following link :\n\n\n http://localhost:3000/company/#/email_verify/bee4384d05789faac7639b58477adf5b6f01a631526f88540b03cf107b4daad561c4af0875aba229a5e0bc135239ec87ea4312b983418a4fa4b2096a6e2b621839191672c67b28abc023402d9185d9d04ad6ccd5be322f4308dc05c9095ef5958c592dfc','comapny','faild','2019-04-17 06:36:33'),(19,'SMS','+4525462357','Din bookingkode er: MtGX8C','comapny','success','2019-04-17 06:36:36'),(20,'EMAIL','nikorelpan1090@gmail.com','Please verify your email by clicking on the following link :\n\n\n http://localhost:3000/company/#/email_verify/e2d97d8f43bfb16b9fd2d2d08f6ba2bc14dc06f107ce219f485c0e0afdf2f77becc7f0d2305caeb2b21ab017ce670186065e9da09b95a49a7ce8080b3c0a13dfa96338e3cbfd1a55798d17df3d7679fe15d9e9ca4ffaa4645b41f4031301d1e6a0f1ab13','comapny','faild','2019-04-17 22:37:25'),(21,'EMAIL','nikorelpan1090@gmail.com','Please verify your email by clicking on the following link :\n\n\n http://localhost:3000/company/#/email_verify/c7821f83e4adfaa7b8ab49529c27e846ae73b545f1a7b988e326d695f488f0a887475e2eacb60cac02eb7679dc000bc89cc445bb918126befe67e237cd424e10d075f7a85ffd0bd920b0e1cc96492b0567966728ca4a3d6b7232fe642cb85215e0fce77c','comapny','faild','2019-04-17 22:58:59'),(22,'EMAIL','nikorelpan1090@gmail.com','Please verify your email by clicking on the following link :\n\n\n http://localhost:3000/company/#/email_verify/c0c6c39021e899380e90ff8e5bdf5dce515b148a1f74341e972e14cc4a4e3da9e0efa05e6dac14965293449680b15768c44c3a1369ca7f9a55b27558f51091e2cce0aa531ff55a1118e36929a9a60740ab506070a96022abb220fa240f91f8224bb3ed38','comapny','success','2019-04-17 23:01:23'),(23,'EMAIL','nikorelpan1090@gmail.com','Please verify your email by clicking on the following link :\n\n\n http://localhost:3000/company/#/email_verify/e83c299c4ba8b3bf45c513eb559f8a68f28544aab101f6c8d3e065014335ed9ca8f5b36d93671d8e0b52226e9e81b2642e17d944fc43866c0410af617f6f1609ec5765d788732323b3360b7abded7a998d843debc76b4cee09e3a5a2c40cc20ce1715d5e','comapny','success','2019-04-17 23:02:03'),(24,'EMAIL','nikorelpan1090@gmail.com','Please verify your email by clicking on the following link :\n\n\n http://localhost:3000/company/#/email_verify/577eab3937b612902c3145ea3f7a7c9c39fdcdfb7c6ed5e8a5ffe99476655c86e389e6042bb08af2d2c89d0713b22ecc173cf11cbea5a95e1037a4d877b9c756ddfb6403f31ddb75cbf0e8014310f2a1db92fd53b0c450877046199aeb32f6112c38f2e0','comapny','success','2019-04-17 23:02:41'),(25,'EMAIL','nikorelpan1090@gmail.com','Please verify your email by clicking on the following link :\n\n\n http://localhost:3000/company/#/email_verify/bea391447bf8cf375235f81f80ddf4441179f445a8b359d01235dcae7189432004ca7d8e0d034cf185add579b7334408ece8aa9d8cd61d07cf8c01fa03665d9c73807935259774b9ae531a9e90674ebc735be8119bacf9546e0913f5d5278bd2072db6d3','comapny','faild','2019-04-17 23:08:12'),(26,'EMAIL','nikorelpan1090@gmail.com','Please verify your email by clicking on the following link :\n\n\n http://localhost:3000/company/#/email_verify/27ba7ab5e418c3125ab57bada009a3893d47144f0c6f44ad6e8c6e8ac69d43389f393ee85cdc6570340343a662e68be4e4c60908cc22677b9dd809a78292278ed8ed930fd9d0f7f3ae7d69ae663247e8465c71612ff689b2c2aee689b5194ae0332eb907','comapny','faild','2019-04-17 23:09:15'),(27,'SMS','+4525155433','Din bookingkode er: ApJJtI','comapny','success','2019-04-17 23:09:17'),(28,'EMAIL','nikorelpan1090@gmail.com','Please verify your email by clicking on the following link :\n\n\n http://localhost:3000/company/#/email_verify/3365e150001bba6d72010aa57613a2c2e02cc8d2da76694b16c7187607dfd97680f71c3be2cd6491e255ee4450755718aa6f612486ec69adfdbdec95b12652548dc96bf9b0c267978047e1e39f64cab886ac4afd72a9e82725eff9834c23be32f871a1f6','comapny','faild','2019-04-17 23:26:15'),(29,'SMS','+4524563467','Din bookingkode er: 1r2fhO','comapny','success','2019-04-17 23:26:18'),(30,'EMAIL','nikorelpan1090@gmail.com','Please verify your email by clicking on the following link :\n\n\n http://localhost:3000/company/#/email_verify/cbf0bd4c9b5d3e9c9753158764503cfadba8a309fecacacad6bd3cfe43f1c5954834615fd7ce6574f162d7f91ef7ec9c2319ed80616740f8696e7854a779ae056100eb7f6e41ff173030f59965359d1c0b7fecd0f0a3ce372c33cffdcf06b8a50d60804a','comapny','faild','2019-04-18 00:18:04'),(31,'SMS','+4525474788','Din bookingkode er: jbdFao','comapny','success','2019-04-18 00:18:14'),(32,'EMAIL','nikorelpan1090@gmail.com','Please verify your email by clicking on the following link :\n\n\n http://localhost:3000/company/#/email_verify/70e6b6976415304cb45f915031ffea9ef615c04a5828975e77ab82f208d4cc481c01e5d1c7f74d5fcb5f74903840bef1a5dd0f5190c21bb8b13559bf0eeeee3bd1edcce88de06ce7a440075b30cae9ad71fcbcf33e10d4e8e8cc9da4fac331ba07f521fc','comapny','faild','2019-04-18 00:23:47'),(33,'SMS','+4525433455','Din bookingkode er: sa6Nj6','comapny','success','2019-04-18 00:23:50'),(34,'EMAIL','nikorelpan1090@gmail.com','Please verify your email by clicking on the following link :\n\n\n http://localhost:3000/company/#/email_verify/7d543efe6c1394a88d718b683111b9c4130b7dcbce98380df238d58176a840c58146d0f58f09646778db7ee6909c3ba0371fbed5b9caa3abac261460bccc65952666af9b2c97abeaaa52ebfc6586d743fb9a4d44759dc2596d5dd0c926f09f3d6acea88e','comapny','faild','2019-04-18 00:30:19'),(35,'SMS','+4525344556','Din bookingkode er: l1gxbL','comapny','success','2019-04-18 00:30:23'),(36,'EMAIL','nikorelpan1090@gmail.com','Please verify your email by clicking on the following link :\n\n\n http://localhost:3000/company/#/email_verify/d569a5518c1bab197904d9a6f2059a67bddc283eb0872db1d883fcc0949db4404a151e6e1d9e43f31a261961f2a24114875b0afff248c6b20a6808e4473c332eaff4d1c0e553a89b4f280d624f0685925213e60a0804d369e131bc4a4da1ac52e75b490f','comapny','faild','2019-04-18 00:35:04'),(37,'SMS','+4525494842','Din bookingkode er: 6vLTGj','comapny','success','2019-04-18 00:35:07'),(38,'SMS','+4512345677','Your booking was accepted.','comapny','success','2019-04-26 00:07:40'),(39,'SMS','+4512345677','Your booking was accepted.','comapny','success','2019-04-26 13:16:00'),(40,'SMS','+4512345677','Your booking was accepted.','comapny','success','2019-04-26 22:03:58'),(41,'SMS','+4512345677','Your booking was accepted.','comapny','success','2019-04-26 22:18:22'),(42,'SMS','+4512345677','Your booking was accepted.','comapny','success','2019-04-26 22:23:39'),(43,'SMS','+4512345677','Your booking was accepted.','comapny','success','2019-04-26 22:33:33'),(44,'SMS','+4512345677','Your booking was accepted.','comapny','success','2019-04-26 22:56:30'),(45,'SMS','+4512345677','Your booking was accepted.','comapny','success','2019-04-26 23:15:00'),(46,'SMS','+4512345677','Your booking was accepted.','comapny','success','2019-04-26 23:16:31');

/*Table structure for table `payment` */

DROP TABLE IF EXISTS `payment`;

CREATE TABLE `payment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned NOT NULL,
  `customer_id` int(10) unsigned NOT NULL,
  `booking_id` int(10) unsigned DEFAULT NULL,
  `payment_method_id` varchar(64) NOT NULL,
  `txid` varchar(256) DEFAULT NULL,
  `payment_amount` decimal(9,2) DEFAULT NULL,
  `total_amount` decimal(9,2) NOT NULL,
  `cash_amount` decimal(9,2) DEFAULT NULL,
  `status` varchar(15) DEFAULT 'COMPLETED',
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `payment_type` tinyint(1) DEFAULT '1' COMMENT '1:upfront,0-after',
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`),
  KEY `customer_id` (`customer_id`),
  KEY `booking_id` (`booking_id`),
  CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`),
  CONSTRAINT `payment_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`),
  CONSTRAINT `payment_ibfk_3` FOREIGN KEY (`booking_id`) REFERENCES `booking` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `payment` */

/*Table structure for table `payment_method` */

DROP TABLE IF EXISTS `payment_method`;

CREATE TABLE `payment_method` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `is_online` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `payment_method` */

insert  into `payment_method`(`id`,`name`,`is_online`) values (1,'PayPal',1),(2,'MasterCard',0),(3,'VISA',0),(4,'Dankort',0);

/*Table structure for table `payment_settings` */

DROP TABLE IF EXISTS `payment_settings`;

CREATE TABLE `payment_settings` (
  `id` tinyint(10) NOT NULL AUTO_INCREMENT,
  `company_id` tinyint(10) NOT NULL,
  `paypal_key` varchar(300) DEFAULT NULL,
  `strip` varchar(300) DEFAULT NULL,
  `coin_payment` varchar(300) DEFAULT NULL,
  `mastercard` tinyint(1) DEFAULT '0',
  `visa` tinyint(1) DEFAULT '0',
  `dankort` tinyint(1) DEFAULT '0',
  `cash` tinyint(1) DEFAULT '0',
  `paypal` tinyint(1) DEFAULT '0',
  `american_express` tinyint(1) DEFAULT '0',
  `maestro` tinyint(1) DEFAULT '0',
  `bitcoin` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `payment_settings` */

insert  into `payment_settings`(`id`,`company_id`,`paypal_key`,`strip`,`coin_payment`,`mastercard`,`visa`,`dankort`,`cash`,`paypal`,`american_express`,`maestro`,`bitcoin`) values (2,1,'eeee344345345435','3344','5566',0,0,1,1,1,1,0,1);

/*Table structure for table `product` */

DROP TABLE IF EXISTS `product`;

CREATE TABLE `product` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `company_id` int(10) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `quantity` int(10) NOT NULL,
  `category` int(10) NOT NULL,
  `retail_price` decimal(6,2) DEFAULT NULL,
  `whole_sale_price` decimal(6,2) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_product` (`category`),
  CONSTRAINT `FK_product` FOREIGN KEY (`category`) REFERENCES `product_categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Data for the table `product` */

insert  into `product`(`id`,`company_id`,`name`,`quantity`,`category`,`retail_price`,`whole_sale_price`,`deleted`) values (1,1,'product1',22,3,'20.00','21.00',0),(3,1,'product3',11,3,'22.00','33.00',0);

/*Table structure for table `product_categories` */

DROP TABLE IF EXISTS `product_categories`;

CREATE TABLE `product_categories` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `company_id` int(10) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

/*Data for the table `product_categories` */

insert  into `product_categories`(`id`,`name`,`company_id`,`deleted`) values (3,'product category 2',1,0),(7,'product category 5',1,0),(8,'product category 7',1,1),(10,'category product test',1,1);

/*Table structure for table `products` */

DROP TABLE IF EXISTS `products`;

CREATE TABLE `products` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `company_id` int(10) NOT NULL,
  `item_number` int(10) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `quantity` varchar(100) NOT NULL,
  `category` int(10) DEFAULT NULL,
  `retail_price` decimal(9,2) DEFAULT NULL,
  `whole_sale_price` decimal(9,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_products` (`category`),
  CONSTRAINT `FK_products` FOREIGN KEY (`category`) REFERENCES `product_categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

/*Data for the table `products` */

insert  into `products`(`id`,`company_id`,`item_number`,`item_name`,`quantity`,`category`,`retail_price`,`whole_sale_price`) values (7,1,4,'product1','2',3,'3.00','44.00'),(8,1,5,'product cutter','1',7,'34.00','32.00'),(9,1,4,'product1','2',3,'3.00','44.00');

/*Table structure for table `role` */

DROP TABLE IF EXISTS `role`;

CREATE TABLE `role` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `role` */

insert  into `role`(`id`,`name`) values (1,'Administrator'),(2,'Accountant'),(3,'Employee'),(4,'Freelancer');

/*Table structure for table `service` */

DROP TABLE IF EXISTS `service`;

CREATE TABLE `service` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `service_category_id` int(10) unsigned DEFAULT NULL,
  `company_id` int(10) unsigned NOT NULL,
  `name` varchar(64) NOT NULL,
  `description` text,
  `price` decimal(9,2) NOT NULL,
  `duration` int(10) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `vary` tinyint(1) DEFAULT '0',
  `weight` int(5) DEFAULT '0',
  `deleted` tinyint(1) DEFAULT '0' COMMENT 'delete=1, no delte=0',
  PRIMARY KEY (`id`),
  KEY `service_category_id` (`service_category_id`),
  KEY `company_id` (`company_id`),
  CONSTRAINT `service_ibfk_1` FOREIGN KEY (`service_category_id`) REFERENCES `service_category` (`id`),
  CONSTRAINT `service_ibfk_2` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

/*Data for the table `service` */

insert  into `service`(`id`,`service_category_id`,`company_id`,`name`,`description`,`price`,`duration`,`gender`,`vary`,`weight`,`deleted`) values (20,25,1,'hair service 1','hair cutter descriptoin','12.00',35,'Man',1,100,0),(28,25,1,'service 2','description 2','1.50',45,'Man',0,70,0),(29,25,1,'serivce3','desc- service2','22.00',15,'Man',0,50,0);

/*Table structure for table `service_category` */

DROP TABLE IF EXISTS `service_category`;

CREATE TABLE `service_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned NOT NULL,
  `name` varchar(64) NOT NULL,
  `default_service_category` tinyint(1) DEFAULT '0',
  `description` text,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`),
  CONSTRAINT `service_category_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

/*Data for the table `service_category` */

insert  into `service_category`(`id`,`company_id`,`name`,`default_service_category`,`description`,`deleted`) values (25,1,'Vipper og Bryn',1,'rorem ipsum for viper description\nvery good description',0),(26,1,'Hår',0,'hair lorem description',0),(32,1,'category name 2test',0,'ddddd',1);

/*Table structure for table `service_extra` */

DROP TABLE IF EXISTS `service_extra`;

CREATE TABLE `service_extra` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned NOT NULL,
  `service_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(64) NOT NULL,
  `description` text,
  `price` decimal(9,2) NOT NULL,
  `duration` int(5) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `vary` tinyint(1) DEFAULT '0',
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `company_id` (`company_id`),
  CONSTRAINT `service_extra_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `service` (`id`),
  CONSTRAINT `service_extra_ibfk_2` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

/*Data for the table `service_extra` */

insert  into `service_extra`(`id`,`company_id`,`service_id`,`name`,`description`,`price`,`duration`,`gender`,`vary`,`deleted`) values (13,1,20,'addon1 of hair','addon1 description of hair','34.10',15,'Man',1,0),(17,1,20,'addon2','description 333','1.50',34,'Man',0,0),(18,1,20,'test33','eee','24.00',33,'Man',1,0),(19,1,NULL,'extra test5511','desc551','2.10',541,'',1,1),(20,1,NULL,'sdfsd','ddd','44.00',333,'Man',1,1);

/*Table structure for table `service_extra_version` */

DROP TABLE IF EXISTS `service_extra_version`;

CREATE TABLE `service_extra_version` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned NOT NULL,
  `service_extra_id` int(10) DEFAULT NULL,
  `service_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(64) NOT NULL,
  `description` text,
  `price` decimal(9,2) NOT NULL,
  `duration` decimal(4,2) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `vary` tinyint(1) DEFAULT '0',
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `service_id` (`service_id`),
  KEY `company_id` (`company_id`),
  CONSTRAINT `service_extra_version_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `service` (`id`),
  CONSTRAINT `service_extra_version_ibfk_2` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `service_extra_version` */

/*Table structure for table `service_version` */

DROP TABLE IF EXISTS `service_version`;

CREATE TABLE `service_version` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `service_category_id` int(10) unsigned DEFAULT NULL,
  `company_id` int(10) unsigned NOT NULL,
  `service_id` int(10) DEFAULT NULL,
  `name` varchar(64) NOT NULL,
  `description` text,
  `price` decimal(9,2) NOT NULL,
  `duration` decimal(4,2) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `vary` tinyint(1) DEFAULT '0',
  `weight` int(5) DEFAULT '0',
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `service_category_id` (`service_category_id`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `service_version` */

/*Table structure for table `terms` */

DROP TABLE IF EXISTS `terms`;

CREATE TABLE `terms` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `company_id` int(10) DEFAULT NULL,
  `language_id` int(5) DEFAULT NULL COMMENT '1-en,2-dan',
  `terms` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/*Data for the table `terms` */

insert  into `terms`(`id`,`company_id`,`language_id`,`terms`) values (3,1,1,'It is the terms of service for the English \nHos Overgaard er kvalitet, personlig rådgivning og økologi i højsædet. Salonen forbinder velvære og skønhed i en afslappet atmosfære.\n\nIndehaveren er udlært hos Palma salon og spa i København K og efteruddannet ved blandt andet Sassoon Academy i London.'),(5,1,2,'It is the terms of service for the English \nHos Overgaard er kvalitet, personlig rådgivning og økologi i højsædet. Salonen forbinder velvære og skønhed i en afslappet atmosfære.\ndanmark language');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `phone` varchar(64) DEFAULT NULL,
  `phone_veryfied` tinyint(1) DEFAULT '0',
  `email_veryfied` tinyint(1) DEFAULT '0',
  `first_name` varchar(64) DEFAULT NULL,
  `last_name` varchar(64) DEFAULT NULL,
  `verify_code` varchar(10) DEFAULT NULL,
  `email_token` varchar(400) DEFAULT NULL,
  `company_id` int(10) DEFAULT NULL,
  `role_id` int(10) DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  `profile_picture_path` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

/*Data for the table `user` */

insert  into `user`(`id`,`email`,`password`,`phone`,`phone_veryfied`,`email_veryfied`,`first_name`,`last_name`,`verify_code`,`email_token`,`company_id`,`role_id`,`deleted`,`profile_picture_path`) values (3,'nikorel@gmail.com','$2a$10$9iAkPNFswW8Dlk1VsAQ5V.mYyQ5WANzcGVMRoGYgsi3vEBTw7T7Hi','25462357',1,1,'fff11','ssss','MtGX8C','bee4384d05789faac7639b58477adf5b6f01a631526f88540b',1,1,0,NULL),(9,'nikorelpan1090@gmail.com','$2a$10$Y1NWArsUbdtjVn6S6Al7kencZGILw59464k/ZWPTXqMuVJYjDj9zu','25494842',1,1,NULL,NULL,'6vLTGj','d569a5518c1bab197904d9a6f2059a67bddc283eb0872db1d883fcc0949db4404a151e6e1d9e43f31a261961f2a24114875b0afff248c6b20a6808e4473c332eaff4d1c0e553a89b4f280d624f0685925213e60a0804d369e131bc4a4da1ac52e75b490f',41,1,0,NULL),(10,NULL,'$2a$10$o3gvseGCq/2EfsQKGzI2w.zhgRa4.qB.a/c5yyyV7x56qNRPPsvxe',NULL,0,0,'fist name em-1','last name em-1',NULL,NULL,1,3,0,'ddeerererererer-1'),(11,'','$2a$10$2WI4S8gEDvDORfhApMWs8.6Km6/o5punv3eNayXOPL.fhB2mKiFKK',NULL,0,0,'seregay','ban',NULL,NULL,1,3,0,'http://test.com'),(12,NULL,'$2a$10$/ID8GgAC25u3cibXpgIPRePrFPmKtuulvMMYJVo9Cj830TBYRGcQe',NULL,0,0,'david','abandon',NULL,NULL,1,3,0,'http://david.com'),(13,NULL,'$2a$10$u9EWqG5JEkKVZte9YGkEU.vLpUMQ0VWIp4.ecT0wgZFdOQgNxDXce',NULL,0,0,'sasha','andrew',NULL,NULL,1,3,1,'http://sasha.com'),(15,'freelancer@gmail.com','$2a$10$fRNrxUd8fsr5oS2L3WPNbOJvclC7VN/PBMEW/S/htDWIurPuqAmwy',NULL,0,0,'ttt','sss',NULL,NULL,1,4,0,'ggg');

/*Table structure for table `vacation` */

DROP TABLE IF EXISTS `vacation`;

CREATE TABLE `vacation` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `company_id` int(10) NOT NULL,
  `employee_id` int(10) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `comment` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

/*Data for the table `vacation` */

insert  into `vacation`(`id`,`company_id`,`employee_id`,`from_date`,`to_date`,`comment`) values (20,1,10,'2019-04-19','2019-04-26','ffdfgdfg22');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
