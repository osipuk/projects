import React from 'react';

// @material-ui/core components
import withStyles from '@material-ui/core/styles/withStyles';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import Success from '@material-ui/icons/CheckCircle';

// @material-ui/icons
import { Person, People } from '@material-ui/icons';

// localization
import withLocalization from 'common/contexts/LocalizationContext';
import withNotifications from 'common/contexts/NotificationsContext';
import withAuth from 'common/contexts/AuthContext';
// core components
import Button from "@material-ui/core/Button";
import Icon from '@material-ui/core/Icon';
import headerLinksStyle from '../../assets/jss/components/headerLinksStyle';

const HeaderLinks = withLocalization(({ localization, ...props }) => {
  const { classes,auth,notifications } = props;  
  const { localizedString } = localization;
  return (
    <List className={classes.list}>
      <ListItem className={classes.listItem}>
        <Button
          href="/company"
         
          target="_self"
          className={classes.navLink}
        >          
          {' '}
          Business
        </Button>
      </ListItem>
      <ListItem className={classes.listItem}>
       {
        !auth.isAuth && <Button
          href="/#/signup"
          
          target="_self"
          className={classes.navLink}
        >          
          {' '}
          Contact
        </Button>
       }
        
       {
        auth.isAuth && <Button
          href="/#/customer/setting"          
          target="_self"
          className={classes.navLink}
        >          
          {' '}
          Setting
        </Button>
       }

      </ListItem>
      <ListItem className={classes.listItem}>
        {
          auth.isAuth && <Button
             onClick={async () => {
              setCookie('customer_email','');
              setCookie('customer_password', '');  
              const result = await auth.logout();
              if(result.success){
              notifications.show({message: localization.localizedString('YOU_HAVE_BEEN_LOGOUT'),icon:Success,color:'info'}); 
              }
            }}
              className={classes.navLink}
            >          
              Logout
            </Button>
        }
        {
          !auth.isAuth && <Button
              href="/#/Login"
            
              target="_self"
              className={classes.navLink}
            >               
              Login
            </Button>
        }
        

      </ListItem>
      <ListItem className={classes.listItem}>
      {
          !auth.isAuth && <Button
              href="/#/signup"
            
              target="_self"
              className={classes.navLink}
              style={{color: '##f50057',}}
            >               
              Register
            </Button>
        }
      </ListItem>
    </List>
  );
});

function setCookie (cname,cvalue) {  
  var d = new Date();
  var exdays=30;
  d.setTime(d.getTime() + (exdays*24*60*60*1000));
 var expires = "expires=" + d.toGMTString();
 document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

const styles = theme => ({
  button2: {
    color: 'red !important',
    width:'300px !important',
    background:'red !important'
  },
 
});

export default withStyles(headerLinksStyle)(withNotifications(withLocalization(withAuth(HeaderLinks))));

