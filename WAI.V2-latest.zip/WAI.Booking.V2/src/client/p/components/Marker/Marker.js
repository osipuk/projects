import React from 'react';
import markerPng from "../../assets/img/pin1.png";
class Marker extends React.Component {
  constructor(props) {
    super(props); 
  } 
 
  render() { 

    return (    
          <div style={{position:'relative'}}>           
           <img style={{
             position: 'absolute',
           top: '-46px',
           left: '-15px'}} src={this.props.src}></img>            
          </div>
      
    );
  }
}

export default Marker
 

