import React from 'react';
import PropTypes from 'prop-types';
import withStyles from '@material-ui/core/styles/withStyles';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
import Typography from '@material-ui/core/Typography';
import CloseIcon from '@material-ui/icons/Close';
import Slide from '@material-ui/core/Slide';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import Grid from "@material-ui/core/Grid";
import GridList from "@material-ui/core/GridList";
import GridListTile from "@material-ui/core/GridListTile";

// core components
import fullScreenStyle from '../../assets/jss/components/fullScreen';

function Transition(props) {
  return <Slide direction="up" {...props} />;
}

class Fullscreen extends React.Component {
  constructor(props) {
    super(props);  
  }
  render() {    
    const { classes,fullScreen,imgSrc } = this.props;
    return (
      <div>
         <Dialog
          fullScreen
          open={fullScreen}
          onClose={this.props.handleClose}
          TransitionComponent={Transition}
        >
           
           <AppBar className={classes.appBar}>
            <Toolbar>              
              <Typography variant="h6" color="inherit" className={classes.flex}>               
              </Typography>             
              <IconButton className={classes.closeButton} onClick={this.props.handleClose} aria-label="Close">
                <CloseIcon  />
              </IconButton>
            </Toolbar>
          </AppBar>
          <DialogContent className={classes.container}>
           
            <Grid container justify='center'>
              <Grid item xs={12} sm={12} md={8} className={classes.tess}>
                    <div>
                      <img
                        src={imgSrc}
                        alt={"title1"}
                        className={classes.item_img}
                      />                                
                </div>
              </Grid>
            </Grid>
            
          </DialogContent>

        </Dialog>
      </div>
    );
  }
}

export default withStyles(fullScreenStyle)(Fullscreen);
