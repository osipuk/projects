import { container, title } from '../../../../common/assets/jss/material-react';
import {
  defaultFont,
  primaryColor,
  dangerColor,
  warningColor,
  successColor,
  infoColor,
  grayColor

} from "../../../../common/assets/jss/material-react.jsx";
const landingPageStyle =theme => ({
  rootMenuScrollHide: {
   // position: 'absolute',
    //top: '0',
    //left: '0',
   // right: '0',
   // bottom: '0',
    //overflowY: 'scroll',
    //webkitOverflowScrolling: 'touch',
    transition: 'left .3s ease-out, right .3s ease-out',
    paddingTop: '96px',
  },
  pageHeader: {
    minHeight: '100vh',
    height: 'auto',
    display: 'inherit',
    position: 'relative',
    margin: '0',
    padding: '0',
    border: '0',
    alignItems: 'center',
    '&:before': {
      background: 'rgba(0, 0, 0, 0.5)'
    },
    '&:before,&:after': {
      position: 'absolute',
      zIndex: '1',
      width: '100%',
      height: '100%',
      display: 'block',
      left: '0',
      top: '0',
      content: '""'
    },
    '& footer li a,& footer li a:hover,& footer li a:active': {
      color: '#FFFFFF'
    },
    '& footer': {
      position: 'absolute',
      bottom: '0',
      width: '100%',
    }
  },
  containerSignup: {
    ...container,
    zIndex: '2',
    position: 'relative',
    paddingTop: '20vh',
    color: '#FFFFFF',
    maxWidth: '600px',
  },
  container: {
    zIndex: '12',
    color: '#FFFFFF',
    marginTop:'-26px !important',
    ...container
  },
  container_1: {
    zIndex: '12',
    color: '#FFFFFF',
    marginTop:'-38px !important',
    ...container
  },
 
  title: {
    ...title,
    display: 'inline-block',
    position: 'relative',
    marginTop: '30px',
    minHeight: '32px',
    color: '#FFFFFF',
    textDecoration: 'none'
  },
  bootstrapFormLabel: {
    fontSize: 18,
    marginLeft: '3px',
  },
  subtitle: {
    fontSize: '1.313rem',
    maxWidth: '500px',
    margin: '10px auto 0'
  },
  main: {
    background: '#FFFFFF',
    position: 'relative',
    zIndex: '3'
  },
  mainRaised: {
    margin: '-60px 30px 0px',
    borderRadius: '6px',
    boxShadow:
      '0 16px 24px 2px rgba(0, 0, 0, 0.14), 0 6px 30px 5px rgba(0, 0, 0, 0.12), 0 8px 10px -5px rgba(0, 0, 0, 0.2)'
  },
  expansionPanelDisabled: {
    backgroundColor: '#fff !important',
  },
  tess: {
    border:'0.3px solid #000000 !important',

  },
  mainPicture: {
    padding: '0px !important',
   // height: '400px !important',
  },
  subPicture: {
   // height: '200px !important',
  },
  tile_1:{
	    width: '100%',
		height: '421px !important',
		padding: '0.5px',
  },
  thms: {     
     display: 'block',    
     '&:hover,&:focus': {     
      transform: 'scale(1.05) !important',
      transition: '-ms-transform 450ms cubic-bezier(0.645, 0.045, 0.355, 1) 0s, -webkit-transform 450ms cubic-bezier(0.645, 0.045, 0.355, 1) 0s, transform 450ms cubic-bezier(0.645, 0.045, 0.355, 1) 0s !important',
      zIndex:99,
      cursor:'pointer'
    },    
  },  
  item_img: {
    width:'100% !important',
    height: '100% !important',
  },
  card:{
    paddingBottom:'30px',
  },
  control: {
    //marginLeft: theme.spacing.unit * 4,
    margin: `auto`,
    maxWidth: '970px',
    //border:'1px solid red !important'
  },
  companyName: {
    margin: '0px !important',
    wordWrap: 'break-word !important',
    fontSize: '45px !important',
    fontWeight: '800 !important',
    lineHeight: '1.125em !important',
    color: '#484848 !important',
    paddingTop: '6px !important',
    paddingBottom: '6px !important',
  },
  address_1: {
    marginTop: '15px !important',
    wordWrap: 'break-word !important',
    fontSize: '15px !important',
    fontWeight: '400 !important',
    lineHeight: '1.375em !important',
    color: '#484848 !important',
    paddingLeft:'20px !important',
    marginBottom:'15px !important',
    paddingBottom: '8px',
  },
  wrap1: {
    padding:'0px !important',
  },
  profile_images: {
    fontWeight: '400 !important',
    fontSize: '0.94rem !important',
    background:
    'linear-gradient(to bottom, rgba(0,0,0,0.7) 0%, ' +
    'rgba(0,0,0,0.3) 70%, rgba(0,0,0,0) 100%)',
  },
  white_icon: {
    color: 'white',
  },
  title_2:  {
    margin: '0px !important',
    wordWrap: 'break-word !important',    
    //paddingLeft:'20px !important',
    fontSize:'1rem',
    fontWeight: '400 !important',
  },
  
  description_1: {
    marginTop:'7px !important',
    wordWrap: 'break-word !important',
    fontSize: '0.94rem !important',   
    //lineHeight: '1.375em !important',
    color: '#7a7a7a !important',
    fontWeight: '400'
   
  },
  title_21:{
    fontSize: '0.875rem !important',
    
    lineHeight: '1.375em !important',
    color: '#484848 !important',   
  },
  title_22:{
    fontWeight: '400',
    fontSize: '0.94rem !important',   
    lineHeight: '1.475em !important',
    color: '#717070 !important',   
  },
  title_22_italic:{
    fontWeight: '400',
    fontSize: '13px !important',   
    lineHeight: '1.475em !important',
    color: '#717070 !important', 
    fontStyle: 'italic',
  },
  list_2:{
    paddingLeft: '16px !important'
  },
  about_header_list: {

  },
  about_paragraph: {
    lineHeight: '1.97 !important',
  },
  PhoneLabel: {
    color: 'rgba(0, 0, 0, 0.54)',
    fontSize: '0.75rem',
    fontFamily: 'Roboto, Helvetica, Arial, sans-serif',
    lineHeight: '1',
    fontWeight: '400',
    marginBottom: '5px !important',
  },
  paymentCards:
  {
    borderRadius: '0% !important',
    marginRight: '10px',
    display: 'inline-block',
  },
  about_header_list_item: {
    paddingLeft: '0px !important',
  },
  about_header:{
    paddingLeft: '0px !important'
  },
  listitem_11:{
    paddingTop:'15px !important',
    paddingBottom:'1px !important',
    paddingLeft: '20px !important',
  },
  nav_list:{
    paddingTop:'0px !important',
    paddingBottom: '35px',
  },
  listitem_hh:{
    paddingLeft: '18px',
    marginTop:'40px !important',
    marginBottom:'0px !important' 
  },
  listitem_1:{
    paddingLeft: '20px !important',
    paddingTop:'1px !important',
    paddingBottom:'1px !important',
  },
  listitem_1_toppad: {
    paddingLeft: '20px !important',
    paddingTop:'10px !important',
    paddingBottom:'1px !important',
  },
  listitem_1_2:{
    paddingLeft: '20px !important',
    paddingTop:'21px !important',
    paddingBottom:'1px !important',
  },
  icon_4:{
    marginRight: '7px !important',
    
  },
  title_3:  {
    marginTop: '2.5px !important',
    wordWrap: 'break-word !important',
    fontSize: '0.94rem !important',
    fontWeight: '400 !important',
    lineHeight: '1.375em !important',
    color: '#000000 !important',    
    marginLeft: '6px !important',
  },
  hour_1: {
    marginTop:'10px !important',
    wordWrap: 'break-word !important',
    fontSize: '15px !important',
   
    lineHeight: '1.375em !important',
    color: '#484848 !important',
    paddingLeft:'20px !important',
  },
  hour_2: {
    wordWrap: 'break-word !important',
    fontSize: '15px !important',
    fontWeight: '400 !important',
    lineHeight: '1.375em !important',
    color: '#484848 !important',
    paddingLeft:'20px !important',
    marginBottom:'10px !important'
  },
  book_now: {
    marginTop:'30px !important',
    textAlign: 'center',
    paddingTop: '22px !important',
    
  },
  root_2: {
    paddingRight:'15px !important',
    paddingLeft:'15px !important',
  },
  button: {
    fontSize: '16px',
    textTransform: 'capitalize',
    boxShadow: '0px 1px 5px 0px rgba(0, 0, 0, 0), 0px 2px 2px 0px rgba(0, 0, 0, 0), 0px 3px 1px -2px rgba(0, 0, 0, 0)',
    '&:hover': {
      backgroundColor: '#f50057',
      color: '#FFF',
    },
  },
  button_outline: {
    margin: '0px',
    width:'100%',
    fontSize: '21px',
    fontWeight: '600 !important',
    paddingTop: '10px !important',
    paddingBottom: '10px !important'
  },
  root_3: {   
    paddingTop:'15px !important',
    paddingRight:'20px !important',
    paddingLeft:'20px !important',
  },
  grow: {
    flexGrow: '1 !important',    
    fontSize: '14px !important',
    color: '#000',   
    marginLeft: '20px',
    marginTop: '2.5px !important',
    fontWeight: '300',
  },
  root_summary: {
    minHeight: '45px !important',
    flexGrow: '1 !important',
    padding: '0px 0px 0 20px !important',
    backgroundColor:'#e5e5e5',
    boxShadow: '0 4px 20px 0px rgba(255, 255, 255, 0), 0 7px 10px -5px rgb(229, 229, 229)',
  },
  step_c: {
    paddingRight: '15px !important',
    color:'#FFF !important'
  },
  summary_2: {
    height: '37px',
    flexGrow: 1,  
    borderBottom: '1px solid #f00',
  },
  action_1: {
    display: 'block !important',
    padding: '2px 8px 0px 8px !important;',
  },
  action_2: {    
    padding: '2px 8px 0px 8px !important;',
  },
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 160,   
    width: '220px',
  },
  formControlSelectInput: {
    borderRadius: 4,
    position: 'relative',
    backgroundColor: theme.palette.background.paper,
    border: '1px solid #ced4da',
    fontSize: 16,
    width: 'auto',
    padding: '10px 26px 10px 12px',
    transition: theme.transitions.create(['border-color', 'box-shadow']),
    // Use the system font instead of the default Roboto font.
    fontFamily: [
      '-apple-system',
      'BlinkMacSystemFont',
      '"Segoe UI"',
      'Roboto',
      '"Helvetica Neue"',
      'Arial',
      'sans-serif',
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"',
    ].join(','),
    '&:focus': {
      borderRadius: 4,
      borderColor: '#80bdff',
      boxShadow: '0 0 0 0.2rem rgba(0,123,255,.25)',
    },
  },
  detail_2:{
    marginTop: '15px',
    flexGrow:'1 !important',
    flexBasis:'100% !important',
  },
  detail_1: {
    display:'block !important',
    paddingTop:'0px',
    
  },
  detail_3:{
    margin:'auto',    
  },
  detail_4:{
    marginTop:'5px !important'
  },
  detail_5:{
    margin:'auto',
    textAlign:'right !important'
  },
  detail_6: {
    flexGrow:1
  },
  chips: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  chip: {
    margin: theme.spacing.unit / 4,
  },
  noLabel: {
    marginTop: theme.spacing.unit * 3,
  },
  hr_cs1:{
    marginBottom:'16px !important'
  },
  addon_1:{
    marginBottom:'16px !important',
   // marginTop: '10px'
  },
  addon_2:{
    margin:'auto',
    textAlign:'right !important',    
  },
  addon_4:{
    marginTop:'4px !important'
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 160,
    minWidth:100,
    maxWidth:160,
  },
  ardon_3:{
    margin:'auto',
    textAlign:'center !important'
  },
  confirm_1:{
    margin:'auto',
    textAlign:'center !important'
  },
  icon_1:{
    fontSize:19
  },
  requestBookingBtn: {
    fontSize:16,
    fontWeight: '600',
    backgroundColor: '#f50057',
    paddingTop: '10px',
    '&:hover,&:focus': {
      backgroundColor: '#c51162 !important',
    },
  },
  cancelBtn: {
    backgroundColor: '#ff6000', 
    marginLeft: '15px',
    marginRight: '15px',
    textTransform: 'capitalize',
    '&:hover,&:focus': {
      backgroundColor: 'rgb(226, 93, 13) !important',
    },
  },
  social_ico:{
    color: '#757575',
    backgroundColor: '#fff',
    float: 'left',   
    margin: '10px',
    display: 'block',
    padding: '10px 12px',
    opacity: 1,
    position: 'relative',
    minWidth: '100px',
    maxWidth: '100%',
    textAlign: 'center',
    transition: 'all .3s',
    fontWeight: 300,
    fontFamily: 'sans-serif',
    flexShrink: 0,
    whiteSpace: 'normal',
    textTransform: 'capitalize',
    border: '0px !important',
    '&:hover,&:focus': {
      backgroundColor: '#e6e6e6 !important',
      opacity: '1 !important',
    }
  },
  about_paragraph: {
    fontSize: '0.94rem',
    lineHeight: '1.475em',
    color: '#757575',
  },
  sub_paragraph: {
    fontSize: '0.94rem !important',
    lineHeight: '1.475em  !important',
    color: 'rgba(0, 0, 0, 0.54)',
  },
  icon_group:{
    marginTop: '30px'
  },
  icon_3:{
    fontWeight:500,
    fontSize: '10px !important',
  },
  icon_size:{
    fontSize: '30px !important',
    display: 'inline-block',
    paddingRight: '20px',
  },
  icon_size_1:{
    fontSize: '25px !important',
  },
  icon_7:{
    color: '#757575',
    marginRight: '5px',
    marginTop: '2px',
    fontSize: '19px !important',
  },
  gridList:{
    minHeight:'120px'
  },
  button_back:{
    marginRight:'15px'
  },
  calander_1:{
    boxShadow:'0 8px 30px 0 rgba(16, 36, 94, 0.2)'
  },
  calander_2:{
    borderRight: '1px solid #0000001f',
    margin:'auto',
    textAlign:'center !important'
  },
  time_2:{
    textAlign:'center',
    //height:'50%',
    borderBottom:'1px solid  #0000001f',
    padding:'25px'

  },
  time_3:{
    textAlign:'center',
    paddingLeft:'29px',
   // padding:'25px'
  },
  time_4:{
   // margin:'auto'
  },
  time_hidden:{
    visibility:'hidden'
  },
  time_visible:{
    visibility:'visible'
  },
  outlineInput:{    
    fontSize: '14px',
    fontWeight: '400',
    color: '#4f4f4f',
    '& fiedset':{
      padding: '18.5px 25px 18.5px 10px'
    },
    '&:before': {
    },
    '&:after': {
        borderColor: '#f50057',
    },
    '&:hove': {
      borderColor: '#f50057',
    }
  },
  tableCellId:{
    width:'20px !important',
    padding: '4px 0px 4px 0px !important'
  },
  tableCell:{
    paddingBottom:'7px',
    paddingTop:'7px'
  },
  tableCell_1:{
    fontSize:'0.9rem'
  },
  tableWrap:{
    overflowX: 'auto',
    width: '100%',
  },
  cardBody_1:{
    overflowX:'auto'
  },
  table:{
    minWidth:'600px'
  },
  nothing_1:{
    textAlign:'center'
  },
  timBoxes:{
    listStyleType:'none',  
    padding: '15px 0 0 0',
    margin: '0',
    fontSize: '13px',
    fontWeight: 'bold',
    '& li':{
      textAlign: 'center',
        width: '57px',
        margin: '0 auto 5px auto',
        backgroundColor: '#fafafa',
        borderRadius: '3px',
        border: '1px solid #3d424533',
        padding: '5px 0',
        lineHeight: 1,
        cursor: 'pointer',
        color: '#7f8182',
        float: 'left',
       marginRight: '5px',
       '&:hover,&:focus,&:active,&:visited':{
        backgroundColor: '#eae9e8'
       }
    }
  },
  time_item:{
    backgroundColor: '#dedcdb !important'
  },
  /** login modal */
  form: {
    margin: '0'
  },
  cardBody:{
    paddingTop:'50px',
    paddingLeft: '3.2rem',
    paddingRight: '3.2rem',
    paddingBottom: '17px',
  },
  GridContainer:{
    padding: '5px 0px !important'
  },
  GridContainer2:{
    paddingBottom: '15px',
    paddingTop: '5px',
  },
  signTitle:{
    fontWeight:'bold',
    color:'#484848'
  },
  loginFormLayout: {
    paddingTop: '20px'
  },
  cssLabel: {
    '&$cssFocused': {
      color: '#000',
      border: '2px #fff !important'
    },
  },
  cssFocused: {
    borderColor: '#000',
  },
  cssUnderline: {
    '&:after': {
      borderBottomColor: '#000',
    },
  },
  buttonPadding: {
    padding: '0 22px !important',
  },
  topPadding: {
    paddingTop: '45px !important',
  },
  dropDownSettings: {
    margin: '27px 0 0 0 !important',
  },
  dropDownSelectSettings: {
    borderColor: '#D2D2D2 !important',
  },
  tabsRoot: {
    borderBottom: '1px solid #d2d2d2',
  },
  tabsIndicator: {
    backgroundColor: '#f50057',
  },
  cssOutlinedInput: {
    fontWeight: '400 !important',
    fontFamily: [
      '-apple-system',
      'BlinkMacSystemFont',
      '"Segoe UI"',
      'Roboto',
      '"Helvetica Neue"',
      'Arial',
      'sans-serif',
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"',
    ].join(','),
    '&:focus': {
      borderRadius: 4,
      borderColor: '#80bdff',
      boxShadow: '0 0 0 0.2rem rgba(0,123,255,.25)',
    },
  },
  notchedOutline: {},
  inputIconsColor: {
    color: '#495057'
  },
  textField:{
    fontWeight: '300 !important',
    fontFamily: [
      '-apple-system',
      'BlinkMacSystemFont',
      '"Segoe UI"',
      'Roboto',
      '"Helvetica Neue"',
      'Arial',
      'sans-serif',
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"',
    ].join(','),
    '&:focus': {
      borderRadius: 4,
      borderColor: '#80bdff',
      boxShadow: '0 0 0 0.2rem rgba(0,123,255,.25)',
    },
    marginTop: '0px !important',
    '& input': {

    },
    '& label': {
     top:'-3px'
    }
  },
  cardFooterBycustomer_1: {
    paddingTop: '0rem',
    border: '0',
    borderRadius: '6px',   
    marginBottom:'35px',
    paddingLeft: '2.3rem',
    paddingRight: '2.3rem',
  },
  dialog_1:{
    padding:'0px !important'
  },
  link_1:{
    fontSize: '0.75rem',
  },
  column: {
    flexBasis: '33.33%',
  },
  helper: {
    borderLeft: `2px solid ${theme.palette.divider}`,
    padding: `${theme.spacing.unit}px ${theme.spacing.unit * 2}px`,
  },
  tableHeader_1:{
    color:primaryColor
  },
  tableCellId:{
    width:'20px !important',
    padding: '4px 20px 4px 20px !important'
  },
  forgotPass:{
    paddingTop: '11px',
    textAlign: 'end',
    fontSize:'0.875rem',
    cursor:'pointer',
    '&:hover,&:focus': {   
      color:'#f50057' 
    }
  },
  compactSwitch: {
    height: '0px !important',
  },
  dividerStyle: {
    width: '100%',
  },
  cardItemGroupHeader: {
    fontSize: '14.04px', 
    fontWeight: '400', 
    height: '20px', 
    letterSpacing: '0.25px', 
    marginTop: '20px', 
    paddingTop: '10px',
  },
  cardItemGroup: {
    display: 'block',
    width: '100%',
    paddingLeft: '15px',
    paddingRight: '15px',
  },
  cardItem: {
    fontSize: '13px',
    padding: '10px 20px',
    display: 'inline-flex',
    width: '100%',
  },
  cardItemFooter: {
    fontSize: '13px',
    padding: '7px 20px',
    display: 'inline-flex',
    width: '100%',
    backgroundColor: '#f3f3f3',
    borderBottomLeftRadius: '6px',
    borderBottomRightRadius: '6px',
  },
  cardItemSub: {
    color: '#63676c',
  },
  cardItemComponent: {
    marginLeft: 'auto', 
    marginRight: '0',
  },
  cardItemTextInput: {
    padding: '4px 0px !important',
  },
  cardItemTextInputRoot: {
    fontSize: '13px !important',
  },
  cardItemTextInputUnderline: {
    '&:after': {
      borderBottom: '1px solid rgb(0, 0, 0)',
    },
    '&:hover': {
      borderColor: '#fff',
    },
    '&:before': {
      borderBottom: '1px solid rgb(210, 210, 210)',
    },
    '&:hover:not(.MuiInput-disabled-499):not(.MuiInput-focused-498):not(.MuiInput-error-501):before': {
      borderBottom: '1px solid rgb(210, 210, 210)',
    },
  },

  textfieldRoot: {
    paddingLeft: '10px',
    borderTopLeftRadius: '0px',
    borderTopRightRadius: '0px',
    marginTop: '0px',
    marginBottom: '0px !important'
  },
  textfieldInput: {
    lineHeight: '24px',
    fontSize: '13px',
    padding: '0px',
    width: '220px',
    marginBottom: '0px'
  },
  textFieldUnderline: {
    '&:after': {
      borderBottom: '2px solid #484848',
    },
  },
  cardItemSaveBtn: {
    textTransform: 'capitalize',
  },
  formControl_employee: {
   // margin: theme.spacing.unit,
    minWidth: 160,   
    width: '240px',
  },
  discountCard:{
    marginTop:'15px !important'
  },
  giftCode:{
    marginTop:'5px !important'
  }
});

export default landingPageStyle;
