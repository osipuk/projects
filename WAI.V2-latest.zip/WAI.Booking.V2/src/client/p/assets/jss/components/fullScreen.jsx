import { fade } from '@material-ui/core/styles/colorManipulator';
import {
  container,
  defaultFont,
  primaryColor,
  infoColor,
  successColor,
  warningColor,
  dangerColor,
  roseColor,
  transition,
  boxShadow,
  drawerWidth
} from 'common/assets/jss/material-react';

const fullScreenStyle =theme => ({
  appBar: {
    position: 'relative',
    backgroundColor: '#fff !important',
    transition: 'left .3s ease-out, right .3s ease-out',   
  },
  flex: {
    flex: 1,
  },
  container: {
    zIndex: '12',
    color: '#FFFFFF',
    marginTop:'0px',
  },
  item_img:{
    width:'100%'
  },
  closeButton:{
    color:'black',
  }
  
});

export default fullScreenStyle;
