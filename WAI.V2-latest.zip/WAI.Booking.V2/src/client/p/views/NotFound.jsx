import React from "react";
import ReactDOM from "react-dom";
import withStyles from "@material-ui/core/styles/withStyles";
import withLocalization from "common/contexts/LocalizationContext";
import Card from "@material-ui/core/Card";
import landingPageStyle from "../assets/jss/views/landingPage";


class NotFound extends React.Component {
  constructor(props) {
    super(props);  
  }
  render() {
    const { classes } = this.props;   
    return (
      <div className={classes.rootMenuScrollHide}>      
         <Card className={classes.card}>
           <h4>Not Found!.</h4>
        </Card>
      </div>
    );
  }
}

export default withStyles(landingPageStyle)(withLocalization(NotFound));