import React from "react";
import ReactDOM from "react-dom";
import withStyles from "@material-ui/core/styles/withStyles";
import GridList from "@material-ui/core/GridList";
import GridListTile from "@material-ui/core/GridListTile";
import Hidden from "@material-ui/core/Hidden";
import withLocalization from "common/contexts/LocalizationContext";
import GridContainer from "common/components/Grid/GridContainer";
import Grid from "@material-ui/core/Grid";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import Card from "@material-ui/core/Card";
import InputAdornment from '@material-ui/core/InputAdornment';
import Button from "@material-ui/core/Button";
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Success from '@material-ui/icons/CheckCircle';
import Link from 'react-router-dom/es/Link';
import axios from 'axios';
import ExpansionPanel from "@material-ui/core/ExpansionPanel";
//import MuiExpansionPanel from '@material-ui/core/ExpansionPanel';
//import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import MuiExpansionPanelSummary from "@material-ui/core/ExpansionPanelSummary";
//import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import MuiExpansionPanelDetails from "@material-ui/core/ExpansionPanelDetails";
import Divider from "@material-ui/core/Divider";
import Typography from "@material-ui/core/Typography";
import Checkbox from "@material-ui/core/Checkbox";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import ExpansionPanelActions from "@material-ui/core/ExpansionPanelActions";
import Select from "@material-ui/core/Select";
import OutlinedInput from "@material-ui/core/OutlinedInput";
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import Input from "@material-ui/core/Input";
import InputLabel from "@material-ui/core/InputLabel";
import classNames from "classnames";
import Chip from "@material-ui/core/Chip";
import TextField from "@material-ui/core/TextField";
import Icon from "@material-ui/core/Icon";
import LocationOn from "@material-ui/icons/LocationOn";
import Phone from "@material-ui/icons/Phone";
import Email from "@material-ui/icons/Email";
import Info from "@material-ui/icons/Info";
import Sms from "@material-ui/icons/Sms";
import Category from "@material-ui/icons/Book";
import Attachment from "@material-ui/icons/SpeakerNotes";
//import AccessTime from '@material-ui/icons/AccessTime';
import Timer from "@material-ui/icons/Timer";
import Payment from "@material-ui/icons/Payment";
import Receipt from "@material-ui/icons/Receipt";
import LockOutlined from '@material-ui/icons/LockOutlined';
import DayPicker from "react-day-picker";
import "../assets/style.css";
import GridListTileBar from "@material-ui/core/GridListTileBar";
import StarBorderIcon from "@material-ui/icons/StarBorder";
import IconButton from "@material-ui/core/IconButton";
import Avatar from "@material-ui/core/Avatar";
import Header from "../components/Header/Header";
import CardFooter from '../../common/components/Card/CardFooter';
import LoginButton from 'common/containers/LoginButton/LoginButton';
//import Card from "../../common/components/Card/Card.jsx";
import CardBody from "../../common/components/Card/CardBody.jsx";
import HeaderLinks from "../components/Header/HeaderLinks";
import landingPageStyle from "../assets/jss/views/landingPage";
import tileData from "../assets/jss/components/tileData";
import withAuth from 'common/contexts/AuthContext';
import withNotifications from 'common/contexts/NotificationsContext';

const dashboardRoutes = [];

const ExpansionPanelSummary = withStyles({
  root: {
    //backgroundColor: 'rgba(0,0,0,.03)',
    borderBottom: "1px solid rgba(0,0,0,.125)",
    boxShadow:
      "0 4px 20px 0px rgba(0, 0, 0, 0.14), 0 7px 10px -5px rgba(179, 172, 177, 1)",
    marginBottom: -1,
    minHeight: 56,
    "&$expanded": {
      minHeight: 56
    }
  },
  content: {
    "&$expanded": {
      margin: "12px 0"
    }
  },
  expanded: {}
})(props => <MuiExpansionPanelSummary {...props} />);

ExpansionPanelSummary.muiName = "ExpansionPanelSummary";
const ExpansionPanelDetails = withStyles(theme => ({
  root: {
    padding: theme.spacing.unit * 2
  }
}))(MuiExpansionPanelDetails);

function getStyles(name, personName) {
  return {
    fontWeight: personName.indexOf(name) === -1 ? "500" : "300"
  };
}

(function() {
  var days = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday"
  ];
  var months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
  ];

  Date.prototype.getMonthName = function() {
    return months[this.getMonth()];
  };
  Date.prototype.getDayName = function() {
    return days[this.getDay()];
  };
})();

class CompanyLandingPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {     
      expanded: "panel1",
      addons: [],
      labelWidth: 0,
      currentPanel: 1,
      duration: 0,
      price: 0,
      timepick: "",
      month: "",
      day: "",
      day_d: "",
      step1: false,
      step2: true,
      step3: true,
      step4: true,
      step5: true,
      cellHeight: 215,
      selectedDay: undefined,
      employee: "Employee 1",
      dayofweek: [0,1,2,3,4,5,6],
      available_date_time: "Please select booking day and time.",      
      //
      category: [],
      company:[],
      services:[],
      defaultCategory:0,
      serviceSelected:[],
      serviceAddons:[],
      addonsSelected:[],
      employees:[],
      employeeId:'',
      workHours:[],//from db,
      workTimes:[],// converted times
      workTimesShadow:[],//real minutes for work times
      bookingFrom:'',
      bookingTo:'',
      totalDuration:'',
      pickedDate:'',
      categoryName:'',
      open_dialog:false,
      password:'',
      phone:''

    };
    this.selectChange = this.selectChange.bind(this);
    this.addonsChange = this.addonsChange.bind(this);  
    this.employeeChange = this.employeeChange.bind(this);
    this.handleDayClick = this.handleDayClick.bind(this);
    this.updateWindowDimensions = this.updateWindowDimensions.bind(this);
  }

  async componentWillMount (){
    const {id}=this.props.match.params;  
    var  {data} = await axios.get('/api/customer/company/'+id+'/customurl');
   console.log(data,'company');
    if(data.success){      
      this.setState({company:data.company});
      var  {data} = await axios.get('/api/customer/company/'+data.company.id+'/services');      
        if(data.success){
          this.setState({
            category:data.serviceCategories,
            services:data.services,
            serviceAddons:data.serviceExtras,
            employees:data.employees,
            workHours:data.bookingHours
          })
          data.serviceCategories.map(row=>{            
            if(row.defaultServiceCategory){
              this.setState({defaultCategory:row.id,
                categoryName:"Category: "+row.name
              });              
            }
          })          
        }
      console.log(data,'all infor',this.state.defaultCategory);      
    }
    else{
      //this.props.history.push('*');
    }
  }
  componentDidMount() {    
    window.addEventListener("resize", this.updateWindowDimensions);
    if (window.innerWidth < 1114 && window.innerWidth > 940) {
      this.setState({ cellHeight: 140 });
    } 
    else if (window.innerWidth < 1315 && window.innerWidth > 1114) {
      this.setState({ cellHeight: 190 });
    }
    else if (window.innerWidth < 450) {
      this.setState({ cellHeight: 125 });
    } else {
      this.setState({ cellHeight: 215 });
    }
  }
  componentWillUnmount() {   
    window.removeEventListener("resize", this.updateWindowDimensions);
  }
  updateWindowDimensions() {
    if (window.innerWidth < 1114 && window.innerWidth > 940) {
      this.setState({ cellHeight: 140 });
    } else if (window.innerWidth < 450) {
      this.setState({ cellHeight: 125 });
    } 
    else if (window.innerWidth < 1315 && window.innerWidth > 1114) {
      this.setState({ cellHeight: 190 });
    }
    else {
      this.setState({ cellHeight: 215 });
    }
  }

  handleTxtChange = prop => event => {
    this.setState({ [prop]: event.target.value });
  };
  handleChange = panel => (event, expanded) => {
    var position = panel.substr(5, 1);
    if (parseInt(position) <= this.state.currentPanel) {
      this.setState({
        expanded: expanded ? panel : false,
        currentPanel: parseInt(position)
      });
    }
    for (var i = parseInt(position) + 1; i <= 5; i++) {
      var steps = "step" + i;
      this.setState({
        [steps]: true
      });
    }
  };

  nextChange = panel => () => {    
    if(!this.props.auth.isAuth){
      this.setState({open_dialog:true});
      return;
    }

    var position = panel.substr(5, 1);
    this.setState({
      expanded: panel,
      currentPanel: parseInt(position)
    });

    var position = panel.substr(5, 1);
    for (var i = 1; i <= parseInt(position); i++) {
      var steps = "step" + i;    
      this.setState({
        [steps]: false
      });
    }

    for (var i = parseInt(position) + 1; i <= 5; i++) {
      var steps = "step" + i;      
      this.setState({
        [steps]: true
      });
    }
  };

  selectChange(event) {  

    this.state.category.map(row=>{
      if(row.id==event.target.value){
          this.setState({categoryName:"Category: "+row.name});
      }
    })
   
    this.setState({
      [event.target.name]: event.target.value
    });
  }
  employeeChange(event) {
    
   const {workHours}=this.state;
   var dayofweek=[];
   var workTimeIsSet=false;
   dayofweek.slice(0,1);
    workHours.map(row=>{
        if(row.employeeId==event.target.value){
             workTimeIsSet=true;
            if(!row.mondayIsOpen){
              dayofweek.push(1);
            }
             if(!row.tuesdayIsOpen){
              dayofweek.push(2);
            }
             if(!row.wednesdayIsOpen){
              dayofweek.push(3);
            }
             if(!row.thursdayIsOpen){
              dayofweek.push(4);
            }
             if(!row.fridayIsOpen){
              dayofweek.push(5);
            }
             if(!row.saturdayIsOpen){
              dayofweek.push(6);
            }
             if(!row.sundayIsOpen){
              dayofweek.push(0);
            }       
        }
    });
    if(!workTimeIsSet){
      dayofweek=[0,1,2,3,4,5,6];
    }
    console.log(dayofweek,workTimeIsSet);    
    this.setState({
      [event.target.name]: event.target.value,
      dayofweek:dayofweek,
      workTimes:[],
      bookingFrom:'',
      bookingTo:'',
      pickedDate:''
    });

  } 
  addonsChange(event) {
    this.setState({
      addons: event.target.value
    });
  }
  time_convert=(num)=>{ 
    var hours = Math.floor(num / 60);  
    var minutes = num % 60;
    minutes= minutes > 9 ? "" + minutes: "0" + minutes;
    return hours + ":" + minutes;         
  }

  handleDayClick(day, { selected, disabled }) {
    if (disabled) {
      // Day is disabled, do nothing
      return;
    }
    if (selected) {
      // Unselect the day if already selected
      this.setState({
        selectedDay: undefined,
        workTimes:[],
        workTimesShadow:[],       
        available_date_time: "Please select booking day and time."
      });
      return;
    }

    var now = day.toLocaleDateString();  
    console.log(now,day);
    var day_temp = now.split("/");
    var now = new Date(day.toLocaleDateString());        
    const {workHours}=this.state;
    var temp=[];
    var tempShadow=[];
    workHours.map(row=>{
        if(row.employeeId==this.state.employeeId){
           var open_at=0;
           var close_at=0;
                 
          if (now.getDayName() == "Monday") {
            var hms_open=row.mondayOpenAt;
            var open = hms_open.split(':');
            var hms_close=row.mondayCloseAt;
            var close=hms_close.split(':');
            open_at=parseInt(open[0]*60)+parseInt(open[1]);            
            close_at=parseInt(close[0]*60)+parseInt(close[1]);             
          }
          else if(now.getDayName() == "Tuesday"){
            var hms_open=row.tuesdayOpenAt;
            var open = hms_open.split(':');
            var hms_close=row.tuesdayCloseAt;
            var close=hms_close.split(':');
            open_at=parseInt(open[0]*60)+parseInt(open[1]);            
            close_at=parseInt(close[0]*60)+parseInt(close[1]); 
          }
          else if(now.getDayName() == "Wednesday"){
            var hms_open=row.wednesdayOpenAt;
            var open = hms_open.split(':');
            var hms_close=row.wednesdayCloseAt;
            var close=hms_close.split(':');
            open_at=parseInt(open[0]*60)+parseInt(open[1]);            
            close_at=parseInt(close[0]*60)+parseInt(close[1]); 
          }
          else if(now.getDayName() == "Thursday"){
            var hms_open=row.thursdayOpenAt;
            var open = hms_open.split(':');
            var hms_close=row.thursdayCloseAt;
            var close=hms_close.split(':');
            open_at=parseInt(open[0]*60)+parseInt(open[1]);            
            close_at=parseInt(close[0]*60)+parseInt(close[1]); 
          }
          else if(now.getDayName() == "Friday"){
            var hms_open=row.fridayOpenAt;
            var open = hms_open.split(':');
            var hms_close=row.fridayCloseAt;
            var close=hms_close.split(':');
            open_at=parseInt(open[0]*60)+parseInt(open[1]);            
            close_at=parseInt(close[0]*60)+parseInt(close[1]); 
          }
          else if(now.getDayName() == "Saturday"){
            var hms_open=row.saturdayOpenAt;
            var open = hms_open.split(':');
            var hms_close=row.saturdayCloseAt;
            var close=hms_close.split(':');
            open_at=parseInt(open[0]*60)+parseInt(open[1]);            
            close_at=parseInt(close[0]*60)+parseInt(close[1]); 
          }
          else if(now.getDayName() == "Sunday"){
            var hms_open=row.sundayOpenAt;
            var open = hms_open.split(':');
            var hms_close=row.sundayCloseAt;
            var close=hms_close.split(':');
            open_at=parseInt(open[0]*60)+parseInt(open[1]);            
            close_at=parseInt(close[0]*60)+parseInt(close[1]); 
          }

            var interval=parseInt(this.state.company.interval);         
            for(var i=open_at;i<=close_at;i=i+interval){
              this.time_convert(i);
              temp.push(this.time_convert(i));
              tempShadow.push(i);
            }

        }
    });

    this.setState({
      selectedDay: day,
      month: now.getMonthName(),
      day: now.getDayName(),
      day_d: day_temp[1],
      workTimes:temp,
      workTimesShadow:tempShadow,
      pickedDate:day_temp[2]+"-"+day_temp[0]+"-"+day_temp[1],     
      timepick:'',
      totalDuration:''

    });
     
  }
  selectTimes=(time,index)=>{
    const {services,serviceSelected,serviceAddons,addonsSelected,pickedDate,workTimesShadow}=this.state;
    var totalDuration=0;
    var totalPrice=0;
    services.map(row=>{
      if(serviceSelected.indexOf(row.id)!=-1){
        totalDuration=totalDuration+parseInt(row.duration);
        totalPrice=totalPrice+parseFloat(row.price);
      }
    })

    serviceAddons.map(row=>{
      if(addonsSelected.indexOf(row.id)!=-1){
        totalDuration=totalDuration+parseInt(row.duration);
        totalPrice=totalPrice+parseFloat(row.price);
      }
    })    
    var toTemp=parseInt(workTimesShadow[index])+parseInt(totalDuration);
    this.setState({bookingFrom:pickedDate+" "+time+":00",
    bookingTo:pickedDate+" "+this.time_convert(toTemp)+":00",
    timepick:time,
    totalDuration:totalDuration
    });    

    this.setState({
      expanded: 'panel4',
      currentPanel: 4,
      step4:false,
      //step3:false
    });

  }
  submitBooking=async()=>{
    const {notifications,localization}=this.props;
    const {company,serviceSelected,bookingFrom,bookingTo,totalDuration,addonsSelected,employeeId}=this.state;
    var { data, } = await axios.post("/api/customer/company/"+company.id+"/booking", {
      book:{ 
        serviceIds:serviceSelected,
        extraIds:addonsSelected,
        bookFrom:bookingFrom,
        bookTo:bookingTo,
        duration:totalDuration,
        employeeId:employeeId     

      }});    
      if(data.success){
        notifications.show({message: localization.localizedString('BOOKING_SUCCESS'),icon:Success,color:'success'});

        this.setState({
          expanded: 'panel1',
          currentPanel: 1,
          step1:false,
         serviceSelected:[],
          addonsSelected:[],
          bookingFrom:'',
          bookingTo:'',
          totalDuration:''
          //step3:false
        });
      }
      else{
        notifications.show({message: localization.localizedError(data.errorCode)});
      }
  }
  serviceClick= (event, id) => {
    const { serviceSelected } = this.state;
    const selectedIndex = serviceSelected.indexOf(id);
    let newSelected = [];
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(serviceSelected, id);
    } 
    else if (selectedIndex === 0) {
      newSelected = newSelected.concat(serviceSelected.slice(1));
    } else if (selectedIndex === serviceSelected.length - 1) {
      newSelected = newSelected.concat(serviceSelected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        serviceSelected.slice(0, selectedIndex),
        serviceSelected.slice(selectedIndex + 1),
      );
    }  
    this.setState({ serviceSelected: newSelected,addonsSelected:[] });
  }
  addonsClick= (event, id) => {    
    const { addonsSelected } = this.state;
    const selectedIndex = addonsSelected.indexOf(id);
    let newSelected = [];
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(addonsSelected, id);
    } 
    else if (selectedIndex === 0) {
      newSelected = newSelected.concat(addonsSelected.slice(1));
    } else if (selectedIndex === addonsSelected.length - 1) {
      newSelected = newSelected.concat(addonsSelected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        addonsSelected.slice(0, selectedIndex),
        addonsSelected.slice(selectedIndex + 1),
      );
    }  

    this.setState({ addonsSelected: newSelected });
  }
  dialogClose=() => {
    this.setState({ open_dialog: false });
  }
  logIn=async()=>{
    var userData={};
    const {auth,notifications,localization}=this.props;
    userData.phone=this.state.phone;
    userData.password=this.state.password;

    const result = await auth.login(userData); 
    if(result.success){
      this.setState({open_dialog:false,
        expanded: 'panel2',
        currentPanel:2,      
        step2:false
      });
     
    }
    else{
      notifications.show({message: localization.localizedError(result.errorCode)});
    }
    console.log(result);
  }

  isSelected = id => this.state.serviceSelected.indexOf(id) !== -1;
  isAddonsSelected = id => this.state.addonsSelected.indexOf(id) !== -1;

  serviceTable=()=>{
    const { classes,localization } = this.props;
    let tbl=[];
    let trs=[];

      this.state.services.map((item, index) => {      
      const isSelected = this.isSelected(item.id);
        if(item.serviceCategoryId==this.state.defaultCategory){
          trs.push(
            <TableRow key={item.id}>
              <TableCell className={classes.tableCellId} >
                  <Checkbox
                      tabIndex={-1}
                      disableRipple
                      checked={isSelected}
                      onChange={event => this.serviceClick(event, item.id)}                            
                   />
              </TableCell>
              <TableCell className={classes.tableCell}>
                  <div className={classNames(classes.title_2)}>
                    {item.name}
                  </div>
                  <div className={classNames(classes.description_1)}>
                    {item.description}
                   </div>
              </TableCell>
              <TableCell  className={classes.tableCell_1}>
                <span>{item.duration} minutes</span>
              </TableCell>

              <TableCell  className={classes.tableCell_1}>
                <span>{item.price+" "+this.state.company.currency_code}</span>
              </TableCell>

            </TableRow>
            );
        }
      });
      if(trs.length==0){
        return <h4 className={classes.nothing_1}>There is nothing.</h4>
      }
      tbl.push(
          <Table className={classes.table} key={1}>              
                <TableBody>
                  {trs}
                </TableBody>
          </Table>
      );
      return tbl;
  } 
  serviceAddonsTable=()=>{
    const { classes,localization } = this.props;
    const {serviceSelected}=this.state;
    let tbl=[];
    let trs=[];

      this.state.serviceAddons.map((item, index) => {      
      const isSelected = this.isAddonsSelected(item.id);
        if(serviceSelected.indexOf(item.serviceId)!=-1){
          trs.push(
            <TableRow key={item.id}>
              <TableCell className={classes.tableCellId} >
                  <Checkbox
                      tabIndex={-1}
                      disableRipple
                      checked={isSelected}
                      onChange={event => this.addonsClick(event, item.id)}                            
                   />
              </TableCell>
              <TableCell className={classes.tableCell}>
                  <div className={classNames(classes.title_2)}>
                    {item.name}
                  </div>
                  <div className={classNames(classes.description_1)}>
                    {item.description}
                   </div>
              </TableCell>
              <TableCell  className={classes.tableCell_1}>
                <span>{item.duration} minutes</span>
              </TableCell>

              <TableCell  className={classes.tableCell_1}>
                <span>{item.price+" "+this.state.company.currency_code}</span>
              </TableCell>

            </TableRow>
            );
        }
      });
      if(trs.length==0){
        return <h4 className={classes.nothing_1}>There is nothing.</h4>
      }
      tbl.push(
          <Table className={classes.table} key={1}>              
                <TableBody>
                  {trs}
                </TableBody>
          </Table>
      );
      return tbl;
  }
  render() {
    const { classes,localization } = this.props;
    const { expanded,phone,password } = this.state;

    return (
      <div className={classes.rootMenuScrollHide}>
        <Header
          color="white"
          routes={dashboardRoutes}
          brand={this.props.localization.localizedString("BRAND")}
          rightLinks={<HeaderLinks />}
          changeColorOnScroll={{
            height: 400,
            color: "white"
          }}
        />

        <div className={classes.container}>
          <GridContainer>
            <Grid item xs={12} sm={12} md={6} className={classes.tess}>
              <GridList
                spacing={1}
                cellHeight={this.state.cellHeight}
                className={classes.gridList}
                cols={2}
              >
                <GridListTile
                  key={"https://material-ui.com/static/images/grid-list/breakfast.jpg"}
                  cols={2}
                  rows={2}
                  className={classes.mainPicture}
                >
                  <div className={classes.thms}>
                    <img
                      src={"https://material-ui.com/static/images/grid-list/breakfast.jpg"}
                      alt={"title1"}
                      className={classes.item_img}
                    />
                  </div>
                  <GridListTileBar
                    title="breakfast x2 sale"
                    titlePosition="top"
                    actionIcon={
                      <IconButton className={classes.white_icon}>
                        <StarBorderIcon />
                      </IconButton>
                    }
                    actionPosition="left"
                    className={classes.profile_images}
                  />
                </GridListTile>
              </GridList>
            </Grid>

            <Grid item xs={12} sm={12} md={6}>
              <Hidden smDown implementation="css">
                <GridList
                  spacing={0}
                  cellHeight={this.state.cellHeight + 1}
                  className={classes.gridList}
                  cols={2}
                >
                  {tileData.map(tile => (
                    <GridListTile
                      className={classes.tess}
                      key={tile.img}
                      cols={tile.cols || 1}
                      className={classes.subPicture}
                    >
                      <div className={classes.thms}>
                        <img
                          src={tile.img}
                          alt={tile.title}
                          className={classes.item_img}
                        />
                      </div>
                      <GridListTileBar
                        title="some description"
                        titlePosition="top"
                        actionPosition="left"
                        className={classes.profile_images}
                      />
                    </GridListTile>
                  ))}
                </GridList>
              </Hidden>
            </Grid>
          </GridContainer>
        </div>

        <Card className={classes.card}>
          <Grid item xs={12} className={classes.control}>
            <Grid container>
              <Grid xs={12} sm={9} md={9} item>
                <div style={{ padding: "0px !important" }}>
                  <div>
                    <h1 className={classes.listitem_hh}>
                      <span className={classes.companyName}>
                        {this.state.company.company_name}
                      </span>
                    </h1>
                  </div>

                  <div>
                    <List
                      component="nav"
                      dense={false}
                      disablePadding={false}
                      className={classes.nav_list}
                    >
                      <ListItem className={classes.listitem_11}>
                        <ListItemIcon className={classes.icon_4}>
                          <LocationOn className={classes.icon_1} />
                        </ListItemIcon>
                        <ListItemText
                          className={classes.list_2}
                          classes={{ primary: classes.title_22 }}
                          primary={this.state.company.address}
                        />
                      </ListItem>
                      <ListItem className={classes.listitem_1}>
                        <ListItemIcon className={classes.icon_4}>
                          <Phone className={classes.icon_1} />
                        </ListItemIcon>
                        <ListItemText
                          className={classes.list_2}
                          classes={{ primary: classes.title_22 }}
                          primary={this.state.company.country_phone_code+"  "+this.state.company.phone}
                        />
                      </ListItem>
                      <ListItem className={classes.listitem_1}>
                        <ListItemIcon className={classes.icon_4}>
                          <Email className={classes.icon_1} />
                        </ListItemIcon>
                        <ListItemText
                          className={classes.list_2}
                          classes={{ primary: classes.title_22 }}
                          primary={this.state.company.email}
                        />
                      </ListItem>
                      <ListItem className={classes.listitem_1_2}>
                        <Button
                          variant="contained"
                          color="primary"
                          className={classes.requestBookingBtn}
                        >
                          Request A Booking
                        </Button>
                      </ListItem>
                      
                      <ListItem className={classes.listitem_1_toppad}>
                      <Typography variant="caption">
                      You can request a booking latest 4 hours before the appointment and cancel a booking latest 2 hours before.                          <br />
                       </Typography>
                      </ListItem>
                    </List>

                    <Divider variant="middle" />
                  </div>

                  <div className={classes.address_1}>
                    <List
                      component="nav"
                      dense={false}
                      disablePadding={false}
                      className={classes.about_header_list}
                    >
                      <ListItem className={classes.about_header_list_item}>
                        <ListItemIcon className={classes.icon_4}>
                          <Icon className={classes.getStartedRightIcon}>
                            home
                          </Icon>
                        </ListItemIcon>
                        <ListItemText
                          className={classes.about_header}
                          primary="About"
                        />
                      </ListItem>
                    </List>

                    <p>
                      Hos Overgaard er kvalitet, personlig rådgivning og økologi
                      i højsædet. Salonen forbinder velvære og skønhed i en
                      afslappet atmosfære.
                    </p>
                    <p>
                      Indehaveren er udlært hos Palma salon og spa i København K
                      og efteruddannet ved blandt andet Sassoon Academy i
                      London.
                    </p>
                    <p>
                      Salonen er beliggende på den hyggelige Willemoesgade på
                      Østerbro i København og deler adresse med en forhandler af
                      antikke effekter til klassiske ejendomme og lejligheder.
                    </p>
                  </div>
                  <Divider variant="middle" />
                  <div className={classes.address_1}>
                    <List
                      component="nav"
                      dense={false}
                      disablePadding={false}
                      className={classes.about_header_list}
                    >
                      <ListItem className={classes.about_header_list_item}>
                        <ListItemIcon className={classes.icon_4}>
                          <Icon className={classes.getStartedRightIcon}>
                            credit_card
                          </Icon>
                        </ListItemIcon>
                        <ListItemText
                          className={classes.about_header}
                          primary="Accepted payment methods"
                        />
                      </ListItem>
                    </List>

                    <Grid container  >
                      <Typography variant="caption">
                          In-store - pay after service has been done
                          <br />
                          
                        </Typography>
                        <Grid xs={12} sm={12} md={12} item>
                        
                          <Avatar
                          alt="Remy Sharp"
                          className={classes.paymentCards}
                          src="http://icons.iconarchive.com/icons/designbolts/credit-card-payment/256/Master-Card-Blue-icon.png"
                        />
                        <Avatar
                          alt="Remy Sharp"
                          className={classes.paymentCards}
                          src="https://cdn.iconscout.com/icon/free/png-256/payment-stripe-card-pay-bank-transaction-51317.png"
                        />
                        <Avatar
                          alt="Remy Sharp"
                          className={classes.paymentCards}
                          src="http://aux2.iconspalace.com/uploads/paypal-payment-icon-256.png"
                        />
                        <Avatar
                          alt="Remy Sharp"
                          className={classes.paymentCards}
                          src="https://cdn.iconscout.com/icon/free/png-256/payment-bitcoin-card-pay-bank-51308.png"
                        />
                        <Avatar
                          alt="Remy Sharp"
                          className={classes.paymentCards}
                          src="http://www.myiconfinder.com/uploads/iconsets/256-256-4c5308bf863a00c56870d053e6ba37c6.png"
                        />
                        <Avatar
                          alt="Remy Sharp"
                          className={classes.paymentCards}
                          src="http://icons.iconarchive.com/icons/designbolts/credit-card-payment/256/American-Express-icon.png"
                          
                        />
                        <Avatar
                          alt="Remy Sharp"
                          className={classes.paymentCards}
                          src="https://www.iconshock.com/image/Clean/Credit_Cards/alipay2/"
                        />
                        
                        
                        </Grid>

                        <Typography variant="caption">
                          Online - pay upfront
                          <br />
                          
                        </Typography>
                        <Grid xs={12} sm={12} md={12} item>
                        
                          <Avatar
                          alt="Remy Sharp"
                          className={classes.paymentCards}
                          src="http://icons.iconarchive.com/icons/designbolts/credit-card-payment/256/Master-Card-Blue-icon.png"
                        />
                        <Avatar
                          alt="Remy Sharp"
                          className={classes.paymentCards}
                          src="https://cdn.iconscout.com/icon/free/png-256/payment-stripe-card-pay-bank-transaction-51317.png"
                        />
                        <Avatar
                          alt="Remy Sharp"
                          className={classes.paymentCards}
                          src="http://aux2.iconspalace.com/uploads/paypal-payment-icon-256.png"
                        />
                        <Avatar
                          alt="Remy Sharp"
                          className={classes.paymentCards}
                          src="https://cdn.iconscout.com/icon/free/png-256/payment-bitcoin-card-pay-bank-51308.png"
                        />
                        <Avatar
                          alt="Remy Sharp"
                          className={classes.paymentCards}
                          src="http://www.myiconfinder.com/uploads/iconsets/256-256-4c5308bf863a00c56870d053e6ba37c6.png"
                        />
                        <Avatar
                          alt="Remy Sharp"
                          className={classes.paymentCards}
                          src="http://icons.iconarchive.com/icons/designbolts/credit-card-payment/256/American-Express-icon.png"
                          
                        />
                        <Avatar
                          alt="Remy Sharp"
                          className={classes.paymentCards}
                          src="https://www.iconshock.com/image/Clean/Credit_Cards/alipay2/"
                        />
                        
                        
                        </Grid>
                  
                    </Grid>
                  </div>
                </div>
              </Grid>
              <Grid xs={12} sm={2} md={3} item className={classes.root_2}>
                <Grid container justify={"center"} className={classes.book_now}>
                  <Grid container justify={"center"} />
                  <Grid
                    container
                    className={classes.icon_group}
                    justify={"center"}
                  >
                    <Grid xs={12} sm={12} md={12} item>
                      <Grid container justify={"center"}>
                        <Button
                          variant="outlined"
                          color="default"
                          className={classes.social_ico}
                        >
                          <div>
                            <div className={classes.icon_size}>
                              <i className="fab fa-facebook" />
                            </div>
                            <div>
                              <span className={classes.icon_3}>Facebook</span>
                            </div>
                          </div>
                        </Button>
                      </Grid>
                    </Grid>
                    <Grid xs={4} sm={4} md={4} item>
                      <Grid container justify={"center"}>
                        <Button
                          variant="outlined"
                          color="default"
                          className={classes.social_ico}
                        >
                          <div>
                            <div className={classes.icon_size}>
                              <i className="fab fa-firefox" />
                            </div>
                            <div>
                              <span className={classes.icon_3}>Website</span>
                            </div>
                          </div>
                        </Button>
                      </Grid>
                    </Grid>
                    <Grid xs={12} sm={12} md={12} item>
                      <Grid container justify={"center"}>
                        <Button
                          variant="outlined"
                          color="default"
                          className={classes.social_ico}
                        >
                          <div>
                            <div className={classes.icon_size}>
                              <i className="fab fa-twitter" />
                            </div>
                            <div>
                              <span className={classes.icon_3}>Twitter</span>
                            </div>
                          </div>
                        </Button>
                      </Grid>
                    </Grid>
                    <Grid xs={12} sm={12} md={12} item>
                      <Grid container justify={"center"}>
                        <Button
                          variant="outlined"
                          color="default"
                          className={classes.social_ico}
                        >
                          <div>
                            <div className={classes.icon_size}>
                              <i className="fab fa-instagram" />
                            </div>
                            <div>
                              <span className={classes.icon_3}>Instagram</span>
                            </div>
                          </div>
                        </Button>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
            <Divider variant="middle"/>
            
            {/** start widzard */}
            <Grid className={classes.root_3}>
            <List
                      component="nav"
                      dense={false}
                      disablePadding={false}
                      className={classes.about_header_list}
                    >
                      <ListItem className={classes.about_header_list_item}>
                        <ListItemIcon className={classes.icon_4}>
                          <Icon className={classes.getStartedRightIcon}>
                          attach_money
                          </Icon>
                        </ListItemIcon>
                        <ListItemText
                          className={classes.about_header}
                          primary="Request a booking"
                        />
                      </ListItem>
                    </List>

              <ExpansionPanel
                disabled={this.state.step1}
                expanded={expanded === "panel1"}
                onChange={this.handleChange("panel1")}
              >
                <ExpansionPanelSummary className={classes.root_summary}>
                  <Category className={classes.icon_7} />
                  <Typography variant="subheading" className={classes.title_3}>
                    Select service
                  </Typography>
                  <Typography className={classes.grow}>
                    {this.state.categoryName}
                  </Typography>
                  <span className={classes.step_c} />
                </ExpansionPanelSummary>

                <ExpansionPanelActions className={classes.action_1}>
                  <FormControl
                    variant="outlined"
                    className={classes.formControl}
                  >
                    <Select
                      value={this.state.defaultCategory}
                      onChange={this.selectChange}                      
                      input={
                        <OutlinedInput
                          fullWidth={true}
                          labelWidth={this.state.labelWidth}
                          name="defaultCategory"
                          id="defaultCategory" 
                          className={classes.outlineInput}
                        />
                      }
                    >
                       {this.state.category.map(row=>(
                        <MenuItem key={row.id} value={row.id}>{row.name}</MenuItem>
                      ))}  
                    </Select>
                  </FormControl>
                </ExpansionPanelActions>
                <Divider />
                <ExpansionPanelDetails className={classes.detail_1}>
                  <Grid container>
                    <Grid item xs={12} sm={12} md={12}>                
                        <div className={classes.cardBody_1}>
                            {this.serviceTable()}
                      </div>                
                    </Grid>
                  </Grid>                 
                  <Grid container className={classes.detail_2}>
                    <Grid
                      xs={6}
                      sm={6}
                      md={9}
                      item
                      className={classes.detail_3}
                    />
                    <Grid xs={6} sm={6} md={3} item className={classes.addon_2}>
                      <Button
                        variant="contained"
                        color="primary"
                        disabled={this.state.serviceSelected.length!=0?false:true}
                        onClick={this.nextChange("panel2")}
                      >
                        Continue2
                      </Button>
                    </Grid>
                  </Grid>

                </ExpansionPanelDetails>
              </ExpansionPanel>
              <ExpansionPanel
                disabled={this.state.step2}
                expanded={expanded === "panel2"}
                onChange={this.handleChange("panel2")}
              >
                <ExpansionPanelSummary className={classes.root_summary}>
                  <Attachment className={classes.icon_7} />
                  <Typography variant="subheading" className={classes.title_3}>
                    Select addons{" "}
                  </Typography>
                  <Typography className={classes.grow}>
                    {this.state.duration != 0
                      ? " Duration: " + this.state.duration + " minutes ,"
                      : " "}
                    {this.state.price != 0
                      ? " Price: " + this.state.price + " USD"
                      : ""}
                  </Typography>
                  <span className={classes.step_c} />
                </ExpansionPanelSummary>
                <Divider />
                <ExpansionPanelDetails className={classes.detail_1}>
                    <Grid container>
                      <Grid item xs={12} sm={12} md={12}>                
                          <div className={classes.cardBody_1}>
                              {this.serviceAddonsTable()}
                        </div>                
                      </Grid>
                    </Grid>   
                
                  <Grid container className={classes.detail_2}>
                    <Grid
                      xs={12}
                      sm={12}
                      md={6}
                      item
                      className={classes.detail_3}
                    />
                    <Grid
                      xs={12}
                      sm={12}
                      md={6}
                      item
                      className={classes.addon_2}
                    >
                      <Button
                        variant="contained"
                        color="secondary"
                        className={classes.button_back}
                        onClick={this.nextChange("panel1")}
                      >
                        Back
                      </Button>
                      <Button
                        variant="contained"
                        color="secondary"
                        className={classes.button}
                        onClick={this.nextChange("panel3")}
                      >
                        Continue
                      </Button>
                    </Grid>
                  </Grid>
                </ExpansionPanelDetails>
              </ExpansionPanel>
              <ExpansionPanel
                disabled={this.state.step3}
                expanded={expanded === "panel3"}
                onChange={this.handleChange("panel3")}
              >
                <ExpansionPanelSummary className={classes.root_summary}>
                  <Timer className={classes.icon_7} />
                  <Typography variant="subheading" className={classes.title_3}>
                    Choose a time
                  </Typography>
                  <Typography className={classes.grow} />
                  <span className={classes.step_c} />
                </ExpansionPanelSummary>

                <ExpansionPanelActions className={classes.action_2}>
                  <Typography>Employee: </Typography>
                  <FormControl
                    variant="outlined"
                    className={classes.formControl}
                  >
                    <Select
                      value={this.state.employeeId}
                      onChange={this.employeeChange}
                      input={
                        <OutlinedInput
                          labelWidth={this.state.labelWidth}
                          name="employeeId"
                          id="employeeId"
                        />
                      }
                    >
                     {this.state.employees.map(row=>(
                      <MenuItem key={row.id} value={row.id}>{row.name}</MenuItem>
                     ))}              
                    
                    </Select>
                  </FormControl>
                  <Typography className={classes.grow} />
                </ExpansionPanelActions>

                <Divider className={classes.hr_cs1} />
                <ExpansionPanelDetails className={classes.detail_1}>
                  <Grid
                    container
                    className={classNames(classes.detail_2, classes.addon_1)}
                  >
                    <Grid
                      xs={12}
                      sm={12}
                      md={5}
                      item
                      className={classes.calander_2}
                    >
                      <DayPicker
                        className={classes.calander_1}
                        disabledDays={{ daysOfWeek: this.state.dayofweek }}
                        onDayClick={this.handleDayClick}
                        selectedDays={this.state.selectedDay}
                      />
                    </Grid>
                    <Grid
                      xs={12}
                      sm={12}
                      md={7}
                      item
                      className={classes.time_4}
                    >
                     
                      <div className={classes.time_3}>                                               
                        {this.state.workTimes.length==0?<Typography
                          variant="subheading"
                          className={classes.title_3}
                        >
                          {this.state.available_date_time}
                        </Typography>:null}
                        <ul className={classes.timBoxes}>
                         {this.state.workTimes.map((row,index)=>(
                           <li key={row} onClick={()=>this.selectTimes(row,index)}>{row}</li>
                         ))}
                        </ul>
                      

                      </div>
                    </Grid>
                  </Grid>
                  <Divider className={classes.hr_cs1} />
                  <Grid container className={classes.detail_2}>
                    <Grid
                      xs={12}
                      sm={12}
                      md={9}
                      item
                      className={classes.detail_3}
                    />
                    <Grid
                      xs={12}
                      sm={12}
                      md={3}
                      item
                      className={classes.addon_2}
                    >
                      <Button
                        variant="contained"
                        color="secondary"
                        className={classes.button_back}
                        onClick={this.nextChange("panel2")}
                      >
                        Back
                      </Button>
                     {/**
                      <Button
                        variant="contained"
                        color="secondary"
                        className={classes.button}
                        onClick={this.nextChange("panel4")}
                      >
                        Continue
                      </Button>
                      */}
                    </Grid>
                  </Grid>
                </ExpansionPanelDetails>
              </ExpansionPanel>
              <ExpansionPanel
                disabled={this.state.step4}
                expanded={expanded === "panel4"}
                onChange={this.handleChange("panel4")}
              >
                <ExpansionPanelSummary className={classes.root_summary}>
                  <Payment className={classes.icon_7} />
                  <Typography variant="subheading" className={classes.title_3}>
                    Confirm and pay
                  </Typography>
                  <Typography className={classes.grow} />
                  <span className={classes.step_c} />
                </ExpansionPanelSummary>
                <ExpansionPanelDetails className={classes.detail_1}>
                  <Grid
                    container
                    className={classNames(classes.detail_2, classes.addon_1)}
                  >
                    <Grid
                      xs={12}
                      sm={12}
                      md={12}
                      item
                      className={classes.confirm_1}
                    >
                      <span>
                        You are about to make a booking at {this.state.company.company_name}{" "}
                        {this.state.day} {this.state.day_d}th {this.state.month}{" "}
                        at {this.state.timepick}. Duration is{" "}
                        {this.state.totalDuration} minutes
                      </span>
                    </Grid>
                  </Grid>
                  <Divider className={classes.hr_cs1} />
                  <Grid container className={classes.detail_2}>
                    <Grid
                      xs={12}
                      sm={12}
                      md={9}
                      item
                      className={classes.detail_3}
                    />
                    <Grid
                      xs={12}
                      sm={12}
                      md={3}
                      item
                      className={classes.addon_2}
                    >
                      <Button
                        variant="contained"
                        color="secondary"
                        className={classes.button_back}
                        onClick={this.nextChange("panel3")}
                      >
                        Back
                      </Button>
                      <Button
                        variant="contained"
                        color="secondary"
                        className={classes.button}
                        onClick={this.nextChange("panel5")}
                      >
                        Confirm
                      </Button>
                    </Grid>
                  </Grid>
                </ExpansionPanelDetails>
              </ExpansionPanel>
              <ExpansionPanel
                disabled={this.state.step5}
                expanded={expanded === "panel5"}
                onChange={this.handleChange("panel5")}
              >
                <ExpansionPanelSummary className={classes.root_summary}>
                  <Receipt className={classes.icon_7} />
                  <Typography variant="subheading" className={classes.title_3}>
                    Receipt
                  </Typography>
                  <Typography className={classes.grow} />
                  <span className={classes.step_c} />
                </ExpansionPanelSummary>
                <ExpansionPanelDetails className={classes.detail_1}>
                  <Grid container className={classes.detail_2}>
                    <Grid
                      xs={12}
                      sm={12}
                      md={9}
                      item
                      className={classes.detail_3}
                    />
                    <Grid
                      xs={12}
                      sm={12}
                      md={3}
                      item
                      className={classes.addon_2}
                    >
                      <Button
                        variant="contained"
                        color="secondary"
                        className={classes.button_back}
                        onClick={this.nextChange("panel4")}
                      >
                        Back
                      </Button>
                      <Button
                        variant="contained"
                        color="secondary"
                        onClick={this.submitBooking}
                        className={classes.button}
                      >
                        Finish
                      </Button>
                    </Grid>
                  </Grid>
                </ExpansionPanelDetails>
              </ExpansionPanel>
            </Grid>
          </Grid>
        </Card>
      {/** dialog */}
      <Dialog
          fullWidth={true}
          maxWidth={'xs'}
          open={this.state.open_dialog}
          onClose={this.dialogClose}
          aria-labelledby="max-width-dialog-title"
          className={classes.dialog_1}     
        >         
          <DialogContent className={classes.dialog_1}>
            <Card >
            <form className={classes.form}>                  
                  <CardBody className={classes.cardBody}>
                  <Grid container className={classes.GridContainer}>
                        <Grid item xs={12} sm={12} md={12}>
                          <Typography  variant="h3" gutterBottom className={classes.signTitle}>
                          {localization.localizedString('LOGIN_FORM_TITLE_CUSTOMER')}
                          <br/>
                          </Typography>
                            <Typography component="p">
                            Manage your booking requests, see previous appointments and more.
                            </Typography>   
                      </Grid>
                  </Grid>
                  <div className={classes.loginFormLayout}>
                  <Grid container className={classes.GridContainer}>
                     <Grid item xs={12} sm={12} md={12}>              
                        <TextField
                            id="phone"
                            label={localization.localizedString('LOGIN_PHONE_LABEL')}
                            InputLabelProps={{
                              classes: {
                                root: classes.cssLabel,
                                focused: classes.cssFocused,
                              },
                            }}
                            InputProps={{
                              type: 'text',
                              classes: {
                                root: classes.cssOutlinedInput,
                                focused: classes.cssFocused,
                                underline: classes.cssUnderline                     
                              },
                              endAdornment: (
                                      <InputAdornment position="end">
                                        <Icon>
                                          <Phone className={classes.inputIconsColor} />
                                        </Icon>
                                      </InputAdornment>
                                    ),
                            }}
                            className={classes.textField}
                            value={phone}
                            onChange={this.handleTxtChange('phone')}
                            margin="normal"
                            fullWidth
                          />
                      </Grid>
                    </Grid>
                <Grid container className={classes.GridContainer}>
                  <Grid item xs={12} sm={12} md={12}> 
                    <TextField
                            id="password"
                            label={localization.localizedString('LOGIN_PASSWORD_LABEL')}
                            InputLabelProps={{
                              classes: {
                                root: classes.cssLabel,
                                focused: classes.cssFocused,
                              },
                            }}
                            InputProps={{
                              type: 'password',
                              classes: {
                                root: classes.cssOutlinedInput,
                                focused: classes.cssFocused,
                                underline: classes.cssUnderline                  
                              },
                              endAdornment: (
                                    <InputAdornment position="end">
                                      <Icon>
                                        <LockOutlined className={classes.inputIconsColor} />
                                      </Icon>
                                     </InputAdornment>
                                    ),
                            }}
                            className={classes.textField}
                            value={password}
                            onChange={this.handleTxtChange('password')}
                            margin="normal"
                            fullWidth
                          />
                   </Grid>
                 </Grid>
                 </div>
                  </CardBody>
                  <CardFooter className={classes.cardFooterBycustomer_1}>
                   
                      <Grid item xs={12} sm={12} md={6} lg={6} xl={6}>
                      <Button
                        variant="contained"
                        color="secondary"
                        className={classes.button_back}                        
                        onClick={this.logIn}
                      >
                        Log in
                      </Button>
                        
                      </Grid>
                      <Grid item xs={12} sm={12} md={6} lg={6} xl={6} style={{textAlign:'right'}}>
                        <Link to="/signup" className={classes.link_1}>
                          {localization.localizedString('LOGIN_CREATE_COMPANY_LINK')}
                        </Link>
                      </Grid>
                   
                  </CardFooter>
                </form>
            </Card>  
          </DialogContent>
      </Dialog>   
      {/** dialog */} 
      </div>
    );
  }
}

export default withStyles(landingPageStyle)(withNotifications(withLocalization(withAuth(CompanyLandingPage))));