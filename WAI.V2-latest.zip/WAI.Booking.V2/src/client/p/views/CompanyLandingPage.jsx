import React from "react";
import ReactDOM from "react-dom";
import withStyles from "@material-ui/core/styles/withStyles";
import GridList from "@material-ui/core/GridList";
import GridListTile from "@material-ui/core/GridListTile";
import Hidden from "@material-ui/core/Hidden";
import withLocalization from "common/contexts/LocalizationContext";
import GridContainer from "common/components/Grid/GridContainer";
import Grid from "@material-ui/core/Grid";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import Card from "@material-ui/core/Card";
import InputAdornment from '@material-ui/core/InputAdornment';
import Button from "@material-ui/core/Button";
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import moment from 'moment';
import Success from '@material-ui/icons/CheckCircle';
import TableRow from '@material-ui/core/TableRow';
import Dialog from '@material-ui/core/Dialog';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Tooltip from '@material-ui/core/Tooltip';
import {  withSnackbar } from 'notistack';
import GoogleMapReact from 'google-map-react';
//import { GoogleApiWrapper, InfoWindow, Map, Marker } from 'google-maps-react';
import Link from 'react-router-dom/es/Link';
import axios from 'axios';
import PaypalExpressBtn from 'react-paypal-express-checkout';
import ExpansionPanel from "@material-ui/core/ExpansionPanel";
//import MuiExpansionPanel from '@material-ui/core/ExpansionPanel';
//import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import MuiExpansionPanelSummary from "@material-ui/core/ExpansionPanelSummary";
//import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import MuiExpansionPanelDetails from "@material-ui/core/ExpansionPanelDetails";
import Divider from "@material-ui/core/Divider";
import Typography from "@material-ui/core/Typography";
import Checkbox from "@material-ui/core/Checkbox";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import ExpansionPanelActions from "@material-ui/core/ExpansionPanelActions";
import Select from "@material-ui/core/Select";
import OutlinedInput from "@material-ui/core/OutlinedInput";
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import Input from "@material-ui/core/Input";
import InputLabel from "@material-ui/core/InputLabel";
import classNames from "classnames";
import Chip from "@material-ui/core/Chip";
import TextField from "@material-ui/core/TextField";
import Icon from "@material-ui/core/Icon";
import LocationOn from "@material-ui/icons/LocationOn";
import Phone from "@material-ui/icons/Phone";
import Email from "@material-ui/icons/Email";
import Category from "@material-ui/icons/Book";
import Attachment from "@material-ui/icons/SpeakerNotes";
import Timer from "@material-ui/icons/Timer";
import Payment from "@material-ui/icons/Payment";
import Receipt from "@material-ui/icons/Receipt";
import LockOutlined from '@material-ui/icons/LockOutlined';
import DayPicker from "react-day-picker";
import GridListTileBar from "@material-ui/core/GridListTileBar";
import StarBorderIcon from "@material-ui/icons/StarBorder";
import IconButton from "@material-ui/core/IconButton";
import Avatar from "@material-ui/core/Avatar";
import DoneIcon from '@material-ui/icons/Done';
import FormHelperText from '@material-ui/core/FormHelperText';
import Header from "../components/Header/Header";
import CardFooter from '../../common/components/Card/CardFooter';
import LoginButton from 'common/containers/LoginButton/LoginButton';
//import Card from "../../common/components/Card/Card.jsx";
import CardBody from "../../common/components/Card/CardBody.jsx";
import CustomInput from "../../common/components/CustomInput/CustomInput.jsx";
import HeaderLinks from "../components/Header/HeaderLinks";
import landingPageStyle from "../assets/jss/views/landingPage";
import tileData from "../assets/jss/components/tileData";
import withAuth from 'common/contexts/AuthContext';
import withNotifications from 'common/contexts/NotificationsContext';
import Fullscreen from "../components/Fullscreen/Fullscreen";
import Marker from "../components/Marker/Marker";
import Signup from "../components/Signup/Signup";
import markerPng from "../assets/img/pin1.png";
import "../assets/style.css";
//import 'react-day-picker/lib/style.css';
const dashboardRoutes = [];

const ExpansionPanelSummary = withStyles({
  root: {
    //backgroundColor: 'rgba(0,0,0,.03)',
    borderBottom: "1px solid rgba(0,0,0,.125)",
    boxShadow:
      "0 4px 20px 0px rgba(0, 0, 0, 0.14), 0 7px 10px -5px rgba(179, 172, 177, 1)",
    marginBottom: -1,
    minHeight: 56,
    "&$expanded": {
      minHeight: 56
    }
  },
  content: {
    "&$expanded": {
      margin: "12px 0"
    }
  },
  expanded: {}
})(props => <MuiExpansionPanelSummary {...props} />);

ExpansionPanelSummary.muiName = "ExpansionPanelSummary";
const ExpansionPanelDetails = withStyles(theme => ({
  root: {
    padding: theme.spacing.unit * 2
  }
}))(MuiExpansionPanelDetails);

function getStyles(name, personName) {
  return {
    fontWeight: personName.indexOf(name) === -1 ? "500" : "300"
  };
}
(function() {
  var days = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday"
  ];
  var months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
  ];

  Date.prototype.getMonthName = function() {
    return months[this.getMonth()];
  };
  Date.prototype.getDayName = function() {
    return days[this.getDay()];
  };
})();

class CompanyLandingPage extends React.Component {
  
  constructor(props) {
    super(props);
    this.state = {     
      expanded: "panel1",
      addons: [],
      labelWidth: 0,
      currentPanel: 1,
      duration: 0,
      price: 0,
      timepick: "",
      month: "",
      day: "",
      day_d: "",
      step1: false,
      step2: true,
      step3: true,
      step4: true,
      step5: true,
      cellHeight: 215,
      selectedDay: undefined,
      employee: "Employee 1",
      dayofweek: [0,1,2,3,4,5,6],
      available_date_time: "Please select booking day and time.", 
      category: [],
      company:[],
      services:[],
      defaultCategory:0,
      category_description:'',
      serviceSelected:[],
      serviceAddons:[],
      addonsSelected:[],
      employees:[],
      filtered_employees:[],//employee was filtered by servicId
      employeeId:'',
      workHours:[],//from db,
      workTimes:[],// converted times
      workTimesShadow:[],//real minutes for work times
      bookingFrom:'',
      bookingTo:'',
      totalDuration:'',
      pickedDate:'',
      categoryName:'',
      open_dialog:false,
      open_forgot_dialog:false,
      dialog_employee_time:false,
      password:'',
      phone:'',
      openImage:false,
      imgSrc:'',
      paymentSetting:[],
      currency:'DKK',
      paypal_key:'1',
      openSignup:false,
      payment_upfront:1,
      labelTime:'',
      remember_me:false,
      selectedTimeIndex:undefined,
      paid:0,
      payment_method_id:0,//1:paypal, 2:MasterCard,3:VISA,4:Dankort,
      txid:0,
      cashAmount:0,
      paymentAmount:0,
      images:{},
      center:{lat:55.689512,lng: 12.5806305},
      lat:55.6974447,//56.099185,
      lng:12.5806305,//9.248742
      selected_serviceId:'', //when service checkbox is seleced in select service panel
      employee_service_relations:[],
      extra_service_relations:[],
      booking_block:[],
      selected_employees_services:[],// they was selected with service id on the modal.
      employee_error:false,
      terms_service:[],
      discountCards:[],
      selected_serviceDiscountCard:false,
      selectedDiscountCards:[],
      selectedDiscountCardId:'',
      dialog_extra_discountCard:false,
      selected_extraDiscountCard:false,
      selectedAddonId:'',
      giftCards:[],
      giftCardCode:'',
      dialog_giftCard_code:false,
      giftCardId:'',
      giftCard_amount:'',
      discountCodes:[],
      discountCode:'',
      dialog_discount_code:false,
      discountCodeId:'',
      pickedDateTime:'',
      discountCodeUsedAmount:0
    };
    this.selectChange = this.selectChange.bind(this);
    this.addonsChange = this.addonsChange.bind(this);  
    this.employeeChange = this.employeeChange.bind(this);
    this.handleDayClick = this.handleDayClick.bind(this);
    this.updateWindowDimensions = this.updateWindowDimensions.bind(this);
  }

  async componentWillMount (){
    console.log(this.props);
    const {id}=this.props.match.params;  
    var  {data} = await axios.get('/api/customer/company/'+id+'/customurl');  
    if(data.success){      
       var temp={};
       temp.lat=data.company.lat;
       temp.lng=data.company.lng;      
      this.setState({company:data.company,
        center:temp,
        lat:data.company.lat,
        lng:data.company.lng,
        payment_upfront:data.company.payment_upfront,
        currency:data.company.currency_code,
        paymentSetting:data.paymentSetting,
        paypal_key:data.paymentSetting.paypalKey,
        images:data.images==null?{}:data.images
      });
      var  {data} = await axios.get('/api/customer/company/'+data.company.id+'/services');  
       console.log(data)     ;
        if(data.success){
          this.setState({
            category:data.serviceCategories,
            services:data.services,
            serviceAddons:data.serviceExtras,
            employees:data.employees,
            workHours:data.bookingHours,
            employee_service_relations:data.employee_service_relations,
            extra_service_relations:data.extra_service_relations,
            terms_service:data.terms_service,
            discountCards:data.discountCard,
            giftCards:data.giftCard,
            discountCodes:data.discountCode
          })
          data.serviceCategories.map(row=>{            
            if(row.defaultServiceCategory){
              this.setState({defaultCategory:row.id,
                categoryName:"Category: "+row.name,
                category_description:row.description
              });              
            }
          })
        }         
    }
   
  }
 async componentDidMount() {    
    window.addEventListener("resize", this.updateWindowDimensions);
    if (window.innerWidth < 1114 && window.innerWidth > 940) {
      this.setState({ cellHeight: 140 });
    } 
    else if (window.innerWidth < 1315 && window.innerWidth > 1114) {
      this.setState({ cellHeight: 190 });
    }
    else if (window.innerWidth < 450) {
      this.setState({ cellHeight: 125 });
    } else {
      this.setState({ cellHeight: 215 });
    }

    const { auth: { isAuth, user }, history,auth } = this.props;    
    if (!isAuth && !user) {    
      if(this.getCookie('customer_email')!='' && this.getCookie('customer_password')!='' ){              
        let userData={};
        userData.phone=this.getCookie('customer_email');
        userData.password=this.getCookie('customer_password');
        const result = await auth.login(userData);
      }
    }
  }
  getCookie=(cname)=>{
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i < ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }
  componentWillUnmount() {
    window.removeEventListener("resize", this.updateWindowDimensions);
  }
  updateWindowDimensions() {
    if (window.innerWidth < 1114 && window.innerWidth > 940) {
      this.setState({ cellHeight: 140 });
    } else if (window.innerWidth < 450) {
      this.setState({ cellHeight: 125 });
    } 
    else if (window.innerWidth < 1315 && window.innerWidth > 1114) {
      this.setState({ cellHeight: 190 });
    }
    else {
      this.setState({ cellHeight: 215 });
    }
  }
  handleToggle = prop => event => this.setState({ [prop]: event.target.checked });
  handleTxtChange = prop => event => {
    this.setState({ [prop]: event.target.value });
  };
  handleChange_1 = prop => event => this.setState({ [prop]: event.target.value });
  handleChange = panel => (event, expanded) => {
    var position = panel.substr(5, 1);
    if (parseInt(position) <= this.state.currentPanel) {
      this.setState({
        expanded: expanded ? panel : false,
        currentPanel: parseInt(position)
      });
    }
    for (var i = parseInt(position) + 1; i <= 5; i++) {
      var steps = "step" + i;
      this.setState({
        [steps]: true
      });
    }
  };

  /**
   * it is the continue event
   */
  nextChange = panel => () => {   
    if(!this.props.auth.isAuth){
      this.setState({open_dialog:true});
      return;
    } 
    var position = panel.substr(5, 1);
    this.setState({
      expanded: panel,
      currentPanel: parseInt(position)
    });

    var position = panel.substr(5, 1);
    for (var i = 1; i <= parseInt(position); i++) {
      var steps = "step" + i;    
      this.setState({
        [steps]: false
      });
    }

    for (var i = parseInt(position) + 1; i <= 5; i++) {
      var steps = "step" + i;      
      this.setState({
        [steps]: true
      });
    }

    var {addonsSelected,//selected addons
      serviceAddons,
      extra_service_relations,//relation
      selected_employees_services// block model
    }=this.state;   
    if(panel=='panel3'){
      var array=[];
      selected_employees_services.map(element=>{
        element.extraIds=[];
        array.push(element);
      })

      var temp_block_array=[];
      extra_service_relations.map(row=>{    
        //var temp_array=[];//item.extraIds;      
          if(addonsSelected.indexOf(row.extraId)!=-1){
             temp_block_array=[];
           array.map(item=>{   
          //  selected_employees_services.map(item=>{              
                if(row.serviceId==item.serviceId){  
                                      
                 var temp_array=item.extraIds;                
                  var block_item=item; 
                  var price=parseFloat(item.price);
                  var duration=parseInt(item.duration);
                  
                  serviceAddons.map(addon=>{
                    if(addon.id==row.extraId){
                      price+=parseFloat(addon.price);
                      duration+=parseInt(addon.duration);                     
                    }
                  })
                  temp_array.push(row.extraId);
                  block_item.extraIds=temp_array;                   
                  block_item.price=price;
                  block_item.duration=duration;                 
                  temp_block_array.push(block_item);
                }
                else{
                  temp_block_array.push(item)
                }
            })           
         this.setState({selected_employees_services:temp_block_array});
          }
      })
      console.log(temp_block_array,'temp_block_array');
     // this.setState({selected_employees_services:temp_block_array});
    /** choose time section */
    const {workHours}=this.state;
    var dayofweek=[];
    var workTimeIsSet=false;
    var employeeIds=[];
   // selected_employees_services.map(item=>{
    temp_block_array.map(item=>{
      employeeIds.push(item.employeeId);
    })    
    dayofweek.slice(0,1);
     workHours.map(row=>{
         if(employeeIds.indexOf(row.employeeId)!=-1){
              workTimeIsSet=true;
             if(!row.mondayIsOpen){
               dayofweek.push(1);
             }
              if(!row.tuesdayIsOpen){
               dayofweek.push(2);
             }
              if(!row.wednesdayIsOpen){
               dayofweek.push(3);
             }
              if(!row.thursdayIsOpen){
               dayofweek.push(4);
             }
              if(!row.fridayIsOpen){
               dayofweek.push(5);
             }
              if(!row.saturdayIsOpen){
               dayofweek.push(6);
             }
              if(!row.sundayIsOpen){
               dayofweek.push(0);
             }       
         }
     });
     if(!workTimeIsSet){
       dayofweek=[0,1,2,3,4,5,6];
     }    
     this.setState({
       [event.target.name]: event.target.value,
       dayofweek:dayofweek,
       workTimes:[],
       bookingFrom:'',
       bookingTo:'',
       pickedDate:''
     });
    /** end choose time section */
    }
    
  };

  selectChange(event) {  

    this.state.category.map(row=>{
      if(row.id==event.target.value){
          this.setState({categoryName:"Category: "+row.name,category_description:row.description});
      }
    })
   
    this.setState({
      [event.target.name]: event.target.value
    });
  }
  employeeChange(event) { 
   /**
    const {workHours}=this.state;
   var dayofweek=[];
   var workTimeIsSet=false;
   dayofweek.slice(0,1);
    workHours.map(row=>{
        if(row.employeeId==event.target.value){
             workTimeIsSet=true;
            if(!row.mondayIsOpen){
              dayofweek.push(1);
            }
             if(!row.tuesdayIsOpen){
              dayofweek.push(2);
            }
             if(!row.wednesdayIsOpen){
              dayofweek.push(3);
            }
             if(!row.thursdayIsOpen){
              dayofweek.push(4);
            }
             if(!row.fridayIsOpen){
              dayofweek.push(5);
            }
             if(!row.saturdayIsOpen){
              dayofweek.push(6);
            }
             if(!row.sundayIsOpen){
              dayofweek.push(0);
            }       
        }
    });
    if(!workTimeIsSet){
      dayofweek=[0,1,2,3,4,5,6];
    }    
    this.setState({
      [event.target.name]: event.target.value,
      dayofweek:dayofweek,
      workTimes:[],
      bookingFrom:'',
      bookingTo:'',
      pickedDate:''
    });
 */
      this.setState({
        [event.target.name]: event.target.value,employee_error:false

      });

  } 
  addonsChange(event) {
    this.setState({
      addons: event.target.value
    });
  }
  time_convert=(num)=>{ 
    var hours = Math.floor(num / 60);  
    var minutes = num % 60;
    minutes= minutes > 9 ? "" + minutes: "0" + minutes;
    return hours + ":" + minutes;         
  }

  fllScreenClose=()=>{   
    this.setState({openImage:false});
  }
  signUpClose=()=>{
    this.setState({openSignup:false});
  }
  /*
  * it is the part when the day is clicked on the calendar.
  */
 async handleDayClick(day, { selected, disabled }) {
    if (disabled) {
      // Day is disabled, do nothing
      return;
    }  
    //var now = new Date(day.toLocaleDateString());
    var now= new Date(day);
    var today=new Date();       
    if(moment(day).format('YYYY-MM-DD')<moment(today).format('YYYY-MM-DD')){
      return;
    }
    if (selected) {
      // Unselect the day if already selected
      this.setState({
        selectedDay: undefined,
        workTimes:[],
        workTimesShadow:[],       
        available_date_time: "Please select booking day and time."
      });
      return;
    }     
    var converted_day=moment(day).format('YYYY-MM-DD');  
    var temp_from=[];
    var temp_to=[];   
    const {workHours,selected_employees_services}=this.state;
    var temp=[];
    var tempShadow=[];
    var employee_work_array=[];    
    var employeeIds=[];
    selected_employees_services.map(item=>{
      employeeIds.push(item.employeeId);
    })

   
    var  {data} = await axios.post('/api/customer/employee/booked/times',
      {       
        day:converted_day,
        employeeIds:employeeIds
     });  
     console.log(data,'employee booked times');
     if(data.success){
     
      data.bookings.map(row=>{
        temp_from.push(moment(row.bookFrom).format('YYYY-MM-DD HH:mm'));
        temp_to.push(moment(row.bookTo).format('YYYY-MM-DD HH:mm'));      
       });
 
     }
   

    console.log(employeeIds,'employee Ids');
    var open_at_array=[];
    var close_at_array=[];
    var interval=parseInt(this.state.company.interval);  
    workHours.map(row=>{
      var employee_work_item={};// employeeId:int, open_at:60, close_at:120      
        //if(row.employeeId==this.state.employeeId){
       if(employeeIds.indexOf(row.employeeId)!=-1){
           var open_at=0;
           var close_at=0;
                 
          if (now.getDayName() == "Monday") {
            var hms_open=row.mondayOpenAt;
            var open = hms_open.split(':');
            var hms_close=row.mondayCloseAt;
            var close=hms_close.split(':');
            open_at=parseInt(open[0]*60)+parseInt(open[1]);            
            close_at=parseInt(close[0]*60)+parseInt(close[1]);             
          }
          else if(now.getDayName() == "Tuesday"){
            var hms_open=row.tuesdayOpenAt;
            var open = hms_open.split(':');
            var hms_close=row.tuesdayCloseAt;
            var close=hms_close.split(':');
            open_at=parseInt(open[0]*60)+parseInt(open[1]);            
            close_at=parseInt(close[0]*60)+parseInt(close[1]); 
          }
          else if(now.getDayName() == "Wednesday"){
            var hms_open=row.wednesdayOpenAt;
            var open = hms_open.split(':');
            var hms_close=row.wednesdayCloseAt;
            var close=hms_close.split(':');
            open_at=parseInt(open[0]*60)+parseInt(open[1]);            
            close_at=parseInt(close[0]*60)+parseInt(close[1]); 
          }
          else if(now.getDayName() == "Thursday"){
            var hms_open=row.thursdayOpenAt;
            var open = hms_open.split(':');
            var hms_close=row.thursdayCloseAt;
            var close=hms_close.split(':');
            open_at=parseInt(open[0]*60)+parseInt(open[1]);            
            close_at=parseInt(close[0]*60)+parseInt(close[1]); 
          }
          else if(now.getDayName() == "Friday"){
            var hms_open=row.fridayOpenAt;
            var open = hms_open.split(':');
            var hms_close=row.fridayCloseAt;
            var close=hms_close.split(':');
            open_at=parseInt(open[0]*60)+parseInt(open[1]);            
            close_at=parseInt(close[0]*60)+parseInt(close[1]); 
          }
          else if(now.getDayName() == "Saturday"){
            var hms_open=row.saturdayOpenAt;
            var open = hms_open.split(':');
            var hms_close=row.saturdayCloseAt;
            var close=hms_close.split(':');
            open_at=parseInt(open[0]*60)+parseInt(open[1]);            
            close_at=parseInt(close[0]*60)+parseInt(close[1]); 
          }
          else if(now.getDayName() == "Sunday"){
            var hms_open=row.sundayOpenAt;
            var open = hms_open.split(':');
            var hms_close=row.sundayCloseAt;
            var close=hms_close.split(':');
            open_at=parseInt(open[0]*60)+parseInt(open[1]);            
            close_at=parseInt(close[0]*60)+parseInt(close[1]); 
          }              
            selected_employees_services.map(block=>{
              if(block.employeeId==row.employeeId){
                employee_work_item.duration=block.duration;
              }
            })    
            employee_work_item.employeeId=row.employeeId;
            employee_work_item.open_at=open_at;
            employee_work_item.close_at=close_at;
            employee_work_array.push(employee_work_item);
            open_at_array.push(open_at);
            close_at_array.push(close_at);
            //for(var i=open_at;i<=close_at;i=i+interval){
            //  var flag=false;
             
              //check if time is already booked.
              /**
              temp_from.map((item,index)=>{
                  if(moment(converted_day+" "+this.time_convert(i)).isBetween(item,temp_to[index],null, '[)')){
                    flag=true;
                  }
              });
              */
               
             // if(!flag){
             //     temp.push(this.time_convert(i));
            //      tempShadow.push(i);
             //   }             
           // }
            
        }
    });    
 /**
  * this is the section to get the eariliest open time and latest time
  */
   
    console.log(employee_work_array);
   for(var i=Math.min.apply(null, open_at_array);i<=Math.max.apply(null, close_at_array);i=i+interval){
      var is_possible=1; 
      var employee_work_array_shadow=employee_work_array;
      employee_work_array.map(row=>{
        var working_duration=parseInt(row.duration)+parseInt(i)    
        var open_at=parseInt(row.open_at); 
        var close_at=parseInt(row.close_at);
       
        if(working_duration>=open_at && working_duration<=close_at){  
          employee_work_array_shadow.map(item=>{
            if(item.employeeId!=row.employeeId && working_duration<item.open_at ){//next open at
              is_possible= is_possible*0;             
            }
            else{              
              is_possible= is_possible*1;
            }
          })
        }
        else{
          is_possible= is_possible*0;
        }

      });

      var flag=false;
      temp_from.map((item,index)=>{
        if(moment(converted_day+" "+this.time_convert(i)).isBetween(item,temp_to[index],null, '[)')){
          flag=true;
        }
      });

      if(!flag && is_possible){
        temp.push(this.time_convert(i));
        tempShadow.push(i);
      }     
   }
 
   /**
      var look_block=employee_work_array;
   var open_at=[];
   employee_work_array.map(row=>{
     var duration=parseInt(row.duration);     
     var close_at=parseInt(row.close_at);    
     var is_possible=1;  
     var sub_val=0;
      look_block.map(item=>{
        sub_val=parseInt(row.open_at)-parseInt(item.open_at);
        
        if(sub_val<parseInt(row.duration)){       
          console.log(sub_val,parseInt(row.duration),row.employeeId,'yyyttt');   
          is_possible=is_possible * 1;
          open_at.push(row.open_at);
        }
        else{
          is_possible=is_possible * 0;
        }
      })
      
      
      if(is_possible){
        console.log(row.open_at,row.employeeId,'ggg');
        open_at.push(row.open_at);
      }
       
   })

   console.log(open_at,'open at');
 */
   console.log(open_at_array,temp,'open at array');
  
    this.setState({
      selectedDay: day,
      month: now.getMonthName(),
      day: now.getDayName(),
      day_d: now.getDate(),
      workTimes:temp,
      workTimesShadow:tempShadow,
     // pickedDate:day_temp[2]+"-"+day_temp[0]+"-"+day_temp[1],     
      pickedDate:converted_day,
      timepick:'',
      totalDuration:'',
      labelTime:'',
      selectedTimeIndex:undefined
    });
     
  }
  /**
   * in choose time panel, it is the event when time is clicked.
   */
  selectTimes=(time,index)=>{    
    const {services,serviceSelected,serviceAddons,addonsSelected,pickedDate,workTimesShadow}=this.state;
    var totalDuration=0;
    var totalPrice=0;
    services.map(row=>{
      if(serviceSelected.indexOf(row.id)!=-1){
        totalDuration=totalDuration+parseInt(row.duration);
        totalPrice=totalPrice+parseFloat(row.price);
      }
    })

    serviceAddons.map(row=>{
      if(addonsSelected.indexOf(row.id)!=-1){
        totalDuration=totalDuration+parseInt(row.duration);
        totalPrice=totalPrice+parseFloat(row.price);
      }
    })    
    var toTemp=parseInt(workTimesShadow[index])+parseInt(totalDuration);    
    this.setState({bookingFrom:this.state.pickedDate+" "+time+":00",
        bookingTo:this.state.pickedDate+" "+this.time_convert(toTemp)+":00",
        timepick:time,
        totalDuration:totalDuration,
        price:totalPrice,
        labelTime:"(" +moment(this.state.pickedDate+" "+time).format('YYYY-MM-DD HH:mm')+")",
        pickedDateTime:moment(this.state.pickedDate+" "+time).format('YYYY-MM-DD HH:mm:ss'),
        selectedTimeIndex:index       
    }); 
   
  }

  submitBooking=async()=>{
    const {localization}=this.props;
    const {company,serviceSelected,bookingFrom,bookingTo,
      totalDuration,addonsSelected,employeeId,paid,
      payment_method_id,txid,price,
      cashAmount,paymentAmount,selected_employees_services,selectedDiscountCards,
      giftCardId,giftCard_amount,discountCodeId,discountCodeUsedAmount}=this.state;
      
      var { data} = await axios.post("/api/customer/company/"+company.id+"/booking", {
      book:{         
        bookingData:selected_employees_services,
        bookFrom:bookingFrom,
        bookTo:bookingTo,
        employeeId:employeeId,
        paid:paid,
        discountCards:selectedDiscountCards,
        giftCardId:giftCardId,
        giftCardAmountUsed:giftCard_amount,
        discountCodeId:discountCodeId,
        discountCodeUsedAmount:discountCodeUsedAmount

      }});
    
      if(data.success){
        if(paid){
          var { data} = await axios.post("/api/customer/company/"+company.id+"/booking/payment", {
            payment:{            
              bookingId:data.booking.id,
              paymentMethodId:payment_method_id,
              txid:txid,
              totalAmount:price,
              paymentAmount:price,
              cashAmount:cashAmount
            }}); 
            if(!data.success){             
              this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
                variant: 'error',
              });  
            }
            else{             
              this.props.enqueueSnackbar(localization.localizedString('BOOKING_SUCCESS'), { 
                variant: 'success',
              });
            }
          }
          else{
            this.props.enqueueSnackbar(localization.localizedString('BOOKING_SUCCESS'), { 
              variant: 'success',
            });           
          }           

        this.setState({
          expanded: 'panel1',
          currentPanel: 1,
          step1:false,
          serviceSelected:[],
          addonsSelected:[],
          bookingFrom:'',
          bookingTo:'',
          totalDuration:'',
          paid:0,
          paymentAmount:0,
          cashAmount:0,
          selected_employees_services:[],
          dayofweek:[],
          selected_serviceId:0,
          filtered_employees:[],
          selectedDay: undefined
          //step3:false
        });
      }
      else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        });  
      }
  }
  /*
  ** in panel1, it  is the event of when checkbox is seleced.
  */
  serviceClick= (event, id) => { 
    this.setState({selected_serviceId:id, selected_serviceDiscountCard:false,selectedDiscountCardId:''});
   
    if(!event.target.checked){
      const { serviceSelected,selected_employees_services,
        selectedDiscountCards,discountCards} = this.state;
      var selectedIndex = serviceSelected.indexOf(id);
      let newSelected = [];
      if (selectedIndex === -1) {
        newSelected = newSelected.concat(serviceSelected, id);
      } 
      else if (selectedIndex === 0) {
        newSelected = newSelected.concat(serviceSelected.slice(1));
      } else if (selectedIndex === serviceSelected.length - 1) {
        newSelected = newSelected.concat(serviceSelected.slice(0, -1));
      } else if (selectedIndex > 0) {
        newSelected = newSelected.concat(
          serviceSelected.slice(0, selectedIndex),
          serviceSelected.slice(selectedIndex + 1),
        );
      }  

      var temp_array=[];
      selected_employees_services.map(row=>{
         if(row.serviceId!=id){
           temp_array.push(row);
         }
      })

        /** discount card */
        let newSelected2 = [];     
        discountCards.map(item=>{
          if(item.serviceId==id){
           
            var idd=item.id;
            var selectedIndex = selectedDiscountCards.indexOf(idd);
            let newSelected2 = [];           
              if (selectedIndex === 0) {
                newSelected2 = newSelected2.concat(selectedDiscountCards.slice(1));
              } else if (selectedIndex === selectedDiscountCards.length - 1) {
                newSelected2 = newSelected2.concat(selectedDiscountCards.slice(0, -1));
              } else if (selectedIndex > 0) {
                newSelected2 = newSelected2.concat(
                  selectedDiscountCards.slice(0, selectedIndex),
                  selectedDiscountCards.slice(selectedIndex + 1),
                );
              }
              console.log(selectedDiscountCards,newSelected2);  
              this.setState({  selectedDiscountCards:newSelected2});         
          }
        })
        /**  */       
      this.setState({ serviceSelected: newSelected,      
        addonsSelected:[],
        price:0,
        dialog_employee_time:false,
        selectedDiscountCardId:'',
       
        employeeId:'',
        selected_employees_services:temp_array
      });
    }
    else{     
      var temp=[];
      this.state.employee_service_relations.map(row=>{
          if(row.serviceId==id)
            temp.push(row.employeeId)
      })
      this.setState({dialog_employee_time:true,filtered_employees:temp,employeeId:''});
    }
    
    
  }
  /*
  * this event is from after employee was selected and then ok button was clicked on the modal box.
  */
  selected_serivce=()=>{        
    const { serviceSelected,selected_serviceId ,employeeId,selected_employees_services,services,
      selectedDiscountCardId,selectedDiscountCards} = this.state;
    if(employeeId==''){
      this.setState({employee_error:true});
      return;
    }
    var id=selected_serviceId;
    var temp_block={};
    var temp_array=selected_employees_services;
    var duration=0;
    var price=0;
    services.map(row=>{
      if(row.id==id){
        duration+=parseInt(row.duration);
        price+=parseFloat(row.price);
      }
    })
    temp_block.duration=duration;
    temp_block.price=price;
    temp_block.serviceId=id;
    temp_block.employeeId=employeeId;
    temp_block.extraIds=[];
    temp_array.push(temp_block);
  
    var selectedIndex = serviceSelected.indexOf(id);
    let newSelected = [];
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(serviceSelected, id);
    } 
    else if (selectedIndex === 0) {
      newSelected = newSelected.concat(serviceSelected.slice(1));
    } else if (selectedIndex === serviceSelected.length - 1) {
      newSelected = newSelected.concat(serviceSelected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        serviceSelected.slice(0, selectedIndex),
        serviceSelected.slice(selectedIndex + 1),
      );
    }  
    /** discount card */    
    var id=selectedDiscountCardId;
    var selectedIndex = selectedDiscountCards.indexOf(id);
    let newSelected2 = [];
    console.log(selectedDiscountCardId,'selected discount card');
    if(id!=''){
      if (selectedIndex === -1) {
        newSelected2 = newSelected2.concat(selectedDiscountCards, id);
      } else if (selectedIndex === 0) {
        newSelected2 = newSelected2.concat(selectedDiscountCards.slice(1));
      } else if (selectedIndex === selectedDiscountCards.length - 1) {
        newSelected2 = newSelected2.concat(selectedDiscountCards.slice(0, -1));
      } else if (selectedIndex > 0) {
        newSelected2 = newSelected2.concat(
          selectedDiscountCards.slice(0, selectedIndex),
          selectedDiscountCards.slice(selectedIndex + 1),
        );
      }
    }
    else{
      newSelected2=selectedDiscountCards;
    }
    /**  */
   
    this.setState({ serviceSelected: newSelected,
      selectedDiscountCards:newSelected2,
      addonsSelected:[],
      price:0,
      dialog_employee_time:false,
      selected_employees_services:temp_array
     });
    
  }

  /**  */
  selected_extraDiscountCard=()=>{
    const {selectedDiscountCardId,selectedDiscountCards}=this.state;
    /** discount card */    
    var id=selectedDiscountCardId;
    var selectedIndex = selectedDiscountCards.indexOf(id);
    let newSelected2 = [];    
    if(id!=''){
      if (selectedIndex === -1) {
        newSelected2 = newSelected2.concat(selectedDiscountCards, id);
      } else if (selectedIndex === 0) {
        newSelected2 = newSelected2.concat(selectedDiscountCards.slice(1));
      } else if (selectedIndex === selectedDiscountCards.length - 1) {
        newSelected2 = newSelected2.concat(selectedDiscountCards.slice(0, -1));
      } else if (selectedIndex > 0) {
        newSelected2 = newSelected2.concat(
          selectedDiscountCards.slice(0, selectedIndex),
          selectedDiscountCards.slice(selectedIndex + 1),
        );
      }
    }
    else{
      newSelected2=selectedDiscountCards;
    }
    console.log(newSelected2);
    this.setState({selectedDiscountCards:newSelected2,dialog_extra_discountCard:false})
  }
  /*
  * it is the event of when addon checkbox is selected on panel2
  */
  addonsClick= (event, id) => {    
    const { addonsSelected,discountCards,selectedDiscountCards } = this.state;
    const selectedIndex = addonsSelected.indexOf(id);
    let newSelected = [];
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(addonsSelected, id);
    } 
    else if (selectedIndex === 0) {
      newSelected = newSelected.concat(addonsSelected.slice(1));
    } else if (selectedIndex === addonsSelected.length - 1) {
      newSelected = newSelected.concat(addonsSelected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        addonsSelected.slice(0, selectedIndex),
        addonsSelected.slice(selectedIndex + 1),
      );
    }  
    if(event.target.checked) {
      var discountId='';       
      discountCards.map(item=>{       
          if(item.serviceExtraId==id){
            discountId=item.id;                   
          }
      })     
      if(discountId!=''){
        this.setState({dialog_extra_discountCard:true});
      }
    }
    else{
           /** discount card */
        let newSelected2 = [];     
        discountCards.map(item=>{
          if(item.serviceExtraId==id){
           
            var idd=item.id;
            var selectedIndex = selectedDiscountCards.indexOf(idd);
            let newSelected2 = [];           
              if (selectedIndex === 0) {
                newSelected2 = newSelected2.concat(selectedDiscountCards.slice(1));
              } else if (selectedIndex === selectedDiscountCards.length - 1) {
                newSelected2 = newSelected2.concat(selectedDiscountCards.slice(0, -1));
              } else if (selectedIndex > 0) {
                newSelected2 = newSelected2.concat(
                  selectedDiscountCards.slice(0, selectedIndex),
                  selectedDiscountCards.slice(selectedIndex + 1),
                );
              }
              console.log(selectedDiscountCards,newSelected2);
              this.setState({selectedDiscountCards:newSelected2});       
          }
        })
        /**  */     
    }
    
   
    this.setState({ addonsSelected: newSelected,selectedAddonId:id,price:0,selected_extraDiscountCard:false });    
  }
  dialogClose=() => {
    this.setState({ open_dialog: false });
  }  
  dialog_forgot_Close=()=>{
    this.setState({dialog_forgot_Close:false,
      dialog_employee_time:false,
      dialog_extra_discountCard:false,
      employeeId:'',
      selectedDiscountCardId:'',
      dialog_giftCard_code:false,
      giftCardCode:'',
      dialog_discount_code:false,
      discountCode:'',
      discountCodeUsedAmount:0
    });
  }
  keyPressPassword=async(e)=>{
    if (e.key === 'Enter') {
       this.logIn();
    }
  }
  forgetPassword=()=>{
    this.setState({open_forgot_dialog:true,open_dialog:false,phone:''});
  }
  loginCard=()=>{
    this.setState({open_forgot_dialog:false,open_dialog:true,phone:''});
  }
  newPawwrodSubmit=async()=>{
    const {localization,classes}=this.props;
    if(this.state.phone==''){   
      this.props.enqueueSnackbar(localization.localizedError(13), { 
        variant: 'error',
      }); 
      return;
    }
    if(this.getCookie('submit')=='true'){
      this.props.enqueueSnackbar(localization.localizedError(35), { 
        variant: 'error',
      }); 
      return;
    } 

    var  {data} = await axios.post('/api/customer/phone_send',
      {       
        phone:this.state.phone
      }); 

      if(data.success){
        this.props.enqueueSnackbar(localization.localizedString('NEW_PASSWORD_SENT_SUCCESS'), { 
          variant: 'success',
        }); 
        this.setState({card_status:'login',phone:''});
        this.setCookieForSubmit("submit",'true');
      }
      else{       
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
      }
  }
  logIn=async()=>{
    var userData={};
    const {auth,localization}=this.props;
    userData.phone=this.state.phone;
    userData.password=this.state.password;

    const result = await auth.login(userData);    
    if(result.success){
      this.setState({
        open_dialog:false,
        expanded: 'panel2',
        currentPanel:2,      
        step2:false
      });
      if(this.state.remember_me){
        this.setCookie('customer_email', this.state.phone);
        this.setCookie('customer_password', this.state.password);
      }
     
    }
    else{
      this.props.enqueueSnackbar(localization.localizedError(result.errorCode), { 
        variant: 'error',
      });  
    }   
  }
  setCookie=(cname,cvalue)=>{ 
    var d = new Date();
    var exdays=30;
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
   var expires = "expires=" + d.toGMTString();
   document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
  }

  setCookieForSubmit=(cname,cvalue)=>{ 
    var d = new Date();
    var minutes=60;
    d.setTime(d.getTime() + (minutes*60*1000));
   var expires = "expires=" + d.toGMTString();
   document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
  }

  isSelected = id => this.state.serviceSelected.indexOf(id) !== -1;
  isAddonsSelected = id => this.state.addonsSelected.indexOf(id) !== -1;
  openFullScreen=(src)=>{    
      this.setState({openImage:true,imgSrc:src});
  }
  serviceDiscountCardToggle= prop => event =>{  
    if(event.target.checked){
      this.setState({ selected_serviceDiscountCard: event.target.checked,selectedDiscountCardId:prop });
    }
    else{
      this.setState({ selected_serviceDiscountCard: event.target.checked,selectedDiscountCardId:'' });
    }
    
  }
  extraDiscountCardToggle=prop=>event=>{
    if(event.target.checked){      
      this.setState({ selected_extraDiscountCard : event.target.checked,selectedDiscountCardId:prop });
    }
    else{
      this.setState({ selected_extraDiscountCard: event.target.checked,selectedDiscountCardId:'' });
    }
  }
  serviceDiscountCard=()=>{
      const {classes}=this.props;
      const {selected_serviceId,discountCards}=this.state;
        var discountId='';       
        discountCards.map(item=>{
            if(item.serviceId==selected_serviceId){
              discountId=item.id;                   
            }
        })

        if(discountId!=''){          
          return <Grid item xs={12} sm={12} md={10} className={classes.discountCard} >
            <FormControlLabel
              control={(
                <Checkbox
                  tabIndex={-1}
                  disableRipple
                  onClick={this.serviceDiscountCardToggle(discountId)}
                  checked={this.state.selected_serviceDiscountCard}
                />
              )}
              classes={{ label: classes.label }}
              label={"Discount Card"}
            />
        </Grid>
        }       
        else 
          return "";
        
  }
  extraDiscountCard=()=>{
    const {classes}=this.props;
      const {selectedAddonId ,discountCards}=this.state;
        var discountId='';       
        discountCards.map(item=>{
            if(item.serviceExtraId==selectedAddonId){
              discountId=item.id;                   
            }
        })

        if(discountId!=''){         
          return <Grid item xs={12} sm={12} md={10} className={classes.discountCard} >
            <FormControlLabel
              control={(
                <Checkbox
                  tabIndex={-1}
                  disableRipple
                  onClick={this.extraDiscountCardToggle(discountId)}
                  checked={this.state.selected_extraDiscountCard}
                />
              )}
              classes={{ label: classes.label }}
              label={"Discount Card"}
            />
        </Grid>
        }       
        else 
          return "";
  }
  giftCard=()=>{
    this.setState({ giftCardCode:'',dialog_giftCard_code:true});
  }

  discountCode=()=>{
    this.setState({dialog_discount_code:true,discountCode:''})
  }

  checkDiscountCode=()=>{
    const { classes,localization } = this.props;    
    var flag=false;
    var today=this.state.pickedDateTime; 
    var limit_flag=false; 
    var discountId='';  
    var limit_count=0;
    console.log(today);
    this.state.discountCodes.map(row=>{
      var from=moment(row.validFrom).format('YYYY-MM-DD HH:mm:ss');
      var to=moment(row.validTo).format('YYYY-MM-DD HH:mm:ss');     
      if(row.code==this.state.discountCode && moment(today).isBetween(from,to,null, '[]')){
      
        flag=true;
        discountId=row.id;
        this.state.selected_employees_services.map(item=>{
          //debugger;
           if(row.allServices){
            limit_count=limit_count+1
           }
           if(row.allServiceExtras){
            limit_count=limit_count+parseInt(item.extraIds.length);
           }          
        })
        var available_code=parseInt(row.limit)-parseInt(row.used);
        if(limit_count>available_code){
          limit_flag=true;
        }
        //this.setState({discountCodeId:row.id});
      }
    })

    if(!flag){    
      this.props.enqueueSnackbar(localization.localizedString('INVALID_DISCOUNT_CODE'), {
        variant: 'error',
      });
      return;
    }

    if(limit_flag){
      this.props.enqueueSnackbar(localization.localizedString('LIMIT_OVER_FLOW'), {
        variant: 'error',
      });
      return;
    }
    this.setState({
      expanded: 'panel5',
      currentPanel:4,
      discountCodeId:discountId,
      dialog_discount_code:false,  
      discountCodeUsedAmount:limit_count
    });
  }

  checkGiftCode=()=>{
    const { classes,localization } = this.props;
    let flag=false;
    let price_flag=false;
    
    this.state.giftCards.map(row=>{
      if(row.code==this.state.giftCardCode){
        flag=true;
        this.setState({giftCardId:row.id});
      }
     
      if(parseFloat(row.availableBalance)<parseFloat(this.state.giftCard_amount)){
        price_flag=true;
      }
    })

    if(!flag){    
      this.props.enqueueSnackbar(localization.localizedString('INVALID_GIFT_CODE'), {
        variant: 'error',
      });
      return;
    }
    if(price_flag){
      this.props.enqueueSnackbar(localization.localizedString('INVALID_GIFT_PRICE'), {
        variant: 'error',
      });
      return;
    }
    
      this.setState({
        expanded: 'panel5',
        currentPanel:4,
        dialog_giftCard_code:false
      });
  }
  
  /**
   * this is for the select service panel.
   */
  serviceTable=()=>{
    const { classes,localization } = this.props;
    let tbl=[];
    let trs=[];

      this.state.services.map((item, index) => {      
      const isSelected = this.isSelected(item.id);
        if(item.serviceCategoryId==this.state.defaultCategory){
          trs.push(
            <TableRow key={item.id}>
              <TableCell className={classes.tableCellId} >
                  <Checkbox
                      tabIndex={-1}
                      disableRipple
                      checked={isSelected}
                      onChange={event => this.serviceClick(event, item.id)}                            
                   />
              </TableCell>
              <TableCell className={classes.tableCell}>
                  <div className={classNames(classes.title_2)}>
                    {item.name}
                  </div>
                  <div className={classNames(classes.description_1)}>
                    {item.description}
                   </div>
              </TableCell>
              <TableCell  className={classes.tableCell_1}>
                <span>{item.duration} minutes</span>
                {item.vary ? <FormHelperText>Can Vary</FormHelperText>:'' }
                
              </TableCell>

              <TableCell  className={classes.tableCell_1}>
                <span>{item.price+" "+this.state.company.currency_code}</span>
              </TableCell>

            </TableRow>
            );
        }
      });
      if(trs.length==0){
        return <h4 className={classes.nothing_1}>There is nothing.</h4>
      }
      tbl.push(
          <Table className={classes.table} key={1}>              
                <TableBody>
                  {trs}
                </TableBody>
          </Table>
      );
      return tbl;
  } 
  /*
  * it is for the select addons panel2
  */
  serviceAddonsTable=()=>{
    const { classes,localization } = this.props;
    const {serviceSelected,extra_service_relations}=this.state;
    let tbl=[];
    let trs=[];    
    let selected_extras=[];
        
    extra_service_relations.map(row=>{
      if(serviceSelected.indexOf(row.serviceId) !=-1){
        selected_extras.push(row.extraId);
      }
    })
      this.state.serviceAddons.map((item, index) => {         
      const isSelected = this.isAddonsSelected(item.id);
        if(selected_extras.indexOf(item.id)!=-1){
          trs.push(
            <TableRow key={item.id}>
              <TableCell className={classes.tableCellId} >
                  <Checkbox
                      tabIndex={-1}
                      disableRipple
                      checked={isSelected}
                      onChange={event => this.addonsClick(event, item.id)}                            
                   />
              </TableCell>
              <TableCell className={classes.tableCell}>
                  <div className={classNames(classes.title_2)}>
                    {item.name}
                  </div>
                  <div className={classNames(classes.description_1)}>
                    {item.description}
                   </div>
              </TableCell>
              <TableCell  className={classes.tableCell_1}>
                <span>{item.duration} minutes</span>
                {item.vary? <FormHelperText>Can vary</FormHelperText>:'' }
              </TableCell>

              <TableCell  className={classes.tableCell_1}>
                <span>{item.price+" "+this.state.company.currency_code}</span>
              </TableCell>

            </TableRow>
            );
        }
      });
      if(trs.length==0){
        return <h4 className={classes.nothing_1}>There is nothing.</h4>
      }
      tbl.push(
          <Table className={classes.table} key={1}>              
                <TableBody>
                  {trs}
                </TableBody>
          </Table>
      );
      return tbl;
  }
  chip_list=()=>{
    const {services,serviceSelected}=this.state; 
    var chips=[];  
    services.map(row=>{
      if(serviceSelected.indexOf(row.id)!=-1){       
        chips.push( <Chip
          key={row.id}
          label={row.name}
          variant="outlined"
          style={{margin: '3px', fontWeight: '400', color: '#000',}}
          onDelete={()=>this.serviceClick(event ,row.id)}
         
        />) ;
      }
    })
  return chips;
       
  }
  render() {
    const { classes,localization } = this.props;
    const { expanded,phone,password,price,currency ,paypal_key,services,serviceSelected,
      serviceAddons,addonsSelected,paymentSetting,images,workHours} = this.state;

    var serviceSumPrice=0;
    services.map(row=>{
      if(serviceSelected.indexOf(row.id)!=-1){      
        serviceSumPrice=serviceSumPrice+parseFloat(row.price);
      }
    })

    var addonSumPrice=0;
    serviceAddons.map(row=>{
      if(addonsSelected.indexOf(row.id)!=-1){      
        addonSumPrice=addonSumPrice+parseFloat(row.price);
      }
      });
   
    var totalPrice=serviceSumPrice+addonSumPrice;

    const onSuccess = (payment) => {
          this.props.enqueueSnackbar(localization.localizedString('PAYMENT_SUCCESS'), { 
            variant: 'success',
          });    
          this.setState({
            expanded: 'panel5',
            currentPanel: 5,
            step5:false,
            paid:1,
            payment_method_id:1,
            paymentAmount:this.state.price
          }) 
      }
      const onCancel = (data) => {
          this.props.enqueueSnackbar(localization.localizedString('PAYMENT_CANCELED'), { 
            variant: 'info',
          });         
      }

      const onError = (err) => {
        this.props.enqueueSnackbar(localization.localizedString('PAYMENT_FAILED'), { 
          variant: 'error',
        });       
      }

      let env = 'sandbox'; // you can set here to 'production' for production
      //let currency ="DKK" ; // or you can set this value from your props or state
      //let price=1;

      const client = {
          sandbox:    (paypal_key=='' || !paypal_key)?'blank':paypal_key,
          production: (paypal_key=='' || !paypal_key)?'blank':paypal_key,
      }
      var today=new Date();
    
          var working_hours={};
          let mondayOpenAt=[];
          let mondayCloseAt=[];
          let tuesdayOpenAt=[];
          let tuesdayCloseAt=[];
          let wednesdayOpenAt=[];
          let wednesdayCloseAt=[];
          let thursdayCloseAt=[];
          let thursdayOpenAt=[];
          let fridayOpenAt=[];
          let fridayCloseAt=[];          
          let saturdayOpenAt=[];
          let saturdayCloseAt=[];
          let sundayOpenAt=[];
          let sundayCloseAt=[];


          
          workHours.map(item=>{
            
            if(item.mondayIsOpen){
              mondayOpenAt.push(item.mondayOpenAt);
              mondayCloseAt.push(item.mondayCloseAt);
            }
            if(item.tuesdayIsOpen){
              tuesdayOpenAt.push(item.tuesdayOpenAt);
              tuesdayCloseAt.push(item.tuesdayCloseAt);
            }
            if(item.wednesdayIsOpen){
              wednesdayOpenAt.push(item.wednesdayOpenAt);
              wednesdayCloseAt.push(item.wednesdayCloseAt);
            }

            if(item.thursdayIsOpen){
              thursdayOpenAt.push(item.thursdayOpenAt);
              thursdayCloseAt.push(item.thursdayCloseAt);
            }

            if(item.fridayIsOpen){
              fridayOpenAt.push(item.fridayOpenAt);
              fridayCloseAt.push(item.thursdayCloseAt);
            }

            if(item.saturdayIsOpen){
              saturdayOpenAt.push(item.saturdayOpenAt);
              saturdayCloseAt.push(item.saturdayCloseAt);
            }

            if(item.sundayIsOpen){
              sundayOpenAt.push(item.sundayOpenAt);
              sundayCloseAt.push(item.sundayCloseAt);
            }
          })
          mondayOpenAt.sort();
          tuesdayOpenAt.sort();
          wednesdayOpenAt.sort();
          thursdayOpenAt.sort();
          fridayOpenAt.sort();
          saturdayOpenAt.sort();
          sundayOpenAt.sort();        

    return (
      <div className={classes.rootMenuScrollHide}>
        <Header
          color="white"
          routes={dashboardRoutes}
          brand={this.props.localization.localizedString("BRAND")}
          rightLinks={<HeaderLinks />}
          changeColorOnScroll={{
            height: 400,
            color: "white"
          }}
        />

        <div className={window.innerWidth>960?classes.container:classes.container_1}>
          <GridContainer>
            <Grid item xs={12} sm={12} md={6} className={classes.tess}>
              <GridList
                spacing={1}
                cellHeight={this.state.cellHeight}
                className={classes.gridList}
                cols={2}
              >
                <GridListTile
                  key={"left_main"}
                  cols={2}
                  rows={2}
                  onClick={()=>this.openFullScreen(images.image1?images.image1:"https://material-ui.com/static/images/grid-list/breakfast.jpg")}
                  className={classes.mainPicture}
                >
                  <div className={classes.thms}>
                    <img
                      src={images.image1?images.image1:"https://material-ui.com/static/images/grid-list/breakfast.jpg"}
                      alt={"title1"}
                      className={classes.item_img}
                    />
                  </div>
                  <GridListTileBar
                    title="breakfast x2 sale"
                    titlePosition="top"
                    actionIcon={
                      <IconButton className={classes.white_icon}>
                        <StarBorderIcon />
                      </IconButton>
                    }
                    actionPosition="left"
                    className={classes.profile_images}
                  />
                </GridListTile>
              </GridList>
            </Grid>

            <Grid item xs={12} sm={12} md={6}>
              <Hidden smDown implementation="css">
                <GridList
                  spacing={0}
                  cellHeight={this.state.cellHeight + 1}
                  className={classes.gridList}
                  cols={2}
                >
             
                    <GridListTile
                      className={classes.tess}
                      key='2'
                      cols={1}
                      className={classes.subPicture}
                      onClick={()=>this.openFullScreen(images.image2?images.image2:"https://material-ui.com/static/images/grid-list/breakfast.jpg")}
                    >
                      <div className={classes.thms}>
                        <img
                          src={images.image2?images.image2:"https://material-ui.com/static/images/grid-list/breakfast.jpg"}
                          alt={"favorite 2"}
                          className={classes.item_img}
                        />
                      </div>
                      <GridListTileBar
                        title="some description"
                        titlePosition="top"
                        actionPosition="left"
                        className={classes.profile_images}
                      />
                    </GridListTile>

                    <GridListTile
                      className={classes.tess}
                      key='3'
                      cols={1}
                      className={classes.subPicture}
                      onClick={()=>this.openFullScreen(images.image3?images.image3:"https://material-ui.com/static/images/grid-list/camera.jpg")}
                    >
                      <div className={classes.thms}>
                        <img
                          src={images.image3?images.image3:"https://material-ui.com/static/images/grid-list/camera.jpg"}
                          alt={"favorite 3"}
                          className={classes.item_img}
                        />
                      </div>
                      <GridListTileBar
                        title="some description"
                        titlePosition="top"
                        actionPosition="left"
                        className={classes.profile_images}
                      />
                    </GridListTile>

                    <GridListTile
                      className={classes.tess}
                      key='4'
                      cols={1}
                      className={classes.subPicture}
                      onClick={()=>this.openFullScreen(images.image4?images.image4:"https://material-ui.com/static/images/grid-list/morning.jpg")}
                    >
                      <div className={classes.thms}>
                        <img
                          src={images.image4?images.image4:"https://material-ui.com/static/images/grid-list/morning.jpg"}
                          alt={"favorite 4"}
                          className={classes.item_img}
                        />
                      </div>
                      <GridListTileBar
                        title="some description"
                        titlePosition="top"
                        actionPosition="left"
                        className={classes.profile_images}
                      />
                    </GridListTile>

                    <GridListTile
                      className={classes.tess}
                      key='5'
                      cols={1}
                      className={classes.subPicture}
                      onClick={()=>this.openFullScreen(images.image5?images.image5:"https://material-ui.com/static/images/grid-list/hats.jpg")}
                    >
                      <div className={classes.thms}>
                        <img
                          src={images.image5?images.image5:"https://material-ui.com/static/images/grid-list/hats.jpg"}
                          alt={"favorite 5"}
                          className={classes.item_img}
                        />
                      </div>
                      <GridListTileBar
                        title="some description"
                        titlePosition="top"
                        actionPosition="left"
                        className={classes.profile_images}
                      />
                    </GridListTile>
               
                </GridList>
              </Hidden>
            </Grid>
          </GridContainer>
        </div>

        <Card className={classes.card}>
          <Grid item xs={12} className={classes.control}>
            <Grid container>
              <Grid xs={12} sm={8} md={8} item>
                <div style={{ padding: "0px !important" }}>
                  <div>
                    <h1 className={classes.listitem_hh}>
                      <span className={classes.companyName}>
                        {this.state.company.company_name}
                      </span>
                    </h1>
                  </div>

                  <div>
                    <List
                      component="nav"
                      dense={false}
                      disablePadding={false}
                      className={classes.nav_list}
                    >
                      <ListItem className={classes.listitem_11}>
                        <ListItemIcon className={classes.icon_4}>
                          <LocationOn className={classes.icon_1} />
                        </ListItemIcon>
                        <ListItemText
                          className={classes.list_2}
                          classes={{ primary: classes.title_22 }}
                          primary={this.state.company.address}
                        />
                      </ListItem>
                      <ListItem className={classes.listitem_1}>
                        <ListItemIcon className={classes.icon_4}>
                          <Phone className={classes.icon_1} />
                        </ListItemIcon>
                        <ListItemText
                          className={classes.list_2}
                          classes={{ primary: classes.title_22 }}
                          primary={this.state.company.country_phone_code+"  "+this.state.company.phone}
                        />
                      </ListItem>
                      <ListItem className={classes.listitem_1}>
                        <ListItemIcon className={classes.icon_4}>
                          <Email className={classes.icon_1} />
                        </ListItemIcon>
                        <ListItemText
                          className={classes.list_2}
                          classes={{ primary: classes.title_22 }}
                          primary={this.state.company.email}
                        />
                      </ListItem>
                      <ListItem className={classes.listitem_1_2}>
                        <Button
                          href="#request_booking"
                          variant="contained"
                        color="secondary"
                        className={classes.button}
                        >
                          Request Booking
                        </Button>
                      </ListItem>
                      <ListItem className={classes.listitem_1_toppad}>
                        <Typography variant="caption" className={classes.sub_paragraph}>
                             You can request a booking latest 4 hours before the appointment and cancel a booking latest 2 hours before.
                          <br />                          
                        </Typography>
                      </ListItem>
                    </List>

                    <Divider variant="middle" />
                  </div>

                  <div className={classes.address_1}>
                    <List
                      component="nav"
                      dense={false}
                      disablePadding={false}
                      className={classes.about_header_list}
                    >
                      <ListItem className={classes.about_header_list_item}>
                        <ListItemText
                          className={classes.about_header}
                          primary="About"
                        />
                      </ListItem>
                    </List>

                    <p className={classes.about_paragraph}>
                      Hos Overgaard er kvalitet, personlig rådgivning og økologi
                      i højsædet. Salonen forbinder velvære og skønhed i en
                      afslappet atmosfære.
                    </p>
                    <p className={classes.about_paragraph}>
                      Indehaveren er udlært hos Palma salon og spa i København K
                      og efteruddannet ved blandt andet Sassoon Academy i
                      London.
                    </p>
                    <p className={classes.about_paragraph}>
                      Salonen er beliggende på den hyggelige Willemoesgade på
                      Østerbro i København og deler adresse med en forhandler af
                      antikke effekter til klassiske ejendomme og lejligheder.
                    </p>
                  </div>
                  <Divider variant="middle" />
                  <div className={classes.address_1}>
                    <List
                      component="nav"
                      dense={false}
                      disablePadding={false}
                      className={classes.about_header_list}
                    >
                      <ListItem className={classes.about_header_list_item}>
                        <ListItemText
                          className={classes.about_header}
                          primary="Accepted Payment Methods"
                        />
                      </ListItem>
                    </List>

                    <Grid container  >
                    <Typography variant="caption" className={classes.sub_paragraph}>
                          {  (paymentSetting.maestro || paymentSetting.paypal 
                            || paymentSetting.bitcoin || paymentSetting.visa || paymentSetting.americanExpress 
                            || paymentSetting.cash  || paymentSetting.dankort || paymentSetting.mastercard) ?"In-store - pay after service has been done":"We do not accept in-store payments"}
                          
                          <br />
                        </Typography>
                       
                        <Grid xs={12} sm={12} md={12} item>
                        {
                          paymentSetting && paymentSetting.maestro ? 
                          <Tooltip title="Maestro" placement="top">
                          <Avatar
                          alt="Remy Sharp"
                          className={classes.paymentCards}
                          src="http://icons.iconarchive.com/icons/designbolts/credit-card-payment/256/Master-Card-Blue-icon.png"
                        /></Tooltip>:''
                         }
                        
                        {/**
                        <Avatar
                          alt="Remy Sharp"
                          className={classes.paymentCards}
                          src="https://cdn.iconscout.com/icon/free/png-256/payment-stripe-card-pay-bank-transaction-51317.png"
                        /> */}
                        {paymentSetting && paymentSetting.paypal ? <Tooltip title="Paypal" placement="top"><Avatar
                          alt="Remy Sharp"
                          className={classes.paymentCards}
                          src="http://aux2.iconspalace.com/uploads/paypal-payment-icon-256.png"
                        /></Tooltip>:'' }
                        {paymentSetting && paymentSetting.bitcoin ?
                          <Tooltip title="BitCoin" placement="top"><Avatar
                          alt="Remy Sharp"
                          className={classes.paymentCards}
                          src="https://cdn.iconscout.com/icon/free/png-256/payment-bitcoin-card-pay-bank-51308.png"
                        /></Tooltip>:''}
                         {paymentSetting && paymentSetting.visa ? 
                          <Tooltip title="Visa" placement="top"><Avatar
                          alt="Remy Sharp"
                          className={classes.paymentCards}
                          src="http://www.myiconfinder.com/uploads/iconsets/256-256-4c5308bf863a00c56870d053e6ba37c6.png"
                        /></Tooltip>:''}
                        {paymentSetting && paymentSetting.americanExpress ?
                          <Tooltip title="American Express" placement="top"><Avatar
                          alt="Remy Sharp"
                          className={classes.paymentCards}
                          src="http://icons.iconarchive.com/icons/designbolts/credit-card-payment/256/American-Express-icon.png"
                        /></Tooltip>:''}
                        {/**
                        <Avatar
                          alt="Remy Sharp"
                          className={classes.paymentCards}
                          src="https://www.iconshock.com/image/Clean/Credit_Cards/alipay2/"
                        />
                          */}
                          {paymentSetting && paymentSetting.cash ? 
                            <Tooltip title="Cash" placement="top"><Avatar
                          alt="Remy Sharp"
                          className={classes.paymentCards}
                          src="https://cdn3.iconfinder.com/data/icons/unigrid-phantom-finance-vol-3/60/014_129_money_notes_cash_finance-512.png"
                        /></Tooltip>:''}
                         {
                          paymentSetting && paymentSetting.dankort ?
                          <Tooltip title="Dankort" placement="top"><Avatar
                          alt="Remy Sharp"
                          className={classes.paymentCards}
                          src="https://cdn.icon-icons.com/icons2/1316/PNG/512/if-dankort-1-2593690_86614.png"
                        /></Tooltip> :''
                         }
                         {paymentSetting && paymentSetting.mastercard ? <Tooltip title="MasterCard" placement="top"><Avatar
                          alt="Remy Sharp"
                          className={classes.paymentCards}
                          src="https://cdn0.iconfinder.com/data/icons/ThemeShock-credit-cards-icons/64/mastercard.png"
                        /></Tooltip>:''} 
                        </Grid>

                        <Typography variant="caption" className={classes.sub_paragraph}>
                          {  paymentSetting.paypalKey  || paymentSetting.strip  ||  paymentSetting.coinPayment  ?"Online - pay upfront":"We do not accept online payments"}
                          <br />

                        </Typography>
                        <Grid xs={12} sm={12} md={12} item>
                        {paymentSetting && paymentSetting.paypalKey ? 
                          <Tooltip title="Paypal" placement="top"><Avatar
                          alt="Remy Sharp"
                          className={classes.paymentCards}
                          src="http://aux2.iconspalace.com/uploads/paypal-payment-icon-256.png"
                        /></Tooltip>:''}
                        {paymentSetting &&  paymentSetting.strip ? 
                          <Tooltip title="Strip" placement="top"><Avatar
                          alt="Remy Sharp"
                          className={classes.paymentCards}
                          src="https://www.studiofeelit.fi/wp-content/uploads/2018/12/stripe.png"
                        /></Tooltip>:''}
                        {paymentSetting &&  paymentSetting.coinPayment ?
                          <Tooltip title="CoinPayment" placement="top"><Avatar
                          alt="Remy Sharp"
                          className={classes.paymentCards}
                          src="https://cdn0.iconfinder.com/data/icons/money-icons-1/110/Coins-512.png"
                        /></Tooltip>:''}
                        </Grid>
                    </Grid>
                  </div>
                </div>
              </Grid>  
              <Grid xs={12} sm={4} md={4} item>
              {/** google map */}
              <div style={{ height: '33vh', width: '100%',marginTop:'20px',position:'relative' }}> 
                  <GoogleMapReact
                    bootstrapURLKeys={{ key: "AIzaSyDTCQc8JvRvCS5z-AZPv3UpX1HxesohbFs&libraries=places" }}
                    defaultCenter={this.state.center}
                    defaultZoom={13}
                  >
                    <Marker lat={this.state.lat}  lng={this.state.lng}  src={markerPng} />                    
                  </GoogleMapReact>
             
                {/**
                <Map
                
                    style = { style }
                    google = { this.props.google }                   
                    zoom = { 14 }
                    initialCenter = {{ lat: 39.648209, lng: -75.711185 }}
                  >
                    <Marker                     
                      title = { 'Changing Colors Garage' }
                      position = {{ lat: 39.648209, lng: -75.711185 }}
                      name = { 'Changing Colors Garage' }
                    />                    
                  </Map>
                   */}
                </div>       
            {/**end google map */}
              <List
                      component="nav"
                      dense={false}
                      disablePadding={false}
                    >
                      <ListItem>
                        <ListItemText
                          className={classes.about_header}
                          primary="Business Hours"
                        />
                      </ListItem>
                    </List>
                    <div style={{fontWeight: '400', fontSize: '0.94rem', color: '#757575',}}>                  
                       <Grid container style={{paddingLeft: '16px',
                         paddingRight: '16px',     paddingBottom: '35px',}}>
                              <Grid xs={4} sm={4} md={4} item>Monday : </Grid>
                              <Grid xs={8} sm={8} md={8} item>
                                 {mondayOpenAt[0]?mondayOpenAt[0].slice(0, 5)+" - "+mondayCloseAt[mondayCloseAt.length-1].slice(0, 5):"Closed"}
                              </Grid>
                              <Grid xs={4} sm={4} md={4} item>Tuesday :</Grid>
                              <Grid xs={8} sm={8} md={8} item>
                                {tuesdayOpenAt[0]?tuesdayOpenAt[0].slice(0, 5)+" - "+tuesdayCloseAt[tuesdayCloseAt.length-1].slice(0, 5):"Closed"}
                              </Grid>
                              <Grid xs={4} sm={4} md={4} item> Wednesday :</Grid>
                              <Grid xs={8} sm={8} md={8} item>
                                 {wednesdayOpenAt[0]?wednesdayOpenAt[0].slice(0, 5)+" - "+wednesdayCloseAt[wednesdayCloseAt.length-1].slice(0, 5):"Closed"}
                              </Grid>
                              <Grid xs={4} sm={4} md={4} item>Thursday :</Grid>
                              <Grid xs={8} sm={8} md={8} item>
                                {thursdayOpenAt[0]?thursdayOpenAt[0].slice(0, 5)+" - "+thursdayCloseAt[thursdayCloseAt.length-1].slice(0, 5):"Closed"}
                              </Grid>
                              <Grid xs={4} sm={4} md={4} item> Friday :</Grid>
                              <Grid xs={8} sm={8} md={8} item>
                                 {fridayOpenAt[0]?fridayOpenAt[0].slice(0, 5)+" - "+fridayCloseAt[fridayCloseAt.length-1].slice(0, 5):"Closed"}
                              </Grid>
                              <Grid xs={4} sm={4} md={4} item>Saturday :</Grid>
                              <Grid xs={8} sm={8} md={8} item>
                                 {saturdayOpenAt[0]?saturdayOpenAt[0].slice(0, 5)+" - "+saturdayCloseAt[saturdayCloseAt.length-1].slice(0, 5):"Closed"}
                              </Grid>
                              <Grid xs={4} sm={4} md={4} item> Sunday :</Grid>
                              <Grid xs={8} sm={8} md={8} item>
                                 {sundayOpenAt[0]?sundayOpenAt[0].slice(0, 5)+" - "+sundayCloseAt[sundayCloseAt.length-1].slice(0, 5):"Closed"}
                              </Grid>
                    
                    </Grid>
                </div>
                <Divider variant="middle" />
                <List
                      component="nav"
                      dense={false}
                      disablePadding={false}
                      style={{marginTop: '15px !important',}}
                    >
                      <ListItem>
                        <ListItemText
                          className={classes.about_header}
                          primary="Social Media"
                        />
                      </ListItem>
                    </List>
                    <div style={{fontWeight: '400', fontSize: '0.94rem', color: '#757575',}}>


<Grid container style={{paddingLeft: '16px',
paddingRight: '16px',     paddingBottom: '35px',}}>
<Grid xs={12} sm={12} md={12} item>
                          <div>
                            <div className={classes.icon_size} style={{color: '#3b5998'}}>
                              <i className="fab fa-facebook" />
                            </div>
                            <div className={classes.icon_size} style={{color: '#ff6611'}}>
                              <i className="fab fa-firefox" />
                            </div>
                            <div className={classes.icon_size} style={{color: '#38A1F3'}}>
                              <i className="fab fa-twitter" />
                            </div>
                            <div className={classes.icon_size} style={{color: '#FFDC80'}}>
                              <i className="fab fa-instagram" />
                            </div>
                          </div>
</Grid>
</Grid>
</div>
              </Grid>
            </Grid>
            <Divider variant="middle"/>
            
            {/** start widzard */}
            <Grid className={classes.root_3}>
                  <List
                      component="nav"
                      dense={false}
                      disablePadding={false}
                      className={classes.about_header_list}
                    >
                      <ListItem className={classes.about_header_list_item}>
                        <ListItemText
                          id="request_booking"
                          className={classes.about_header}
                          primary="Request Booking"
                        />
                      </ListItem>
                    </List>

              <ExpansionPanel
                disabled={this.state.step1}
                expanded={expanded === "panel1"}
                onChange={this.handleChange("panel1")}
              >
                <ExpansionPanelSummary className={classes.root_summary}>
                  <Category className={classes.icon_7} />
                  <Typography variant="subheading" className={classes.title_3}>
                    Select Service
                  </Typography>
                  <Typography className={classes.grow}>
                    {serviceSumPrice!=0?'Price: '+serviceSumPrice+' '+this.state.currency:''}
                  </Typography>
                  <span className={classes.step_c} />
                </ExpansionPanelSummary>

                <ExpansionPanelActions className={classes.action_1}>
                 <Grid container>
                    <Grid item xs={12} sm={6} md={4}>      
                      <FormControl
                          className={classes.formControl}
                        >
                          <Select
                            value={this.state.defaultCategory}
                            onChange={this.selectChange}                      
                            input={
                              <Input
                                fullWidth={true}
                              
                                name="defaultCategory"
                                id="defaultCategory" 
                                />
                              }
                              className={classes.outlineInput}
                          >
                            {this.state.category.map(row=>(
                              <MenuItem key={row.id} value={row.id}>{row.name}</MenuItem>
                            ))}  
                          </Select>
                          <FormHelperText>Category</FormHelperText>
                        </FormControl>
                      </Grid>
                      <Grid item xs={12} sm={6} md={8} className={classes.detail_3}>
                        <Typography variant="caption" className={classes.sub_paragraph}>
                          {this.state.category_description}
                        </Typography>                          
                      </Grid>
                    </Grid>       
                </ExpansionPanelActions>
                <Divider />
                <ExpansionPanelDetails className={classes.detail_1}>
                  <Grid container>
                    <Grid item xs={12} sm={12} md={12}>                
                        <div className={classes.cardBody_1}>
                            {this.serviceTable()}
                        </div>                
                    </Grid>
                  </Grid>                 
                  <Grid container className={classes.detail_2}>
                    <Grid
                      xs={6}
                      sm={6}
                      md={9}
                      item
                      className={classes.detail_3}
                    >
                    {this.chip_list()}               

                    </Grid>
                    <Grid xs={6} sm={6} md={3} item className={classes.addon_2}>
                      <Button
                        variant="contained"
                        color="secondary"
                        disabled={this.state.serviceSelected.length!=0?false:true}
                        className={classes.button}
                        onClick={this.nextChange("panel2")}
                      >
                        Continue
                      </Button>
                    </Grid>
                  </Grid>

                </ExpansionPanelDetails>
              </ExpansionPanel>
              <ExpansionPanel
                disabled={this.state.step2}
                className={classes.expansionPanelDisabled}
                expanded={expanded === "panel2"}
                onChange={this.handleChange("panel2")}
              >
                <ExpansionPanelSummary className={classes.root_summary}>
                  <Attachment className={classes.icon_7} />
                  <Typography variant="subheading" className={classes.title_3}>
                    Select Addons{" "}
                  </Typography>
                  <Typography className={classes.grow}>                    
                     {addonSumPrice!=0?'Price: '+addonSumPrice+' '+this.state.currency:''}
                  </Typography>
                  <span className={classes.step_c} />
                </ExpansionPanelSummary>
                <Divider />
                <ExpansionPanelDetails className={classes.detail_1}>
                    <Grid container>
                      <Grid item xs={12} sm={12} md={12}>                
                          <div className={classes.cardBody_1}>
                              {this.serviceAddonsTable()}
                        </div>                
                      </Grid>
                    </Grid>   
                
                  <Grid container className={classes.detail_2}>
                    <Grid
                      xs={12}
                      sm={12}
                      md={6}
                      item
                      className={classes.detail_3}
                    />
                    <Grid
                      xs={12}
                      sm={12}
                      md={6}
                      item
                      className={classes.addon_2}
                    >
                      <Button
                        variant="contained"
                        color="secondary"
                        className={classes.button_back}
                        onClick={this.nextChange("panel1")}
                      >
                        Back
                      </Button>
                      <Button
                        variant="contained"
                        color="secondary"
                        className={classes.button}
                        onClick={this.nextChange("panel3")}
                      >
                        Continue
                      </Button>
                    </Grid>
                  </Grid>
                </ExpansionPanelDetails>
              </ExpansionPanel>
              <ExpansionPanel
                disabled={this.state.step3}
                className={classes.expansionPanelDisabled}
                expanded={expanded === "panel3"}
                onChange={this.handleChange("panel3")}
              >
                <ExpansionPanelSummary className={classes.root_summary}>
                  <Timer className={classes.icon_7} />
                  <Typography variant="subheading" className={classes.title_3}>
                    Choose Time
                  </Typography>
                  <Typography className={classes.grow} >
                    {this.state.labelTime}
                  </Typography>

                  <span className={classes.step_c} />
                </ExpansionPanelSummary>

                {/**
                <ExpansionPanelActions className={classes.action_2}>
                  <Typography>Employee: </Typography>
                  <FormControl
                    variant="outlined"
                    className={classes.formControl}
                  >
                    <Select
                      value={this.state.employeeId}
                      onChange={this.employeeChange}
                      input={
                        <OutlinedInput
                          labelWidth={this.state.labelWidth}
                          name="employeeId"
                          id="employeeId"
                        />
                      }
                    >
                     {this.state.employees.map(row=>(
                      <MenuItem key={row.id} value={row.id}>{row.name}</MenuItem>
                     ))}              
                    
                    </Select>
                  </FormControl>
                  <Typography className={classes.grow} />
                </ExpansionPanelActions>
                */}              
                <Divider className={classes.hr_cs1} />
                <ExpansionPanelDetails className={classes.detail_1}>
                  <Grid
                    container
                    className={classNames(classes.detail_2, classes.addon_1)}
                  >
                    <Grid
                      xs={12}
                      sm={12}
                      md={5}
                      item
                      className={classes.calander_2}
                    >
                      <DayPicker
                        className={classes.calander_1}
                        disabledDays={[{ daysOfWeek: this.state.dayofweek },{
                                  after: new Date(2016, 1, 1),
                                  before: today,
                                },]}
                        onDayClick={this.handleDayClick}
                        selectedDays={this.state.selectedDay}
                      />
                    </Grid>
                    <Grid
                      xs={12}
                      sm={12}
                      md={7}
                      item
                      className={classes.time_4}
                    >
                     
                      <div className={classes.time_3}>                                               
                        {this.state.workTimes.length==0?<Typography
                          variant="subheading"
                          className={classes.title_3}
                        >
                          {this.state.available_date_time}
                        </Typography>:null}
                        <ul className={classes.timBoxes}>
                         {this.state.workTimes.map((row,index)=>(

                           <li key={row}  className={this.state.selectedTimeIndex==index?classes.time_item:{}} onClick={()=>this.selectTimes(row,index)}>{row}</li>
                         ))}
                        </ul>
                      

                      </div>
                    </Grid>
                  </Grid>
                  <Divider className={classes.hr_cs1} />
                  <Grid container className={classes.detail_2}>
                    <Grid
                      xs={12}
                      sm={12}
                      md={9}
                      item
                      className={classes.detail_3}
                    />
                    <Grid
                      xs={12}
                      sm={12}
                      md={3}
                      item
                      className={classes.addon_2}
                    >
                      <Button
                        variant="contained"
                        color="secondary"
                        className={classes.button_back}
                        onClick={this.nextChange("panel2")}
                      >
                        Back
                      </Button>
                   
                      <Button
                        variant="contained"
                        color="secondary"
                        className={classes.button}
                        disabled={this.state.labelTime?false:true}
                        onClick={this.nextChange("panel4")}
                      >
                        Continue
                      </Button>
                     
                    </Grid>
                  </Grid>
                </ExpansionPanelDetails>
              </ExpansionPanel>
              <ExpansionPanel
                disabled={this.state.step4}
                className={classes.expansionPanelDisabled}
                expanded={expanded === "panel4"}
                onChange={this.handleChange("panel4")}
              >
                <ExpansionPanelSummary className={classes.root_summary}>
                  <Payment className={classes.icon_7} />
                  <Typography variant="subheading" className={classes.title_3}>
                    Confirm and Pay
                  </Typography>
                  <Typography className={classes.grow}>
                    {totalPrice!=0?'Total Price: '+totalPrice.toFixed(2)+' '+this.state.currency:''}
                  </Typography>
                  <span className={classes.step_c} />
                </ExpansionPanelSummary>
                <ExpansionPanelDetails className={classes.detail_1}>
                  <Grid
                    container
                    className={classNames(classes.detail_2, classes.addon_1)}
                  >
                    <Grid
                      xs={12}
                      sm={12}
                      md={12}
                      item
                      className={classes.confirm_1}
                    >
                      <span>
                        You are about to make a booking at {this.state.company.company_name}{" "}
                        {this.state.day} {this.state.day_d}th {this.state.month}{" "}
                        at {this.state.timepick}. Duration is{" "}
                        {this.state.totalDuration} minutes
                      </span>
                    </Grid>
                  </Grid>
                  <Divider className={classes.hr_cs1} />
                  <Grid container className={classes.detail_2}>
                    <Grid
                      xs={12}
                      sm={12}
                      md={10}
                      item
                      className={classes.detail_3}
                    >
                     <Button
                        variant="contained"
                        color="secondary"
                        className={classes.button_back}
                        onClick={this.nextChange("panel3")}
                      >
                        Back
                      </Button> 
                      {
                        this.state.giftCards.length>0?
                        <Button
                        variant="contained"
                        color="secondary"
                        className={classes.button_back}
                        onClick={this.giftCard}
                      >
                        Gift Card
                      </Button>:''}
                      
                      <Button
                        variant="contained"
                        color="secondary"
                        className={classes.button_back}
                        onClick={this.discountCode}
                      >
                        Discount Code
                      </Button> 
                    </Grid>
                   
               
                    {(this.state.payment_upfront==1 && this.state.paypal_key !='') && 
                      <Grid
                      xs={6}
                      sm={6}
                      md={2}
                      item
                      className={classes.addon_2}
                    >
                    <PaypalExpressBtn 
                    style={{color:'blue',shape:'pill',label:'pay',height:40}}
                   env={env} client={client} currency={currency} total={price} onError={onError} onSuccess={onSuccess} onCancel={onCancel} /></Grid>}
                   
                   {(this.state.payment_upfront==0 || this.state.paypal_key=='') &&
                    <Grid
                      xs={6}
                      sm={6}
                      md={1}
                      item
                      className={classes.addon_2}
                    >
                   <Button
                        variant="contained"
                        color="secondary"
                        className={classes.button}                      
                        onClick={this.nextChange("panel5")}
                      >
                        Confirm
                      </Button></Grid>}                    
                  </Grid>
                </ExpansionPanelDetails>
              </ExpansionPanel>
              <ExpansionPanel
                disabled={this.state.step5}
                className={classes.expansionPanelDisabled}
                expanded={expanded === "panel5"}
                onChange={this.handleChange("panel5")}
              >
                <ExpansionPanelSummary className={classes.root_summary}>
                  <Receipt className={classes.icon_7} />
                  <Typography variant="subheading" className={classes.title_3}>
                    Receipt
                  </Typography>
                  <Typography className={classes.grow} />
                  <span className={classes.step_c} />
                </ExpansionPanelSummary>
                <ExpansionPanelDetails className={classes.detail_1}>
                  <Grid container className={classes.detail_2}>
                    <Grid
                      xs={12}
                      sm={12}
                      md={9}
                      item
                      className={classes.detail_3}
                    />
                    <Grid
                      xs={12}
                      sm={12}
                      md={3}
                      item
                      className={classes.addon_2}
                    >
                      <Button
                        variant="contained"
                        color="secondary"
                        className={classes.button_back}
                        onClick={this.nextChange("panel4")}
                      >
                        Back
                      </Button>
                      <Button
                        variant="contained"
                        color="secondary"
                        onClick={this.submitBooking}
                        className={classes.button}
                      >
                        Finish
                      </Button>
                    </Grid>
                  </Grid>
                </ExpansionPanelDetails>
              </ExpansionPanel>              
            </Grid>

             
               <Grid className={classes.root_3}>              
                <List
                      component="nav"
                      dense={false}
                      disablePadding={false}
                      className={classes.about_header_list}
                    >
                      <ListItem className={classes.about_header_list_item}>
                        <ListItemText
                          id="request_booking"
                          className={classes.about_header}
                          primary="Terms of Services"
                        />
                      </ListItem>
                </List>
                <p className={classes.about_paragraph}>
                   {localization.lang=='en'?this.state.terms_service.en:this.state.terms_service.dan}
                     
                 </p>
              </Grid>                      
          </Grid>
        </Card>
      {/** dialog login */}
      <Dialog
          fullWidth={true}
          maxWidth={'sm'}
          open={this.state.open_dialog}
          onClose={this.dialogClose}
          aria-labelledby="max-width-dialog-title"
          className={classes.dialog_1}     
        >         
          <DialogContent className={classes.dialog_1}>
            <Card >
            <form className={classes.form}>                  
                  <CardBody className={classes.cardBody}>
                  <Grid container className={classes.GridContainer}>
                        <Grid item xs={12} sm={12} md={12}>
                          <Typography  variant="h3" gutterBottom className={classes.signTitle}>
                          {localization.localizedString('LOGIN_FORM_TITLE_CUSTOMER')}
                          <br/>
                          </Typography>
                            <Typography component="p">
                            Manage your booking requests, see previous appointments and more.
                            </Typography>   
                      </Grid>
                  </Grid>
                  <div className={classes.loginFormLayout}>
                  <Grid container className={classes.GridContainer}>
                     <Grid item xs={12} sm={12} md={12}>              
                        <TextField
                            id="phone"
                            label={localization.localizedString('LOGIN_PHONE_LABEL')}
                            InputLabelProps={{
                              classes: {
                                root: classes.cssLabel,
                                focused: classes.cssFocused,
                              },
                            }}
                            InputProps={{
                              type: 'text',
                              classes: {
                                root: classes.cssOutlinedInput,
                                focused: classes.cssFocused,
                                underline: classes.cssUnderline                     
                              },
                              endAdornment: (
                                      <InputAdornment position="end">
                                        <Icon>
                                          <Phone className={classes.inputIconsColor} />
                                        </Icon>
                                      </InputAdornment>
                                    ),
                            }}
                            className={classes.textField}
                            value={phone}
                            onChange={this.handleTxtChange('phone')}
                            margin="normal"
                            fullWidth
                          />
                      </Grid>
                    </Grid>
                <Grid container className={classes.GridContainer}>
                  <Grid item xs={12} sm={12} md={12}> 
                    <TextField
                            id="password"
                            label={localization.localizedString('LOGIN_PASSWORD_LABEL')}
                            InputLabelProps={{
                              classes: {
                                root: classes.cssLabel,
                                focused: classes.cssFocused,
                              },
                            }}
                            InputProps={{
                              type: 'password',
                              classes: {
                                root: classes.cssOutlinedInput,
                                focused: classes.cssFocused,
                                underline: classes.cssUnderline                  
                              },
                              endAdornment: (
                                    <InputAdornment position="end">
                                      <Icon>
                                        <LockOutlined className={classes.inputIconsColor} />
                                      </Icon>
                                     </InputAdornment>
                                    ),
                            }}
                            className={classes.textField}
                            value={password}
                            onChange={this.handleTxtChange('password')}
                            onKeyPress={(event)=>this.keyPressPassword(event)}
                            margin="normal"
                            fullWidth
                          />
                   </Grid>
                   <Grid item xs={12} sm={12} md={6}>
                              <FormControlLabel
                              control={(
                                <Checkbox
                                  tabIndex={-1}                                                               
                                  checked={this.state.remember_me}
                                  onClick={this.handleToggle('remember_me')}
                                />
                              )}
                              classes={{ label: classes.label }}
                              label={"Remember me"}
                            />
                  </Grid>
                  <Grid item xs={12} sm={12} md={6}>
                        <Typography
                          variant="subheading" 
                          className={classes.forgotPass}
                          onClick={this.forgetPassword}
                          >
                            Forgot the password?
                          </Typography>
                  </Grid>
                 </Grid>
                 </div>
                  </CardBody>
                  <CardFooter className={classes.cardFooterBycustomer_1}>
                   
                      <Grid item xs={12} sm={12} md={6} lg={6} xl={6}>
                      <Button
                        variant="contained"
                        color="secondary"
                        className={classes.button_back}                        
                        onClick={this.logIn}
                      >
                        Log in
                      </Button>
                        
                      </Grid>
                      <Grid item xs={12} sm={12} md={6} lg={6} xl={6} style={{textAlign:'right'}}>
                      <Button                                               
                          onClick={()=>{this.setState({openSignup:true,open_dialog:false})}}
                          className={classes.navLink + ' ' + classes.NavLinkSignUp}
                        >          
                          {localization.localizedString('LOGIN_CREATE_COMPANY_LINK')}
                        </Button>                 
                      
                      </Grid>
                   
                  </CardFooter>
                </form>
            </Card>  
          </DialogContent>
      </Dialog>   
      {/** dialog */} 

      {/**forgot password */}
      <Dialog
          fullWidth={true}
          maxWidth={'sm'}
          open={this.state.open_forgot_dialog}
          onClose={this.dialog_forgot_Close}
          aria-labelledby="max-width-dialog-title"
          className={classes.dialog_1}     
        >         
          <DialogContent className={classes.dialog_1}>
            <Card >
            <form className={classes.form}>                  
                  <CardBody className={classes.cardBody}>
                  <Grid container className={classes.GridContainer}>
                        <Grid item xs={12} sm={12} md={12}>
                          <Typography  variant="h3" gutterBottom className={classes.signTitle}>
                             Reset Password
                          <br/>
                          </Typography>
                            <Typography component="p">
                              Please put the your phone number.
                            </Typography>   
                      </Grid>
                  </Grid>
                  <div className={classes.loginFormLayout}>
                  <Grid container className={classes.GridContainer}>
                     <Grid item xs={12} sm={12} md={12}>              
                        <TextField
                            id="phone"
                            label={localization.localizedString('LOGIN_PHONE_LABEL')}
                            InputLabelProps={{
                              classes: {
                                root: classes.cssLabel,
                                focused: classes.cssFocused,
                              },
                            }}
                            InputProps={{
                              type: 'text',
                              classes: {
                                root: classes.cssOutlinedInput,
                                focused: classes.cssFocused,
                                underline: classes.cssUnderline                     
                              },
                              endAdornment: (
                                      <InputAdornment position="end">
                                        <Icon>
                                          <Phone className={classes.inputIconsColor} />
                                        </Icon>
                                      </InputAdornment>
                                    ),
                            }}
                            className={classes.textField}
                            value={phone}
                            onChange={this.handleTxtChange('phone')}
                            margin="normal"
                            fullWidth
                          />
                      </Grid>
                    </Grid>
                <Grid container className={classes.GridContainer}>                  
                   <Grid item xs={12} sm={12} md={12}>                 
                        <Typography
                          variant="subheading" 
                          className={classes.forgotPass}
                          onClick={this.loginCard}
                          >
                          Already have login and password? Sign in
                        </Typography> 
                  </Grid>
                  
                 </Grid>
                 </div>
                  </CardBody>
                  <CardFooter className={classes.cardFooterBycustomer_1}>
                   
                      <Grid item xs={12} sm={12} md={12} lg={12} xl={12}>
                        <Button
                          variant="contained"
                          color="secondary"
                          className={classes.button_back}                        
                          onClick={this.newPawwrodSubmit}
                        >
                          Submit
                        </Button>                        
                      </Grid>                      
                   
                  </CardFooter>
                </form>
            </Card>  
          </DialogContent>
      </Dialog>   
      {/** dialog */} 

      {/**choose time/employee dialog  */}
      <Dialog
          fullWidth={true}
          maxWidth={'xs'}
          open={this.state.dialog_employee_time}
          onClose={this.dialog_forgot_Close}
          aria-labelledby="max-width-dialog-title"
          className={classes.dialog_1}     
        >     
          <DialogTitle id="simple-dialog-title" className={classes.dialog_title} >Select Employee</DialogTitle>      
          <DialogContent className={classes.dialog_2}>          
                    <Grid container className={classes.GridContainer}>
                        <Grid item xs={12} sm={12} md={10}> 
                            <FormControl
                              error={this.state.employee_error}
                              variant="outlined"
                              className={classes.formControl_employee}
                            >
                            <InputLabel htmlFor="employeeId">Employee</InputLabel>
                              <Select
                                value={this.state.employeeId}
                                onChange={this.employeeChange}
                               inputProps={{
                                  name: 'employeeId',
                                  id: 'employeeId',
                                }}
                              >                              
                              {this.state.employees.map(row=>{                                
                                if(this.state.filtered_employees.indexOf(row.id)!=-1)
                                return <MenuItem key={row.id} value={row.id}>{row.firstName+" "+row.lastName}</MenuItem>                                
                              })} 
                              </Select>
                            </FormControl>
                        </Grid>
                        {
                          this.serviceDiscountCard()
                        }
                        
                    </Grid>
          </DialogContent>
          <DialogActions className={classes.cardFooter}>
              <Button color="primary" onClick={this.dialog_forgot_Close}>Cancel</Button> 
              <Button   variant="contained"   color="secondary" onClick={this.selected_serivce}   className={classes.button_2}>Ok</Button>
          </DialogActions>
      </Dialog>   
      {/** dialog */} 

      {/** discount card for service extra  */}
      <Dialog
          fullWidth={true}
          maxWidth={'xs'}
          open={this.state.dialog_extra_discountCard}
          onClose={this.dialog_forgot_Close}
          aria-labelledby="max-width-dialog-title"
          className={classes.dialog_1}     
        >     
          <DialogTitle id="simple-dialog-title" className={classes.dialog_title} >Choose Discount Card</DialogTitle>      
          <DialogContent className={classes.dialog_2}>          
                    <Grid container className={classes.GridContainer}>                        
                        {
                          this.extraDiscountCard()
                        }
                        
                    </Grid>
          </DialogContent>
          <DialogActions className={classes.cardFooter}>
              <Button color="primary" onClick={this.dialog_forgot_Close}>Cancel</Button> 
              <Button   variant="contained"   color="secondary" onClick={this.selected_extraDiscountCard}   className={classes.button_2}>Ok</Button>
          </DialogActions>
      </Dialog>   
      {/** dialog */} 

       {/** gift card input */}
       <Dialog
          fullWidth={true}
          maxWidth={'xs'}
          open={this.state.dialog_giftCard_code}
          onClose={this.dialog_forgot_Close}
          aria-labelledby="max-width-dialog-title"
          className={classes.dialog_1}     
        >     
          <DialogTitle id="simple-dialog-title" className={classes.dialog_title} >Input The Gift Code</DialogTitle>      
          <DialogContent className={classes.dialog_2}>          
                    <Grid container className={classes.giftCode}>                        
                        <Grid item xs={12} sm={12} md={12}>
                          <CustomInput
                            labelText="Gift Code"
                            inputProps={{
                              value: this.state.giftCardCode,
                            }}
                            formControlProps={{
                              required: true,
                              fullWidth: true,
                              value: this.state.giftCardCode,
                              onChange: this.handleChange_1('giftCardCode')
                            }}
                          />
                        </Grid>   

                        <Grid item xs={12} sm={12} md={12}>
                          <CustomInput
                            labelText="Amount"
                            inputProps={{
                              value: this.state.giftCard_amount,
                            }}
                            formControlProps={{
                              required: true,
                              fullWidth: true,
                              value: this.state.giftCard_amount,
                              onChange: this.handleChange_1('giftCard_amount')
                            }}
                          />
                        </Grid>                        
                    </Grid>
          </DialogContent>
          <DialogActions className={classes.cardFooter}>
              <Button color="primary" onClick={this.dialog_forgot_Close}>Cancel</Button> 
              <Button   variant="contained"   color="secondary" onClick={this.checkGiftCode}   className={classes.button_2}>Ok</Button>
          </DialogActions>
      </Dialog>   
      {/** dialog */} 
       {/** Discount Code input */}
       <Dialog
          fullWidth={true}
          maxWidth={'xs'}
          open={this.state.dialog_discount_code}
          onClose={this.dialog_forgot_Close}
          aria-labelledby="max-width-dialog-title"
          className={classes.dialog_1}     
        >     
          <DialogTitle id="simple-dialog-title" className={classes.dialog_title} >Input The Gift Code</DialogTitle>      
          <DialogContent className={classes.dialog_2}>          
                    <Grid container className={classes.giftCode}>                        
                        <Grid item xs={12} sm={12} md={12}>
                          <CustomInput
                            labelText="Discount Code"
                            inputProps={{
                              value: this.state.discountCode,
                            }}
                            formControlProps={{
                              required: true,
                              fullWidth: true,
                              value: this.state.discountCode,
                              onChange: this.handleChange_1('discountCode')
                            }}
                          />
                        </Grid>        
                    </Grid>
          </DialogContent>
          <DialogActions className={classes.cardFooter}>
              <Button color="primary" onClick={this.dialog_forgot_Close}>Cancel</Button> 
              <Button   variant="contained"   color="secondary" onClick={this.checkDiscountCode}   className={classes.button_2}>Ok</Button>
          </DialogActions>
      </Dialog>   
      {/** dialog */}

      <Fullscreen 
        fullScreen={this.state.openImage} 
        handleClose={this.fllScreenClose}
        imgSrc={this.state.imgSrc}
      ></Fullscreen>
      <Signup openSignup={this.state.openSignup}
        signUpClose={this.signUpClose}
        goBack={()=>{this.setState({openSignup:false,open_dialog:true})}}
        afterLogin={()=>{
          this.setState({openSignup:false,
          open_dialog:false,
          expanded: 'panel2',
          currentPanel:2
          });
         
          }}
      >
      </Signup>
      </div>
    );
  }
}

//export default withStyles(landingPageStyle)(withSnackbar(withLocalization(withAuth(GoogleApiWrapper({
 // api: ("AIzaSyDTCQc8JvRvCS5z-AZPv3UpX1HxesohbFs&libraries=places")
//})(CompanyLandingPage)))));

/**
export default withStyles(landingPageStyle) (GoogleApiWrapper({
   api: ("AIzaSyDTCQc8JvRvCS5z-AZPv3UpX1HxesohbFs")
 })(withSnackbar(withLocalization(withAuth(CompanyLandingPage)))));
 */

export default withStyles(landingPageStyle) (withSnackbar(withLocalization(withAuth(CompanyLandingPage))));