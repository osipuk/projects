import React from 'react';
import ReactDOM from 'react-dom';
import { HashRouter, Route, Switch,Redirect } from 'react-router-dom';
import { AuthProvider } from 'common/contexts/AuthContext';
import { SnackbarProvider, withSnackbar } from 'notistack';
import { LocalizationProvider } from 'common/contexts/LocalizationContext';
import { NotificationsProvider } from 'common/contexts/NotificationsContext';
import UserLoader from 'common/containers/UserLoader/UserLoader';
import LandingPage from './views/LandingPage';
import CompanyLandingPage from './views/CompanyLandingPage';
import NotFound from './views/NotFound';
import { get } from '../customer/api/customer';
import { login, logout, signup } from '../customer/api/auth';
import 'common/assets/css/material-react.css';

class App extends React.Component {
  state = {
    loading: true
  };

  onFinished = () => {
    this.setState({ loading: false });
  };

  render() {
    const { loading } = this.state;   
      return(
        <HashRouter>
          <LocalizationProvider
            lang="en"
            >
            <AuthProvider
              login={login}
              logout={logout}
              signup={signup}
              get={get}
            >
             <NotificationsProvider>
            {loading ? (
            <UserLoader onFinished={this.onFinished} />
            ) : (
              <SnackbarProvider 
                        maxSnack={2}
                     >
              <Switch>  
                <Route exact path="/:id" component={CompanyLandingPage} />   
                <Route path="/" component={LandingPage} />
                <Route path="/signup" component={LandingPage} />    
              </Switch> 
              </SnackbarProvider>
              )}      
          </NotificationsProvider>       
          </AuthProvider> 
          </LocalizationProvider>
        </HashRouter>
      )  
  }
}
  

ReactDOM.render(<App />, document.getElementById('root'));
