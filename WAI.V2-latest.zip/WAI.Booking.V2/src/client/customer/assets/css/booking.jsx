import {
  defaultFont,
  primaryColor,
  dangerColor,
  warningColor,
  successColor,
  infoColor,
  grayColor

} from "../../../common/assets/jss/material-react.jsx";

const bookingStyle =theme => ({

 
  cardCategoryWhite: {
    "&,& a,& a:hover,& a:focus": {
      color: "rgba(255,255,255,.62)",
      margin: "0",
      fontSize: "14px",
      marginTop: "0",
      marginBottom: "0"
    },
    "& a,& a:hover,& a:focus": {
      color: "#FFFFFF"
    }
  },
  cardTitleWhite: {
    color: "#FFFFFF",
    marginTop: "0px",
    minHeight: "auto",
    fontWeight: "300",
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    marginBottom: "3px",
    textDecoration: "none",
    "& small": {
      color: "#777",
      fontSize: "65%",
      fontWeight: "400",
      lineHeight: "1"
    }
  },
  cardBody_1:{
    overflowX:'auto',
    marginTop:'10px'
   
  },
  card: {
    minWidth: 275,
  },
  dialog_2:{
    padding:'0px !important'
  },

  root: {
    width: '100%',
    marginTop: theme.spacing.unit * 3,
    overflowX: 'auto',
  },  
  card_2:{
    marginBottom:'0px !important'
  },
  tableCellId:{
    width:'20px !important',
    padding: '4px 20px 4px 20px !important'
  },
  tableCellId_1:{    
    padding: '4px 0px !important',
    minWidth:'100px'
  },
  tableCellId_2:{    
    padding: '4px 0px !important',
    minWidth:'120px'
  },
  tableCellId_3:{    
    padding: '4px 0px !important',
    minWidth:'50px'
  },
  tableCellId_4:{    
    padding: '4px 0px !important',
    minWidth:'210px'
  },
  tableHeader_1:{
    color:grayColor,
    padding: '4px 26px 4px 24px !important'
  },
  tableHeader_2:{
    color:grayColor,
  },
  tableCell:{
    padding: '4px 16px 4px 14px !important',
    minWidth:'202px'
  },
  accept: {
    backgroundColor: "transparent",
    color: infoColor,
    boxShadow: "none"
  },
  edit:{
    backgroundColor: "transparent",
    color: primaryColor,
    boxShadow: "none"
  },
  close: {
    backgroundColor: "transparent",
    color: dangerColor,
    boxShadow: "none"
  },
  create: {
    backgroundColor: "transparent",
    color: '#FFF',
    boxShadow: "none",
    width: "27px",
    height: "27px",
    padding: "0"
  },
tableActionButton: {
    width: "27px",
    height: "27px",
    padding: "0"
  },
  header_2:{
    textAlign:'right',
    paddingRight: '15px',
    margin: 'auto'
  },
  
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 120,
    marginTop:'7px !important'
  },
  
});


export default bookingStyle;
