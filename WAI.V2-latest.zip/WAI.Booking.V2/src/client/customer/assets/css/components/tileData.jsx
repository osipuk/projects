const tileData = [
  
  {
    img: 'https://material-ui.com/static/images/grid-list/breakfast.jpg',
    title: 'Tasty burger',
    author: 'director90',
    cols:1,
  },
  {
    img: 'https://material-ui.com/static/images/grid-list/camera.jpg',
    title: 'Camera',
    author: 'Danson67',
    cols:1,
  },  
  {
    img: 'https://material-ui.com/static/images/grid-list/morning.jpg',
    title: 'Morning',
    author: 'fancycrave1',
    cols:1,
    
  },
  {
    img: 'https://material-ui.com/static/images/grid-list/hats.jpg',
    title: 'Hats',
    author: 'Hans',
    cols:1,
     
  }
];

export default tileData;