

import {
  defaultFont,
  primaryColor,
  dangerColor,
  warningColor,
  successColor,
  infoColor,
  grayColor,
  container, title
} from "../../../common/assets/jss/material-react.jsx";


const homePageStyle =theme => ({
  rootMenuScrollHide: {
    //overflowY: 'scroll',
    //webkitOverflowScrolling: 'touch',    
    paddingTop: '96px',
  },
  container: {
    zIndex: '12',
    color: '#FFFFFF',    
    ...container
  },
  
});

export default homePageStyle;
