import React from 'react';

// @material-ui/core components
import withStyles from '@material-ui/core/styles/withStyles';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import Success from '@material-ui/icons/CheckCircle';
// @material-ui/icons
import { Person, People } from '@material-ui/icons';

// localization
import withLocalization from 'common/contexts/LocalizationContext';
import withNotifications from 'common/contexts/NotificationsContext';
import withAuth from 'common/contexts/AuthContext';
// core components
import Button from 'common/components/CustomButtons/Button';
import Icon from '@material-ui/core/Icon';
import headerLinksStyle from '../../../p/assets/jss/components/headerLinksStyle';

const HeaderLinks = withLocalization(({ localization, ...props }) => {
  //const {notifications,localization,classes}=props;
  const { classes,notifications } = props; 
  const { localizedString } = localization;
  return (
    <List className={classes.list}>
      <ListItem className={classes.listItem}>
        <Button
          href="#/customer/booking_overview"
          color="transparent"
          target="_self"
          className={classes.navLink}
        >
          
          {' '}
          {localizedString('CUSTOMER_BOOKING_OVERVIEW')}
        </Button>
      </ListItem>
      <ListItem className={classes.listItem}>
        <Button
          href="#/customer/setting"
          color="transparent"
          target="_self"
          className={classes.navLink }
        >          
          {''}
          {localizedString('CUSTOMER_SETTING')}
        </Button>
      </ListItem>
      <ListItem className={classes.listItem}>
        <Button         
          color="transparent"   
          onClick={async () => {  
            setCookie('customer_email','');
            setCookie('customer_password', '');
            const result = await props.auth.logout();            
            if(result.success){
             notifications.show({message: localization.localizedString('YOU_HAVE_BEEN_LOGOUT'),icon:Success,color:'info'}); 
            }
          }}      
          className={classes.navLink + ' ' + classes.NavLinkSignUp}
        >
          
          {'Logout'}
          
        </Button>
      </ListItem>
      
    </List>
  );
});

function setCookie (cname,cvalue) {  
  var d = new Date();
  var exdays=30;
  d.setTime(d.getTime() + (exdays*24*60*60*1000));
 var expires = "expires=" + d.toGMTString();
 document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

const styles = theme => ({
  button2: {
    color: 'red !important',
    width:'300px !important',
    background:'red !important'
  },
 
});
export default withStyles(headerLinksStyle)(withNotifications(withLocalization(withAuth(HeaderLinks))));

