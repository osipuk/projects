import axios from 'axios';

import errors from '../../../common/error_codes';

export const login = async (customer) => { 
  try {
    const { data } = await axios.post('/api/customer/login', {
      user: {
        phone: customer.phone,
        password: customer.password
      }
    });

    if (!data.success || data.errorCode) {
      return {
        success: data.success,
        errorCode: data.errorCode,
        user: null
      };
    }
   
    return {
      success: data.success,
      errorCode: 0,
      user: data.customer
    };
  } catch (error) {
    console.log(`Error while company login: ${error}`);

    return {
      success: false,
      errorCode: errors.REQUEST_ERROR,
      user: null
    };
  }
};

export const logout = async () => {
  try {
    const { data } = await axios.post('/api/customer/logout');

    return {
      success: data.success,
      errorCode: data.errorCode ? data.errorCode : 0
    };
  } catch (error) {
    console.log(`Error while company logout: ${error}`);

    return {
      success: false,
      errorCode: errors.REQUEST_ERROR
    };
  }
};

export const signup = async (customer) => {
  try {
    const { data } = await axios.post('/api/customer/signup', { customer });

    console.log(`Data: ${JSON.stringify(data)}`);

    if (!data.success || data.errorCode) {
      return {
        success: data.success,
        errorCode: data.errorCode,
        user: null
      };
    }

    return {
      success: data.success,
      errorCode: 0,
      user: data.company
    };
  } catch (error) {
    console.log(`Error while company signup: ${error}`);

    return {
      success: false,
      errorCode: errors.REQUEST_ERROR,
      user: null
    };
  }
};
