import axios from 'axios';

import errors from '../../../common/error_codes';

export const get = async () => {
  try {
    const { data } = await axios.get('/api/customer');       
    if (!data.success || data.errorCode) {
      return {
        success: data.success,
        errorCode: data.errorCode,
        user: null
      };
    }

    return {
      success: data.success,
      errorCode: 0,
      user: data.customer
    };
  } catch (error) {
    console.log(`Error while company get: ${error}`);

    return {
      success: false,
      errorCode: errors.REQUEST_ERROR,
      user: null
    };
  }
};
