import React from 'react';
import './app.css';

const App = () => (
  <div>
    <h1>Customer Page</h1>
  </div>
);

export default App;
