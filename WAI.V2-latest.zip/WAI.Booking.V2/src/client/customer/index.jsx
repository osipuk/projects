import React from 'react';
import ReactDOM from 'react-dom';

/**
import App from './App.jsx';

ReactDOM.render(<App />, document.getElementById('root'));
 */
import { SnackbarProvider, withSnackbar } from 'notistack';
import { HashRouter, Route, Switch } from 'react-router-dom';
import { LocalizationProvider } from 'common/contexts/LocalizationContext';
import { AuthProvider } from 'common/contexts/AuthContext';
import { NotificationsProvider } from 'common/contexts/NotificationsContext';
import { LoadingProvider } from 'common/contexts/LoadingContext';

import ProtectedRoute from 'common/containers/ProtectedRoute/ProtectedRoute';
import UserLoader from 'common/containers/UserLoader/UserLoader';
import HomePage from './views/HomePage';
import { login, logout, signup } from './api/auth';
import Login from './views/Login';
import { get } from './api/customer';
import Signup from './views/Signup';
import Landing from '../p/views/LandingPage';
import CompanyLandingPage from '../p/views/CompanyLandingPage';
import 'common/assets/css/material-react.css';


class App extends React.Component {
    state = {
      loading: true
    };
  
    onFinished = () => {
      this.setState({ loading: false });
    };
  
    render() {
      const { loading } = this.state;
  
      return (
        <HashRouter>
          <LocalizationProvider lang="en">
            <LoadingProvider>
              <AuthProvider
                login={login}
                logout={logout}
                signup={signup}
                get={get}
              >
                <NotificationsProvider>
                  {loading ? (
                    <UserLoader onFinished={this.onFinished} />
                  ) : (
                    <SnackbarProvider 
                        maxSnack={2}
                     >
                    <Switch>                     
                      <Route exact path="/signup" component={Signup} />   
                      <Route exact path="/login" component={Login} />
                      <Route exact path="/" component={Landing} />
                      <Route exact path="/:id" component={CompanyLandingPage} />         
                      <ProtectedRoute path="/customer" component={HomePage} loginURL="../login" />                                       
                    </Switch>
                    </SnackbarProvider>
                  )}
                </NotificationsProvider>
              </AuthProvider>
            </LoadingProvider>
          </LocalizationProvider>
        </HashRouter>
      );
    }
  }
  
ReactDOM.render(<App />, document.getElementById('root'));

