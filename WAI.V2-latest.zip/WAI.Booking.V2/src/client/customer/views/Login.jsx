import React from 'react';

import Link from 'react-router-dom/es/Link';

import withStyles from '@material-ui/core/styles/withStyles';
import InputAdornment from '@material-ui/core/InputAdornment';
import Icon from '@material-ui/core/Icon';
import Grid from '@material-ui/core/Grid';
import Phone from '@material-ui/icons/Phone';
import TextField from '@material-ui/core/TextField';
import LockOutlined from '@material-ui/icons/LockOutlined';
import Typography from '@material-ui/core/Typography';
import Checkbox from '@material-ui/core/Checkbox';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormLabel from '@material-ui/core/FormLabel';
import axios from 'axios';
import {  withSnackbar } from 'notistack';
//import Button from 'common/components/CustomButtons/Button';
import Button from "@material-ui/core/Button";
import withLocalization from 'common/contexts/LocalizationContext';
import withAuth from 'common/contexts/AuthContext';
import GridContainer from 'common/components/Grid/GridContainer';
import GridItem from 'common/components/Grid/GridItem';
import Card from 'common/components/Card/Card';
import CardBody from 'common/components/Card/CardBody';
import CardHeader from 'common/components/Card/CardHeader';
import CardFooter from 'common/components/Card/CardFooter';
import LoginButton from 'common/containers/LoginButton/LoginButton';
import landingPageStyle from "../../p/assets/jss/views/landingPage";
import bgImage from '../assets/img/businessBg.jpg';

class LoginPage extends React.Component {
  state = {
    phone: '',
    password: '',
    remember_me:false,
    type:'customer',
    card_status:'login'
  };

  async componentDidMount() {
   
    const { auth: { isAuth, user }, history,auth } = this.props;    
    if (isAuth && user) {
      history.push('/customer/booking_overview');
    }
    else{     
      if(this.getCookie('customer_email')!='' && this.getCookie('customer_password')!='' ){              
        let userData={};
        userData.phone=this.getCookie('customer_email');
        userData.password=this.getCookie('customer_password');
        const result = await auth.login(userData);
      }
    }
    
  }
  forgetPassword=()=>{    
    this.setState({card_status:'forgot'});
  }
  loginCard=()=>{
    this.setState({card_status:'login'});
  }
  getCookie=(cname)=>{
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i < ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }
   componentDidUpdate (prevProps, prevState, snapshot) {
    const { auth: { isAuth: prevIsAuth, user: prevUser } } = prevProps;
    const { auth: { isAuth: newIsAuth, user: newUser }, history } = this.props;

    if (!prevIsAuth && newIsAuth && !prevUser && newUser) {
      history.push('/customer/booking_overview');
    }
    
  }

  handleToggle = prop => event => this.setState({ [prop]: event.target.checked });

  handleChange = prop => event => {
    this.setState({ [prop]: event.target.value });
  };

  handleClickShowPassword = () => {
    this.setState(state => ({ showPassword: !state.showPassword }));
  };
  keyPressPassword=async(e)=>{
    if (e.key === 'Enter') {
         var userData={};
        const {auth,localization}=this.props;
        userData.phone=this.state.phone;
        userData.password=this.state.password;
        const result = await auth.login(userData); 
        if(result.success){         
          if(this.state.remember_me){
            setCookie('customer_email', this.state.phone);
            setCookie('customer_password', this.state.password);
          }        
        }
        else{         
          this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
            variant: 'error',
          }); 
        }   
    }
  }
  setCookieForSubmit=(cname,cvalue)=>{ 
    var d = new Date();
    var minutes=60;
    d.setTime(d.getTime() + (minutes*60*1000));
   var expires = "expires=" + d.toGMTString();
   document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
  }
  newPassword=async()=>{
    const {localization,classes}=this.props;   
    if(this.state.phone==''){   
      this.props.enqueueSnackbar(localization.localizedError(13), { 
        variant: 'error',
      }); 
      return;
    }
    if(this.getCookie('submit')=='true'){
      this.props.enqueueSnackbar(localization.localizedError(35), { 
        variant: 'error',
      }); 
      return;
    }   
    
    var  {data} = await axios.post('/api/customer/phone_send',
      {       
        phone:this.state.phone
      }); 

      if(data.success){
        this.props.enqueueSnackbar(localization.localizedString('NEW_PASSWORD_SENT_SUCCESS'), { 
          variant: 'success',
        }); 
        this.setState({card_status:'login',phone:''});
        this.setCookieForSubmit("submit",'true');
      }
      else{
        console.log(data.errorCode)
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
      }

  }
  forgot_password=()=>{
    const {classes,localization}=this.props;
    const { phone, password,remember_me,type } = this.state;
    return    <form className={classes.form}>      
    <CardBody className={classes.cardBody}>
    <Grid container className={classes.GridContainer}>
          <Grid item xs={12} sm={12} md={12}>
            <Typography  variant="h3" gutterBottom className={classes.signTitle}>
               Reset Password
            <br/>
            </Typography>
            <Typography component="p">
                Please put the your phone number.
            </Typography>   
          </Grid>
    </Grid>                
    <Grid container className={classes.GridContainer}>
       <Grid item xs={12} sm={12} md={12}>              
          <TextField
              id="phone"
              label={localization.localizedString('LOGIN_PHONE_LABEL')}
              InputLabelProps={{
                classes: {
                  root: classes.cssLabel,
                  focused: classes.cssFocused,
                },
              }}
              InputProps={{
                type: 'text',
                classes: {
                  root: classes.cssOutlinedInput,
                  focused: classes.cssFocused,
                  underline: classes.cssUnderline                     
                },
                endAdornment: (
                        <InputAdornment position="end">
                          <Icon className={classes.iconTextFieldPos}>
                            <Phone className={classes.inputIconsColor} />
                          </Icon>
                        </InputAdornment>
                      ),
              }}
              className={classes.textField}
              value={phone}
              onChange={this.handleChange('phone')}
              
              margin="normal"
              fullWidth
            />
        </Grid>
      </Grid>
        <Grid container className={classes.GridContainer}>
            <Grid  item xs={12} sm={12} md={12}>
              <Typography
                variant="subheading" 
                className={classes.forgotPass}
                onClick={this.loginCard}
                >
                Already have login and password? Sign in
              </Typography>      
            </Grid>
          </Grid>
      </CardBody>
      <CardFooter className={classes.cardFooterBycustomer_1}>                   
          <Grid item xs={12} sm={12} md={6} lg={6} xl={6}>
            <Button
              variant="contained"
              color="secondary"                       
              className={classes.button}
              onClick={this.newPassword}
              >
              Submit
            </Button>
          </Grid>
          <Grid item xs={12} sm={12} md={6} lg={6} xl={6} style={{textAlign:'right'}}>                       
          </Grid>
                   
   </CardFooter>
  </form>
  }
  login_cardBody=()=>{
    const {classes,localization}=this.props;
    const { phone, password,remember_me,type } = this.state;
    return   <form className={classes.form}>             
     <CardBody className={classes.cardBody}>
    <Grid container className={classes.GridContainer}>
          <Grid item xs={12} sm={12} md={12}>
            <Typography  variant="h3" gutterBottom className={classes.signTitle}>
            {localization.localizedString('LOGIN_FORM_TITLE_CUSTOMER')}
            <br/>
            </Typography>
            <Typography component="p">
                Manage your booking requests, see previous appointments and more.
            </Typography>   
          </Grid>
    </Grid>                
    <Grid container className={classes.GridContainer}>
       <Grid item xs={12} sm={12} md={12}>              
          <TextField
              id="phone"
              label={localization.localizedString('LOGIN_PHONE_LABEL')}
              InputLabelProps={{
                classes: {
                  root: classes.cssLabel,
                  focused: classes.cssFocused,
                },
              }}
              InputProps={{
                type: 'text',
                classes: {
                  root: classes.cssOutlinedInput,
                  focused: classes.cssFocused,
                  underline: classes.cssUnderline                     
                },
                endAdornment: (
                        <InputAdornment position="end">
                          <Icon className={classes.iconTextFieldPos}>
                            <Phone className={classes.inputIconsColor} />
                          </Icon>
                        </InputAdornment>
                      ),
              }}
              className={classes.textField}
              value={phone}
              onChange={this.handleChange('phone')}
              
              margin="normal"
              fullWidth
            />
        </Grid>
      </Grid>
  <Grid container className={classes.GridContainer}>
    <Grid item xs={12} sm={12} md={12}> 
      <TextField
              id="password"
              label={localization.localizedString('LOGIN_PASSWORD_LABEL')}
              InputLabelProps={{
                classes: {
                  root: classes.cssLabel,
                  focused: classes.cssFocused,
                },
              }}
              InputProps={{
                type: 'password',
                classes: {
                  root: classes.cssOutlinedInput,
                  focused: classes.cssFocused,
                  underline: classes.cssUnderline                  
                },
                endAdornment: (
                      <InputAdornment position="end">
                        <Icon className={classes.iconTextFieldPos}>
                          <LockOutlined className={classes.inputIconsColor} />
                        </Icon>
                       </InputAdornment>
                      ),
              }}
              className={classes.textField}
              value={password}
              onChange={this.handleChange('password')}
              onKeyPress={(event)=>this.keyPressPassword(event)}
              margin="normal"
              fullWidth
            />
     </Grid>
     <Grid item xs={12} sm={6} md={6}>
          <FormControlLabel
          control={(
            <Checkbox
              tabIndex={-1}                                                               
              checked={this.state.remember_me}
              onClick={this.handleToggle('remember_me')}
            />
          )}
          classes={{ label: classes.label }}
          label={"Remember me"}
        />
     </Grid>
     <Grid  item xs={12} sm={6} md={6}>
        <Typography
         variant="subheading" 
         className={classes.forgotPass}
         onClick={this.forgetPassword}
         >
          Forgot the password?
        </Typography>

     </Grid>
   </Grid>
    </CardBody>
    <CardFooter className={classes.cardFooterBycustomer_1}>
                   
                      <Grid item xs={12} sm={12} md={6} lg={6} xl={6}>
                        <LoginButton                        
                          variant="contained"
                          color="secondary"                        
                          userData={{ phone, password,remember_me,type }}
                        />
                      </Grid>
                      <Grid item xs={12} sm={12} md={6} lg={6} xl={6} style={{textAlign:'right'}}>                    
                        <Link to="/signup">
                          {localization.localizedString('LOGIN_CREATE_COMPANY_LINK')}
                        </Link>
                      
                      </Grid>
                   
   </CardFooter>
  </form>
  }
  render() {
    const { localization, classes } = this.props;
    const { phone, password,remember_me,type,card_status } = this.state;

    return (
      <div
        className={classes.pageHeader}
        style={{
          backgroundImage: `url(${'../'+bgImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'top center'
        }}
      >
        <div className={classes.containerSignup}>
          <GridContainer justify="center">
            <GridItem xs={12}>
              <Card >                                    
                  {card_status=='login'?this.login_cardBody():this.forgot_password()}    
              </Card>
            </GridItem>
          </GridContainer>
        </div>
      </div>
    );
  }
}
function setCookie(cname,cvalue) { 
  var d = new Date();
  var exdays=30;
  d.setTime(d.getTime() + (exdays*24*60*60*1000));
 var expires = "expires=" + d.toGMTString();
 document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}
export default withStyles(landingPageStyle)(withSnackbar(withLocalization(withAuth(LoginPage))));
