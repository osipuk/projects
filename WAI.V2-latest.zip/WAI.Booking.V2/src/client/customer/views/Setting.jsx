import React from 'react';

import withStyles from '@material-ui/core/styles/withStyles';
import axios from 'axios';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import {  withSnackbar } from 'notistack';
import withLocalization from '../../common/contexts/LocalizationContext';
import withAuth from '../../common/contexts/AuthContext';
import withNotifications from '../../common/contexts/NotificationsContext';
import GridContainer from '../../common/components/Grid/GridContainer';
import GridItem from '../../common/components/Grid/GridItem';
import Card from '../../common/components/Card/Card';
import CardBody from '../../common/components/Card/CardBody';
import CardHeader from '../../common/components/Card/CardHeader';
import CardFooter from '../../common/components/Card/CardFooter';
import CustomInput from '../../common/components/CustomInput/CustomInput';
//import Button from "../../common/components/CustomButtons/Button.jsx";
import Button from "@material-ui/core/Button";
import Success from '@material-ui/icons/CheckCircle';
import settingPageStyle from '../assets/css/settings';
//import signupPageStyle from '../../../common/assets/jss/material-react/views/loginPage';


class Setting extends React.Component {
  state = {
    email: '',    
    firstName: '',
    lastName: '',
    countryCode: '',
    phone: '',
    oldPhone:'',
    zipCode: '',
    city: '',
    address1: '',
    address2: '',    
    country:[],
    countryId:0,
    verifyCode:'',
    cardState:'update',
    sr_verify_code:''   
  };

  componentWillMount(){
  this.loadCustomerProfile();      
  }

  loadCustomerProfile=async()=>{
    const {notifications,localization,auth}=this.props;
    const { data } = await  axios.get('/api/customer');    
    var customer=data.customer;   
    if(data.success){
      this.setState({
        email:customer.email?data.customer.email:'', 
        firstName:customer.firstName?customer.firstName:'', 
        lastName:customer.lastName?customer.lastName:'', 
        phone:customer.phone?customer.phone:'',
        oldPhone:customer.phone,
        zipCode:customer.zipCode?customer.zipCode:'', 
        city:customer.city?customer.city:'', 
        address1:customer.address1?customer.address1:'', 
        address2:customer.address2?customer.address2:'', 
        countryId:customer.countryId
       
      })
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
  }
  handleChange = prop => event => this.setState({ [prop]: event.target.value });
  smsNameChange= prop => event =>{
    if(event.target.value.length>11)
     return;
    this.setState({ [prop]: event.target.value })
  }
  //handleToggle = prop => event => this.setState({ [prop]: event.target.checked });
  update=async()=>{    
    const { localization} = this.props; 
        if(this.state.oldPhone!=this.state.phone){
          var { data } = await axios.post('/api/customer/phone', {
            customer:{ 
                phone:this.state.phone,
                countryId:this.state.countryId
            }
          });
          console.log(data,'verify part');
          if (!data.success) {
            this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
              variant: 'error',
            }); 
          }
          else{
            this.setState({cardState:'verify',sr_verify_code:data.verify_code});
          }
        }
        else{
          var { data } = await axios.put('/api/customer/', {
            customer:{ 
                email:this.state.email,
                firstName:this.state.firstName,
                lastName:this.state.lastName,
                phone:this.state.phone,           
                zipCode:this.state.zipCode,
                city:this.state.city,
                address1:this.state.address1,
                address2:this.state.address2,
            }
          });
          if (!data.success) {
            this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
              variant: 'error',
            }); 
          }
          else{               
            this.props.enqueueSnackbar(localization.localizedString('UPDATED_SUCCESS'), { 
              variant: 'success',
            }); 
            this.loadCustomerProfile();
          }
        }          
    
     
  }
  checkRequiredFields = () => {
    const {
      email,  firstName, lastName,
       phone, zipCode,
      city, address1,address2,
    } = this.state;

    return (email && email.length > 0)     
      && (firstName && firstName.length > 0)
      && (lastName && lastName.length > 0)      
      && (phone && phone.length > 0)     
      && (zipCode && zipCode.length > 0)
      && (city && city.length > 0)
      && (address1 && address1.length > 0)
      && (address2 && address2.length > 0);
     
  };
  submitVerifyCode=async()=>{
    const { localization } = this.props;
    if(this.state.verifyCode==this.state.sr_verify_code){
        var { data } = await axios.put('/api/customer', {
          customer:{ 
              email:this.state.email,
              firstName:this.state.firstName,
              lastName:this.state.lastName,
              phone:this.state.phone,           
              zipCode:this.state.zipCode,
              city:this.state.city,
              address1:this.state.address1,
              address2:this.state.address2,
              //password:this.state.verifyCode
          }
        });
        if (!data.success) {
          this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
            variant: 'error',
          }); 
        }
        else{
          this.setState({cardState:'update'});
          this.loadCustomerProfile();     
          
        }
    }
    else{     
      this.props.enqueueSnackbar(localization.localizedError(25), { 
        variant: 'error',
      }); 
    }
  }
  verifyBody=()=>{
    const { localization, classes } = this.props;
     return <Grid item xs={12} sm={12} md={4} 
     style={{
      marginTop: '20vh'
    }}>
     <Card>
     <form className={classes.form}>
     <CardHeader color="info" className={classes.cardHeader}>
       <h4>Phone Veryfy</h4>
     </CardHeader>
     <CardBody>
       <Grid container justify="center">
         <GridItem xs={12} sm={12} md={7}>
          <CustomInput
              labelText={'Verify Code'}
              formControlProps={{
                required: true,
                fullWidth: true
              }}
              inputProps={{
                type: 'text',
                value: this.state.verifyCode,
                onChange: this.handleChange('verifyCode')
              }}
            />
         </GridItem>
         </Grid>
        </CardBody>
        <CardFooter className={classes.cardFooter}>
        <Button onClick={() =>(this.submitVerifyCode())}                      
            color="secondary"            
            disabled={this.state.verifyCode.length==0}
            >Submit</Button>  
        </CardFooter>
      </form>
    </Card>
    </Grid>
  }
  cardBody=()=>{
    const { localization, classes } = this.props;
    const {
      email, firstName, lastName,
       phone,  zipCode,
      city, address1, address2,      
    } = this.state;

    if(this.state.cardState!='update'){
      return this.verifyBody();
    }
    
    return  <GridItem xs={12} sm={12} md={8}>
    <Card>
    <form className={classes.form}>
      <CardHeader color="info" className={classes.cardHeader}>
        <h4>{localization.localizedString('DASHBOARD_SIDEBAR_SETTINGS_NAME')}</h4>
      </CardHeader>
      <CardBody className={classes.cardBody_1}>
        <GridContainer>                   
          
          <GridItem xs={12} sm={12} md={6}>
            <CustomInput
              labelText={localization.localizedString('SIGNUP_FIRST_NAME_LABEL')}
              formControlProps={{
                required: true,
                fullWidth: true
              }}
              inputProps={{
                type: 'text',
                value: firstName,
                onChange: this.handleChange('firstName')
              }}
            />
          </GridItem>
          <GridItem xs={12} sm={12} md={6}>
            <CustomInput
              labelText={localization.localizedString('SIGNUP_LAST_NAME_LABEL')}
              formControlProps={{
                required: true,
                fullWidth: true
              }}
              inputProps={{
                type: 'text',
                value: lastName,
                onChange: this.handleChange('lastName')
              }}
            />
          </GridItem>

          <GridItem xs={12} sm={12} md={6}>
            <CustomInput
              labelText={localization.localizedString('SIGNUP_EMAIL_LABEL')}
              formControlProps={{
                required: true,
                fullWidth: true
              }}
              inputProps={{
                type: 'text',
                value: email,
                onChange: this.handleChange('email')
              }}
            />
          </GridItem>
          <GridItem xs={12} sm={12} md={6}>
            <CustomInput
              labelText={localization.localizedString('SIGNUP_PHONE_LABEL')}
              formControlProps={{
                required: true,
                fullWidth: true
              }}
              inputProps={{
                type: 'text',
                value: phone,
                onChange: this.handleChange('phone')
              }}
            />
          </GridItem>                      
          <GridItem xs={12} sm={12} md={4}>
            <CustomInput
              labelText={localization.localizedString('SIGNUP_ZIP_CODE_LABEL')}
              formControlProps={{
                required: true,
                fullWidth: true
              }}
              inputProps={{
                type: 'text',
                value: zipCode,
                onChange: this.handleChange('zipCode')
              }}
            />
          </GridItem>
          <GridItem xs={12} sm={12} md={8}>
            <CustomInput
              labelText={localization.localizedString('SIGNUP_CITY_LABEL')}
              formControlProps={{
                required: true,
                fullWidth: true
              }}
              inputProps={{
                type: 'text',
                value: city,
                onChange: this.handleChange('city')
              }}
            />
          </GridItem>
          <GridItem xs={12} sm={12} md={7}>
            <CustomInput
              labelText={localization.localizedString('SIGNUP_ADDRESS_LABEL_1')}
              formControlProps={{
                required: true,
                fullWidth: true
              }}
              inputProps={{
                type: 'text',
                value: address1,
                onChange: this.handleChange('address1')
              }}
            />
          </GridItem>
          <GridItem xs={12} sm={12} md={5}>
            <CustomInput
              labelText={localization.localizedString('SIGNUP_ADDRESS_LABEL_2')}
              formControlProps={{
                required: true,
                fullWidth: true
              }}
              inputProps={{
                type: 'text',
                value: address2,
                onChange: this.handleChange('address2')
              }}
            />
          </GridItem>  
        </GridContainer>
      </CardBody>
      <CardFooter className={classes.cardFooter}>
          <Button onClick={() =>(this.update())}                      
          color="secondary"  
          disabled={!this.checkRequiredFields()}
          >Update</Button>  
      </CardFooter>
    </form>
    </Card>
    </GridItem>
  }
  render() {  

    return (       
          <GridContainer justify="center">            
                {this.cardBody()}            
          </GridContainer>
        
     
    );
  }
}
export default withStyles(settingPageStyle)(withSnackbar(withLocalization(withAuth(Setting))));

