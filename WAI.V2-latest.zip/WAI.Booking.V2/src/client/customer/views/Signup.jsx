import React from 'react';

import Link from 'react-router-dom/es/Link';

//import withStyles from '@material-ui/core/styles/withStyles';
import { withStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import TextField from '@material-ui/core/TextField';
import InputAdornment from '@material-ui/core/InputAdornment';
import Icon from "@material-ui/core/Icon";
import Looks1Outlined from '@material-ui/icons/LooksOneOutlined';
import Looks2Outlined from '@material-ui/icons/LooksTwoOutlined';
import Button from "@material-ui/core/Button";
import axios from 'axios';
import ReactPhoneInput from 'react-phone-input-mui';
import Typography from '@material-ui/core/Typography';
import {withSnackbar } from 'notistack';
import withLocalization from 'common/contexts/LocalizationContext';
import withAuth from 'common/contexts/AuthContext';
import withLoading from 'common/contexts/LoadingContext';
import withNotifications from 'common/contexts/NotificationsContext';
import GridContainer from 'common/components/Grid/GridContainer';
import GridItem from 'common/components/Grid/GridItem';
import Card from 'common/components/Card/Card';
import CardBody from 'common/components/Card/CardBody';
import CardHeader from 'common/components/Card/CardHeader';
import CardFooter from 'common/components/Card/CardFooter';
import CustomInput from 'common/components/CustomInput/CustomInput';
import signupPageStyle from 'common/assets/jss/material-react/views/loginPage';
import landingPageStyle from "../../p/assets/jss/views/landingPage";
import bgImage from '../assets/img/businessBg.jpg';

class SignupPage extends React.Component {
  state = {
    cardState:'signUp',//signUp
    firstName: '',
    lastName: '',   
    phone: '',
    countries:[],
    country:["dk"],
    countryId:1,
    verifyCode:'',
    dialCode:'',   
  };
  
  componentWillMount(){    
    this.loadCountryInf();
  }
  
  componentDidUpdate(prevProps, prevState, snapshot) {
    const { auth: { isAuth: prevIsAuth, user: prevUser } } = prevProps;
    const { auth: { isAuth: newIsAuth, user: newUser }, history } = this.props; 
    if (!prevIsAuth && newIsAuth && !prevUser && newUser) {
      history.push('/');
    }
  }
  loadCountryInf=async()=>{
    const { data } = await axios.get('/api/company/countrys');   
    if(data.success){
      var temp=[];
      data.country.map(row=>{
        temp.push(row.country_prefix);
      });     
      this.setState({country:temp,countries:data.country});    
    }    
  }

  handleChange = prop => event => this.setState({ [prop]: event.target.value }); 

  checkRequiredFields = () => {
    const {
      firstName, lastName,
      countryId, phone,
    } = this.state;   
    return (firstName && firstName.length > 0)
      && (lastName && lastName.length > 0)     
      && (phone && phone.length > 0)    
     
  };
  handleOnChange=(val,event)=>{    
    this.setState({phone:val,dialCode:"+"+event.dialCode});   
  }
  signUp=async()=>{
      const {localization}=this.props;
      var countryId=1;
      this.state.countries.map(row=>{
        if(row.country_phone_code==this.state.dialCode){
          countryId=row.id;
        }
      });
     var phone_number=this.state.phone.substring(3,15);      
     //this.props.loading.show();
     var userData={customer:{
       firstName:this.state.firstName,
       lastName:this.state.lastName,
       countryId:countryId,
       phone:phone_number.replace(/\s+/g, ''),
       type:'customer'
     }}
    
    
      try {
       // const result = await this.props.auth.signup(userData);
       const { data } = await axios.post('/api/customer/signup',  userData );
        var result=data;      
        if (!result.success) {          
          this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
            variant: 'error',
          }); 
        }
        else{
          this.setState({cardState:'verify'})
        }
      } finally {
        this.props.loading.hide();
      }
      
  }
  submitVerifyCode=async()=>{
    const {localization}=this.props;
    this.props.loading.show();
      try {              
        var phone_number=this.state.phone.substring(3,15);   
        var userData={phone:phone_number.replace(/\s+/g, ''),password:this.state.verifyCode,type:'customer'};
        const result = await this.props.auth.login(userData);
        if (!result.success) {        
          this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
            variant: 'error',
          }); 
        }
        else{
          this.setState({cardState:'verify'})
        }
      } finally {
        this.props.loading.hide();
      }
  }
  cardBody=()=>{   
    if(this.state.cardState!='signUp'){
      return this.verifyBody();
    }
    else{
      return this.signBody();
    }
  }
  verifyBody=()=>{
    const { localization, classes } = this.props;
     return <form className={classes.form}>   
     <CardBody className={classes.cardBody}>
       <Grid container className={classes.GridContainer}>
              <GridItem xs={12} sm={12} md={12}>
                <Typography  variant="h4" gutterBottom className={classes.signTitle}>
                  Phone Verify
                </Typography>
              </GridItem>
        </Grid>
       <Grid container justify="center" className={classes.GridContainer}>
         <Grid item xs={12} sm={12} md={12}>
          <TextField
            id="outlined-name"
            label="Verify Code"
            InputLabelProps={{
                  classes: {
                    root: classes.cssLabel,
                    focused: classes.cssFocused,
                  },
                }}
                InputProps={{
                  classes: {
                    root: classes.cssOutlinedInput,
                    focused: classes.cssFocused,
                    //notchedOutline: classes.notchedOutline,                    
                  },
            }}
            className={classes.textField}
            value={this.state.verifyCode}
            onChange={this.handleChange('verifyCode')}
            margin="normal"
            fullWidth
          />
         </Grid>
         </Grid>
        </CardBody>
        <CardFooter className={classes.cardFooterBycustomer}>
        <Button onClick={() =>(this.submitVerifyCode())}                      
              variant="contained"
              color="secondary" 
            disabled={this.state.verifyCode.length==0}
            >Submit</Button>  
        </CardFooter>
      </form>

  }
  signBody=()=>{
    const { localization, classes } = this.props; 
    return  <form className={classes.form}>    
    <CardBody className={classes.cardBody}>
       <Grid container className={classes.GridContainer}>
            <Grid item xs={12} sm={12} md={12}>
              <Typography  variant="h4" gutterBottom className={classes.signTitle}>
              {localization.localizedString('SIGNUP_FORM_TITLE_CUSTOMER')}
              </Typography>
              <Typography component="p">
                            It's free and you will have access to all our features :-) Start accepting Dankort, MasterCard, VISA and PayPal in no time wthout any costs.
                            </Typography>  
            </Grid>
      </Grid>
      <div className={classes.loginFormLayout}>
      <Grid container className={classes.GridContainer}>
           <Grid item xs={12} sm={12} md={12}>
            <TextField
                id="outlined-name"
                label="First name"
                InputLabelProps={{
                  classes: {
                    root: classes.cssLabel,
                    focused: classes.cssFocused,
                  },
                }}
                InputProps={{
                  classes: {
                    root: classes.cssOutlinedInput,
                    focused: classes.cssFocused,
                    underline: classes.cssUnderline                     
                  },
                  endAdornment: (
                    <InputAdornment position="end">
                      <Icon>
                        <Looks1Outlined className={classes.inputIconsColor} />
                      </Icon>
                    </InputAdornment>
                  ),
                }}
                className={classes.textField}
                value={this.state.firstName}
                onChange={this.handleChange('firstName')}
                margin="normal"
                fullWidth
              />
        </Grid>
        </Grid>
        <Grid  container className={classes.GridContainer}>
        <Grid item xs={12} sm={12} md={12}>
          <TextField
                id="outlined-name"
                label="Last name"
                InputLabelProps={{
                  classes: {
                    root: classes.cssLabel,
                    focused: classes.cssFocused,
                  },
                }}
                InputProps={{
                  classes: {
                    root: classes.cssOutlinedInput,
                    focused: classes.cssFocused,
                    underline: classes.cssUnderline    
                  },
                  endAdornment: (
                    <InputAdornment position="end">
                      <Icon>
                        <Looks2Outlined className={classes.inputIconsColor} />
                      </Icon>
                    </InputAdornment>
                  ),
                }}
                className={classes.textField}
                value={this.state.lastName}
                onChange={this.handleChange('lastName')}
                margin="normal"
                fullWidth
              />         
        </Grid>
        </Grid>
        <Grid container className={classes.GridContainer2}>
                
        <Grid item xs={12} sm={12} md={12} >  
        <Typography component="p" className={classes.PhoneLabel}>
                     We will send you a SMS with your password.
        </Typography>          
          <ReactPhoneInput 
            defaultCountry={'dk'} 
            onlyCountries={this.state.country}
            regions={'europe'}
            component={TextField}   
            onChange={this.handleOnChange}
            value={this.state.phone}
            countryCodeEditable={false}
            />
        </Grid>                     
      </Grid>
      </div>
    </CardBody>
    <CardFooter className={classes.cardFooterBycustomer_1}>
    <Grid item xs={12} sm={12} md={6} lg={6} xl={6}>
    <Button onClick={() =>(this.signUp())}       
    style={{fontSize: '0.875rem', fontWeight: '600'}}               
        variant="contained"
        color="secondary"  
        className={classes.button}>Sign up</Button>  
    
    </Grid>
    <Grid item xs={12} sm={12} md={6} lg={6} xl={6}  style={{textAlign:'right'}}>
                        <Link to="/login">
                          BACK
                        </Link>
                      </Grid>
    </CardFooter>
  </form>
  }
  render() {
    const { localization, classes } = this.props;  

    return (
      <div
        className={classes.pageHeader}
        style={{
          backgroundImage: `url(${'../'+bgImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'top center'
        }}
      >
        <div
          className={classes.containerSignup}>
          <GridContainer justify="center">
            <GridItem xs={12}>
              <Card>
               {this.cardBody()}
              </Card>
            </GridItem>
          </GridContainer>
        </div>
      </div>
    );
  }
}


export default withStyles(landingPageStyle)(withLoading(withSnackbar(withLocalization(withAuth(SignupPage)))));

