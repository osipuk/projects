import React from "react";
import { Switch, Route, Redirect } from 'react-router-dom';
import withStyles from "@material-ui/core/styles/withStyles";



import withLocalization from "common/contexts/LocalizationContext";
import homePageStyle from "../assets/css/home";
import Header from "../components/Header/Header";
import HeaderLinks from "../components/Header/HeaderLinks";
import homeRoutes from '../routes/routes';

/**
import "../assets/style.css";

 */
const dashboardRoutes = [];
class HomePage extends React.Component {


  componentDidUpdate(prevProps, prevState, snapshot) {
   
    //const { history: prevHistory } = prevProps;
    //const { history } = this.props;
   
  }
  routes = props => (
    <Switch>
      {homeRoutes(props).map((prop, key) => {
        if (prop.redirect) {
          return <Redirect from={prop.path} to={prop.to} key={key} />;
        }
        return <Route path={prop.path} component={prop.component} key={key} />;
      })}
    </Switch>
  );

  render(){
    const { classes } = this.props;
    return(
        <div className={classes.rootMenuScrollHide}>
            <Header
              color="white"
              brand={this.props.localization.localizedString("BRAND")}
              rightLinks={<HeaderLinks />}
              changeColorOnScroll={{
                height: 400,
                color: "white"
              }}
            />
          
            <div className={classes.container}>{this.routes()}</div>
          
        </div>

    )
  }
}
export default withStyles(homePageStyle)(withLocalization(HomePage));