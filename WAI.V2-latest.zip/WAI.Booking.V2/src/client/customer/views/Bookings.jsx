import React from 'react';
import moment from 'moment'
import withStyles from '@material-ui/core/styles/withStyles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Button from '@material-ui/core/Button';
import axios from 'axios';
import {  withSnackbar } from 'notistack';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import Typography from '@material-ui/core/Typography';
import withAuth from '../../common/contexts/AuthContext';
import withNotifications from '../../common/contexts/NotificationsContext';
import GridItem from "../../common/components/Grid/GridItem.jsx";
import GridContainer from "../../common/components/Grid/GridContainer.jsx";
import withLocalization from '../../common/contexts/LocalizationContext';
import Card from "../../common/components/Card/Card.jsx";
import CardHeader from "../../common/components/Card/CardHeader.jsx";
import CardBody from "../../common/components/Card/CardBody.jsx";
import bookingStyle from '../assets/css/booking';
class Booking extends React.Component {
  constructor(props){
  super (props);
  this.state={ 
    serviceId:0,
    labelWidth:0,   
    bookingId:0,  
    serviceIds:'',
    bookingIds:'',
    bookings:[],
    services:[],
    serviceAddons:[],
    companies:[]
  }; 
}
  componentDidMount(){
    this.loadBookingData();   
  }
  loadBookingData=async()=>{
    const {notifications,localization,auth}=this.props;    
    const { data } = await axios.get('/api/customer/booking');   
    if(data.success){
      let bookings=data.bookings;
      this.setState({
        bookings:bookings,
        services:data.bookingService,
        serviceAddons:data.bookingExtras
        
      });
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    } 
    this.loadCompany();   
  }
  loadCountryInf=async()=>{
    const { data } = await axios.get('/api/company/country');    
    if(data.success){
      localStorage.setItem("currency_code",data.country[0].currency_code);
      localStorage.setItem("phone_code",data.country[0].country_phone_code);
    }    
  }
 
  loadCompany=async()=>{    
       const  {data} = await axios.get('/api/customer/company'); 
        if(data.success){
          this.setState({companies:data.company});
        }
  }   
  cancelRequest=async(row)=>{///company/:id/booking/:bookingId/cancel
    const { localization } = this.props;
    var { data } = await axios.put("/api/customer/company/"+row.companyId+"/booking/"+row.id+"/cancel");
    if(!data.success){
      this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
        variant: 'error',
      }); 
      return;
    }
    this.loadBookingData();
  } 
 
  table_body=()=>{
    const { classes,localization } = this.props;
    const {companies,services,serviceAddons}=this.state;
    let tbl=[];
    let trs=[];
    if(this.state.bookings.length==0){
      return <h4 className={classes.nothing_1}>There is nothing.</h4>
    }

    this.state.bookings.map((row,index) => {
      let number=index+1;    
      
      const bookingFrom = moment(row.bookFrom);      
      const bookingTo = moment(row.bookTo);

      var company_name="";
      companies.map(company=>{
          if(company.id==row.companyId){
            company_name=company.company_name;
          }
      })

      var total_price=0;
      var service_temp=[];
      services.map(service=>{
        if(row.id==service.booking_id){
          service_temp.push(service.name);
          total_price+=parseFloat(service.price);
        }
      })
      var addons_name=[];
      serviceAddons.map(addon=>{       
        if(row.id==addon.booking_id){
          addons_name.push(addon.name);
          total_price+=parseFloat(addon.price);
        }
      })

      total_price=(Math.round(total_price*100)/100).toFixed(2);       

      trs.push(<TableRow hover
      key={row.id} >
      <TableCell  className={classes.tableCellId} >
        {number}
      </TableCell>
      <TableCell  className={classes.tableCellId_1} >
        {company_name}
      </TableCell>
      <TableCell  className={classes.tableCell} >{bookingFrom.format('YYYY-MM-DD HH:mm')} ~ {bookingTo.format('HH:mm')}</TableCell>
      <TableCell  className={classes.tableCellId_2}>{service_temp.join()}</TableCell>      
      <TableCell  className={classes.tableCell} >
        {addons_name.join()}
      </TableCell>
      <TableCell className={classes.tableCellId_3}>
        {  total_price }
      </TableCell>
      <TableCell  className={classes.tableCellId_4}>
           {row.status}
      </TableCell>
      <TableCell  >
            <Button variant="contained" 
                  size="small" color="primary"
                    className={classes.margin}
                    onClick={() =>(this.cancelRequest(row))}
                    disabled={row.status=='AWAITING RESPONSE'?false:true}                        
                    >
                    Cancel
            </Button>
       
      </TableCell>      
    </TableRow>);

    })

    tbl.push(<Table key={1} className={classes.table}>
      <TableHead >
        <TableRow>
          <TableCell  className={classes.tableCellId+" "+classes.tableHeader_1}>No</TableCell>     
          <TableCell  className={classes.tableCellId_1+" "+classes.tableHeader_2}>Company Name</TableCell>
          <TableCell  className={classes.tableHeader_1}>Booking Time</TableCell>
          <TableCell  className={classes.tableCellId_2+" "+classes.tableHeader_2}>Service</TableCell>     
          <TableCell  className={classes.tableHeader_1}>Service Addons</TableCell>
          <TableCell  className={classes.tableCellId_3+" "+classes.tableHeader_2}>Total Price</TableCell>  
          <TableCell  className={classes.tableCellId_4+" "+classes.tableHeader_2}>Status</TableCell>
          <TableCell  className={classes.tableHeader_1}>Cancel</TableCell>        
        </TableRow>
      </TableHead>
      <TableBody>
        {trs}
      </TableBody>
    </Table>);
    return tbl;    
  }
  render(){
    const { classes,localization } = this.props;
    return(
     
        <Card className={classes.card}>
          <CardHeader color="info">            
          <GridContainer>
            <GridItem xs={12} sm={12} md={12}>
              <h4 className={classes.cardTitleWhite}>{localization.localizedString('CUSTOMER_BOOKING_OVERVIEW_CARD')}</h4>
              <p className={classes.cardCategoryWhite}>              
              </p>
            </GridItem>
           </GridContainer>            
          </CardHeader>
          <CardBody className={classes.cardBody_1}>
            {this.table_body()}
          </CardBody>
        </Card>
            
    )
  }
}
export default withStyles(bookingStyle)(withSnackbar(withLocalization(withAuth(Booking))));



