

import Setting from '../views/Setting';
import Booking from '../views/Bookings';

export default () => ([
  {
    path: '/customer/setting',    
    component: Setting
  },
  {
    path: '/customer/booking_overview', 
    component: Booking
  }, 
  
  {
    redirect: true,
    path: '/customer',
    to: '/customer/setting',
    navbarName: 'Redirect'
  }
]);
