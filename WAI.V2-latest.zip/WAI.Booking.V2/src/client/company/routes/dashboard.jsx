import OverviewIcon from '@material-ui/icons/Dashboard';
import CalendarIcon from '@material-ui/icons/CalendarViewDay';
import ServicesIcon from '@material-ui/icons/Shop';
import OpenHoursIcon from '@material-ui/icons/CalendarToday';
import BookingsIcon from '@material-ui/icons/ShoppingBasket';
import SettingsIcon from '@material-ui/icons/Settings';
import ServiceCategoriesIcon from '@material-ui/icons/FilterNone';
import ServiceAddonsIcon from '@material-ui/icons/InsertComment';
import EmployeeIcon from '@material-ui/icons/Dns';
import ProductCategoriesIcon from '@material-ui/icons/BusinessCenter';
import ProductsIcon from '@material-ui/icons/Shop';
import BookingRequestIcon from '@material-ui/icons/Bookmark';
import AboutIcon from '@material-ui/icons/Description';

import Overview from '../views/dashboard/Overview';
import CalendarRoute from '../views/dashboard/CalendarRoute';
import Services from '../views/dashboard/Services';
/**
import ServiceCategories from '../views/dashboard/ServiceCategories';
import ServiceAddons from '../views/dashboard/ServiceAddons';
import OpenHours from '../views/dashboard/OpenHours';
import Vacation from '../views/dashboard/Vacation';
 */
//import Bookings from '../views/dashboard/Bookings';
import BookingRoute from '../views/dashboard/BookingRoute';
import Settings from '../views/dashboard/Settings';
import ImageSetting from '../views/dashboard/ImageSetting';
import EmployeeRoute from '../views/dashboard/EmployeeRoute';
import ProductCategories from '../views/dashboard/ProductCategories';
import Products from '../views/dashboard/Products';
import About from '../views/dashboard/About';
import TermsOfService from '../views/dashboard/TermsOfService';
import Customer from '../views/dashboard/Customer';
import Payments from '../views/dashboard/Payments';
import CreateBooking from '../views/dashboard/CreateBooking';

import BookingRequest from '../views/dashboard/BookingRequest';

export default ({ localization }) => ([
  {
    path: '/overview',
    sidebarName: localization.localizedString('DASHBOARD_SIDEBAR_OVERVIEW_NAME'),
    navbarName: localization.localizedString('DASHBOARD_NAVBAR_OVERVIEW_NAME'),
    icon: OverviewIcon,
    component: Overview
  },
  {
    path: '/calendar',
    sidebarName: localization.localizedString('DASHBOARD_SIDEBAR_CALENDAR_NAME'),
    navbarName: localization.localizedString('DASHBOARD_NAVBAR_CALENDAR_NAME'),
    icon: CalendarIcon,
    component: CalendarRoute
  },  
  {
    path: '/services',
    sidebarName: localization.localizedString('DASHBOARD_SIDEBAR_SERVICES_NAME'),
    navbarName: localization.localizedString('DASHBOARD_NAVBAR_SERVICES_NAME'),
    icon: ServicesIcon,
    component: Services
  },
  /**
   {
    path: '/service_categories',
    sidebarName: localization.localizedString('DASHBOARD_SIDEBAR_SERVICE_CATEGORIES_NAME'),
    navbarName: localization.localizedString('DASHBOARD_NAVBAR_SERVICES_CATEGORIES_NAME'),
    icon: ServiceCategoriesIcon,
    component: ServiceCategories
  },
  {
    path: '/service_addons',
    sidebarName: localization.localizedString('DASHBOARD_SIDEBAR_SERVICE_ADDONS_NAME'),
    navbarName: localization.localizedString('DASHBOARD_NAVBAR_SERVICES_ADDONS_NAME'),
    icon: ServiceAddonsIcon,
    component: ServiceAddons
  }, 
 
*/
  {
    path: '/employees',
    sidebarName: localization.localizedString('DASHBOARD_SIDEBAR_EMPLOYEES_NAME'),
    navbarName: localization.localizedString('DASHBOARD_NAVBAR_EMPLOYEES_NAME'),
    icon: EmployeeIcon,
    component: EmployeeRoute
  },
  {
    path: '/customers',
    sidebarName: localization.localizedString('DASHBOARD_SIDEBAR_CUSTOMERS_NAME'),
    navbarName: localization.localizedString('DASHBOARD_NAVBAR_CUSTOMERS_NAME'),
    icon: EmployeeIcon,
    component: Customer
  },
  /**
  {
    path: '/openhours',
    sidebarName: localization.localizedString('DASHBOARD_SIDEBAR_OPENHOURS_NAME'),
    navbarName: localization.localizedString('DASHBOARD_NAVBAR_OPENHOURS_NAME'),
    icon: OpenHoursIcon,
    component: OpenHours
  },
  {
    path: '/vacation',
    sidebarName: localization.localizedString('DASHBOARD_SIDEBAR_VACATION_NAME'),
    navbarName: localization.localizedString('DASHBOARD_NAVBAR_VACATION_NAME'),
    icon: OpenHoursIcon,
    component: Vacation
  },
   
  {
    path: '/product_categories',
    sidebarName: localization.localizedString('DASHBOARD_SIDEBAR_PRODUCT_CATEGORIES_NAME'),
    navbarName: localization.localizedString('DASHBOARD_NAVBAR_PRODUCT_CATEGORIES_NAME'),
    icon: ProductCategoriesIcon,
    component: ProductCategories
  },
  {
    path: '/terms',
    sidebarName: localization.localizedString('DASHBOARD_SIDEBAR_TERMS_SERVICE_NAME'),
    navbarName: localization.localizedString('DASHBOARD_NAVBAR_TERMS_SERVICE_NAME'),
    icon: AboutIcon,
    component: TermsOfService
  },
  */
  {
    path: '/products',
    sidebarName: localization.localizedString('DASHBOARD_SIDEBAR_PRODUCTS_NAME'),
    navbarName: localization.localizedString('DASHBOARD_NAVBAR_PRODUCTS_NAME'),
    icon: ProductsIcon,
    component: Products
  },
  
  {
    path: '/about',
    sidebarName: localization.localizedString('DASHBOARD_SIDEBAR_ABOUT_NAME'),
    navbarName: localization.localizedString('DASHBOARD_NAVBAR_ABOUT_NAME'),
    icon: AboutIcon,
    component: About
  },
  
  {
    path: '/createbooking',
    sidebarName: localization.localizedString('DASHBOARD_SIDEBAR_CREATE_BOOKINGS_NAME'),
    navbarName: localization.localizedString('DASHBOARD_NAVBAR_CREATE_BOOKINGS_NAME'),
    icon: BookingsIcon,
    component: CreateBooking
  },
  /**
  {
    path: '/bookings',
    sidebarName: localization.localizedString('DASHBOARD_SIDEBAR_BOOKINGS_NAME'),
    navbarName: localization.localizedString('DASHBOARD_NAVBAR_BOOKINGS_NAME'),
    icon: BookingsIcon,
    component: BookingRoute
  }, */
  {
    path: '/bookingrequest',
    sidebarName: localization.localizedString('DASHBOARD_SIDEBAR_BOOKINGS_REQUEST_NAME'),
    navbarName: localization.localizedString('DASHBOARD_NAVBAR_BOOKINGS_REQUEST_NAME'),
    icon: BookingRequestIcon,
    component: BookingRequest
  },  
  {
    path: '/payments',
    sidebarName: localization.localizedString('DASHBOARD_SIDEBAR_PAYMENT_VIEW_NAME'),
    navbarName: localization.localizedString('DASHBOARD_NAVBAR_PAYMENT_VIEW_NAME'),
    icon: EmployeeIcon,
    component: Payments
  },
  {
    path: '/images',
    sidebarName: localization.localizedString('DASHBOARD_SIDEBAR_LANDING_IMAGE_NAME'),
    navbarName: localization.localizedString('DASHBOARD_NAVBAR_LANDING_IMAGE_NAME'),
    icon: SettingsIcon,
    component: ImageSetting
  },
  {
    path: '/settings',
    sidebarName: localization.localizedString('DASHBOARD_SIDEBAR_SETTINGS_NAME'),
    navbarName: localization.localizedString('DASHBOARD_NAVBAR_SETTINGS_NAME'),
    icon: SettingsIcon,
    component: Settings
  },
  
  {
    redirect: true,
    path: '/',
    to: '/overview',
    navbarName: 'Redirect'
  }
]);
