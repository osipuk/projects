import React from 'react';

import Link from 'react-router-dom/es/Link';

import withStyles from '@material-ui/core/styles/withStyles';
import InputAdornment from '@material-ui/core/InputAdornment';
import Icon from '@material-ui/core/Icon';
import Grid from '@material-ui/core/Grid';
import EmailOutlined from '@material-ui/icons/EmailOutlined';
import LockOutlined from '@material-ui/icons/LockOutlined';
import Checkbox from '@material-ui/core/Checkbox';
import {  withSnackbar } from 'notistack';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import axios from 'axios';
import withLocalization from 'common/contexts/LocalizationContext';
//import withNotifications from 'common/contexts/NotificationsContext';
import withAuth from 'common/contexts/AuthContext';
import GridContainer from 'common/components/Grid/GridContainer';
import GridItem from 'common/components/Grid/GridItem';
import Card from 'common/components/Card/Card';
import CardBody from 'common/components/Card/CardBody';
import CardHeader from 'common/components/Card/CardHeader';
import CardFooter from 'common/components/Card/CardFooter';
import CustomInput from 'common/components/CustomInput/CustomInput';
import Button from "@material-ui/core/Button";
import LoginButton from 'common/containers/LoginButton/LoginButton';

import landingPageStyle from "../../p/assets/jss/views/landingPage";

import bgImage from '../assets/img/businessBg.jpg';
import Typography from '@material-ui/core/Typography';
import TextField from '@material-ui/core/TextField';

class LoginPage extends React.Component {
  state = {
    email: '',
    password: '',
    remember_me:false,
    type:'company',
    card_status:'login'
  };  
  
 getCookie=(cname)=>{
  var name = cname + "=";
  var decodedCookie = decodeURIComponent(document.cookie);
  var ca = decodedCookie.split(';');
  for(var i = 0; i < ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}

  async componentDidMount  () {
    const { auth: { isAuth, user }, history,auth } = this.props;   
    if (isAuth && user) {
      history.push('/');
    }    
    else{     
      if(this.getCookie('company_email')!='' && this.getCookie('company_password')!='' ){       
       
        let userData={};
        userData.email=this.getCookie('company_email');
        userData.password=this.getCookie('company_password');
        const result = await auth.login(userData);
      }
    }
  }
  componentDidUpdate(prevProps, prevState, snapshot) {
    const { auth: { isAuth: prevIsAuth, user: prevUser } } = prevProps;
    const { auth: { isAuth: newIsAuth, user: newUser }, history } = this.props;

    if (!prevIsAuth && newIsAuth && !prevUser && newUser) {
      history.push('/');
    }
  }
  keyPressPassword=async(e)=>{
    if (e.key === 'Enter') {
         var userData={};
        const {auth,notifications,localization}=this.props;
        userData.email=this.state.email;
        userData.password=this.state.password;
        const result = await auth.login(userData); 
        if(result.success){         
          if(this.state.remember_me){
            setCookie('company_email', this.state.email);
            setCookie('company_password', this.state.password);
          }        
        }
        else{
          this.props.enqueueSnackbar(localization.localizedError(result.errorCode), { 
            variant: 'error',
          });          
        }   
    }
  }
  forgetPassword=()=>{
    this.setState({card_status:'forgot'});   
  }
  loginCard=()=>{
    this.setState({card_status:'login'});  
  }
  handleChange = prop => event => this.setState({ [prop]: event.target.value });
  handleToggle = prop => event => this.setState({ [prop]: event.target.checked });
  newPassword=async()=>{
    const {localization,classes}=this.props;   
    if(this.state.email==''){   
      this.props.enqueueSnackbar(localization.localizedError(29), { 
        variant: 'error',
      }); 
      return;
    }
    var submit_times=this.getCookie('submit');

    if(submit_times=='3' || submit_times==3){
      this.props.enqueueSnackbar(localization.localizedError(35), { 
        variant: 'error',
      }); 
      return;
    }

    submit_times=1+parseInt(submit_times?submit_times:0);   
    this.setCookieForSubmit("submit",submit_times);
    var  {data} = await axios.post('/api/company/send_email',
          {
            email:this.state.email
          }); 
          if(data.success){
            this.props.enqueueSnackbar(localization.localizedString('EMAIL_SENT_PASSWORD_RECOVERY'), { 
              variant: 'success',
            }); 
            this.setState({card_status:'login',email:''});  
          }
          else{
            this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
              variant: 'error',
            }); 
          }
  }
  setCookieForSubmit=(cname,cvalue)=>{ 
    var d = new Date();
    var minutes=40;
    d.setTime(d.getTime() + (minutes*60*1000));
   var expires = "expires=" + d.toGMTString();
   document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
  }
  forgot_card=()=>{
    const {classes,localization}=this.props;
    const { email } = this.state;
    return  <form className={classes.form}>
    <CardBody className={classes.cardBody}>
    <Grid container className={classes.GridContainer}>
          <Grid item xs={12} sm={12} md={12}>
            <Typography  variant="h3" gutterBottom className={classes.signTitle}>
            {localization.localizedString('PASSWORD_RESET')}
            <br/>
            </Typography>
              <Typography component="p">
              Please put the your email.
              </Typography>   
        </Grid>
    </Grid>
    <div className={classes.loginFormLayout}>
      <Grid container className={classes.GridContainer}>
        <Grid item xs={12} sm={12} md={12}>   
      <TextField
        id="email"
        label={localization.localizedString('LOGIN_EMAIL_LABEL')}
        
        InputLabelProps={{
          required: true,
            classes: {
              root: classes.cssLabel,
              focused: classes.cssFocused,
            },
          }}
          InputProps={{
            type: 'text',
            classes: {
              root: classes.cssOutlinedInput,
              focused: classes.cssFocused,
              underline: classes.cssUnderline,                    
            },
            endAdornment: (
              <InputAdornment position="end">
                <Icon>
                  <EmailOutlined className={classes.inputIconsColor} />
                </Icon>
              </InputAdornment>
            ),
      }}

        className={classes.textField}
        onChange={this.handleChange('email')}
        value={email}
        margin="normal"
        fullWidth
      />
       </Grid>
      </Grid>
      <Grid container className={classes.GridContainer}>        
          <Grid  item xs={12} sm={12} md={12}>
              <Typography
                variant="subheading" 
                className={classes.forgotPass}
                onClick={this.loginCard}
                >
                Already have login and password? Sign in
              </Typography>      
            </Grid>
        </Grid>

        </div>
      </CardBody>
      <CardFooter className={classes.cardFooterBycustomer_1}>
      
      <Grid item xs={12} sm={12} md={6} lg={6} xl={6}>
            <Button
              variant="contained"
              color="secondary"                       
              className={classes.button}
              onClick={this.newPassword}
              >
              Submit
            </Button>
          </Grid>
          <Grid item xs={12} sm={12} md={6} lg={6} xl={6} style={{textAlign:'right'}}>                       
          </Grid>
      </CardFooter>
    </form>
  }

  login_card=()=>{
    const {classes,localization}=this.props;
    const { email, password,remember_me,type } = this.state;
    return  <form className={classes.form}>
    <CardBody className={classes.cardBody}>
    <Grid container className={classes.GridContainer}>
          <Grid item xs={12} sm={12} md={12}>
            <Typography  variant="h3" gutterBottom className={classes.signTitle}>
            {localization.localizedString('LOGIN_FORM_TITLE')}
            <br/>
            </Typography>
              <Typography component="p">
              somethin something...
              </Typography>   
        </Grid>
    </Grid>
    <div className={classes.loginFormLayout}>
      <Grid container className={classes.GridContainer}>
        <Grid item xs={12} sm={12} md={12}>   
      <TextField
        id="email"
        label={localization.localizedString('LOGIN_EMAIL_LABEL')}
        
        InputLabelProps={{
          required: true,
            classes: {
              root: classes.cssLabel,
              focused: classes.cssFocused,
            },
          }}
          InputProps={{
            type: 'text',
            classes: {
              root: classes.cssOutlinedInput,
              focused: classes.cssFocused,
              underline: classes.cssUnderline,                    
            },
            endAdornment: (
              <InputAdornment position="end">
                <Icon>
                  <EmailOutlined className={classes.inputIconsColor} />
                </Icon>
              </InputAdornment>
            ),
      }}

        className={classes.textField}
        onChange={this.handleChange('email')}
        value={email}
        margin="normal"
        fullWidth
      />
       </Grid>
      </Grid>
      <Grid container className={classes.GridContainer}>
        <Grid item xs={12} sm={12} md={12}>  
              <TextField
              id="password"
                label={localization.localizedString('LOGIN_PASSWORD_LABEL')}
                InputLabelProps={{
                  required: true,
                    classes: {
                      root: classes.cssLabel,
                      focused: classes.cssFocused,
                    },
                  }}
                  InputProps={{
                    type: 'password',
                    classes: {
                      root: classes.cssOutlinedInput,
                      focused: classes.cssFocused,
                      underline: classes.cssUnderline,                    
                    },
                    endAdornment: (
                      <InputAdornment position="end">
                        <Icon>
                          <LockOutlined className={classes.inputIconsColor} />
                        </Icon>
                      </InputAdornment>
                    ),
              }}
                value={password}
                onChange={this.handleChange('password')}
                onKeyPress={(event)=>this.keyPressPassword(event)}
                className={classes.textField}
                margin="normal"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} sm={12} md={6}>
                <FormControlLabel
                control={(
                  <Checkbox
                    tabIndex={-1}                                                               
                    checked={this.state.remember_me}
                    onClick={this.handleToggle('remember_me')}
                  />
                )}
                classes={{ label: classes.label }}
                label={"Remember me"}
              />
           </Grid>
           <Grid  item xs={12} sm={6} md={6}>
                <Typography
                variant="subheading" 
                className={classes.forgotPass}
                onClick={this.forgetPassword}
                >
                  Forgot the password?
                </Typography>
            </Grid>
        </Grid>

        </div>
      </CardBody>
      <CardFooter className={classes.cardFooterBycustomer_1}>
      
          <Grid item xs={12} sm={12} md={6} lg={6} xl={6}>
            <LoginButton
            
            variant="contained"
            color="secondary" 
            props={this.props}
            userData={{ email, password,remember_me,type }}
            />                        
          </Grid>
          <Grid item xs={12} sm={12} md={6} lg={6} xl={6}  style={{textAlign:'right'}}>
            <Link to="/signup">
              {localization.localizedString('LOGIN_CREATE_COMPANY_LINK')}
            </Link>
          </Grid>
      
      </CardFooter>
    </form>
  }

  render() {
    const { localization, classes } = this.props;  

    return (
      <div
        className={classes.pageHeader}
        style={{
          backgroundImage: `url(${bgImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'top center'
        }}
      >
        <div className={classes.containerSignup}>
          <GridContainer justify="center">
            <GridItem xs={12}>
              <Card>
               {this.state.card_status=='login'?this.login_card():this.forgot_card()}
              </Card>
            </GridItem>
          </GridContainer>
        </div>
      </div>
    );
  }
}
function setCookie(cname,cvalue) { 
  var d = new Date();
  var exdays=30;
  d.setTime(d.getTime() + (exdays*24*60*60*1000));
 var expires = "expires=" + d.toGMTString();
 document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}
export default withStyles(landingPageStyle)(withSnackbar(withLocalization(withAuth(LoginPage))));
