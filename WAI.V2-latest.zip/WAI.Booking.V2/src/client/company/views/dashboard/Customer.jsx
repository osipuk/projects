import React from 'react';
//import classNames from 'classnames';
import withStyles from '@material-ui/core/styles/withStyles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Edit from "@material-ui/icons/Edit";
import Visibility from "@material-ui/icons/Visibility";
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import axios from 'axios';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import Success from '@material-ui/icons/CheckCircle';
import Button from '@material-ui/core/Button';
import {  withSnackbar } from 'notistack';
//import errors from '../../../common/error_codes';
import withAuth from '../../../common/contexts/AuthContext';
import withNotifications from '../../../common/contexts/NotificationsContext';
import GridItem from "../../../common/components/Grid/GridItem.jsx";
import GridContainer from "../../../common/components/Grid/GridContainer.jsx";
import withLocalization from '../../../common/contexts/LocalizationContext';
import Card from "../../../common/components/Card/Card.jsx";
import CardHeader from "../../../common/components/Card/CardHeader.jsx";
import CardBody from "../../../common/components/Card/CardBody.jsx";
import CustomInput from "../../../common/components/CustomInput/CustomInput.jsx";
import CardFooter from "../../../common/components/Card/CardFooter.jsx";
//import Button from "../../../common/components/CustomButtons/Button.jsx";
import customerStyle from '../../assets/css/customer';

class Customer extends React.Component {
  constructor(props){
    super (props);
    this.state={
      addDialog:false,//category dialog         
      customers:[],//
      comments:[],
      phone:'',
      gender:'',
      firstName:'',
      lastName:'',
      zipCode:'',
      comment:'',
      customerId:0,
      commentId:0,
      updatedComments:[]
    };       
    this.saveChanges=this.saveChanges.bind(this);    
     
  }  
  componentWillMount(){  
    this.loadCustomers();
  }

  loadCustomers=async()=>{
    const {localization,auth}=this.props;     
    const { data } = await axios.get('/api/company/customer');  
    if(data.success){
        this.setState({customers:data.customers});
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
  }  
  editChange=async(row)=>{   
    const {localization,auth}=this.props; 
    const { data } = await axios.get('/api/company/customer/'+row.id+'/comment');
    console.log(data);
    if(data.success){
      this.setState({  
        customerId:row.id,  
        firstName:row.firstName,
        lastName:row.lastName,
        phone:row.phone,
        gender:row.gender,
        zipCode:row.zipCode,
        comments:data.comment,
        addDialog:true});
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }    
  }  
 
  dia1Close = () => {
    this.setState({ addDialog: false });
  }  
 
  async saveChanges(){
      const {localization,auth}=this.props;     
      
        var { data } = await axios.put('/api/company/customer/comment/'+this.state.commentId, {   
          comment:this.state.comments
         });  
     
   
        if(this.state.comment!=''){
        var { data } = await axios.post('/api/company/customer/'+this.state.customerId+"/comment", {   
          comment:this.state.comment
          });  
        }       
   
      
      if(data.success){
        this.props.enqueueSnackbar(localization.localizedString('SAVED_SUCCESS'), { 
          variant: 'success',
        });               
      } 
     else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
      }
      this.setState({ addDialog: false,comment:'' });
  }  
  handleChange = prop => event => this.setState({ [prop]: event.target.value });
  handleUpdate= (id)=>event=> {
    let comment=event.target.value;
    let temp=[];  
    
    this.state.comments.map(row=>{
      let comments={};
      if(row.id==id){
        comments.id=id;
        comments.comment=comment;
        temp.push(comments);          
      }
      else{
        comments.id=row.id;
        comments.comment=row.comment;
        temp.push(comments);
      }      
     
     this.setState({comments:temp});
    })
    
    
  };
  table_body=()=>{
    const { classes,localization,auth } = this.props;
    let tbl=[];
    let trs=[];
    if(this.state.customers.length==0){
      return <h4 className={classes.nothing_1}>There is nothing.</h4>
    }

    this.state.customers.map(row => {
      trs.push(<TableRow hover
      key={row.id} >
       <TableCell  className={classes.tableCellId+" "+classes.gray_title}>
         {row.id}
       </TableCell>
      <TableCell  className={classes.tableCell+" "+classes.gray_title} >
        {row.firstName}
      </TableCell>
      <TableCell className={classes.gray_title}>{row.lastName}</TableCell>
      <TableCell className={classes.gray_title} >{row.phone}</TableCell>      
      <TableCell className={classes.gray_title}>{row.gender}  </TableCell>
      <TableCell className={classes.gray_title}>{row.city}  </TableCell>
      <TableCell className={classes.gray_title}>{row.zipCode}  </TableCell>
      <TableCell  className={classes.tableCellId+" "+classes.gray_title}>
            <Tooltip
              id="tooltip-top"
              title="View Details"
              placement="top"
              classes={{ tooltip: classes.tooltip }}
            >
              <IconButton
                aria-label="Edit"                
                onClick={() =>(this.editChange(row))}                
              >
                <Visibility
                  className={
                    classes.tableActionButtonIcon + " " + classes.edit
                  }
                />
              </IconButton>
            </Tooltip>
      </TableCell>      
    </TableRow>);      
    })

    tbl.push(<Table key={1} className={classes.table}>
      <TableHead >
        <TableRow>   
          <TableCell  className={classes.tableCellId+" "+classes.tableHeader_1}>ID</TableCell>       
          <TableCell  className={classes.tableCell+" "+classes.tableHeader_1}>Fist Name</TableCell>
          <TableCell  className={classes.tableHeader_1}>Last Name</TableCell>
          <TableCell  className={classes.tableHeader_1}>Phone</TableCell>         
          <TableCell  className={classes.tableHeader_1}>Gender</TableCell>
          <TableCell  className={classes.tableHeader_1}>City</TableCell>
          <TableCell  className={classes.tableCell+" "+classes.tableHeader_1}>Zip Code</TableCell>
          <TableCell  className={classes.tableCellId+" "+classes.tableHeader_1}>Detail</TableCell>         
        </TableRow>
      </TableHead>
      <TableBody>
     {trs}
      </TableBody>
    </Table>);
    return tbl;    
  }
  render() {
    const { classes,localization} = this.props;
     return(
      <GridContainer>
      <GridItem xs={12} sm={12} md={12}>
        <Card>
          {/**
          <CardHeader color="primary">            
          <GridContainer>
            <GridItem xs={10} sm={10} md={10}>
              <h4 className={classes.cardTitleWhite}>{localization.localizedString('DASHBOARD_SIDEBAR_CUSTOMERS_NAME')}</h4>
              <p className={classes.cardCategoryWhite}>             
              </p>
            </GridItem>
            <Grid xs={2} item sm={2} md={2} className={classes.header_2}>                 
            </Grid>
           </GridContainer>            
          </CardHeader>
        */}
          <CardBody className={classes.cardBody_1}>
              {this.table_body()}            
          </CardBody>
        </Card>
      </GridItem>
      {/** for add/update product */}
      <Dialog
          fullWidth={true}
          maxWidth={'sm'}
          open={this.state.addDialog}
          onClose={this.dia1Close}
          aria-labelledby="max-width-dialog-title"         
        >         
           <DialogTitle id="simple-dialog-title" className={classes.dialog_title}>Customer Detail View</DialogTitle>
          <DialogContent className={classes.dialog_22}> 
                <GridContainer  justify={'center'}>
                    <Grid item xs={12} sm={12} md={11}>
                      <Typography component="h5" style={{display: 'inline',}} color="textPrimary">
                        ID: {this.state.customerId}
                      </Typography>
                    </Grid>
                    <Grid item xs={12} sm={12} md={11}>
                      <Typography component="h5" style={{display: 'inline',}} color="textPrimary">
                       First Name: {this.state.firstName}
                     </Typography>
                    </Grid>
                    <Grid item xs={12} sm={12} md={11}>
                      <Typography component="h5" style={{display: 'inline',}} color="textPrimary">
                        Last Name: {this.state.lastName}
                      </Typography>
                    </Grid> 
                      <Grid item xs={12} sm={12} md={11}>
                        <Typography component="h5" style={{display: 'inline',}} color="textPrimary">
                          Phone: {this.state.phone}
                         </Typography>
                      </Grid>
                      <Grid item xs={12} sm={12} md={11}>
                          <Typography component="h5" style={{display: 'inline',}} color="textPrimary">
                          Gender: {this.state.gender}
                        </Typography>
                      </Grid>
                      <Grid item xs={12} sm={12} md={11}>
                         <Typography component="h5" style={{display: 'inline',}} color="textPrimary">
                          ZipCode: {this.state.zipCode}
                        </Typography>
                      </Grid>
                      {
                        this.state.comments.map(row=>{
                          let comment=row.comment;
                         return  <Grid item key={row.id} xs={12} sm={12} md={11}>
                            <CustomInput
                                labelText=""              
                                inputProps={{
                                value:comment,
                                multiline: true,
                                rows: 2
                              }}
                              formControlProps={{
                                className:classes.customInput_1,   
                                onChange: this.handleUpdate(row.id)
                              }}
                            />          
                           </Grid>
                        })
                      }
                      <Grid item xs={12} sm={12} md={11}>
                        <CustomInput
                            labelText="Add a comment"                        
                            inputProps={{
                            value:this.state.comment,
                            multiline: true,
                            rows: 2
                          }}
                          formControlProps={{
                            className:classes.customInput_2,   
                            onChange: this.handleChange('comment')
                          }}
                        />          
                     </Grid>
                </GridContainer> 
          </DialogContent>
          <DialogActions className={classes.cardFooter}>
          <Button color="secondary" onClick={this.dia1Close}>Cancel</Button>
          <Button color="secondary"               
            onClick={this.saveChanges}>Save Changes</Button>                  
      </DialogActions>
      </Dialog>
      
      </GridContainer>
     )
   }
}
export default withStyles(customerStyle)(withSnackbar(withLocalization(withAuth(Customer))));
