import React from 'react';
import moment from 'moment'
import withStyles from '@material-ui/core/styles/withStyles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Success from '@material-ui/icons/CheckCircle';
import Select from "@material-ui/core/Select";
import FormHelperText from '@material-ui/core/FormHelperText';
import InputLabel from "@material-ui/core/InputLabel";
import FormControl from "@material-ui/core/FormControl";
import MenuItem from "@material-ui/core/MenuItem";
import Grid from '@material-ui/core/Grid';
import Tooltip from "@material-ui/core/Tooltip";
import IconButton from "@material-ui/core/IconButton";
import Edit from "@material-ui/icons/Edit";
import SearchIcon from '@material-ui/icons/Search';
import Input from "@material-ui/core/Input";
import InputBase from '@material-ui/core/InputBase';
import Button from '@material-ui/core/Button';
import axios from 'axios';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import { withSnackbar } from 'notistack';
import Typography from '@material-ui/core/Typography';
import withAuth from '../../../common/contexts/AuthContext';
import GridItem from "../../../common/components/Grid/GridItem.jsx";
import GridContainer from "../../../common/components/Grid/GridContainer.jsx";
import withLocalization from '../../../common/contexts/LocalizationContext';
import CustomInput from "../../../common/components/CustomInput/CustomInput.jsx";
//import Button from "../../../common/components/CustomButtons/Button.jsx";
import servicesStyle from '../../assets/css/services';

class GiftCard extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      giftCardModal: false,
      startBalance:'',
      availableBalance:'',
      active:true,  
      delete_confirm:false ,
      code:'',
      giftCards:[],
      rowSelected:[],
      selectRowId:0
    };
  }
  componentWillReceiveProps(nowprops) {
    if (nowprops.createState) {
      this.setState({
        giftCardModal: nowprops.createState,
        dialog_state: 'Add',
      });
    }
  }

  componentWillMount = async () => {
    this.loadGiftCard();
  }
  loadGiftCard = async () => {
    const { data } = await axios.get('/api/company/gift_card/getall'); 
    if (data.success) {
      this.setState({
        giftCards: data.giftCards        
      })
    }
  }
  closeDialog = () => {
    this.props.closeCardState();
    this.setState({ giftCardModal: false, delete_confirm: false });
  }

  saveGiftCard=async()=>{
    const { localization, auth } = this.props;
    var data = {};
    if (this.state.dialog_state == 'Add') {
      var { data } = await axios.post('/api/company/gift_card/save', {
        giftCard: {
          code: this.state.code,
          startBalance:this.state.startBalance,
          availableBalance:this.state.availableBalance,
          active:this.state.active         
        }
      });
      if (data.success) {
        this.props.enqueueSnackbar(localization.localizedString('ADDED_SUCCESS'), {
          variant: 'success',
        });
      }
    }
    else if (this.state.dialog_state == 'Update') {
      var { data } = await axios.put('/api/company/gift_card/update/'+this.state.selectRowId, {
        giftCard: {
          code: this.state.code,
          startBalance:this.state.startBalance,
         availableBalance:this.state.availableBalance,
          active:this.state.active?1:0       
        }
      });

      if (data.success) {
        this.props.enqueueSnackbar(localization.localizedString('UPDATED_SUCCESS'), {
          variant: 'success',
        });
      }
    }

    this.setState({ giftCardModal:false });
    this.loadGiftCard();
    if (!data.success) {
      if (data.errorCode == 2 || data.errorCode == 5 || data.errorCode == 6) {
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), {
          variant: 'error',
        });
        await auth.get();
      }
      else {
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), {
          variant: 'error',
        });
      }
    }
  }
  rowClick=()=>{

  }
  editDiscountCard = (row) => {
    this.setState({
      giftCardModal : true,
      dialog_state: 'Update',
      code:row.code,
      startBalance:row.startBalance,
      availableBalance:row.availableBalance,
      active:row.active?true:false,
      selectRowId:row.id
     
    });
  }

  changeActive = async (event, rid) => {
    var checked = event.target.checked;
    const { localization, auth } = this.props;
  
    var { data } = await axios.put('/api/company/gift_card/update/'+ rid, {
      giftCard: {
        active: checked ? 1 : 0
      }
    });

    if (!data.success) {
      if (data.errorCode == 2 || data.errorCode == 5 || data.errorCode == 3 || data.errorCode == 6) {
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), {
          variant: 'error',
        });
        await auth.get();
      }
      else {
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), {
          variant: 'error',
        });
      }
    }   
    this.loadGiftCard();
    
  }
  giftCardDelete=()=>{
    this.setState({ delete_confirm: true });
  }
  delete_process = async () => {
    const { localization, auth } = this.props;
    var { data } = await axios.delete('/api/company/gift_card/delete/' + this.state.selectRowId);
    if (data.success) {
      this.props.enqueueSnackbar(localization.localizedString('DELETED_SUCCESS'), {
        variant: 'success',
      });
      this.loadGiftCard();
    }
    else {
      if (data.errorCode == 2 || data.errorCode == 3 || data.errorCode == 5 || data.errorCode == 6) {
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), {
          variant: 'error',
        });
        await auth.get();
      }
      else {
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), {
          variant: 'error',
        });
      }
    }
    this.setState({ delete_confirm: false,giftCardModal:false })
  }
  handleChange = prop => event => this.setState({ [prop]: event.target.value });
  handleToggle = prop => event => this.setState({ [prop]: event.target.checked });
  isSelected = id => this.state.rowSelected.indexOf(id) !== -1;
  render() {
    const { classes, localization, auth } = this.props;
    const { giftCards } = this.state;
    return (
      <GridContainer>
        <GridItem xs={12} sm={12} md={12}>
          <Table className={classes.table} aria-labelledby="tableTitle">
            <TableHead>
              <TableRow>
                <TableCell padding="checkbox">
                </TableCell>
                <TableCell className={classes.dark_title}>
                  Code
                  </TableCell>
                <TableCell className={classes.dark_title}>
                  Start Balance ({auth.user.currency_code})
                  </TableCell>
                <TableCell className={classes.dark_title}>
                  Available Balance ({auth.user.currency_code})
                  </TableCell>
                <TableCell className={classes.dark_title}>
                  Active
                  </TableCell>
                <TableCell className={classes.dark_title}>
                  Edit
                 </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
            {
              giftCards.map(row=>{
                return <TableRow key={row.id}>
                  <TableCell padding="checkbox">
                    <Checkbox checked={this.isSelected(row.id)}
                      onClick={() => this.rowClick(row.id)}
                    />
                  </TableCell>
                  <TableCell className={classes.gray_title}> {row.code}</TableCell>
                  <TableCell className={classes.gray_title}> {row.startBalance}</TableCell>
                  <TableCell className={classes.gray_title}> {row.availableBalance}</TableCell>
                  <TableCell className={classes.gray_title}> 
                      <Checkbox checked={row.active ? true : false}
                          onClick={(event) => this.changeActive(event, row.id)}
                        />
                  </TableCell>
                  <TableCell className={classes.tableCellId}>
                    <Tooltip
                      id="tooltip-top"
                      title="Edit Service"
                      placement="top"
                      classes={{ tooltip: classes.tooltip }}
                    >
                      <IconButton
                        aria-label="Edit"
                        onClick={() => (this.editDiscountCard(row))}

                      >
                        <Edit
                          className={
                            classes.tableActionButtonIcon + " " + classes.edit
                          }
                        />
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                  </TableRow>
              })
            }
            </TableBody>
          </Table>

          {/** for modal */}
          <Dialog
            fullWidth={true}
            maxWidth={'sm'}
            open={this.state.giftCardModal}
            onClose={this.closeDialog}
            aria-labelledby="max-width-dialog-title"
          >
            <DialogTitle id="simple-dialog-title" className={classes.dialog_title}>{this.state.dialog_state} Gift Card</DialogTitle>
            <DialogContent className={classes.dialog_2}>
              <Grid container className={classes.dialog_3} justify={'center'}>
                <Grid item xs={12} sm={12} md={10}>
                  <CustomInput
                    labelText="Gift Code"
                    inputProps={{
                      value: this.state.code,
                    }}
                    formControlProps={{
                      required: true,
                      fullWidth: true,
                      value: this.state.code,
                      onChange: this.handleChange('code')
                    }}
                  />
                </Grid>
                <Grid item xs={12} sm={12} md={10}>
                  <CustomInput
                    labelText="Start Balance "
                    inputProps={{
                      value: this.state.startBalance,
                    }}
                    formControlProps={{
                      required: true,
                      fullWidth: true,
                      value: this.state.startBalance,
                      onChange: this.handleChange('startBalance')
                    }}
                  />
                </Grid>
               
                <Grid item xs={12} sm={12} md={10}>
                  <CustomInput
                    labelText="Available Balance"
                    inputProps={{
                      value: this.state.availableBalance,
                    }}
                    formControlProps={{
                      required: true,
                      fullWidth: true,
                      value: this.state.availableBalance,
                      onChange: this.handleChange('availableBalance')
                    }}
                  />
                </Grid>                
               
                <Grid item xs={12} sm={12} md={11} style={{ margin: 'auto' }} className={classes.active}>
                  <FormControlLabel
                    control={(
                      <Checkbox
                        tabIndex={-1}
                        disableRipple
                        onClick={this.handleToggle('active')}
                        checked={this.state.active}
                      />
                    )}
                    classes={{ label: classes.label }}
                    label={"Active"}
                  />
                </Grid>
              </Grid>
            </DialogContent>
            <DialogActions className={classes.cardFooter}>
              <GridItem xs={12} sm={12} md={6}>
                <Button color="primary" onClick={this.giftCardDelete}>Delete</Button>
              </GridItem>
              <Grid item xs={12} sm={12} md={6} className={classes.cardFooter_1}>
                <Button onClick={this.closeDialog} color="secondary" className={classes.button_2}>Cancel</Button>
                <Button variant="contained" color="secondary"
                  onClick={this.saveGiftCard}>Save</Button>
              </Grid>
            </DialogActions>
          </Dialog>
          {/**  */}
          {/** delete  dialog */}
          <Dialog
            open={this.state.delete_confirm}
            onClose={this.closeDialog}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
          >
            <DialogTitle id="alert-dialog-title">{"Are you sure to delete?"}</DialogTitle>
            <DialogContent>
            </DialogContent>
            <DialogActions>
              <Button onClick={this.closeDialog} autoFocus color="primary" >
                Cancel
                      </Button>
              <Button onClick={this.delete_process} variant="contained" color="secondary" >
                Yes
                      </Button>
            </DialogActions>
          </Dialog>
        </GridItem>
      </GridContainer>
    )
  }
}
export default withStyles(servicesStyle)(withSnackbar(withLocalization(withAuth(GiftCard))));



