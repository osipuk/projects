import React from 'react';
import moment from 'moment'
import withStyles from '@material-ui/core/styles/withStyles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Success from '@material-ui/icons/CheckCircle';
import Select from "@material-ui/core/Select";
import FormHelperText from '@material-ui/core/FormHelperText';
import InputLabel from "@material-ui/core/InputLabel";
import FormControl from "@material-ui/core/FormControl";
import MenuItem from "@material-ui/core/MenuItem";
import Grid from '@material-ui/core/Grid';
import Tooltip from "@material-ui/core/Tooltip";
import IconButton from "@material-ui/core/IconButton";
import Edit from "@material-ui/icons/Edit";
import SearchIcon from '@material-ui/icons/Search';
import Input from "@material-ui/core/Input";
import InputBase from '@material-ui/core/InputBase';
import Button from '@material-ui/core/Button';
import axios from 'axios';
import TextField from '@material-ui/core/TextField';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import { withSnackbar } from 'notistack';
import Typography from '@material-ui/core/Typography';
import withAuth from '../../../common/contexts/AuthContext';
import GridItem from "../../../common/components/Grid/GridItem.jsx";
import GridContainer from "../../../common/components/Grid/GridContainer.jsx";
import withLocalization from '../../../common/contexts/LocalizationContext';
import CustomInput from "../../../common/components/CustomInput/CustomInput.jsx";
//import Button from "../../../common/components/CustomButtons/Button.jsx";
import servicesStyle from '../../assets/css/services';

class DiscountCode extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      discountCardModal:false,
      dialog_state:'Add',
      allServices:false,
      allExtras:false,
      validFrom:moment().format('YYYY-MM-DD')+"T"+moment().format('HH:mm'),
      validTo:moment().format('YYYY-MM-DD')+"T"+moment().format('HH:mm'),
      limit:'',
      percentage:'',
      amount:'',
      code:'',
      upfront:false,
      active:true,
      discountCodes:[],
      rowSelected:[],
      selectRowId:0,
      delete_confirm:false
    };
  }
  componentWillReceiveProps(nowprops) {
    if (nowprops.createState) {
      this.setState({
        discountCardModal: nowprops.createState,
        dialog_state: 'Add',
        code:'',
        amount:'',
        percentage:'',
        limit:'',
        allExtras:false,
        allServices:false,
        validFrom:moment().format('YYYY-MM-DD')+"T"+moment().format('HH:mm'),
        validTo:moment().format('YYYY-MM-DD')+"T"+moment().format('HH:mm'),
        upfront:false,
        active:true
      });
    }
  }

  componentWillMount = async () => {
    this.discountCode();
  }
  discountCode = async () => {
    const { data } = await axios.get('/api/company/discount_code/getall'); 
    console.log(data);
    if (data.success) {
      this.setState({
        discountCodes: data.discountCodes        
      })
    }
  }
  discountCodeDelete=()=>{
    this.setState({delete_confirm:true});
  }
  delete_process=async()=>{
    const { localization, auth } = this.props;
    var { data } = await axios.delete('/api/company/discount_code/delete/' + this.state.selectRowId);
    if (data.success) {
      this.props.enqueueSnackbar(localization.localizedString('DELETED_SUCCESS'), {
        variant: 'success',
      });
      this.discountCode();
    }
    else {
      if (data.errorCode == 2 || data.errorCode == 3 || data.errorCode == 5 || data.errorCode == 6) {
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), {
          variant: 'error',
        });
        await auth.get();
      }
      else {
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), {
          variant: 'error',
        });
      }
    }
    this.setState({ delete_confirm: false,discountCardModal:false })
  }
  closeDialog = () => {
    this.props.closeCardState();
    this.setState({discountCardModal:false , delete_confirm: false });
  }   
  saveDiscountCard=async()=>{
    const { localization, auth } = this.props;
    if (this.state.dialog_state == 'Add') {
      var { data } = await axios.post('/api/company/discount_code/save', {
        discountCode: {
          code:this.state.code,          
          active: this.state.active?1:0,
          type:this.state.amount==''?'0':'1',
          amount:this.state.amount,
          percentage:this.state.percentage,
          allServices:this.state.allServices,
          allServiceExtras:this.state.allExtras,
          validFrom:this.state.validFrom,
          validTo:this.state.validTo,
          requirePaymentUpfront:this.state.upfront?1:0,
          used:0,
          limit:this.state.limit,
          active:this.state.active?1:0
        }
      }
      );
      if (data.success) {
        this.props.enqueueSnackbar(localization.localizedString('ADDED_SUCCESS'), {
          variant: 'success',
        });
      }
    }
    else if (this.state.dialog_state == 'Update') {
      var { data } = await axios.put('/api/company/discount_code/update/'+this.state.selectRowId, {
        discountCode: {
          code:this.state.code,          
          active: this.state.active?1:0,
          type:this.state.amount==''?'0':'1',
          amount:this.state.amount,
          percentage:this.state.percentage,
          allServices:this.state.allServices,
          allServiceExtras:this.state.allExtras,
          validFrom:this.state.validFrom,
          validTo:this.state.validTo,
          requirePaymentUpfront:this.state.upfront?1:0,
          used:0,
          limit:this.state.limit,
          active:this.state.active?1:0
        }
      }
      );
      if (data.success) {
        this.props.enqueueSnackbar(localization.localizedString('UPDATED_SUCCESS'), {
          variant: 'success',
        });
      }
    }

    this.setState({ discountCardModal:false });
    this.discountCode();
    if (!data.success) {
      if (data.errorCode == 2 || data.errorCode == 5 || data.errorCode == 6) {
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), {
          variant: 'error',
        });
        await auth.get();
      }
      else {
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), {
          variant: 'error',
        });
      }
    }

  }
  handleChange = prop => event =>{
    if(prop=='amount'){
      this.setState({ [prop]: event.target.value,percentage:'' });
    }
    else if(prop=='percentage'){
      this.setState({ [prop]: event.target.value,amount:'' });
    }
    else{
      this.setState({ [prop]: event.target.value});
    }
   
  } 
  rowClick=()=>{

  }
  changeAllServices=async (event, rid) => {
    var checked = event.target.checked;
    const { localization, auth } = this.props;
    var { data } = await axios.put('/api/company/discount_code/update/' + rid, {
      discountCode: {
        allServices: checked ? 1 : 0
      }
    });

    if (!data.success) {
      if (data.errorCode == 2 || data.errorCode == 5 || data.errorCode == 3 || data.errorCode == 6) {
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), {
          variant: 'error',
        });
        await auth.get();
      }
      else {
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), {
          variant: 'error',
        });
      }
    }    
    this.discountCode();
  }
  changeAllExtras=async (event, rid) => {

    var checked = event.target.checked;
    const { localization, auth } = this.props;
    var { data } = await axios.put('/api/company/discount_code/update/' + rid, {
      discountCode: {
        allServiceExtras: checked ? 1 : 0
      }
    });

    if (!data.success) {
      if (data.errorCode == 2 || data.errorCode == 5 || data.errorCode == 3 || data.errorCode == 6) {
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), {
          variant: 'error',
        });
        await auth.get();
      }
      else {
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), {
          variant: 'error',
        });
      }
    }    
    this.discountCode();
  }
  changeUpfront=async (event, rid) => {
    var checked = event.target.checked;
    const { localization, auth } = this.props;
    var { data } = await axios.put('/api/company/discount_code/update/' + rid, {
      discountCode: {
        requirePaymentUpfront: checked ? 1 : 0
      }
    });

    if (!data.success) {
      if (data.errorCode == 2 || data.errorCode == 5 || data.errorCode == 3 || data.errorCode == 6) {
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), {
          variant: 'error',
        });
        await auth.get();
      }
      else {
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), {
          variant: 'error',
        });
      }
    }    
    this.discountCode();
  }
  changeActive=async (event, rid) => {
    var checked = event.target.checked;
    const { localization, auth } = this.props;
    var { data } = await axios.put('/api/company/discount_code/update/' + rid, {
      discountCode: {
        active: checked ? 1 : 0
      }
    });

    if (!data.success) {
      if (data.errorCode == 2 || data.errorCode == 5 || data.errorCode == 3 || data.errorCode == 6) {
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), {
          variant: 'error',
        });
        await auth.get();
      }
      else {
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), {
          variant: 'error',
        });
      }
    }    
    this.discountCode();

  }
  editDiscountCard=(row)=>{
    this.setState({
      selectRowId:row.id,
      code:row.code,
      amount:row.amount,
      percentage:row.percentage,
      limit:row.limit,
      allServices:row.allServices?true:false,
      allExtras:row.allServiceExtras?true:false,
      validFrom:moment(row.validFrom).format('YYYY-MM-DD')+"T"+moment(row.validFrom).format('HH:mm'),
      validTo:moment(row.validTo).format('YYYY-MM-DD')+"T"+moment(row.validTo).format('HH:mm'),
      upfront:row.requirePaymentUpfront?true:false,
      active:row.active?true:false,
      discountCardModal:true,
      dialog_state:'Update'

    })
  }
  handleToggle = prop => event => this.setState({ [prop]: event.target.checked });
  isSelected = id => this.state.rowSelected.indexOf(id) !== -1;
  render() {
    const { classes, localization, auth } = this.props;
    const { giftCards } = this.state;
    return (
      <GridContainer>
        <GridItem xs={12} sm={12} md={12}>
          <Table className={classes.table} aria-labelledby="tableTitle">
            <TableHead>
              <TableRow>
                <TableCell padding="checkbox">
                </TableCell>
                <TableCell className={classes.dark_title}>
                  Code
                  </TableCell>                  
                <TableCell className={classes.dark_title}>
                  Amount({auth.user.currency_code})
                  </TableCell>
                <TableCell className={classes.dark_title}>
                  Percentage (%)
                  </TableCell>
                  <TableCell className={classes.dark_title}>
                  All Services
                  </TableCell>
                  <TableCell className={classes.dark_title}>
                  All Service Extras
                  </TableCell>
                  <TableCell className={classes.dark_title}>
                 Valid From
                  </TableCell>
                  <TableCell className={classes.dark_title}>
                  Valid To
                  </TableCell>
                  <TableCell className={classes.dark_title}>
                  Upfront
                  </TableCell>
                  <TableCell className={classes.dark_title}>
                  Used
                  </TableCell>
                  <TableCell className={classes.dark_title}>
                  Limit
                  </TableCell>
                <TableCell className={classes.dark_title}>
                  Active
                  </TableCell>
                <TableCell className={classes.dark_title}>
                  Edit
                 </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
            {
              this.state.discountCodes.map(row=>{
                return <TableRow key={row.id}>
                    <TableCell padding="checkbox">
                      <Checkbox checked={this.isSelected(row.id)}
                        onClick={() => this.rowClick(row.id)}
                      />
                    </TableCell>
                    <TableCell className={classes.gray_title}> {row.code}</TableCell>
                    <TableCell className={classes.gray_title}> {row.amount}</TableCell>
                    <TableCell className={classes.gray_title}> {row.percentage}</TableCell>
                    <TableCell className={classes.gray_title}> 
                      <Checkbox checked={row.allServices ? true : false}
                        onClick={(event) => this.changeAllServices(event, row.id)}
                      />
                    </TableCell>
                    <TableCell className={classes.gray_title}> 
                     <Checkbox checked={row.allServiceExtras ? true : false}
                        onClick={(event) => this.changeAllExtras(event, row.id)}
                      />                      
                    </TableCell>
                    <TableCell className={classes.gray_title}> 
                     {moment(row.validFrom).format('YYYY-MM-DD HH:mm:ss')}                  
                    </TableCell>
                    <TableCell className={classes.gray_title}> 
                     {moment(row.validTo).format('YYYY-MM-DD HH:mm:ss')}                  
                    </TableCell>
                    <TableCell className={classes.gray_title}> 
                    <Checkbox checked={row.requirePaymentUpfront ? true : false}
                        onClick={(event) => this.changeUpfront(event, row.id)}
                      />                   
                    </TableCell>
                    <TableCell className={classes.gray_title}> 
                     {row.used}                  
                    </TableCell>
                    <TableCell className={classes.gray_title}> 
                     {row.limit}                  
                    </TableCell>
                    <TableCell className={classes.gray_title}> 
                      <Checkbox checked={row.active ? true : false}
                        onClick={(event) => this.changeActive(event, row.id)}
                      />
                    </TableCell>
                    <TableCell  className={classes.tableCellId}>
                        <Tooltip
                          id="tooltip-top"
                          title="Edit Discount Card"
                          placement="top"
                          classes={{ tooltip: classes.tooltip }}
                        >
                          <IconButton
                            aria-label="Edit"                                            
                            onClick={() =>(this.editDiscountCard(row))}
                            
                          >
                            <Edit
                              className={
                                classes.tableActionButtonIcon + " " + classes.edit
                              }
                            />
                          </IconButton>
                        </Tooltip>
                    </TableCell>
                  </TableRow>
              })
            }
            </TableBody>
          </Table> 
           {/** for modal */}
           <Dialog
            fullWidth={true}
            maxWidth={'sm'}
            open={this.state.discountCardModal}
            onClose={this.closeDialog}
            aria-labelledby="max-width-dialog-title"
          >
            <DialogTitle id="simple-dialog-title" className={classes.dialog_title}>{this.state.dialog_state} Gift Card</DialogTitle>
            <DialogContent className={classes.dialog_2}>
              <Grid container className={classes.dialog_3} justify={'center'}>
                <Grid item xs={12} sm={12} md={10}>
                  <CustomInput
                    labelText="Code"
                    inputProps={{
                      value: this.state.code,
                    }}
                    formControlProps={{
                      required: true,
                      fullWidth: true,
                      value: this.state.code,
                      onChange: this.handleChange('code')
                    }}
                  />
                </Grid>
                <Grid item xs={12} sm={12} md={10}>
                  <CustomInput
                    labelText="Amount (DDK)"
                    inputProps={{
                      value: this.state.amount,
                    }}
                    formControlProps={{
                      required: true,
                      fullWidth: true,
                      value: this.state.amount,
                      onChange: this.handleChange('amount')
                    }}
                  />
                </Grid>
                <Grid item xs={12} sm={12} md={10}>
                  <CustomInput
                    labelText="Percentage (%)"
                    inputProps={{
                      value: this.state.percentage,
                    }}
                    formControlProps={{
                      required: true,
                      fullWidth: true,
                      value: this.state.percentage,
                      onChange: this.handleChange('percentage')
                    }}
                  />
                </Grid>

                <Grid item xs={12} sm={12} md={10}>
                  <CustomInput
                    labelText="Limit "
                    inputProps={{
                      value: this.state.limit,
                    }}
                    formControlProps={{
                      required: true,
                      fullWidth: true,
                      value: this.state.limit,
                       onChange: this.handleChange('limit')
                    }}
                  />
                </Grid>

                <Grid item xs={12} sm={12} md={10} className={classes.check_2}>
                  <FormControlLabel
                      control={(
                        <Checkbox
                          tabIndex={-1}
                          disableRipple
                          onClick={this.handleToggle('allServices')}
                          checked={this.state.allServices}
                        />
                      )}
                      classes={{ label: classes.label }}
                      label={"All Services"}
                    />                  
                </Grid>      
                <Grid item xs={12} sm={12} md={10} className={classes.check_3}>
                  <FormControlLabel
                      control={(
                        <Checkbox
                          tabIndex={-1}
                          disableRipple
                          onClick={this.handleToggle('allExtras')}
                          checked={this.state.allExtras}
                        />
                      )}
                      classes={{ label: classes.label }}
                      label={"All Service Extras"}
                    />                  
                </Grid>               
                
                <Grid xs={12} sm={12} item md={10}  >
                  <form className={classes.container}>
                    <TextField
                      id="validFrom"
                      label="Valid From"
                      type="datetime-local"
                      onChange={this.handleChange('validFrom')}     
                      defaultValue={this.state.validFrom}
                      className={classes.textFieldDate}
                      InputLabelProps={{
                        shrink: true,
                      }}
                    />
                  </form>
                  </Grid>

                  <Grid xs={12} sm={12} item md={10}  >
                  <form className={classes.container}>
                    <TextField
                      id="validTo"
                      label="Valid To"
                      type="datetime-local"
                      onChange={this.handleChange('validTo')}     
                      defaultValue={this.state.validTo}
                      className={classes.textFieldDate}
                      InputLabelProps={{
                        shrink: true,
                      }}
                    />
                  </form>
                  </Grid>

                  <Grid item xs={12} sm={12} md={10} className={classes.check_2}>
                  <FormControlLabel
                      control={(
                        <Checkbox
                          tabIndex={-1}
                          disableRipple
                          onClick={this.handleToggle('upfront')}
                          checked={this.state.upfront}
                        />
                      )}
                      classes={{ label: classes.label }}
                      label={"Require Upfront Payment"}
                    />                  
                </Grid> 

                <Grid item xs={12} sm={12} md={10} className={classes.check_2}>
                  <FormControlLabel
                    control={(
                      <Checkbox
                        tabIndex={-1}
                        disableRipple
                        onClick={this.handleToggle('active')}
                        checked={this.state.active}
                      />
                    )}
                    classes={{ label: classes.label }}
                    label={"Active"}
                  />
                </Grid>
              </Grid>
            </DialogContent>
            <DialogActions className={classes.cardFooter}>
              <GridItem xs={12} sm={12} md={6}>
                <Button color="primary" onClick={this.discountCodeDelete}>Delete</Button>
              </GridItem>
              <Grid item xs={12} sm={12} md={6} className={classes.cardFooter_1}>
                <Button onClick={this.closeDialog} color="secondary" className={classes.button_2}>Cancel</Button>
                <Button variant="contained" color="secondary"
                  onClick={this.saveDiscountCard}>Save</Button>
              </Grid>
            </DialogActions>
          </Dialog>
          {/**  */}  
          {/** delete  dialog */}
          <Dialog
            open={this.state.delete_confirm}
            onClose={this.closeDialog}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
          >
            <DialogTitle id="alert-dialog-title">{"Are you sure to delete?"}</DialogTitle>
            <DialogContent>
            </DialogContent>
            <DialogActions>
              <Button onClick={this.closeDialog} autoFocus color="primary" >
                Cancel
                      </Button>
              <Button onClick={this.delete_process} variant="contained" color="secondary" >
                Yes
                      </Button>
            </DialogActions>
          </Dialog>       
        </GridItem>
      </GridContainer>
    )
  }
}
export default withStyles(servicesStyle)(withSnackbar(withLocalization(withAuth(DiscountCode))));



