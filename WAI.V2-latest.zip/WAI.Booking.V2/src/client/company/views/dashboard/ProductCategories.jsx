import React from 'react';
//import classNames from 'classnames';
import withStyles from '@material-ui/core/styles/withStyles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Edit from "@material-ui/icons/Edit";
import Close from "@material-ui/icons/Close";
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import Create from '@material-ui/icons/AddCircle';
import Grid from '@material-ui/core/Grid';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Button from '@material-ui/core/Button';
import Success from '@material-ui/icons/CheckCircle';
import axios from 'axios';
import {  withSnackbar } from 'notistack';
//import errors from '../../../common/error_codes';
import withAuth from '../../../common/contexts/AuthContext';
import GridItem from "../../../common/components/Grid/GridItem.jsx";
import GridContainer from "../../../common/components/Grid/GridContainer.jsx";
import withLocalization from '../../../common/contexts/LocalizationContext';
import Card from "../../../common/components/Card/Card.jsx";
import CardHeader from "../../../common/components/Card/CardHeader.jsx";
import CardBody from "../../../common/components/Card/CardBody.jsx";
import CustomInput from "../../../common/components/CustomInput/CustomInput.jsx";
import CardFooter from "../../../common/components/Card/CardFooter.jsx";
//import Button from "../../../common/components/CustomButtons/Button.jsx";
import serviceProductsStyle from '../../assets/css/products';

class ProductCategories extends React.Component {
  constructor(props){
    super (props);
    this.state={
      open_dia1:false,//category dialog
      open_dia2:false,//confirm dialog     
      category_name:'',
      categories:[],     
      category_state:'Add',
      gategoryId:'',     
      deleteType:'',     
    };
    this.confirmCateDelete=this.confirmCateDelete.bind(this);
    this.confirmDialogClose=this.confirmDialogClose.bind(this);
    this.createCategory=this.createCategory.bind(this);
    this.saveCategroy=this.saveCategroy.bind(this);
    this.loadCategories=this.loadCategories.bind(this);
   
  }  
  componentWillMount(){
    this.loadCategories();
  }
  async loadCategories(){
        const {localization,auth}=this.props;     
        const { data } = await axios.get('/api/company/product/category');       
        if(data.success){
          this.setState({categories:data.productCategories});
        }
        else{
          if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
            this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
              variant: 'error',
            }); 
            await auth.get();       
           }
           else{        
            this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
              variant: 'error',
            }); 
           }
        }
     
  }
  editChange=(val)=>{   
    this.setState({category_state:'Update',category_name:val,open_dia1:true});
  }  
  createCategory(){
    this.setState({open_dia1:true,category_name:'',category_state:'Add',gategoryId:''});
  }
  categoryDelete= () => {
      this.setState({open_dia2:true,deleteType:'category'});
      return;     
  }  
  async confirmCateDelete(){   
        const {localization,auth}=this.props;          
        const {data } = await axios.delete('/api/company/product/category/'+this.state.gategoryId);
        if(data.success){            
          this.props.enqueueSnackbar(localization.localizedString('DELETED_SUCCESS'), { 
            variant: 'success',
          });     
          this.loadCategories();         
        }
        else{
          if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
            this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
              variant: 'error',
            }); 
            await auth.get();       
           }
           else{        
            this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
              variant: 'error',
            }); 
           }
        }
        this.setState({open_dia2:false,addons_card:this.props.classes.service_card_disable,service_card:this.props.classes.service_card_disable});
  }
  rowClickCategory(rowId){    
    this.setState({gategoryId:rowId})
  }
  dia1Close = () => {
    this.setState({ open_dia1: false });
  }  
  checkRequiredFields = () => {
  }
  async saveCategroy(){  
    const {localization,auth}=this.props;     
    if(this.state.category_state=='Add'){
      var { data } = await axios.post('/api/company/product/category', {     
        name: this.state.category_name,    
      }); 
      if(data.success){          
        this.props.enqueueSnackbar(localization.localizedString('ADDED_SUCCESS'), { 
          variant: 'success',
        }); 
        this.setState({ open_dia1: false });
        this.loadCategories();
      }
    }
    else{
      var { data } = await axios.put('/api/company/product/category/'+this.state.gategoryId, {     
        name: this.state.category_name,
      });
      if(data.success){ 
        this.props.enqueueSnackbar(localization.localizedString('UPDATED_SUCCESS'), { 
          variant: 'success',
        });
        this.setState({ open_dia1: false });
        this.loadCategories();
      }
    }    
    if(!data.success){
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
  }
  handleChange = prop => event => this.setState({ [prop]: event.target.value });
  confirmDialogClose(){
      this.setState({ open_dia2: false });
  }
  table_body=()=>{
    const { classes,localization } = this.props;
    let tbl=[];
    let trs=[];
    if(this.state.categories.length==0){
      return <h4 className={classes.nothing_1}>There is nothing.</h4>
    }

    this.state.categories.map(row => {
      trs.push(<TableRow hover
      key={row.id} onClick={()=>(this.rowClickCategory(row.id))}>
      <TableCell  className={classes.tableCellId+" "+classes.gray_title} >{row.id}</TableCell>
      <TableCell  className={classes.tableCell+" "+classes.gray_title} >
        {row.name}
      </TableCell>     
      <TableCell  className={classes.tableCellId+" "+classes.gray_title}>
            <Tooltip
              id="tooltip-top"
              title="Edit Category"
              placement="top"
              classes={{ tooltip: classes.tooltip }}
            >
              <IconButton
                aria-label="Edit"
              
                onClick={() =>(this.editChange(row.name))}              
                
              >
                <Edit
                  className={
                    classes.tableActionButtonIcon + " " + classes.edit
                  }
                />
              </IconButton>
            </Tooltip>
      </TableCell>
     
    </TableRow>);      
    })

    tbl.push(<Table key={1} className={classes.table}>
      <TableHead >
        <TableRow>
          <TableCell  className={classes.tableCellId+" "+classes.tableHeader_1}>ID</TableCell>
          <TableCell  className={classes.tableCell+" "+classes.tableHeader_1}>Category Name</TableCell>
         
          <TableCell  className={classes.tableCellId +" "+classes.tableHeader_1}>Edit</TableCell>         
        </TableRow>
      </TableHead>
      <TableBody>
        {trs}
      </TableBody>
    </Table>);
    return tbl;    
  }
  render(){
    const { classes,localization } = this.props;
     return(
      <Grid container className={classes.container_1}>
             <GridItem xs={2} sm={2} md={8}>             
            </GridItem>
            <Grid xs={10} item sm={10} md={4} className={classes.header_2}>
              <Button variant="contained" 
                onClick={this.createCategory}
              color="secondary" className={classes.button}>                
                  <Create
                    className={
                        classes.create
                    }
                  />
                Add Product Category
              </Button>   
          </Grid>    
      <Grid item xs={12} sm={12} md={12}>
        <Card>        
         {/**
          <CardHeader color="primary">            
          <GridContainer>
            <GridItem xs={10} sm={10} md={10}>
              <h4 className={classes.cardTitleWhite}>Product Category</h4>
              <p className={classes.cardCategoryWhite}>             
              </p>
            </GridItem>
            <Grid xs={2} item sm={2} md={2} className={classes.header_2}>
                  <Tooltip
                  id="tooltip-top-start"
                  title="Add Category"
                  placement="top"
                  classes={{ tooltip: classes.tooltip }}
                  >
                    <IconButton
                      aria-label="Close"
                      className={classes.tableActionButton}
                      onClick={this.createCategory}
                    >
                      <Create
                        className={
                           classes.create
                        }
                      />
                    </IconButton>
                  </Tooltip>
            </Grid>
           </GridContainer>            
          </CardHeader>
          */}
          <CardBody className={classes.cardBody_1}>
              {this.table_body()}
          </CardBody>
        </Card>
      </Grid>      
      
      {/**  category dialog */}
      <Dialog
          fullWidth={true}
          maxWidth={'sm'}
          open={this.state.open_dia1}
          onClose={this.dia1Close}
          aria-labelledby="max-width-dialog-title"         
        >         
           <DialogTitle id="simple-dialog-title" className={classes.dialog_title}>{this.state.category_state} Product Category</DialogTitle>  
          <DialogContent className={classes.dialog_22}>           
           
                <GridContainer  justify={'center'}>
                    <GridItem xs={12} sm={12} md={11}>
                      <CustomInput
                        labelText="Product Category Name"
                        id="name"
                        inputProps={{
                          value:this.state.category_name,
                        }}
                        formControlProps={{
                          required: true,
                          fullWidth: true,                         
                          value:this.state.category_name,
                          onChange: this.handleChange('category_name')
                        }}
                      />
                    </GridItem>
                    
                </GridContainer>
           
                               
          </DialogContent>
          <DialogActions className={classes.cardFooter}>
          <GridItem xs={12} sm={12} md={6}>
             {
              this.state.employeeId!=''?<Button color="primary" onClick={this.categoryDelete}>Delete</Button>:''
             } 
              </GridItem>
              <Grid item xs={12} sm={12} md={6} className={classes.cardFooter_1}>               
                <Button variant="contained"   onClick={this.dia1Close}>Cancel</Button>   
                <Button color="secondary" variant="contained" className={classes.button_2}
                disabled={this.state.category_name.length==0 || !this.state.category_name}
                 onClick={this.saveCategroy}>Save</Button>
              </Grid>        

            
          </DialogActions>
      </Dialog>  
{/** delete category dialog */}
      <Dialog
        open={this.state.open_dia2}
        onClose={this.confirmDialogClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">{"Are you sure to delete?"}</DialogTitle>
        <DialogContent>       
        </DialogContent>
        <DialogActions>
          <Button onClick={this.confirmDialogClose}  autoFocus>
            Cancel
          </Button>
          <Button  variant="contained" onClick={this.confirmCateDelete} color="secondary" >
            Yes
          </Button>
        </DialogActions>
      </Dialog>

      </Grid>
     )
   }
}
export default withStyles(serviceProductsStyle)(withSnackbar(withLocalization(withAuth(ProductCategories))));
