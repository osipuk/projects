import React from 'react';
//import classNames from 'classnames';
import withStyles from '@material-ui/core/styles/withStyles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Edit from "@material-ui/icons/Edit";
import Close from "@material-ui/icons/Close";
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import Create from '@material-ui/icons/AddCircle';
import Grid from '@material-ui/core/Grid';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Success from '@material-ui/icons/CheckCircle';
import Select from '@material-ui/core/Select';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import axios from 'axios';
import {  withSnackbar } from 'notistack';

import withAuth from '../../../common/contexts/AuthContext';
//import withNotifications from '../../../common/contexts/NotificationsContext';
import GridItem from "../../../common/components/Grid/GridItem.jsx";
import GridContainer from "../../../common/components/Grid/GridContainer.jsx";
import withLocalization from '../../../common/contexts/LocalizationContext';
import Card from "../../../common/components/Card/Card.jsx";
import CardHeader from "../../../common/components/Card/CardHeader.jsx";
import CardBody from "../../../common/components/Card/CardBody.jsx";
import CustomInput from "../../../common/components/CustomInput/CustomInput.jsx";
import CardFooter from "../../../common/components/Card/CardFooter.jsx";
//import Button from "../../../common/components/CustomButtons/Button.jsx";
import Button from '@material-ui/core/Button';
import aboutStyle from '../../assets/css/about';

class TermsOfService extends React.Component {
  constructor(props){
    super (props);
    this.state={
      terms:[],
      languages:[],
      open_dialog_1:false,//employee
      open_dia2:false,//delete dialog
      term:'',
      about_state:'Add',    
      language:1,
      workHours:[],
      termId:0
    };    
  }
  componentWillMount(){
    this.loadTerms();    
    this.loadLanguages();
  }

  loadLanguages=async()=>{
    const {localization}=this.props;
    const { data } = await axios.get('/api/company/languages');       
    if(data.success){
      this.setState({languages:data.languages});      
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }    
  }
  loadTerms=async()=>{
    const {localization,auth}=this.props;
    const { data } = await axios.get('/api/company/termsofservice');   
    console.log(data)  ;
    if(data.success){
      this.setState({terms:data.terms});      
    }
    else{

      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
  }
  createEmployee=()=>{
    this.setState({
      open_dialog_1:true,
      employee_name:'',
      term:'',
      about_state:'Add',
      termId:0
    });
  }
  dia1Close=()=>{
    this.setState({ open_dialog_1: false });
  }
  confirmDialogClose=()=>{
    this.setState({ open_dia2: false,});
  }
  saveDescription=async()=>{
    const {localization,auth}=this.props;
    if(this.state.about_state=='Add'){
      var { data } = await axios.post('/api/company/termsofservice', {
        terms:{ 
          terms:this.state.term,
          languageId:this.state.language}
      });
      if(data.success){
        this.setState({open_dialog_1:false,}); 
        this.loadTerms(); 
        this.props.enqueueSnackbar(localization.localizedString('ADDED_SUCCESS'), { 
          variant: 'success',
        });              
      }
      else{
        if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
          this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
            variant: 'error',
          }); 
          await auth.get();       
         }
         else{        
          this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
            variant: 'error',
          }); 
         }
      }
    }
    else{
      var { data } = await axios.put('/api/company/termsofservice/'+this.state.termId, {
        terms:{ 
          terms:this.state.term,
          languageId:this.state.language
          }
      }); 
      if(data.success){
        this.setState({open_dialog_1:false,}); 
        this.loadTerms();
        this.props.enqueueSnackbar(localization.localizedString('UPDATED_SUCCESS'), { 
          variant: 'success',
        });     
      }
      else{
        if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
          this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
            variant: 'error',
          }); 
          await auth.get();       
         }
         else{        
          this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
            variant: 'error',
          }); 
         }
      }  
    }
    
    
  } 
  editAbout=(row,languageId)=>{
    this.setState({
      open_dialog_1:true,
      termId:row.id,      
      term:row.terms,
      language:languageId,
      about_state:'Update'
    });
  }
  aboutDelete=(id)=>{
    this.setState({ termId:id,open_dia2:true });
  }
  deleteProcess=async()=>{
    const {localization,auth}=this.props;
    const { data } = await axios.delete('/api/company/termsofservice/'+this.state.termId);
    if(data.success){
      this.props.enqueueSnackbar(localization.localizedString('DELETED_SUCCESS'), { 
        variant: 'success',
      }); 
      this.loadTerms();       
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
    this.setState({open_dia2:false});
  }
  handleChange = prop => event => this.setState({ [prop]: event.target.value });
  languageChange=event=>{
    this.setState({language:event.target.value});

  }
  employee_tbody=()=>{
    const { classes,localization } = this.props;
    const {terms,languages}=this.state;
     if(terms.length==0){
       return <h4 className={classes.nothing_1}>There is nothing.</h4>
     }
     let table=[];
     let trs=[];
     terms.map(row => { 
      let language='';
      let languageId=1;
      languages.map(item=>{
        if(item.id==row.languageId){
          language=item.name;
          languageId=item.id;
        }
      })
      trs.push(
      <TableRow key={row.id} hover>
      <TableCell  className={classes.tableCellId+" "+classes.gray_title} >{row.id}</TableCell>
      <TableCell  className={classes.tableCell+" "+classes.gray_title} >
        {row.terms}
      </TableCell>
      <TableCell  className={classes.tableCell+" "+classes.gray_title} >
        {language}
      </TableCell>      
      <TableCell  className={classes.tableCellId+" "+classes.gray_title}>
            <Tooltip
              id="tooltip-top"
              title="Edit Terms of Service"
              placement="top"
              classes={{ tooltip: classes.tooltip }}
            >
              <IconButton
                aria-label="Edit"             
                onClick={() =>(this.editAbout(row,languageId))}              
                
              >
                <Edit
                  className={
                    classes.tableActionButtonIcon + " " + classes.view
                  }
                />
              </IconButton>
            </Tooltip>
      </TableCell>
      <TableCell  className={classes.tableCellId}>
          <Tooltip
            id="tooltip-top-start"
            title="Delete"
            placement="top"
            classes={{ tooltip: classes.tooltip }}
          >
            <IconButton
              aria-label="Close"           
              onClick={() =>(this.aboutDelete(row.id))}
            >
              <Close
                className={
                  classes.tableActionButtonIcon + " " + classes.close
                }
              />
            </IconButton>
          </Tooltip>
      </TableCell>
    </TableRow>);
     });
       table.push(<Table key={1} className={classes.table}>
      <TableHead>
        <TableRow >
          <TableCell  className={classes.tableCellId+" "+classes.tableHeader_1}>ID</TableCell>
          <TableCell  className={classes.tableCell+" "+classes.tableHeader_1}>Terms of Service</TableCell>
          <TableCell  className={classes.tableCell+" "+classes.tableHeader_1}>Laguage</TableCell>
          <TableCell  className={classes.tableCellId+" "+classes.tableHeader_1}>Edit</TableCell>
          <TableCell  className={classes.tableCellId+" "+classes.tableHeader_1}>Delete</TableCell>
        </TableRow>
      </TableHead>
      <TableBody>
        {trs}
     </TableBody>
    </Table>);

    return table;
  }
  render(){
    const { classes,localization } = this.props;
    return(
      <Grid container className={classes.container_1}>
           <GridItem xs={2} sm={2} md={8}>             
          </GridItem>
          <Grid xs={10} item sm={10} md={4} className={classes.header_2}>
            <Button variant="contained" 
              onClick={this.createEmployee}
              color="secondary" className={classes.button}>                
                <Create
                  className={
                      classes.create
                  }
                />
              Add Terms of Services
            </Button>   
        </Grid>    
       <GridItem xs={12} sm={12} md={12}>
        <Card>
          {/**
          <CardHeader color="primary">            
          <GridContainer>
            <GridItem xs={10} sm={10} md={10}>
              <h4 className={classes.cardTitleWhite}>Terms of Service</h4>
              <p className={classes.cardCategoryWhite}>             
              </p>
            </GridItem>
            <Grid xs={2} item sm={2} md={2} className={classes.header_2}>
                  <Tooltip
                  id="tooltip-top-start"
                  title="Add Category"
                  placement="top"
                  classes={{ tooltip: classes.tooltip }}
                  >
                    <IconButton
                      aria-label="Close"
                      className={classes.tableActionButton}
                      onClick={this.createEmployee}
                    >
                      <Create
                        className={
                           classes.create
                        }
                      />
                    </IconButton>
                  </Tooltip>                 
            </Grid>
           </GridContainer>
            
          </CardHeader>
           */}
          <CardBody className={classes.cardBody_1}>          
              {this.employee_tbody()}
         </CardBody>
         </Card>
      </GridItem>
    {/** dialog for about */}
      <Dialog
          fullWidth={true}
          maxWidth={'sm'}
          open={this.state.open_dialog_1}
          onClose={this.dia1Close}
          aria-labelledby="max-width-dialog-title"         
        >         
          <DialogContent className={classes.dialog_2}>
            <Card className={classes.card_2}>
              <CardHeader color="primary">
                <h4 className={classes.cardTitleWhite}>{this.state.empoyee_state} Terms of Services</h4>
                <p className={classes.cardCategoryWhite}>                  
                </p>
              </CardHeader>             
              <CardBody className={classes.cardBody_1}>
                <GridContainer  justify={'center'}>
                    <GridItem xs={12} sm={12} md={10}>
                            <FormControl className={classes.formControl}>
                              <InputLabel htmlFor="age-simple">Language</InputLabel>
                              <Select
                                value={this.state.language}
                                onChange={this.languageChange}
                                inputProps={{
                                  name: 'addon_gender',
                                  id: 'age-simple',
                                }}
                              >
                                {/**
                                <MenuItem value="">
                                  <em>None</em>
                                </MenuItem>                                
                                 */}                                

                                {this.state.languages.map(row=>(
                                  <MenuItem key={row.id} value={row.id}>{row.name}</MenuItem>
                                ))}
                               
                                   
                              </Select>
                           </FormControl>
                    </GridItem>
                    <GridItem xs={12} sm={12} md={10}>
                      <CustomInput
                                labelText="Terms of Services"              
                                inputProps={{
                                value:this.state.term,
                                multiline: true,
                                rows: 3
                              }}
                              formControlProps={{
                                className:classes.customInput_1,   
                                onChange: this.handleChange('term')
                              }}
                       />
                    </GridItem>
                </GridContainer>
              </CardBody>
              <CardFooter>
              <Button color="secondary"
               variant="contained"
               onClick={this.dia1Close}>Cancel</Button>
                <Button color="secondary"
                variant="contained"
                disabled={this.state.term.length==0}
                 onClick={this.saveDescription}>Save</Button>
               
              </CardFooter>             
            </Card>  
          </DialogContent>
      </Dialog> 
      {/** delete category dialog */}
      <Dialog
        open={this.state.open_dia2}
        onClose={this.confirmDialogClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">{"Are you sure to delete?"}</DialogTitle>
        <DialogContent>       
        </DialogContent>
        <DialogActions>
          <Button onClick={this.confirmDialogClose} color="secondary" >
            Cancel
          </Button>
          <Button  variant="contained" onClick={this.deleteProcess} color="secondary" autoFocus>
            Yes
          </Button>
        </DialogActions>
      </Dialog>     

     </Grid>
    )
  }
}
export default withStyles(aboutStyle)(withSnackbar(withLocalization(withAuth(TermsOfService))));
