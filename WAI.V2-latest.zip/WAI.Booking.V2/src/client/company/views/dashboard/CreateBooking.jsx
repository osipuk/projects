import React from 'react';
import ReactDOM from 'react-dom';
import withStyles from '@material-ui/core/styles/withStyles';
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
//import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
//import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import FormHelperText from '@material-ui/core/FormHelperText';
import MuiExpansionPanel from '@material-ui/core/ExpansionPanel';
import MuiExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import MuiExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import ExpansionPanelActions from "@material-ui/core/ExpansionPanelActions";
import Input from '@material-ui/core/Input';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import Timer from "@material-ui/icons/Timer";
import TableRow from '@material-ui/core/TableRow';
import Divider from "@material-ui/core/Divider";
import Chip from "@material-ui/core/Chip";
import DayPicker from "react-day-picker";
import Edit from "@material-ui/icons/Edit";
import PropTypes from 'prop-types';
import Close from "@material-ui/icons/Close";
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import Create from '@material-ui/icons/AddCircle';
import Grid from '@material-ui/core/Grid';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Select from '@material-ui/core/Select';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import MenuItem from '@material-ui/core/MenuItem';
import ListItemText from '@material-ui/core/ListItemText';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import Toolbar from '@material-ui/core/Toolbar';
import axios from 'axios';
import moment from 'moment';
import classNames from 'classnames';
import Success from '@material-ui/icons/CheckCircle';
import { withSnackbar } from 'notistack';
import Typography from '@material-ui/core/Typography';
import Button from "@material-ui/core/Button";
import DeleteIcon from '@material-ui/icons/Delete';
import FilterListIcon from '@material-ui/icons/FilterList';
import { lighten } from '@material-ui/core/styles/colorManipulator';
import withAuth from '../../../common/contexts/AuthContext';
//import withNotifications from '../../../common/contexts/NotificationsContext';
import GridItem from "../../../common/components/Grid/GridItem.jsx";
import GridContainer from "../../../common/components/Grid/GridContainer.jsx";
import withLocalization from '../../../common/contexts/LocalizationContext';
import Card from "../../../common/components/Card/Card.jsx";
import CardHeader from "../../../common/components/Card/CardHeader.jsx";
import CardBody from "../../../common/components/Card/CardBody.jsx";
import CustomInput from "../../../common/components/CustomInput/CustomInput.jsx";
import CardFooter from "../../../common/components/Card/CardFooter.jsx";
//import Button from "../../../common/components/CustomButtons/Button.jsx";
import createbookingStyle from '../../assets/css/createbooking';
import "../../assets/css/style.css";
//import { domainToASCII } from 'url';

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;

const ExpansionPanelSummary = withStyles({
  root: {
    //backgroundColor: 'rgba(0,0,0,.03)',
    borderBottom: "1px solid rgba(0,0,0,.125)",
    boxShadow:
      "0 4px 20px 0px rgba(0, 0, 0, 0.14), 0 7px 10px -5px rgba(179, 172, 177, 1)",
    marginBottom: -1,
    minHeight: 56,
    "&$expanded": {
      minHeight: 56
    }
  },
  content: {
    "&$expanded": {
      margin: "12px 0"
    }
  },
  expanded: {}
})(props => <MuiExpansionPanelSummary {...props} />);

ExpansionPanelSummary.muiName = "ExpansionPanelSummary";
const ExpansionPanelDetails = withStyles(theme => ({
  root: {
    padding: theme.spacing.unit * 2
  }
}))(MuiExpansionPanelDetails);

(function () {
  var days = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday"
  ];
  var months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
  ];

  Date.prototype.getMonthName = function () {
    return months[this.getMonth()];
  };
  Date.prototype.getDayName = function () {
    return days[this.getDay()];
  };
})();

class Services extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      expanded: 'panel1',
      categoryId: 0,
      categories: [],
      employees: [],
      selectRowId: '', //category on panel1
      selectRowId_1: '', // addon chage on panel1    
      selectRowId_2: '',//for employee on panel1
      serviceId: 0,// for service table
      selectRowId_3: '',// for addons
      selected_service_category: '',
      serviceSelected: [],
      selected_addons: [],//for service talbe
      selected_categories: [],
      selected_addons_name: [],//for service talbe
      selected_employees: [],// on panel1
      addons: [],
      selected_categoryId: 0,//on panel 2
      extra_service_relations: [],
      employee_service_relations: [],
      serviceDialog: false,
      can_vary: false,
      service_price: '',
      weight: 0,
      selected_serviceId_2: 0,// for addon table
      selected_addons_1: [],// for addon table
      delete_confirm: false,
      delete_confirm_1: false,
      countryId: 1,// for the new booking table
      countries: [],
      phone_1: '',
      customerDialog: false,
      address: '',
      zip_code: '',
      gender: '',
      customerId: '',
      customerName: '',
      first_name: '',
      last_name: '',
      email: '',
      defaultCategory: 0,
      categoryName: '',
      category_description: '',
      services: [],
      serviceSelected: [],
      selected_serviceId: '', //when service checkbox is seleced in select service panel
      addonsSelected: [],
      price: 0,
      dialog_employee_time: false,
      employeeId: '',
      selected_employees_services: [],
      employee_error: false,
      filtered_employees: [],//employee was filtered by servicId
      serviceAddons: [],
      workHours: [],//from db,
      workTimes: [],// converted times
      workTimesShadow: [],//real minutes for work times
      anonymously: false
    };
    this.handleDayClick = this.handleDayClick.bind(this);
  }
  componentWillMount() {
    this.loadCountrys();
  }
  loadCountrys = async () => {
    const { data } = await axios.get('/api/company/create_booking/getallinf');
    console.log(data);
    if (data.success) {
      this.setState({
        countries: data.country
        , categories: data.categories,
        services: data.services,
        serviceAddons: data.serviceExtras,
        employees: data.employees,
        workHours: data.bookingHours,
        employee_service_relations: data.employee_service_relations,
        extra_service_relations: data.extra_service_relations,
        terms_service: data.terms_service
      })
      data.categories.map(row => {
        if (row.defaultServiceCategory) {
          this.setState({
            defaultCategory: row.id,
            categoryName: "Category: " + row.name,
            category_description: row.description
          });
        }
      })
    }
  }
  handleChange = prop => event => this.setState({ [prop]: event.target.value });
  handleChange_1 = panel => (event, expanded) => {

    var position = panel.substr(5, 1);
    if (parseInt(position) <= this.state.currentPanel) {
      this.setState({
        expanded: expanded ? panel : false,
        currentPanel: parseInt(position)
      });
    }
    for (var i = parseInt(position) + 1; i <= 5; i++) {
      var steps = "step" + i;
      this.setState({
        [steps]: true
      });
    }
    /** 
    this.setState({
      expanded: expanded ? panel : false,     
    });
   */
  };
  closeDialog = () => {
    this.setState({ customerDialog: false, dialog_forgot_Close: false, dialog_employee_time: false });
  }

  selectChange = (event) => {
    this.setState({
      [event.target.name]: event.target.value,
    });
  }
  compareCustomer = async () => {
    var { data } = await axios.post('/api/company/create_booking/getcustomer', {
      customer: {
        countryId: this.state.countryId,
        phone: this.state.phone_1,
      }
    });

    console.log(data);
    if (data.success) {
      if (data.customer) {
        this.setState({
          customerId: data.customer.id,
          customerName: data.customer.firstName + " " + data.customer.lastName,
          expanded: 'panel2'
        })
      }
      else {
        this.setState({ customerDialog: true })
      }
    }

  }

  submitBooking = async () => {
    const { localization } = this.props;
    const { company, serviceSelected, bookingFrom, bookingTo,
      totalDuration, addonsSelected, employeeId, paid,
      payment_method_id, txid, price, customerId,
      cashAmount, paymentAmount, selected_employees_services } = this.state;

    console.log('dddd', selected_employees_services);

    var { data } = await axios.post("/api/company/create_booking/newbooking", {
      book: {
        bookingData: selected_employees_services,
        bookFrom: bookingFrom,
        bookTo: bookingTo,
        paid: 0,
        customerId: customerId,
        employeeId: employeeId
      }
    });
    if (data.success) {

      this.setState({
        expanded: 'panel1',
        currentPanel: 1,
        step1: false,
        serviceSelected: [],
        addonsSelected: [],
        bookingFrom: '',
        bookingTo: '',
        totalDuration: '',
        paid: 0,
        paymentAmount: 0,
        cashAmount: 0,
        selected_employees_services: [],
        dayofweek: [],
        selected_serviceId: 0,
        filtered_employees: [],
        selectedDay: undefined
        //step3:false
      });
      this.props.enqueueSnackbar(localization.localizedString('BOOKING_SUCCESS'), {
        variant: 'success',
      });
    }
    else {
      this.props.enqueueSnackbar(localization.localizedError(data.errorCode), {
        variant: 'error',
      });
    }
  }

  handleToggle = prop => event => this.setState({ [prop]: event.target.checked });

  time_convert = (num) => {
    var hours = Math.floor(num / 60);
    var minutes = num % 60;
    minutes = minutes > 9 ? "" + minutes : "0" + minutes;
    return hours + ":" + minutes;
  }

  /*
 * it is the part when the day is clicked on the calendar.
 */
  async handleDayClick(day, { selected, disabled }) {
    if (disabled) {
      // Day is disabled, do nothing
      return;
    }
    //var now = new Date(day.toLocaleDateString());
    var now = new Date(day);
    var today = new Date();
    if (moment(day).format('YYYY-MM-DD') < moment(today).format('YYYY-MM-DD')) {
      return;
    }
    if (selected) {
      // Unselect the day if already selected
      this.setState({
        selectedDay: undefined,
        workTimes: [],
        workTimesShadow: [],
        available_date_time: "Please select booking day and time."
      });
      return;
    }
    var converted_day = moment(day).format('YYYY-MM-DD');
    var temp_from = [];
    var temp_to = [];
    const { workHours, selected_employees_services } = this.state;
    var temp = [];
    var tempShadow = [];
    var employee_work_array = [];
    var employeeIds = [];
    selected_employees_services.map(item => {
      employeeIds.push(item.employeeId);
    })

    var { data } = await axios.post('/api/company/employee/booked/times',
      {
        day: converted_day,
        employeeIds: employeeIds
      });
    console.log(data, 'employee booked times');
    if (data.success) {

      data.bookings.map(row => {
        temp_from.push(moment(row.bookFrom).format('YYYY-MM-DD HH:mm'));
        temp_to.push(moment(row.bookTo).format('YYYY-MM-DD HH:mm'));
      });

    }



    var open_at_array = [];
    var close_at_array = [];
    var interval = parseInt(this.props.auth.user.interval);
    workHours.map(row => {
      var employee_work_item = {};// employeeId:int, open_at:60, close_at:120      
      //if(row.employeeId==this.state.employeeId){
      if (employeeIds.indexOf(row.employeeId) != -1) {
        var open_at = 0;
        var close_at = 0;

        if (now.getDayName() == "Monday") {
          var hms_open = row.mondayOpenAt;
          var open = hms_open.split(':');
          var hms_close = row.mondayCloseAt;
          var close = hms_close.split(':');
          open_at = parseInt(open[0] * 60) + parseInt(open[1]);
          close_at = parseInt(close[0] * 60) + parseInt(close[1]);
        }
        else if (now.getDayName() == "Tuesday") {
          var hms_open = row.tuesdayOpenAt;
          var open = hms_open.split(':');
          var hms_close = row.tuesdayCloseAt;
          var close = hms_close.split(':');
          open_at = parseInt(open[0] * 60) + parseInt(open[1]);
          close_at = parseInt(close[0] * 60) + parseInt(close[1]);
        }
        else if (now.getDayName() == "Wednesday") {
          var hms_open = row.wednesdayOpenAt;
          var open = hms_open.split(':');
          var hms_close = row.wednesdayCloseAt;
          var close = hms_close.split(':');
          open_at = parseInt(open[0] * 60) + parseInt(open[1]);
          close_at = parseInt(close[0] * 60) + parseInt(close[1]);
        }
        else if (now.getDayName() == "Thursday") {
          var hms_open = row.thursdayOpenAt;
          var open = hms_open.split(':');
          var hms_close = row.thursdayCloseAt;
          var close = hms_close.split(':');
          open_at = parseInt(open[0] * 60) + parseInt(open[1]);
          close_at = parseInt(close[0] * 60) + parseInt(close[1]);
        }
        else if (now.getDayName() == "Friday") {
          var hms_open = row.fridayOpenAt;
          var open = hms_open.split(':');
          var hms_close = row.fridayCloseAt;
          var close = hms_close.split(':');
          open_at = parseInt(open[0] * 60) + parseInt(open[1]);
          close_at = parseInt(close[0] * 60) + parseInt(close[1]);
        }
        else if (now.getDayName() == "Saturday") {
          var hms_open = row.saturdayOpenAt;
          var open = hms_open.split(':');
          var hms_close = row.saturdayCloseAt;
          var close = hms_close.split(':');
          open_at = parseInt(open[0] * 60) + parseInt(open[1]);
          close_at = parseInt(close[0] * 60) + parseInt(close[1]);
        }
        else if (now.getDayName() == "Sunday") {
          var hms_open = row.sundayOpenAt;
          var open = hms_open.split(':');
          var hms_close = row.sundayCloseAt;
          var close = hms_close.split(':');
          open_at = parseInt(open[0] * 60) + parseInt(open[1]);
          close_at = parseInt(close[0] * 60) + parseInt(close[1]);
        }
        selected_employees_services.map(block => {
          if (block.employeeId == row.employeeId) {
            employee_work_item.duration = block.duration;
          }
        })
        employee_work_item.employeeId = row.employeeId;
        employee_work_item.open_at = open_at;
        employee_work_item.close_at = close_at;
        employee_work_array.push(employee_work_item);
        open_at_array.push(open_at);
        close_at_array.push(close_at);

      }
    });
    /**
    * this is the section to get the eariliest open time and latest time
    */

    console.log(employee_work_array, temp_from, 'temp_from');
    for (var i = Math.min.apply(null, open_at_array); i <= Math.max.apply(null, close_at_array); i = i + interval) {

      var is_possible = 1;
      var employee_work_array_shadow = employee_work_array;
      employee_work_array.map(row => {
        var working_duration = parseInt(row.duration) + parseInt(i)
        var open_at = parseInt(row.open_at);
        var close_at = parseInt(row.close_at);

        if (working_duration >= open_at && working_duration <= close_at) {
          employee_work_array_shadow.map(item => {
            if (item.employeeId != row.employeeId && working_duration < item.open_at) {//next open at
              is_possible = is_possible * 0;
            }
            else {
              is_possible = is_possible * 1;
            }
          })
        }
        else {
          is_possible = is_possible * 0;
        }

      });

      var flag = false;
      temp_from.map((item, index) => {
        if (moment(converted_day + " " + this.time_convert(i)).isBetween(item, temp_to[index], null, '[)')) {
          flag = true;
        }
      });

      if (!flag && is_possible) {
        temp.push(this.time_convert(i));
        tempShadow.push(i);
      }
    }

    /**
       var look_block=employee_work_array;
    var open_at=[];
    employee_work_array.map(row=>{
      var duration=parseInt(row.duration);     
      var close_at=parseInt(row.close_at);    
      var is_possible=1;  
      var sub_val=0;
       look_block.map(item=>{
         sub_val=parseInt(row.open_at)-parseInt(item.open_at);
         
         if(sub_val<parseInt(row.duration)){       
           console.log(sub_val,parseInt(row.duration),row.employeeId,'yyyttt');   
           is_possible=is_possible * 1;
           open_at.push(row.open_at);
         }
         else{
           is_possible=is_possible * 0;
         }
       })
       
       
       if(is_possible){
         console.log(row.open_at,row.employeeId,'ggg');
         open_at.push(row.open_at);
       }
        
    })
   
    console.log(open_at,'open at');
   */
    console.log(open_at_array, temp, 'open at array');

    this.setState({
      selectedDay: day,
      month: now.getMonthName(),
      day: now.getDayName(),
      day_d: now.getDate(),
      workTimes: temp,
      workTimesShadow: tempShadow,
      // pickedDate:day_temp[2]+"-"+day_temp[0]+"-"+day_temp[1],     
      pickedDate: converted_day,
      timepick: '',
      totalDuration: '',
      labelTime: '',
      selectedTimeIndex: undefined
    });

  }
  /*
    ** in panel1, it  is the event of when checkbox is seleced.
    */
  serviceClick = (event, id) => {
    this.setState({ selected_serviceId: id });

    if (!event.target.checked) {

      const { serviceSelected, selected_employees_services } = this.state;
      console.log(serviceSelected);
      const selectedIndex = serviceSelected.indexOf(id);
      let newSelected = [];
      if (selectedIndex === -1) {
        newSelected = newSelected.concat(serviceSelected, id);
      }
      else if (selectedIndex === 0) {
        newSelected = newSelected.concat(serviceSelected.slice(1));
      } else if (selectedIndex === serviceSelected.length - 1) {
        newSelected = newSelected.concat(serviceSelected.slice(0, -1));
      } else if (selectedIndex > 0) {
        newSelected = newSelected.concat(
          serviceSelected.slice(0, selectedIndex),
          serviceSelected.slice(selectedIndex + 1),
        );
      }

      var temp_array = [];
      selected_employees_services.map(row => {
        if (row.serviceId != id) {
          temp_array.push(row);
        }
      })

      console.log(newSelected)
      this.setState({
        serviceSelected: newSelected,
        addonsSelected: [],
        price: 0,
        dialog_employee_time: false,
        employeeId: '',
        selected_employees_services: temp_array
      });
    }
    else {
      var temp = [];
      this.state.employee_service_relations.map(row => {
        if (row.serviceId == id)
          temp.push(row.employeeId)
      })
      this.setState({ dialog_employee_time: true, filtered_employees: temp, employeeId: '' });
    }
  }
  /*
    * it is the event of when addon checkbox is selected on panel2
    */
  addonsClick = (event, id) => {
    const { addonsSelected } = this.state;
    const selectedIndex = addonsSelected.indexOf(id);
    let newSelected = [];
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(addonsSelected, id);
    }
    else if (selectedIndex === 0) {
      newSelected = newSelected.concat(addonsSelected.slice(1));
    } else if (selectedIndex === addonsSelected.length - 1) {
      newSelected = newSelected.concat(addonsSelected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        addonsSelected.slice(0, selectedIndex),
        addonsSelected.slice(selectedIndex + 1),
      );
    }

    this.setState({ addonsSelected: newSelected, price: 0 });
  }



  employeeChange = (event) => {
    this.setState({
      [event.target.name]: event.target.value, employee_error: false

    });

  }
  /*
   * it is for the select addons panel2
   */
  serviceAddonsTable = () => {
    const { classes, localization } = this.props;
    const { serviceSelected, extra_service_relations } = this.state;
    let tbl = [];
    let trs = [];
    let selected_extras = [];

    extra_service_relations.map(row => {
      if (serviceSelected.indexOf(row.serviceId) != -1) {
        selected_extras.push(row.extraId);
      }
    })

    this.state.serviceAddons.map((item, index) => {

      const isSelected = this.isAddonsSelected(item.id);
      if (selected_extras.indexOf(item.id) != -1) {
        trs.push(
          <TableRow key={item.id}>
            <TableCell className={classes.tableCellId} >
              <Checkbox
                tabIndex={-1}
                disableRipple
                checked={isSelected}
                onChange={event => this.addonsClick(event, item.id)}
              />
            </TableCell>
            <TableCell className={classes.tableCell}>
              <div className={classNames(classes.title_2)}>
                {item.name}
              </div>
              <div className={classNames(classes.description_1)}>
                {item.description}
              </div>
            </TableCell>
            <TableCell className={classes.tableCell_1}>
              <span>{item.duration} minutes</span>
              {item.vary ? <FormHelperText>Can vary</FormHelperText> : ''}
            </TableCell>

            <TableCell className={classes.tableCell_1}>
              <span>{item.price + " " + this.props.auth.user.currency_code}</span>
            </TableCell>

          </TableRow>
        );
      }
    });
    if (trs.length == 0) {
      return <h4 className={classes.nothing_1}>There is nothing.</h4>
    }
    tbl.push(
      <Table className={classes.table} key={1}>
        <TableBody>
          {trs}
        </TableBody>
      </Table>
    );
    return tbl;
  }

  /**
     * it is the continue event
     */
  nextChange = panel => () => {


    var position = panel.substr(5, 1);
    this.setState({
      expanded: panel,
      currentPanel: parseInt(position)
    });

    var position = panel.substr(5, 1);
    for (var i = 1; i <= parseInt(position); i++) {
      var steps = "step" + i;
      this.setState({
        [steps]: false
      });
    }

    for (var i = parseInt(position) + 1; i <= 5; i++) {
      var steps = "step" + i;
      this.setState({
        [steps]: true
      });
    }


    var { addonsSelected,//selected addons
      serviceAddons,
      extra_service_relations,//relation
      selected_employees_services// block model
    } = this.state;

    console.log(panel);
    if (panel == 'panel5') {
      var array = [];
      selected_employees_services.map(element => {
        element.extraIds = [];
        array.push(element);
      })

      var temp_block_array = [];
      extra_service_relations.map(row => {
        //var temp_array=[];//item.extraIds;      
        if (addonsSelected.indexOf(row.extraId) != -1) {
          temp_block_array = [];
          array.map(item => {
            //  selected_employees_services.map(item=>{              
            if (row.serviceId == item.serviceId) {

              var temp_array = item.extraIds;
              var block_item = item;
              var price = parseFloat(item.price);
              var duration = parseInt(item.duration);

              serviceAddons.map(addon => {
                if (addon.id == row.extraId) {
                  price += parseFloat(addon.price);
                  duration += parseInt(addon.duration);
                }
              })
              temp_array.push(row.extraId);
              block_item.extraIds = temp_array;
              block_item.price = price;
              block_item.duration = duration;
              temp_block_array.push(block_item);
            }
            else {
              temp_block_array.push(item)
            }
          })
          this.setState({ selected_employees_services: temp_block_array });
        }
      })
      console.log(temp_block_array, 'temp_block_array');
      // this.setState({selected_employees_services:temp_block_array});
      /** choose time section */
      const { workHours } = this.state;
      var dayofweek = [];
      var workTimeIsSet = false;
      var employeeIds = [];
      // selected_employees_services.map(item=>{
      temp_block_array.map(item => {
        employeeIds.push(item.employeeId);
      })
      dayofweek.slice(0, 1);
      workHours.map(row => {
        if (employeeIds.indexOf(row.employeeId) != -1) {
          workTimeIsSet = true;
          if (!row.mondayIsOpen) {
            dayofweek.push(1);
          }
          if (!row.tuesdayIsOpen) {
            dayofweek.push(2);
          }
          if (!row.wednesdayIsOpen) {
            dayofweek.push(3);
          }
          if (!row.thursdayIsOpen) {
            dayofweek.push(4);
          }
          if (!row.fridayIsOpen) {
            dayofweek.push(5);
          }
          if (!row.saturdayIsOpen) {
            dayofweek.push(6);
          }
          if (!row.sundayIsOpen) {
            dayofweek.push(0);
          }
        }
      });
      if (!workTimeIsSet) {
        dayofweek = [0, 1, 2, 3, 4, 5, 6];
      }
      this.setState({
        [event.target.name]: event.target.value,
        dayofweek: dayofweek,
        workTimes: [],
        bookingFrom: '',
        bookingTo: '',
        pickedDate: ''
      });
      /** end choose time section */
    }

  };
  /*
  * this event is from after employee was selected and then ok button was clicked on the modal box.
  */
  selected_serivce = () => {
    const { serviceSelected, selected_serviceId, employeeId, selected_employees_services, services } = this.state;
    if (employeeId == '') {
      this.setState({ employee_error: true });
      return;
    }
    var id = selected_serviceId;
    var temp_block = {};
    var temp_array = selected_employees_services;
    var duration = 0;
    var price = 0;
    services.map(row => {
      if (row.id == id) {
        duration += parseInt(row.duration);
        price += parseFloat(row.price);
      }
    })
    temp_block.duration = duration;
    temp_block.price = price;
    temp_block.serviceId = id;
    temp_block.employeeId = employeeId;
    temp_block.extraIds = [];
    temp_array.push(temp_block);

    const selectedIndex = serviceSelected.indexOf(id);
    let newSelected = [];
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(serviceSelected, id);
    }
    else if (selectedIndex === 0) {
      newSelected = newSelected.concat(serviceSelected.slice(1));
    } else if (selectedIndex === serviceSelected.length - 1) {
      newSelected = newSelected.concat(serviceSelected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        serviceSelected.slice(0, selectedIndex),
        serviceSelected.slice(selectedIndex + 1),
      );
    }
    console.log(temp_array, 'tttt');
    this.setState({
      serviceSelected: newSelected,
      addonsSelected: [],
      price: 0,
      dialog_employee_time: false,
      selected_employees_services: temp_array
    });

  }

  /**
     * in choose time panel, it is the event when time is clicked.
     */
  selectTimes = (time, index) => {
    const { services, serviceSelected, serviceAddons, addonsSelected, pickedDate, workTimesShadow } = this.state;
    var totalDuration = 0;
    var totalPrice = 0;
    services.map(row => {
      if (serviceSelected.indexOf(row.id) != -1) {
        totalDuration = totalDuration + parseInt(row.duration);
        totalPrice = totalPrice + parseFloat(row.price);
      }
    })

    serviceAddons.map(row => {
      if (addonsSelected.indexOf(row.id) != -1) {
        totalDuration = totalDuration + parseInt(row.duration);
        totalPrice = totalPrice + parseFloat(row.price);
      }
    })
    var toTemp = parseInt(workTimesShadow[index]) + parseInt(totalDuration);
    console.log(toTemp, workTimesShadow[index], 'totemp');
    this.setState({
      bookingFrom: this.state.pickedDate + " " + time + ":00",
      bookingTo: this.state.pickedDate + " " + this.time_convert(toTemp) + ":00",
      timepick: time,
      totalDuration: totalDuration,
      price: totalPrice,
      labelTime: "(" + moment(this.state.pickedDate + " " + time).format('YYYY-MM-DD HH:mm') + ")",
      selectedTimeIndex: index
      //expanded: 'panel4',
      // currentPanel: 4,
      //step4:false,
    });

  }

  addCustomer = async () => {
    const { localization } = this.props;
    console.log('addcustomer');
    var { data } = await axios.post('/api/company/create_booking/createcustomer',
      {
        customer: {
          countryId: this.state.countryId,
          phone: this.state.phone_1,
          firstName: this.state.first_name,
          lastName: this.state.last_name,
          email: this.state.email,
          zipCode: this.state.zip_code,
          gender: this.state.gender,
          note: this.state.note,
          address1: this.state.address,
          anonymously: this.state.anonymously ? 1 : 0
        }
      });

    if (data.success) {
      this.props.enqueueSnackbar(localization.localizedString('SAVED_SUCCESS'), {
        variant: 'success',
      });
      this.setState({
        customerId: data.customer.id,
        customerDialog: false,
        expanded: 'panel2',
        customerName: data.customer.firstName + " " + data.customer.lastName
      })
    }
    else {
      if(data.errorCode==2 || data.errorCode==3 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
    this.setState({ customerDialog: false,})
  }
  chip_list = () => {
    const { services, serviceSelected } = this.state;
    var chips = [];
    services.map(row => {
      if (serviceSelected.indexOf(row.id) != -1) {
        chips.push(<Chip
          key={row.id}
          label={row.name}
          variant="outlined"
          style={{ margin: '3px', fontWeight: '400', color: '#000', }}
          onDelete={() => this.serviceClick(event, row.id)}

        />);
      }
    })
    return chips;

  }
  isSelected = id => this.state.serviceSelected.indexOf(id) !== -1;
  isAddonsSelected = id => this.state.addonsSelected.indexOf(id) !== -1;
  serviceTable = () => {
    const { classes, localization } = this.props;
    let tbl = [];
    let trs = [];

    this.state.services.map((item, index) => {
      const isSelected = this.isSelected(item.id);
      if (item.serviceCategoryId == this.state.defaultCategory) {
        trs.push(
          <TableRow key={item.id}>
            <TableCell className={classes.tableCellId} >
              <Checkbox
                tabIndex={-1}
                disableRipple
                checked={isSelected}
                onChange={event => this.serviceClick(event, item.id)}
              />
            </TableCell>
            <TableCell className={classes.tableCell}>
              <div className={classNames(classes.title_2)}>
                {item.name}
              </div>
              <div className={classNames(classes.description_1)}>
                {item.description}
              </div>
            </TableCell>
            <TableCell className={classes.tableCell_1}>
              <span>{item.duration} minutes</span>
              {item.vary ? <FormHelperText>Can Vary</FormHelperText> : ''}

            </TableCell>

            <TableCell className={classes.tableCell_1}>
              <span>{item.price + " " + this.props.auth.user.currency_code}</span>
            </TableCell>

          </TableRow>
        );
      }
    });
    if (trs.length == 0) {
      return <h4 className={classes.nothing_1}>There is nothing.</h4>
    }
    tbl.push(
      <Table className={classes.table} key={1}>
        <TableBody>
          {trs}
        </TableBody>
      </Table>
    );
    return tbl;
  }
  render() {
    const { classes, localization, auth } = this.props;
    const { expanded, categories, addons, selected_categories,
      selected_addons_1, countries, workHours, services, serviceSelected, serviceAddons, addonsSelected, } = this.state;

    var serviceSumPrice = 0;
    services.map(row => {
      if (serviceSelected.indexOf(row.id) != -1) {
        serviceSumPrice = serviceSumPrice + parseFloat(row.price);
      }
    })

    var addonSumPrice = 0;
    serviceAddons.map(row => {
      if (addonsSelected.indexOf(row.id) != -1) {
        addonSumPrice = addonSumPrice + parseFloat(row.price);
      }
    });

    var totalPrice = serviceSumPrice + addonSumPrice;


    var today = new Date();

    var working_hours = {};
    let mondayOpenAt = [];
    let mondayCloseAt = [];
    let tuesdayOpenAt = [];
    let tuesdayCloseAt = [];
    let wednesdayOpenAt = [];
    let wednesdayCloseAt = [];
    let thursdayCloseAt = [];
    let thursdayOpenAt = [];
    let fridayOpenAt = [];
    let fridayCloseAt = [];
    let saturdayOpenAt = [];
    let saturdayCloseAt = [];
    let sundayOpenAt = [];
    let sundayCloseAt = [];



    workHours.map(item => {

      if (item.mondayIsOpen) {
        mondayOpenAt.push(item.mondayOpenAt);
        mondayCloseAt.push(item.mondayCloseAt);
      }
      if (item.tuesdayIsOpen) {
        tuesdayOpenAt.push(item.tuesdayOpenAt);
        tuesdayCloseAt.push(item.tuesdayCloseAt);
      }
      if (item.wednesdayIsOpen) {
        wednesdayOpenAt.push(item.wednesdayOpenAt);
        wednesdayCloseAt.push(item.wednesdayCloseAt);
      }

      if (item.thursdayIsOpen) {
        thursdayOpenAt.push(item.thursdayOpenAt);
        thursdayCloseAt.push(item.thursdayCloseAt);
      }

      if (item.fridayIsOpen) {
        fridayOpenAt.push(item.fridayOpenAt);
        fridayCloseAt.push(item.thursdayCloseAt);
      }

      if (item.saturdayIsOpen) {
        saturdayOpenAt.push(item.saturdayOpenAt);
        saturdayCloseAt.push(item.saturdayCloseAt);
      }

      if (item.sundayIsOpen) {
        sundayOpenAt.push(item.sundayOpenAt);
        sundayCloseAt.push(item.sundayCloseAt);
      }
    })
    mondayOpenAt.sort();
    tuesdayOpenAt.sort();
    wednesdayOpenAt.sort();
    thursdayOpenAt.sort();
    fridayOpenAt.sort();
    saturdayOpenAt.sort();
    sundayOpenAt.sort();
    return (
      <GridContainer>
        <GridItem xs={12} sm={12} md={12}>
          <Card>
            <CardBody className={classes.cardBody_1}>
              <GridContainer>
                <GridItem xs={12} sm={12} md={12}>
                  <ExpansionPanel
                    square
                    expanded={expanded === 'panel1'}
                    onChange={this.handleChange_1('panel1')}
                  >
                    <ExpansionPanelSummary className={classes.root_summary}>
                      <Grid xs={10} item sm={10} md={10} className={classes.grid_title}>
                        <Typography variant="subtitle1" className={classes.title_3}>Select Customer</Typography>
                      </Grid>
                      <Grid xs={2} item sm={2} md={2} className={classes.header_2}>
                      </Grid>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>
                      <Grid container>
                        <Grid item xs={12} sm={6} md={3}>
                          <FormControl
                            className={classes.formControl_1}
                          >
                            <InputLabel htmlFor="countryId">Country</InputLabel>
                            <Select
                              value={this.state.countryId}
                              onChange={this.selectChange}
                              input={
                                <Input
                                  fullWidth={true}

                                  name="countryId"
                                  id="countryId"
                                />
                              }
                              className={classes.outlineInput}
                            >
                              {
                                countries.map(row => {
                                  return <MenuItem key={row.id} value={row.id}>{row.name}</MenuItem>
                                })
                              }

                            </Select>
                          </FormControl>
                        </Grid>
                        <Grid item xs={12} sm={6} md={3}>
                          <CustomInput
                            labelText={"Phone Number"}
                            inputProps={{
                              value: this.state.phone_1,
                            }}
                            formControlProps={{
                              required: true,
                              fullWidth: true,
                              value: this.state.phone_1,
                              onChange: this.handleChange('phone_1')
                            }}
                          />
                        </Grid>
                        <Grid
                          xs={12}
                          sm={12}
                          md={6}
                          item
                          className={classes.detail_3}
                        />
                        <Grid
                          xs={12}
                          sm={12}
                          md={10}
                          item
                          className={classes.detail_3}
                        />
                        <Grid
                          xs={12}
                          sm={12}
                          md={2}
                          item
                          className={classes.addon_2}
                        >

                          <Button
                            variant="contained"
                            color="secondary"
                            disabled={this.state.phone_1.length != 0 ? false : true}
                            className={classes.button}
                            onClick={this.compareCustomer}
                          >
                            Continue
                      </Button>
                        </Grid>

                      </Grid>
                    </ExpansionPanelDetails>

                  </ExpansionPanel>

                  <ExpansionPanel
                    square
                    expanded={expanded === 'panel2'}
                    onChange={this.handleChange_1('panel2')}
                  >
                    <ExpansionPanelSummary className={classes.root_summary}>
                      <Grid xs={10} item sm={10} md={10} className={classes.grid_title}>
                        <Typography variant="subtitle1" className={selected_categories.length > 0 ? classes.title_4 : classes.title_3}>Select Service</Typography>
                        <Typography variant="subtitle1" color="secondary" className={classes.selectedLabel}></Typography>
                      </Grid>
                      <Grid xs={2} item sm={2} md={2} className={classes.header_2}>

                      </Grid>
                    </ExpansionPanelSummary>
                    <ExpansionPanelActions className={classes.action_1}>
                      <Grid container>
                        <Grid item xs={12} sm={6} md={4}>
                          <FormControl
                            className={classes.formControl}
                          >
                            <Select
                              value={this.state.defaultCategory}
                              onChange={this.selectChange}
                              input={
                                <Input
                                  fullWidth={true}

                                  name="defaultCategory"
                                  id="defaultCategory"
                                />
                              }
                              className={classes.outlineInput}
                            >
                              {categories.map(row => (
                                <MenuItem key={row.id} value={row.id}>{row.name}</MenuItem>
                              ))}
                            </Select>
                            <FormHelperText>Category</FormHelperText>
                          </FormControl>
                        </Grid>
                        <Grid item xs={12} sm={6} md={8} className={classes.detail_3}>
                          <Typography variant="caption" className={classes.sub_paragraph}>
                            {this.state.category_description}
                          </Typography>
                        </Grid>
                      </Grid>
                    </ExpansionPanelActions>
                    <Divider />
                    <ExpansionPanelDetails className={classes.detail_1}>
                      <Grid container>
                        <Grid item xs={12} sm={12} md={12}>
                          <div className={classes.cardBody_1}>
                            {this.serviceTable()}
                          </div>
                        </Grid>
                      </Grid>

                      <Grid container className={classes.detail_2}>
                        <Grid
                          xs={6}
                          sm={6}
                          md={9}
                          item
                          className={classes.detail_3}
                        >
                          {this.chip_list()}

                        </Grid>
                        <Grid xs={6} sm={6} md={3} item className={classes.addon_2}>
                          <Button
                            variant="contained"
                            color="secondary"
                            className={classes.button_back}
                            onClick={this.nextChange("panel1")}
                          >
                            Back
                      </Button>

                          <Button
                            variant="contained"
                            color="secondary"
                            disabled={this.state.serviceSelected.length != 0 ? false : true}
                            className={classes.button}
                            onClick={this.nextChange('panel3')}
                          >
                            Continue
                      </Button>
                        </Grid>
                      </Grid>

                    </ExpansionPanelDetails>

                  </ExpansionPanel>
                  <ExpansionPanel
                    square
                    expanded={expanded === 'panel3'}
                    onChange={this.handleChange_1('panel3')}
                  >
                    <ExpansionPanelSummary className={classes.root_summary}>
                      <Grid xs={10} item sm={10} md={10} className={classes.grid_title}>
                        <Typography variant="subtitle1" className={selected_addons_1.length > 0 ? classes.title_4 : classes.title_3}>Select Addons</Typography>
                        <Typography variant="subtitle1" color="secondary" className={classes.selectedLabel}></Typography>
                      </Grid>
                      <Grid xs={2} item sm={2} md={2} className={classes.header_2}>
                      </Grid>
                    </ExpansionPanelSummary>
                    <Divider />
                    <ExpansionPanelDetails className={classes.detail_1}>
                      <Grid container>
                        <Grid item xs={12} sm={12} md={12}>
                          <div className={classes.cardBody_1}>
                            {this.serviceAddonsTable()}
                          </div>
                        </Grid>
                      </Grid>

                      <Grid container className={classes.detail_2}>
                        <Grid
                          xs={12}
                          sm={12}
                          md={6}
                          item
                          className={classes.detail_3}
                        />
                        <Grid
                          xs={12}
                          sm={12}
                          md={6}
                          item
                          className={classes.addon_2}
                        >
                          <Button
                            variant="contained"
                            color="secondary"
                            className={classes.button_back}
                            onClick={this.nextChange("panel3")}
                          >
                            Back
                      </Button>
                          <Button
                            variant="contained"
                            color="secondary"
                            className={classes.button}
                            onClick={this.nextChange('panel5')}
                          >
                            Continue
                      </Button>
                        </Grid>
                      </Grid>
                    </ExpansionPanelDetails>
                  </ExpansionPanel>
                  <ExpansionPanel
                    disabled={this.state.step3}
                    className={classes.expansionPanelDisabled}
                    expanded={expanded === "panel5"}
                    onChange={this.handleChange_1("panel5")}
                  >
                    <ExpansionPanelSummary className={classes.root_summary}>
                      <Typography variant="subheading" className={classes.title_3}>
                        Choose Time
                  </Typography>
                      <Typography className={classes.grow} >
                        {this.state.labelTime}
                      </Typography>

                      <span className={classes.step_c} />
                    </ExpansionPanelSummary>

                    <Divider className={classes.hr_cs1} />
                    <ExpansionPanelDetails className={classes.detail_1}>
                      <Grid
                        container
                        className={classNames(classes.detail_2, classes.addon_1)}
                      >
                        <Grid
                          xs={12}
                          sm={12}
                          md={5}
                          item
                          className={classes.calander_2}
                        >
                          <DayPicker
                            className={classes.calander_1}
                            disabledDays={[{ daysOfWeek: this.state.dayofweek }, {
                              after: new Date(2019, 1, 1),
                              before: today,
                            },]}
                            onDayClick={this.handleDayClick}
                            selectedDays={this.state.selectedDay}
                          />
                        </Grid>
                        <Grid
                          xs={12}
                          sm={12}
                          md={7}
                          item
                          className={classes.time_4}
                        >

                          <div className={classes.time_3}>
                            {this.state.workTimes.length == 0 ? <Typography
                              variant="subheading"
                              className={classes.title_3}
                            >
                              {this.state.available_date_time}
                            </Typography> : null}
                            <ul className={classes.timBoxes}>
                              {this.state.workTimes.map((row, index) => (

                                <li key={row} className={this.state.selectedTimeIndex == index ? classes.time_item : {}} onClick={() => this.selectTimes(row, index)}>{row}</li>
                              ))}
                            </ul>


                          </div>
                        </Grid>
                      </Grid>
                      <Divider className={classes.hr_cs1} />
                      <Grid container className={classes.detail_2}>
                        <Grid
                          xs={12}
                          sm={12}
                          md={9}
                          item
                          className={classes.detail_3}
                        />
                        <Grid
                          xs={12}
                          sm={12}
                          md={3}
                          item
                          className={classes.addon_2}
                        >
                          <Button
                            variant="contained"
                            color="secondary"
                            className={classes.button_back}
                            onClick={this.nextChange("panel4")}
                          >
                            Back
                      </Button>

                          <Button
                            variant="contained"
                            color="secondary"
                            className={classes.button}
                            disabled={this.state.labelTime ? false : true}
                            onClick={this.nextChange("panel6")}
                          >
                            Continue
                      </Button>

                        </Grid>
                      </Grid>
                    </ExpansionPanelDetails>
                  </ExpansionPanel>
                  <ExpansionPanel
                    disabled={this.state.step4}
                    className={classes.expansionPanelDisabled}
                    expanded={expanded === "panel6"}
                    onChange={this.handleChange("panel6")}
                  >
                    <ExpansionPanelSummary className={classes.root_summary}>

                      <Typography variant="subheading" className={classes.title_3}>
                        Confirm and Receipt
                  </Typography>
                      <Typography className={classes.grow}>
                        {totalPrice != 0 ? 'Total Price: ' + totalPrice.toFixed(2) + ' ' + this.props.auth.user.currency_code : ''}
                      </Typography>
                      <span className={classes.step_c} />
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails className={classes.detail_1}>
                      <Grid
                        container
                        className={classNames(classes.detail_2, classes.addon_1)}
                      >
                        <Grid
                          xs={12}
                          sm={12}
                          md={12}
                          item
                          className={classes.confirm_1}
                        >
                          <span>
                            {this.state.customerName} is about to make a booking at {this.props.auth.user.company_name}{" "}
                            {this.state.day} {this.state.day_d}th {this.state.month}{" "}
                            at {this.state.timepick}. Duration is{" "}
                            {this.state.totalDuration} minutes
                      </span>
                        </Grid>
                      </Grid>
                      <Divider className={classes.hr_cs1} />
                      <Grid container className={classes.detail_2}>
                        <Grid
                          xs={12}
                          sm={12}
                          md={9}
                          item
                          className={classes.detail_3}
                        />
                        <Grid
                          xs={6}
                          sm={6}
                          md={1}
                          item
                          className={classes.addon_4}
                        >


                        </Grid>
                        <Grid
                          xs={6}
                          sm={6}
                          md={2}
                          item
                          className={classes.addon_2}
                        >
                          <Button
                            variant="contained"
                            color="secondary"
                            className={classes.button_back}
                            onClick={this.nextChange("panel5")}
                          >
                            Back
                      </Button>
                          <Button
                            variant="contained"
                            color="secondary"
                            className={classes.button}
                            onClick={this.submitBooking}
                          >
                            Submit
                      </Button></Grid>
                      </Grid>
                    </ExpansionPanelDetails>
                  </ExpansionPanel>

                </GridItem>
              </GridContainer>
            </CardBody>
          </Card>
        </GridItem>
        {/** for services */}
        <Dialog
          fullWidth={true}
          maxWidth={'sm'}
          open={this.state.customerDialog}
          onClose={this.closeDialog}
          aria-labelledby="max-width-dialog-title"
        >
          <DialogTitle id="simple-dialog-title" className={classes.dialog_title}>Set the customer information</DialogTitle>
          <DialogContent className={classes.dialog_2}>
            <Grid container className={classes.dialog_3} justify={'center'}>
              <GridItem xs={12} sm={12} md={11}>
                <FormControl className={classes.formControl_1}>
                  <InputLabel htmlFor="age-simple">Select Country</InputLabel>
                  <Select
                    value={this.state.countryId}
                    onChange={this.selectChange}
                    inputProps={{
                      name: 'countryId',
                      id: 'countryId',
                    }}
                  >
                    <MenuItem value="">
                      <em>None</em>
                    </MenuItem>
                    {
                      countries.map(row => {
                        return <MenuItem key={row.id} value={row.id}>{row.name}</MenuItem>
                      })
                    }
                  </Select>
                </FormControl>
              </GridItem>

              <GridItem xs={12} sm={12} md={11}>
                <CustomInput
                  labelText="Phone number"
                  inputProps={{
                    value: this.state.phone_1,
                  }}
                  formControlProps={{
                    required: true,
                    fullWidth: true,
                    value: this.state.phone_1,
                    onChange: this.handleChange('phone_1')
                  }}
                />
              </GridItem>
              <GridItem xs={12} sm={12} md={6}>
                <CustomInput
                  labelText="First Name"
                  inputProps={{
                    value: this.state.first_name,
                  }}
                  formControlProps={{
                    required: true,
                    fullWidth: true,
                    value: this.state.first_name,
                    onChange: this.handleChange('first_name')
                  }}
                />
              </GridItem>

              <GridItem xs={12} sm={12} md={5}>
                <CustomInput
                  labelText="Last Name"
                  inputProps={{
                    value: this.state.last_name,
                  }}
                  formControlProps={{
                    required: true,
                    fullWidth: true,
                    value: this.state.last_name,
                    onChange: this.handleChange('last_name')
                  }}
                />
              </GridItem>

              <GridItem xs={12} sm={12} md={11}>
                <CustomInput
                  labelText={"Email"}
                  inputProps={{
                    value: this.state.email,
                  }}
                  formControlProps={{
                    required: true,
                    fullWidth: true,
                    value: this.state.email,
                    onChange: this.handleChange('email')
                  }}
                />
              </GridItem>

              <GridItem xs={12} sm={12} md={5}>
                <CustomInput
                  labelText={"Zip Code"}
                  inputProps={{
                    value: this.state.zip_code,
                  }}
                  formControlProps={{
                    required: true,
                    fullWidth: true,
                    value: this.state.zip_code,
                    onChange: this.handleChange('zip_code')
                  }}
                />
              </GridItem>


              <GridItem xs={12} sm={12} md={6}>
                <FormControl className={classes.formControl_2}>
                  <InputLabel htmlFor="gender">Gender</InputLabel>
                  <Select
                    value={this.state.gender}
                    onChange={this.selectChange}
                    inputProps={{
                      name: 'gender',
                      id: 'gender',
                    }}
                  >
                    <MenuItem value="">
                      <em>None</em>
                    </MenuItem>

                    <MenuItem value={'Man'}>Man</MenuItem>
                    <MenuItem value={'Woman'}>Woman</MenuItem>
                  </Select>
                </FormControl>
              </GridItem>

              <GridItem xs={12} sm={12} md={11}>
                <CustomInput
                  labelText="Note"
                  inputProps={{
                    value: this.state.note,
                    multiline: true,
                    rows: 2
                  }}
                  formControlProps={{
                    fullWidth: true,
                    value: this.state.note,
                    onChange: this.handleChange('note')
                  }}
                />
              </GridItem>

              <GridItem xs={12} sm={12} md={11}>
                <CustomInput
                  labelText={"Address"}
                  inputProps={{
                    value: this.state.address,
                  }}
                  formControlProps={{
                    required: true,
                    fullWidth: true,
                    value: this.state.address,
                    onChange: this.handleChange('address')
                  }}
                />
              </GridItem>
              <GridItem xs={12} sm={12} md={11}>
                <FormControlLabel
                  control={(
                    <Checkbox
                      tabIndex={-1}
                      disableRipple
                      onClick={this.handleToggle('anonymously')}
                      checked={this.state.anonymously}
                    />
                  )}
                  classes={{ label: classes.label }}
                  label={"Register user and send password on SMS"}
                />
              </GridItem>
            </Grid>
          </DialogContent>
          <DialogActions className={classes.cardFooter}>
            <GridItem xs={12} sm={12} md={6}>
              <Button onClick={this.closeDialog} color="secondary" className={classes.button_2}>Cancel</Button>
            </GridItem>
            <Grid item xs={12} sm={12} md={6} className={classes.cardFooter_1}>

              <Button variant="contained" color="secondary"

                onClick={this.addCustomer}>Save</Button>
            </Grid>
          </DialogActions>
        </Dialog>
        {/**  */}
        {/**choose time/employee dialog  */}
        <Dialog
          fullWidth={true}
          maxWidth={'xs'}
          open={this.state.dialog_employee_time}
          onClose={this.closeDialog}
          aria-labelledby="max-width-dialog-title"
          className={classes.dialog_1}
        >
          <DialogTitle id="simple-dialog-title" className={classes.dialog_title} >Select Employee</DialogTitle>
          <DialogContent >
            <Grid container className={classes.GridContainer}>
              <Grid item xs={12} sm={12} md={10}>
                <FormControl
                  error={this.state.employee_error}
                  variant="outlined"
                  className={classes.formControl_employee}
                >
                  <InputLabel htmlFor="employeeId">Employee</InputLabel>
                  <Select
                    value={this.state.employeeId}
                    onChange={this.employeeChange}
                    inputProps={{
                      name: 'employeeId',
                      id: 'employeeId',
                    }}
                  >
                    {this.state.employees.map(row => {
                      if (this.state.filtered_employees.indexOf(row.id) != -1)
                        return <MenuItem key={row.id} value={row.id}>{row.firstName+" "+row.lastName}</MenuItem>
                    })}
                  </Select>
                </FormControl>
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions className={classes.cardFooter}>
            <Button color="primary" onClick={this.closeDialog}>Cancel</Button>
            <Button variant="contained" color="secondary" onClick={this.selected_serivce} className={classes.button_2}>Ok</Button>
          </DialogActions>
        </Dialog>
        {/** dialog */}


        {/** delete  dialog for multi delete */}
        <Dialog
          open={this.state.delete_confirm_1}
          onClose={this.confirmDialogClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle id="alert-dialog-title">{"Are you sure to delete?"}</DialogTitle>
          <DialogContent>
          </DialogContent>
          <DialogActions>
            <Button onClick={this.confirmDialogClose} autoFocus color="primary" >
              Cancel
          </Button>
            <Button onClick={this.delete_process_1} variant="contained" color="secondary" >
              Yes
          </Button>
          </DialogActions>
        </Dialog>

      </GridContainer>
    )
  }
}
export default withStyles(createbookingStyle)(withSnackbar(withLocalization(withAuth(Services))));
