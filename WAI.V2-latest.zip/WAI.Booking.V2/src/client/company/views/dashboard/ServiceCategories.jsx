import React from 'react';
//import classNames from 'classnames';
import withStyles from '@material-ui/core/styles/withStyles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Edit from "@material-ui/icons/Edit";
import Close from "@material-ui/icons/Close";
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import Create from '@material-ui/icons/AddCircle';
import Grid from '@material-ui/core/Grid';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import FormControl from '@material-ui/core/FormControl';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import MenuItem from '@material-ui/core/MenuItem';
import InputLabel from '@material-ui/core/InputLabel';
import Select from '@material-ui/core/Select';
import axios from 'axios';
import Success from '@material-ui/icons/CheckCircle';
import Button from '@material-ui/core/Button';
import {  withSnackbar } from 'notistack';
//import errors from '../../../common/error_codes';
import withAuth from '../../../common/contexts/AuthContext';
//import withNotifications from '../../../common/contexts/NotificationsContext';
import GridItem from "../../../common/components/Grid/GridItem.jsx";
import GridContainer from "../../../common/components/Grid/GridContainer.jsx";
import withLocalization from '../../../common/contexts/LocalizationContext';
import Card from "../../../common/components/Card/Card.jsx";
import CardHeader from "../../../common/components/Card/CardHeader.jsx";
import CardBody from "../../../common/components/Card/CardBody.jsx";
import CustomInput from "../../../common/components/CustomInput/CustomInput.jsx";
import CardFooter from "../../../common/components/Card/CardFooter.jsx";
//import Button from "../../../common/components/CustomButtons/Button.jsx";
import servicesStyle from '../../assets/css/services';

class ServiceCategories extends React.Component {
  constructor(props){
    super (props);
    this.state={
      open_dia1:false,//category dialog
      open_dia2:false,//confirm dialog     
      category_name:'',
      categories:[],     
      category_state:'Add',
      gategoryId:0,     
      deleteType:'',
      default_category:0,
      description:''
    };
    this.confirmCateDelete=this.confirmCateDelete.bind(this);
    this.confirmDialogClose=this.confirmDialogClose.bind(this);
    this.createCategory=this.createCategory.bind(this);
    this.saveCategroy=this.saveCategroy.bind(this);   
   
  }  
  componentDidMount(){
    this.loadCategories();
  }
   loadCategories=async()=>{
    const {localization,auth}=this.props;
      
        const { data } = await axios.get('/api/company/service/category'); 
        
        if(data.success){
          this.setState({categories:data.serviceCategories});
        }
        else{
          if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
            this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
              variant: 'error',
            }); 
            await auth.get();       
           }
           else{        
            this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
              variant: 'error',
            }); 
           }
        }
      
  }
  editChange=(row)=>{   
    this.setState({category_state:'Update',
    category_name:row.name,
    default_category:row.defaultServiceCategory,
    description:row.description?row.description:'',
    open_dia1:true});
  }  
  createCategory(){
    this.setState({open_dia1:true,category_name:'',category_state:'Add',description:''});
  }
  categoryDelete=async (val) => {
      this.setState({open_dia2:true,gategoryId:val,deleteType:'category'});
      return;     
  }  
  async confirmCateDelete(){   
         const {localization,auth}=this.props;
        const { data } = await axios.delete('/api/company/service/category/'+this.state.gategoryId);
      
        if(data.success){
          this.props.enqueueSnackbar(localization.localizedString('DELETED_SUCCESS'), { 
            variant: 'success',
          }); 
          this.loadCategories();         
        }
        else{
          if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
            this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
              variant: 'error',
            }); 
            await auth.get();       
           }
           else{        
            this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
              variant: 'error',
            }); 
           }
        }
        this.setState({open_dia2:false,addons_card:this.props.classes.service_card_disable,service_card:this.props.classes.service_card_disable});
  }
  rowClickCategory(rowId){    
    this.setState({gategoryId:rowId})
  }
  dia1Close = () => {
    this.setState({ open_dia1: false });
  }  
  serviceGenderChange=(event)=>{
    this.setState({
      [event.target.name]: event.target.value,
    });
  }
  async saveCategroy(){  
    const {localization,auth}=this.props;
    console.log(this.state.description);
    if(this.state.category_state=='Add'){
      var { data } = await axios.post('/api/company/service/category', {     
        name: this.state.category_name,
        defaultServiceCategory:this.state.default_category,
        description:this.state.description
      }); 
      if(data.success){        
        this.props.enqueueSnackbar(localization.localizedString('ADDED_SUCCESS'), { 
          variant: 'success',
        }); 
      }
    }
    else{
      var { data } = await axios.put('/api/company/service/category/'+this.state.gategoryId, {     
        name: this.state.category_name,
        defaultServiceCategory:this.state.default_category,
        description:this.state.description
      });
      if(data.success){       
        this.props.enqueueSnackbar(localization.localizedString('UPDATED_SUCCESS'), { 
          variant: 'success',
        });      
      }
    }
    if(data.success){    
      this.setState({ open_dia1: false });        
      this.loadCategories();
    }
    else if(!data.success){
      if(data.errorCode==2 || data.errorCode==5 || data.errorCode==3  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
  }
  handleChange = prop => event => this.setState({ [prop]: event.target.value });
  confirmDialogClose(){
      this.setState({ open_dia2: false });
  }
  table_body=()=>{
    const { classes,localization } = this.props;
    let tbl=[];
    let trs=[];
    if(this.state.categories.length==0){
      return <h4 className={classes.nothing_1}>There is nothing.</h4>
    }

    this.state.categories.map(row => {
      trs.push(<TableRow hover
      key={row.id} onClick={()=>(this.rowClickCategory(row.id))}>
      <TableCell  className={classes.tableCellId} >{row.id}</TableCell>
      <TableCell  className={classes.tableCell} >
        {row.name}
      </TableCell>    
      <TableCell  className={classes.tableCell_2} >
        {row.defaultServiceCategory?"True":"False"}
      </TableCell>     
      <TableCell  className={classes.tableCellId} style={{minWidth: '110px',}}>
      <div style={{float: 'left', width: '45%',}}>
            <Tooltip
              id="tooltip-top"
              title="Edit"
              placement="top"
              classes={{ tooltip: classes.tooltip }}
            >
              <IconButton
                aria-label="Edit"
                className={classes.tableActionButton}  
                onClick={() =>(this.editChange(row))}              
                
              >
                <Edit
                  className={
                    classes.tableActionButtonIcon + " " + classes.edit
                  }
                />
              </IconButton>
            </Tooltip>

      </div>
      <div style={{float: 'left', width: '10%',}}>
      </div>
      <div style={{float: 'left', width: '45%',}}>
            <Tooltip
            id="tooltip-top-start"
            title="Delete"
            placement="top"
            classes={{ tooltip: classes.tooltip }}
          >
            <IconButton
              aria-label="Close"
              className={classes.tableActionButton}
              onClick={() =>(this.categoryDelete(row.id))}
            >
              <Close
                className={
                  classes.tableActionButtonIcon + " " + classes.close
                }
              />
            </IconButton>
          </Tooltip>

      </div>
      </TableCell>
    </TableRow>);      
    })

    tbl.push(<Table key={1} className={classes.table}>
      <TableHead >
        <TableRow>
          <TableCell  className={classes.tableCellId+" "+classes.tableHeader_1}>ID</TableCell>
          <TableCell  className={classes.tableCell+" "+classes.tableHeader_1}>Category Name</TableCell>
          <TableCell  className={classes.tableCell_2+" "+classes.tableHeader_1}>Default Service Category</TableCell>
          <TableCell  className={classes.tableCellId +" "+classes.tableHeader_1}>Actions</TableCell>
        </TableRow>
      </TableHead>
      <TableBody>
        {trs}
      </TableBody>
    </Table>);
    return tbl;    
  }
  render(){
    const { classes,localization } = this.props;
     return(
      <Grid container className={classes.container_1}>     
            <GridItem xs={2} sm={2} md={8}>             
            </GridItem>
            <Grid xs={10} item sm={10} md={4} className={classes.header_2}>
              <Button variant="contained" 
                onClick={this.createCategory}
              color="secondary" className={classes.button}>                
                  <Create
                    className={
                        classes.create
                    }
                  />
                Add Service Category
              </Button>   
        </Grid>    
      <GridItem xs={12} sm={12} md={12}>
        <Card>         
          <CardBody className={classes.cardBody_1}>
              {this.table_body()}
          </CardBody>
        </Card>
      </GridItem>      
      
      {/**  category dialog */}
      <Dialog
          fullWidth={true}
          maxWidth={'sm'}
          open={this.state.open_dia1}
          onClose={this.dia1Close}
          aria-labelledby="max-width-dialog-title"         
        >         
          <DialogContent className={classes.dialog_2}>
            <Card className={classes.card_2}>
              <CardHeader color="primary">
                <h4 className={classes.cardTitleWhite}>{this.state.category_state} Service Category</h4>
                <p className={classes.cardCategoryWhite}>                  
                </p>
              </CardHeader>
             
              <CardBody className={classes.cardBody_1}>
                <GridContainer  justify={'center'}>
                    <GridItem xs={12} sm={12} md={10}>
                      <CustomInput
                        labelText="Add Service Category Name"
                        id="name"
                        inputProps={{
                          value:this.state.category_name,
                        }}
                        formControlProps={{
                          required: true,
                          fullWidth: true,                         
                          value:this.state.category_name,
                          onChange: this.handleChange('category_name')
                        }}
                      />
                    </GridItem>
                    <GridItem xs={12} sm={12} md={10}>
                      <CustomInput
                          labelText="Description"                        
                          inputProps={{
                            value:this.state.description,
                            multiline: true,
                            rows: 3
                          }}
                          formControlProps={{                         
                            fullWidth: true,                         
                            value:this.state.description,
                            onChange: this.handleChange('description')
                          }}
                        />
                    </GridItem>
                    </GridContainer>
                    <GridContainer  justify={'center'}>
                    <GridItem xs={12} sm={12} md={10}>
                             <FormControl className={classes.formControl_1}>
                              <InputLabel htmlFor="age-simple">Default Service Category</InputLabel>
                              <Select
                                value={this.state.default_category}
                                onChange={this.serviceGenderChange}
                                inputProps={{
                                  name: 'default_category',
                                  id: 'age-simple',
                                }}
                              >                               
                                <MenuItem value={1}>True</MenuItem>
                                <MenuItem value={0}>False</MenuItem>        
                              </Select>
                            </FormControl>
                    </GridItem>
                    
                </GridContainer>
              </CardBody>
              <CardFooter>
                <Button color="secondary" variant="contained" 
                disabled={this.state.category_name.length==0 || !this.state.category_name}
                 onClick={this.saveCategroy}>Save</Button>
                <Button color="secondary"  variant="contained"  onClick={this.dia1Close}>Cancel</Button>
              </CardFooter>             
            </Card>  
          </DialogContent>
      </Dialog>  
{/** delete category dialog */}
      <Dialog
        open={this.state.open_dia2}
        onClose={this.confirmDialogClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">{"Are you sure to delete?"}</DialogTitle>
        <DialogContent>       
        </DialogContent>
        <DialogActions>
          <Button onClick={this.confirmDialogClose} color="primary" >
            Cancel
          </Button>
          <Button  onClick={this.confirmCateDelete} color="primary" autoFocus>
            Yes
          </Button>
        </DialogActions>
      </Dialog>

      </Grid>
     )
   }
}
export default withStyles(servicesStyle)(withSnackbar(withLocalization(withAuth(ServiceCategories))));
