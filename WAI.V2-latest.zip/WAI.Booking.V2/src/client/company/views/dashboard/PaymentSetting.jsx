import React from 'react';

import withStyles from '@material-ui/core/styles/withStyles';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Check from '@material-ui/icons/Check';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import Success from '@material-ui/icons/CheckCircle';
import axios from 'axios';
import Grid from '@material-ui/core/Grid';
import Typography from '@material-ui/core/Typography';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';

import InputAdornment from '@material-ui/core/InputAdornment';
import withLocalization from '../../../common/contexts/LocalizationContext';
import withAuth from '../../../common/contexts/AuthContext';
import withNotifications from '../../../common/contexts/NotificationsContext';
import GridContainer from '../../../common/components/Grid/GridContainer';
import GridItem from '../../../common/components/Grid/GridItem';
import Card from '../../../common/components/Card/Card';
import CardBody from '../../../common/components/Card/CardBody';
import CardHeader from '../../../common/components/Card/CardHeader';
import CardFooter from '../../../common/components/Card/CardFooter';
import CustomInput from '../../../common/components/CustomInput/CustomInput';
import Button from "../../../common/components/CustomButtons/Button.jsx";
//import SignupButton from '../../../common/containers/SignupButton/SignupButton';
import settingPageStyle from '../../assets/css/settings';
//import signupPageStyle from '../../../common/assets/jss/material-react/views/loginPage';

class PaymentSetting extends React.Component {
  state = {
    paypal_key: '',
    strip:'',
    coin_payment:'',
    masterCard:false,
    visa:false,
    dankort:false,
    cash:false,
    paypal:false,
    american_express:false,
    maestro:false,
    bitcoin:false,
    paymentSettingId:0,
    
  };

  componentWillMount(){  
   this.loadPaymentSetting();
  }
    loadPaymentSetting=async()=>{
    const { data } = await axios.get('/api/company/payment_setting');
    console.log(data);
    if(data.success){
       var settings=data.settings;
      this.setState({
        paypal_key: settings.paypalKey,
        strip:settings.strip,
        coin_payment:settings.coinPayment,
        masterCard:settings.mastercard?true:false,
        visa:settings.visa?true:false,
        dankort:settings.dankort?true:false,
        cash:settings.cash?true:false,
        paypal:settings.paypal?true:false,
        american_express:settings.americanExpress?true:false,
        maestro:settings.maestro?true:false,
        bitcoin:settings.bitcoin?true:false,
        paymentSettingId:settings.id,     
      })
    }
  }
  handleChange = prop => event => this.setState({ [prop]: event.target.value });
 

  handleToggle = prop => event => this.setState({ [prop]: event.target.checked });
  saveSetting=async()=>{
  
      const { localization, classes } = this.props;

    
        if(this.state.paymentSettingId==0){
          var { data } = await axios.post('/api/company/payment_setting', {
            settings:{
                paypalKey: this.state.paypal_key,
                strip:this.state.strip,
                coinPayment:this.state.coin_payment,
                mastercard:this.state.masterCard,
                visa:this.state.visa?1:0,
                dankort:this.state.dankort?1:0,
                cash:this.state.cash?1:0,
                paypal:this.state.paypal?1:0,
                americanExpress:this.state.american_express?1:0,
                maestro:this.state.maestro?1:0,
                bitcoin:this.state.bitcoin?1:0              
            }
          });
          if(data.success){
            this.props.notifications.show({message: localization.localizedString('ADDED_SUCCESS'),icon:Success,color:'success'});
          }
      }
      else{
        var { data } = await axios.put('/api/company/payment_setting/'+this.state.paymentSettingId, {
          settings:{
              paypalKey: this.state.paypal_key,
              strip:this.state.strip,
              coinPayment:this.state.coin_payment,
              mastercard:this.state.masterCard,
              visa:this.state.visa?1:0,
              dankort:this.state.dankort?1:0,
              cash:this.state.cash?1:0,
              paypal:this.state.paypal?1:0,
              americanExpress:this.state.american_express?1:0,
              maestro:this.state.maestro?1:0,
              bitcoin:this.state.bitcoin?1:0              
          }
        });
        if(data.success){
          this.props.notifications.show({message: localization.localizedString('UPDATED_SUCCESS'),icon:Success,color:'success'});
        }
      }    
        if (!data.success) {         
          this.props.notifications.show({message: localization.localizedError(data.errorCode)});
          return
        }
        
        this.loadPaymentSetting();
      
      
     
  }
  checkRequiredFields = () => {
    const {
      email, password, firstName, lastName,
     phone, companyName, zipCode,
      city, address, smsSenderName,customUrl
    } = this.state;

    return (email && email.length > 0)
      && (password && password.length > 0)
      && (firstName && firstName.length > 0)
      && (lastName && lastName.length > 0)    
      && (phone && phone.length > 0)
      && (companyName && companyName.length > 0)
      && (zipCode && zipCode.length > 0)
      && (city && city.length > 0)
      && (address && address.length > 0)   
      && (customUrl && customUrl.length > 0)         
      && (smsSenderName && smsSenderName.length > 0 && smsSenderName.length < 12);
  };
  offlineChange=(event,value)=>{
    this.setState({
      [value]: event.target.checked
    });
  }
  render() {
    const { localization, classes } = this.props;
    const {
      paypal_key,
      strip,
      coin_payment,
      masterCard,      
      visa,
      dankort,
      cash,
      paypal,
      american_express,
      maestro,
      bitcoin,
    } = this.state;

    return (       
          <GridContainer >
            <GridItem xs={12} sm={12} md={12}>
              <Card>
                <form className={classes.form}>
                  <CardHeader color="primary" className={classes.cardHeader}>
                    <h4>{localization.localizedString('DASHBOARD_NAVBAR_PAYMENT_SETTINGS_NAME')}</h4>
                  </CardHeader>
                  <CardBody className={classes.cardBody_1}>
                    <GridContainer justify="center">
                     
                      <Grid item xs={12} sm={12} md={6}>
                          <Typography variant="h6">
                             Online Payments
                          </Typography>

                          <GridContainer>
                          <GridItem xs={12} sm={12} md={10}>
                              <CustomInput
                                labelText={'Paypal Api Key'}
                                formControlProps={{                                
                                    required: false,
                                    fullWidth: true,
                                    
                                  }}
                                  inputProps={{
                                    type: 'text',
                                    value: paypal_key,
                                    onChange: this.handleChange('paypal_key')
                                  }}
                                />
                            </GridItem>
                            <GridItem xs={12} sm={12} md={10}>
                              <CustomInput
                                labelText={'Stripe'}
                                formControlProps={{                                
                                    required: false,
                                    fullWidth: true,
                                    
                                  }}
                                  inputProps={{
                                    type: 'text',
                                    value: strip,
                                    onChange: this.handleChange('strip')
                                  }}
                                />
                            </GridItem>
                            <GridItem xs={12} sm={12} md={10} >
                              <CustomInput
                              className={classes.online_bottom}
                                labelText={'CoinPayment'}
                                formControlProps={{                                
                                    required: false,
                                    fullWidth: true,
                                    
                                  }}
                                  inputProps={{
                                    type: 'text',
                                    value: coin_payment,
                                    onChange: this.handleChange('coin_payment')
                                  }}
                                />
                            </GridItem>
                          </GridContainer>

                      </Grid>

                      <Grid item xs={12} sm={12} md={6}>
                          <Typography variant="h6">
                             Offline Payments
                          </Typography>     
                          <Grid container className={classes.offline_margin}>
                            <Grid item xs={2} sm={2} md={1} >
                                <Checkbox
                                  tabIndex={-1}
                                  disableRipple
                                  checked={masterCard}
                                  onChange={() => this.offlineChange(event, 'masterCard')}                            
                                />
                            
                            </Grid>
                            <Grid item xs={10} sm={10} md={11} className={classes.offline_label}>
                                <Typography variant="subtitle2">
                                  Master Card
                              </Typography>                           
                            </Grid>

                            <Grid item xs={2} sm={2} md={1} >
                                <Checkbox
                                    tabIndex={-1}
                                    disableRipple
                                    checked={visa}
                                    onChange={() => this.offlineChange(event, 'visa')}                            
                                />
                            
                            </Grid>
                            <Grid className={classes.offline_label} item xs={10} sm={10} md={11}>
                                <Typography  variant="subtitle2" >
                                  VISA
                              </Typography>                           
                            </Grid>

                            <Grid item xs={2} sm={2} md={1} >
                                <Checkbox
                                    tabIndex={-1}
                                    disableRipple
                                    checked={dankort}
                                    onChange={() => this.offlineChange(event, 'dankort')}                            
                                />
                            
                            </Grid>
                            <Grid className={classes.offline_label} item xs={10} sm={10} md={11}>
                                <Typography  variant="subtitle2" >
                                  Dankort
                              </Typography>                           
                            </Grid>

                            <Grid item xs={2} sm={2} md={1} >
                                <Checkbox
                                    tabIndex={-1}
                                    disableRipple
                                    checked={cash}
                                    onChange={() => this.offlineChange(event, 'cash')}                            
                                />                            
                            </Grid>
                            <Grid className={classes.offline_label} item xs={10} sm={10} md={11}>
                                <Typography  variant="subtitle2" >
                                  Dankort
                              </Typography>                           
                            </Grid>

                            <Grid item xs={2} sm={2} md={1} >
                                <Checkbox
                                    tabIndex={-1}
                                    disableRipple
                                    checked={paypal}
                                    onChange={() => this.offlineChange(event, 'paypal')}                            
                                />                            
                            </Grid>
                            <Grid className={classes.offline_label} item xs={10} sm={10} md={11}>
                                <Typography  variant="subtitle2" >
                                  Paypal
                              </Typography>                           
                            </Grid>

                            <Grid item xs={2} sm={2} md={1} >
                                <Checkbox
                                    tabIndex={-1}
                                    disableRipple
                                    checked={american_express}
                                    onChange={() => this.offlineChange(event, 'american_express')}                            
                                />                            
                            </Grid>
                            <Grid className={classes.offline_label} item xs={10} sm={10} md={11}>
                                <Typography  variant="subtitle2" >
                                  American Express
                              </Typography>                           
                            </Grid>

                            <Grid item xs={2} sm={2} md={1} >
                                <Checkbox
                                    tabIndex={-1}
                                    disableRipple
                                    checked={maestro}
                                    onChange={() => this.offlineChange(event, 'maestro')}                            
                                />                            
                            </Grid>
                            <Grid className={classes.offline_label} item xs={10} sm={10} md={11}>
                                <Typography  variant="subtitle2" >
                                  Maestro
                              </Typography>                           
                            </Grid>

                            <Grid item xs={2} sm={2} md={1} >
                                <Checkbox
                                    tabIndex={-1}
                                    disableRipple
                                    checked={bitcoin}
                                    onChange={() => this.offlineChange(event, 'bitcoin')}                            
                                />                            
                            </Grid>
                            <Grid className={classes.offline_label} item xs={10} sm={10} md={11}>
                                <Typography  variant="subtitle2" >
                                  Bitcoin
                              </Typography>                           
                            </Grid>


                          </Grid>     
                      </Grid>
                     
                    </GridContainer>
                  </CardBody>
                  <CardFooter className={classes.cardFooter}>
                      <Button onClick={() =>(this.saveSetting())}                      
                      color="primary"                     
                       >Save</Button>  
                  </CardFooter>
                </form>
              </Card>
            </GridItem>
          </GridContainer>
        
     
    );
  }
}
export default withStyles(settingPageStyle)(withNotifications(withLocalization(withAuth(PaymentSetting))));

