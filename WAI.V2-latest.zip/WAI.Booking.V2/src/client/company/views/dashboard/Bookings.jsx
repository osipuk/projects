import React from 'react';
import moment from 'moment'
import BigCalendar from 'react-big-calendar';
import withStyles from '@material-ui/core/styles/withStyles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Success from '@material-ui/icons/CheckCircle';
import Select from "@material-ui/core/Select";
import FormHelperText from '@material-ui/core/FormHelperText';
import InputLabel from "@material-ui/core/InputLabel";
import FormControl from "@material-ui/core/FormControl";
import MenuItem from "@material-ui/core/MenuItem";
import Grid from '@material-ui/core/Grid';;
import DialogActions from '@material-ui/core/DialogActions';
import SearchIcon from '@material-ui/icons/Search';
import Input from "@material-ui/core/Input";
import InputBase from '@material-ui/core/InputBase';
import Button from '@material-ui/core/Button';
import axios from 'axios';
import {  withSnackbar } from 'notistack';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import Typography from '@material-ui/core/Typography';
import withAuth from '../../../common/contexts/AuthContext';
import GridItem from "../../../common/components/Grid/GridItem.jsx";
import GridContainer from "../../../common/components/Grid/GridContainer.jsx";
import withLocalization from '../../../common/contexts/LocalizationContext';
import Card from "../../../common/components/Card/Card.jsx";
import CardHeader from "../../../common/components/Card/CardHeader.jsx";
import CardBody from "../../../common/components/Card/CardBody.jsx";
import CustomInput from "../../../common/components/CustomInput/CustomInput.jsx";
import CardFooter from "../../../common/components/Card/CardFooter.jsx";
//import Button from "../../../common/components/CustomButtons/Button.jsx";
const localizer = BigCalendar.momentLocalizer(moment) // or globalizeLocalizer
let allViews=Object.keys(BigCalendar.Views).map(k => BigCalendar.Views[k]);

import bookingStyle from '../../assets/css/booking';
import '../../assets/css/calendarStyle.css';
import da from '../../../common/localization/da';

class Booking extends React.Component {
  constructor(props){
  super (props);
  this.state={
    detail_modal:false,
    booking_from:'',
    booking_to:'',       
    firstName:'',
    lastName:'',
    customerPhone:'',
    customerBooking_time:'',
    bookingPrice:0,
    bookingTotal_time:'',
    bookings:[],
    services:[],
    serviceAddons:[],
    serviceAddons_1:[],
    serviceId:0,
    bookingExtraId:0,//when addons is edited
    serviceIdEdit:0,
    addonId:0,
    created_time:'',
    bookingStatus:'',
    duration:'',
    status:'',
    labelWidth:0,
    customerId:0,
    title:'', 
    bookingId:0,
    employeeId:0,
    employeeName:'',
    bookingServices:[],
    bookingExtras:[],
    employees:[],
    searchCustomer:'',
    bookingRequestStatus:true
  };
}
  componentDidMount(){
    this.loadBookingData();
   }
   componentWillReceiveProps(){
     if(this.state.bookingRequestStatus!=this.props.bookingStatus){
       this.setState({bookingRequestStatus:this.props.bookingStatus});      
       this.loadBookingData();
     }
    
   }   
  loadBookingData=async()=>{
    const {localization,auth}=this.props;    
    const { data } = await axios.get('/api/company/booking');   
      if(data.success){
        this.setState({
          bookings:data.bookings,
          bookingServices:data.bookingServices,
          bookingExtras:data.bookingExras,
          employees:data.employees
        });
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }

  }
  handleChange = prop => event => this.setState({ [prop]: event.target.value });
  completedBooking=async(row)=>{

    const {localization,auth}=this.props;  

     var  {data} = await axios.get('/api/company/booking/'+row.id+"/service"); 
     if(data.success){
        this.setState({services:data.bookingServices});
     }
     else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
     }

     var  {data} = await axios.get('/api/company/booking/'+row.id+'/extra');  
     if(data.success){
      this.setState({serviceAddons:data.bookingExtras});
      }     
      this.props.goOtherPage(row.id,this.state.services,this.state.serviceAddons,row.customer_id);

     /**
     var { data } = await axios.put('/api/company/booking/'+row.id+'/completed');
     if(data.success){
      notifications.show({message: localization.localizedString('COMPLETED_SUCCESS'),icon:Success,color:'success'});
      this.props.goOtherPage(row.id,this.state.services,this.state.serviceAddons,row.customer_id);
      //this.loadBookingData();
     }
     else{
      notifications.show({message:localization.localizedError(data.errorCode)});
     }   
      */ 
  }
  selectChange=(event)=> {
    this.setState({
      [event.target.name]: event.target.value
    });
  }
  
  handleSearch = name => event => {
    this.setState({
      [name]: event.target.value,
    });
  };

  stayedBooking=async(id)=>{
    const {localization,auth}=this.props; 
    var { data } = await axios.put('/api/company/booking/'+id+'/stayed_away');
    if(data.success){
      this.props.enqueueSnackbar(localization.localizedString('STAYED_AWAY_SUCCESS'), { 
        variant: 'success',
      }); 
      this.loadBookingData();
     }
     else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
     }
  }
  table_body=()=>{
    const { classes,localization } = this.props;
    const{bookingServices,bookings,bookingExtras,employees,searchCustomer,status}=this.state;
    let tbl=[];
    let trs=[];    

   bookings.map((row,index) => {
      let number=index+1;
      const bookingFrom = moment(row.book_from);      
      const bookingTo = moment(row.book_to);
      var services_temp=[];
      var extras_temp=[];
      
      bookingServices.map(item=>{
        if( item.booking_id==row.id){
         services_temp.push(item.name);
        }
       })

       bookingExtras.map(item=>{
         if(item.booking_id==row.id){
           extras_temp.push(item.name);
         }
       })  

       let employeeName='';
       employees.map(item=>{
          if(item.id=row.employee_id){
           employeeName=item.name;
          }
       })

       let custmoer_name=row.first_name + " "+ row.last_name;
      if(row.status!='AWAITING RESPONSE' 
      && row.status=='ACCEPTED' 
      && custmoer_name.search(searchCustomer)!=-1 
      && row.status.search(status)!=-1
      ){ 
        
      
      trs.push(<TableRow hover
      key={row.id} >
      <TableCell  className={classes.tableCell+" "+classes.gray_title} >
        {row.id}
      </TableCell>
      <TableCell  className={classes.tableCell+" "+classes.gray_title} >
        {custmoer_name}
      </TableCell>
      <TableCell  className={classes.tableCell+" "+classes.gray_title} >
        {employeeName}
      </TableCell>
      
      <TableCell className={classes.gray_title}>{bookingFrom.format('YYYY-MM-DD HH:mm')} ~ {bookingTo.format('HH:mm')}</TableCell>
      <TableCell className={classes.gray_title+" "+classes.gray_title} >{services_temp.join()}</TableCell>      
      <TableCell  className={classes.gray_titl+" "+classes.gray_title}>{extras_temp.join()}</TableCell>           
      <TableCell  className={classes.tableCell+" "+classes.gray_title} >
        {row.status}
      </TableCell>
      <TableCell  className={classes.tableCellId}>
                  <Button variant="contained" 
                      size="small" color="secondary"
                      className={classes.margin}
                      onClick={() =>(this.completedBooking(row))}                                           
                  >
                     Completed
                  </Button>               
           
      </TableCell>
      <TableCell  >
              <Button variant="contained" 
                    size="small" color="primary"
                    className={classes.margin}
                    onClick={() =>(this.stayedBooking(row.id))}                                           
                >
                    Stayed Away
                </Button>
          
      </TableCell>      
    </TableRow>); 
      }     
     if(row.status!='AWAITING RESPONSE' 
     && row.status!='ACCEPTED'  
     && row.status.search(status)!=-1
     && custmoer_name.search(searchCustomer)!=-1)
        trs.push(<TableRow hover
        key={row.id} >
        <TableCell  className={classes.tableCell} >
          {number}
        </TableCell>
        <TableCell  className={classes.tableCell} >
          {row.first_name + " "+ row.last_name}
        </TableCell>
        <TableCell  className={classes.tableCell} >
        {employeeName}
         </TableCell>
        <TableCell className={classes.tableCell} >{bookingFrom.format('YYYY-MM-DD HH:mm')} ~ {bookingTo.format('HH:mm')}</TableCell>
        <TableCell  >{services_temp.join()}</TableCell>      
        <TableCell  >{extras_temp.join()}</TableCell>       
        <TableCell align="center"  className={classes.tableCell} >
          {row.status}
        </TableCell>
        <TableCell  className={classes.tableCellId}>                              
        </TableCell>
        <TableCell  >
        </TableCell>      
      </TableRow>);   

    })

    tbl.push(<Table key={1} className={classes.table}>
      <TableHead >
        <TableRow>
        <TableCell  className={classes.tableCellId+" "+classes.tableHeader_1}>No</TableCell>     
          <TableCell  className={classes.tableCell+" "+classes.tableHeader_1}>
            <div className={classes.search}>
              <div className={classes.searchIcon}>
                <SearchIcon />
              </div>
              <InputBase
                placeholder="Customer Name"
                onChange={this.handleSearch('searchCustomer')}
                value={this.state.searchCustomer}
                classes={{
                  root: classes.inputRoot,
                  input: classes.inputInput,
                }}
              />
            </div>
          </TableCell>
          <TableCell className={classes.tableCell+" "+classes.tableHeader_1}>Employee Name</TableCell>
          <TableCell  className={classes.tableHeader_1}>Booking Time</TableCell>
          <TableCell  className={classes.tableHeader_1}>Services</TableCell>
          <TableCell  className={classes.tableHeader_1}>Service Addons</TableCell>              
          <TableCell align="left"  className={classes.tableHeader_1}>
            <FormControl
                    className={classes.formControl_1+" "+classes.inputLabel}
                  >
            <InputLabel  className={classes.inputLabel} htmlFor="status-simple">Status</InputLabel>
              <Select
                  value={this.state.status}
                  onChange={this.selectChange}                     
                 
                      
                    inputProps={{
                      name: 'status',
                      id: 'status-simple',
                      className:classes.itemSize
                    }}
                    className={classes.outlineInput}
                >
                    <MenuItem className={classes.itemSize}  value=''>
                       <em>All</em>
                    </MenuItem>
                    <MenuItem className={classes.itemSize} value={'ACCEPTED'}>{'ACCEPTED'}</MenuItem>
                    <MenuItem className={classes.itemSize} value={'COMPLETED'}>{'COMPLETED'}</MenuItem>
                    <MenuItem className={classes.itemSize}  value={'REJECTED'}>{'REJECTED'}</MenuItem>
                    <MenuItem className={classes.itemSize} value={'STAYED AWAY'}>{'STAYED AWAY'}</MenuItem>
                    <MenuItem className={classes.itemSize} value={'CANCELLED BY COMPANY'}>{'CANCELLED BY COMPANY'}</MenuItem>
                    <MenuItem className={classes.itemSize} value={'CANCELLED BY CUSTOMER'}>{'CANCELLED BY CUSTOMER'}</MenuItem>
                    
                
              </Select>             
           </FormControl>
          </TableCell>   
          <TableCell  className={classes.tableCellId+" "+classes.tableHeader_1}>Completed</TableCell>
          <TableCell  className={classes.tableHeader_1}>Stayed Away</TableCell>
        
        </TableRow>
      </TableHead>
      <TableBody>
        {trs}
      </TableBody>
    </Table>);

      //if(trs.length==0){
     //   return <h4 className={classes.nothing_1}>There is nothing.</h4>
     // }

    return tbl;    
  }
  render(){
    const { classes,localization } = this.props;
    return(
      <GridContainer>
      <GridItem xs={12} sm={12} md={12}>        
            {this.table_body()}          
        </GridItem>     
      </GridContainer>      
    )
  }
}
export default withStyles(bookingStyle)(withSnackbar(withLocalization(withAuth(Booking))));



