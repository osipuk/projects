import React from 'react';
//import classNames from 'classnames';
import withStyles from '@material-ui/core/styles/withStyles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import moment from 'moment'
import Edit from "@material-ui/icons/Edit";
import Visibility from "@material-ui/icons/Visibility";
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import axios from 'axios';
import {  withSnackbar } from 'notistack';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import Success from '@material-ui/icons/CheckCircle';

//import errors from '../../../common/error_codes';
import withAuth from '../../../common/contexts/AuthContext';
//import withNotifications from '../../../common/contexts/NotificationsContext';
import GridItem from "../../../common/components/Grid/GridItem.jsx";
import GridContainer from "../../../common/components/Grid/GridContainer.jsx";
import withLocalization from '../../../common/contexts/LocalizationContext';
import Card from "../../../common/components/Card/Card.jsx";
import CardHeader from "../../../common/components/Card/CardHeader.jsx";
import CardBody from "../../../common/components/Card/CardBody.jsx";
import CustomInput from "../../../common/components/CustomInput/CustomInput.jsx";
import CardFooter from "../../../common/components/Card/CardFooter.jsx";
import Button from "../../../common/components/CustomButtons/Button.jsx";
import paymentsStyle from '../../assets/css/payments';

class Payments extends React.Component {
  constructor(props){
    super (props);
    this.state={
     payments:[]
    };       
    this.saveChanges=this.saveChanges.bind(this);    
     
  }  
  componentWillMount(){  
    this.loadPayments();
  }

  loadPayments=async()=>{
    const {localization,auth}=this.props;
    const { data } = await axios.get('/api/company/payment/all');
  
    if(data.success){    
     this.setState({payments:data.payments});      
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }    
  }
  loadCustomers=async()=>{
    const {localization,auth}=this.props;     
    const { data } = await axios.get('/api/company/customer');
    console.log(data);
    if(data.success){
        this.setState({customers:data.customers});
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
  }  
  editChange=async(row)=>{   
    const {localization,auth}=this.props; 
    const { data } = await axios.get('/api/company/customer/'+row.id+'/comment');
    console.log(data);
    if(data.success){
      this.setState({  
        customerId:row.id,  
        firstName:row.firstName,
        lastName:row.lastName,
        phone:row.phone,
        gender:row.gender,
        zipCode:row.zipCode,
        comments:data.comment,
        addDialog:true});
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }    
  }  
 
  dia1Close = () => {
    this.setState({ addDialog: false });
  }  
 
  async saveChanges(){
      const {localization,auth}=this.props;     
      
        var { data } = await axios.put('/api/company/customer/comment/'+this.state.commentId, {   
          comment:this.state.comments
         });  
     
   
        if(this.state.comment!=''){
        var { data } = await axios.post('/api/company/customer/'+this.state.customerId+"/comment", {   
          comment:this.state.comment
          });  
        }
      if(data.success){       
        this.props.enqueueSnackbar(localization.localizedString('SAVED_SUCCESS'), { 
          variant: 'success',
        });         
      } 
     else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
      }
      this.setState({ addDialog: false,comment:'' });
  }  
  handleChange = prop => event => this.setState({ [prop]: event.target.value });
  
  table_body=()=>{
    const { classes,localization,auth } = this.props;
    let tbl=[];
    let trs=[];
    if(this.state.payments.length==0){
      return <h4 className={classes.nothing_1}>There is nothing.</h4>
    }

    this.state.payments.map(row => {
      trs.push(<TableRow hover
      key={row.id} >
       <TableCell align='center' className={classes.gray_title}>{row.booking_id}</TableCell>
      <TableCell align='center' className={classes.gray_title}>{row.first_name} {row.last_name}</TableCell>
      <TableCell align='center' className={classes.gray_title}>{row.phone}</TableCell>      
      <TableCell align='center' className={classes.gray_title}>{row.payment_amount}  </TableCell>
      <TableCell align='center' className={classes.gray_title}>{row.total_amount}  </TableCell>
      <TableCell align='center' className={classes.gray_title}>{row.name}</TableCell>
      <TableCell align='center' className={classes.gray_title}>{moment(row.created_on).format('YYYY-MM-DD HH:mm')}</TableCell>   
      <TableCell align='center' className={classes.gray_title}>{moment(row.bcreated_on).format('YYYY-MM-DD HH:mm')}</TableCell>   
    </TableRow>);      
    })

    tbl.push(<Table key={1} className={classes.table}>
      <TableHead >
        <TableRow>   
          <TableCell  className={classes.tableCellId+" "+classes.tableHeader_1}>Booking Id</TableCell>       
          <TableCell  className={classes.tableCell+" "+classes.tableHeader_1}>Customer Name</TableCell>        
          <TableCell  className={classes.tableHeader_1}>Phone</TableCell>         
          <TableCell  className={classes.tableHeader_1}>Upfront Payment</TableCell>
          <TableCell align='center' className={classes.tableHeader_1}>Total Amount</TableCell>
          <TableCell  className={classes.tableHeader_1}>Payment Name</TableCell>
          <TableCell  className={classes.tableHeader_1}>Payment Created Date</TableCell>
          <TableCell  className={classes.tableHeader_1}>Booking Created Date</TableCell>      
        </TableRow>
      </TableHead>
      <TableBody>
     {trs}
      </TableBody>
    </Table>);
    return tbl;    
  }
  render() {
    const { classes,localization} = this.props;
     return(
      <GridContainer>
      <GridItem xs={12} sm={12} md={12}>
        <Card>
          {/**
          <CardHeader color="primary">            
          <GridContainer>
            <GridItem xs={10} sm={10} md={10}>
              <h4 className={classes.cardTitleWhite}>{localization.localizedString('DASHBOARD_NAVBAR_PAYMENT_VIEW_NAME')}</h4>
              <p className={classes.cardCategoryWhite}>             
              </p>
            </GridItem>
            <Grid xs={2} item sm={2} md={2} className={classes.header_2}>                 
            </Grid>
           </GridContainer>            
          </CardHeader>
          */}
          <CardBody className={classes.cardBody_1}>
              {this.table_body()}            
          </CardBody>
        </Card>
      </GridItem>         
      </GridContainer>
     )
   }
}
export default withStyles(paymentsStyle)(withSnackbar(withLocalization(withAuth(Payments))));
