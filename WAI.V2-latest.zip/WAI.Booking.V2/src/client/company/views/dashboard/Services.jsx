import React from 'react';
import ReactDOM from 'react-dom';
import withStyles from '@material-ui/core/styles/withStyles';
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';

import MuiExpansionPanel from '@material-ui/core/ExpansionPanel';
import MuiExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import MuiExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Input from '@material-ui/core/Input';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Edit from "@material-ui/icons/Edit";
import PropTypes from 'prop-types';
import Close from "@material-ui/icons/Close";
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import Create from '@material-ui/icons/AddCircle';
import Grid from '@material-ui/core/Grid';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Select from '@material-ui/core/Select';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import MenuItem from '@material-ui/core/MenuItem';
import ListItemText from '@material-ui/core/ListItemText';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import Toolbar from '@material-ui/core/Toolbar';
import axios from 'axios';
import classNames from 'classnames';
import Success from '@material-ui/icons/CheckCircle';
import {  withSnackbar } from 'notistack';
import Typography from '@material-ui/core/Typography';
import Button from "@material-ui/core/Button";
import DeleteIcon from '@material-ui/icons/Delete';
import DiscountCard from './DiscountCard';
import GiftCard from './GiftCard';
import DiscountCode from './DiscountCode';
import withAuth from '../../../common/contexts/AuthContext';
//import withNotifications from '../../../common/contexts/NotificationsContext';
import GridItem from "../../../common/components/Grid/GridItem.jsx";
import GridContainer from "../../../common/components/Grid/GridContainer.jsx";
import withLocalization from '../../../common/contexts/LocalizationContext';
import Card from "../../../common/components/Card/Card.jsx";
import CardHeader from "../../../common/components/Card/CardHeader.jsx";
import CardBody from "../../../common/components/Card/CardBody.jsx";
import CustomInput from "../../../common/components/CustomInput/CustomInput.jsx";
import CardFooter from "../../../common/components/Card/CardFooter.jsx";
//import Button from "../../../common/components/CustomButtons/Button.jsx";
import servicesStyle from '../../assets/css/services';
//import { domainToASCII } from 'url';

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,     
    },
  },
};

var button_event=false;

class Services extends React.Component {
  constructor(props){
    super (props);
    this.state={
      expanded: 'panel1',
      categoryId:0,
      categories:[],
      services:[],
      employees:[],
      selectRowId:'', //category on panel1
      selectRowId_1:'', // addon chage on panel1    
      selectRowId_2:'',//for employee on panel1
      serviceId:0,// for service table
      selectRowId_3:'',// for addons
      selected_service_category:'',
      serviceSelected:[],
      selected_addons: [],//for service talbe
      selected_categories:[],
      selected_addons_name: [],//for service talbe
      selected_employees:[],// on panel1
      addons:[],
      selected_categoryId:0,//on panel 2
      extra_service_relations:[], 
      employee_service_relations:[],
      serviceDialog:false,
      serivice_state:'Add',
      category_state:'Add',
      service_name:'',
      service_description:'',
      service_gender:'',
      service_duration:'',
      can_vary:false,
      service_price:'',
      weight:0,
      selected_serviceId_2:0,// for addon table
      selected_addons_1:[],// for addon table
      delete_confirm:false,     
      categoryDialog:false,
      default_category:0,
      category_description:'',
      category_name:'',
      extraDialog:false,
      addon_name:'',
      addon_description:'',
      addon_duration:'',    
      addon_price:'',
      addon_gender:'',
      selected_extraId:0 ,
      delete_confirm_1:false,
      create_discount_card_st:false,
      create_gift_card_st:false,
      create_discount_code_st:false,

    };   
  }  
  componentWillMount(){  
    this.load_services();
  } 
  load_services=async()=>{
    const {localization,auth}=this.props;
   const { data } = await axios.get('/api/company/services');  
  
   if(data.success){
      this.setState({
        categories:data.categories,
        services:data.services,
        addons:data.addons,
        employees:data.employees,
        extra_service_relations:data.extra_service_relations,
        employee_service_relations:data.employee_service_relations
      });
   }
   else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
      }
      else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
      }
   }   
  }
  handleChange = prop => event => this.setState({ [prop]: event.target.value });
  handleChange_1 = panel => (event, expanded) => {
    if(button_event)
     return;
    this.setState({
      expanded: expanded ? panel : false,     
    });
  };
  categoryChange=async (event,rid)=>{    // in service table category dropdown change
    const {localization,auth}=this.props;
    this.setState({categoryId:event.target.value,selectRowId:rid});   
    var { data } = await axios.put('/api/company/service/'+rid, {
      service:{ 
      serviceCategoryId:event.target.value
      }
    });   
    
    if(!data.success){
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    } 
    this.load_services();
  }
  
  handleAddonChange = async(event,rid) => {
    this.setState({ selected_addons: event.target.value,selectRowId_1:rid });
    
    var temp=[];
    var temp_target_value=[];
    temp_target_value=event.target.value;
  
    this.state.addons.map(row=>{
        if(temp_target_value.indexOf(row.name)!=-1){
          temp.push(row.id);
        }
    });
    
    var { data } = await axios.post('/api/company/service_extra_relations', {
      relations:{ 
              extraIds:temp,
              serviceId:rid
              }
      });
      if(!data.success){
        if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
          this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
            variant: 'error',
          }); 
          await auth.get();       
         }
         else{        
          this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
            variant: 'error',
          }); 
         }
      } 
      this.load_services();
   };

   handleEmployeeChange= async(event,rid) => {
    this.setState({ selected_employees: event.target.value,selectRowId_2:rid });    
    var temp=[];
    var temp_target_value=[];
    temp_target_value=event.target.value;
  console.log(temp_target_value);
    this.state.employees.map(row=>{
        if(temp_target_value.indexOf(row.firstName+" "+row.lastName)!=-1){
          temp.push(row.id);
        }
    });  
  
 
    var { data } = await axios.post('/api/company/employee_extra_relations', {
      relations:{ 
              employeeIds:temp,
              serviceId:rid
        }
      });
      if(!data.success){
        if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
          this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
            variant: 'error',
          }); 
          await auth.get();       
         }
         else{        
          this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
            variant: 'error',
          }); 
         }
      } 
      this.load_services();
   };

  serviceChangeforAddon=(event,rid)=>{ // in addon table
    this.setState({selected_serviceId_2:event.target.value,selectRowId_2:rid});
  }
  serviceClick= (id) => {
    const { serviceSelected } = this.state;
    const selectedIndex = serviceSelected.indexOf(id);
    let newSelected = [];
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(serviceSelected, id);
    } 
    else if (selectedIndex === 0) {
      newSelected = newSelected.concat(serviceSelected.slice(1));
    } else if (selectedIndex === serviceSelected.length - 1) {
      newSelected = newSelected.concat(serviceSelected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        serviceSelected.slice(0, selectedIndex),
        serviceSelected.slice(selectedIndex + 1),
      );
    }
    this.setState({ serviceSelected: newSelected, });
  }

  categoryClick= (id) => {
    const { selected_categories } = this.state;
    const selectedIndex = selected_categories.indexOf(id);
    let newSelected = [];
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected_categories, id);
    } 
    else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected_categories.slice(1));
    } else if (selectedIndex === selected_categories.length - 1) {
      newSelected = newSelected.concat(selected_categories.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected_categories.slice(0, selectedIndex),
        selected_categories.slice(selectedIndex + 1),
      );
    }
    this.setState({ selected_categories: newSelected, });
  }

  addonClick= (id) => {
    const { selected_addons_1 } = this.state;
    const selectedIndex = selected_addons_1.indexOf(id);
    let newSelected = [];
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected_addons_1, id);
    } 
    else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected_addons_1.slice(1));
    } else if (selectedIndex === selected_addons_1.length - 1) {
      newSelected = newSelected.concat(selected_addons_1.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected_addons_1.slice(0, selectedIndex),
        selected_addons_1.slice(selectedIndex + 1),
      );
    }
    this.setState({ selected_addons_1: newSelected, });
  }

  headCheck=(event)=>{
    let temp=[];
    if(event.target.checked){
      this.state.services.map(row=>{
        temp.push(row.id);
      })
    } 
    this.setState({serviceSelected:temp});
  }
  headCheck_1=(event)=>{
    let temp=[];
    if(event.target.checked){
      this.state.categories.map(row=>{
        temp.push(row.id);
      })
    } 
    this.setState({selected_categories:temp});
  }
  headCheck_2=(event)=>{// for addon panel
    let temp=[];
    if(event.target.checked){
      this.state.addons.map(row=>{
        temp.push(row.id);
      })
    } 
    this.setState({selected_addons_1 :temp});
  }

  getAddonByService=(sid)=>{   
    let temp=[];
    this.state.extra_service_relations.map(row=>{
      if(row.serviceId==sid){
         this.state.addons.map(item=>{
           if(item.id==row.extraId){
            temp.push(item.name);
           }
         })
       
      }
    })   
    return  temp;    
  }
  getEmployeeByService=(sid)=>{
    let temp=[];
    this.state.employee_service_relations.map(row=>{
      if(row.serviceId==sid){
         this.state.employees.map(item=>{
           if(item.id==row.employeeId){
            temp.push(item.firstName+" "+item.lastName);
           }
         })
       
      }
    })   
    return  temp;
  }

  getServiceByAddon=(eid)=>{
    let temp=[];

    this.state.extra_service_relations.map(row=>{
      if(row.extraId==eid){
         this.state.services.map(item=>{
           if(item.id==row.serviceId){
            temp.push(item.name);
           }
         })       
      }
    })

    return  temp;
  }
  createService=()=>{
    button_event=true;
    setTimeout(() => {
      button_event=false;
    }, 1000);
      this.setState({
        serviceDialog:true,
        serivice_state:'Add',
        selected_service_category:'',
        service_name:'',
        service_description:'',
        service_gender:'',
        service_duration:'',
        service_price:'',
        weight:'',
        can_vary:false,
        expanded:'panel1'
      })
  }
  editServiceChange=(row)=>{
    this.setState({
      serviceDialog:true,
      serivice_state:'Update',
      selected_service_category:row.serviceCategoryId,
      service_name:row.name,
      service_description:row.description,
      service_price:row.price,
      service_gender:row.gender,
      service_duration:row.duration,
      serviceId:row.id,
      weight:row.weight,
      can_vary:row.vary?true:false
    })
  }

  closeDialog=()=>{   
    this.setState({ serviceDialog: false,
      categoryDialog:false,
      extraDialog:false,
      create_discount_card_st:false,
      create_gift_card_st:false,
      create_discount_code_st:false
    
    });
  }
  
  createExtra=()=>{
    button_event=true;
    setTimeout(() => {
      button_event=false;
    }, 1000);
    this.setState({
      extraDialog:true,
      extra_state:'Add',   
      addon_name:'',
      addon_description:'',
      addon_duration:'',
      can_vary:false,
      addon_price:'',
      addon_gender:'',   
      expanded:'panel3'
    })
  }

  editAddonChange=(row)=>{    
    this.setState({
      extraDialog:true,
      extra_state:'Update',   
      addon_name:row.name,
      addon_description:row.description,
      addon_duration:row.duration,
      can_vary:row.vary?true:false,
      addon_price:row.price,
      addon_gender:row.gender,   
      expanded:'panel3',
      selected_extraId:row.id
    })
  }

  handleToggle = prop => event => this.setState({ [prop]: event.target.checked });

  serviceGenderChange=(event)=>{
    this.setState({
      [event.target.name]: event.target.value,
    });
  }
  
  saveService=async()=>{
    const {localization,auth}=this.props;    
   if(this.state.serivice_state=='Add'){
     var { data } = await axios.post('/api/company/service', {
       service:{ serviceCategoryId:this.state.selected_service_category,
       name:this.state.service_name,
       description:this.state.service_description,
       price:this.state.service_price,
       duration:this.state.service_duration,
       vary:this.state.can_vary,
       weight:this.state.weight,
       gender:this.state.service_gender}
     }); 

     if(data.success){       
       this.props.enqueueSnackbar(localization.localizedString('ADDED_SUCCESS'), { 
         variant: 'success',
       });     
       this.load_services();
       this.setState({serviceDialog:false});
     }
     else{
       if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
         this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
           variant: 'error',
         }); 
         await auth.get();       
        }
        else{        
         this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
           variant: 'error',
         }); 
        }
     }
    
   }
   else{
     var { data } = await axios.put('/api/company/service/'+this.state.serviceId, {
       service:{ 
       serviceCategoryId:this.state.selected_service_category,
       name:this.state.service_name,
       description:this.state.service_description,
       price:this.state.service_price,
       duration:this.state.service_duration,
       vary:this.state.can_vary,
       weight:this.state.weight,
       gender:this.state.service_gender}
     });    
       if(data.success){
         this.props.enqueueSnackbar(localization.localizedString('UPDATED_SUCCESS'), { 
           variant: 'success',
         });    
         this.load_services();
         this.setState({serviceDialog:false});
       }
       else{
         if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
           this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
             variant: 'error',
           }); 
           await auth.get();       
          }
          else{        
           this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
             variant: 'error',
           }); 
          }
       }  
    }    
   }

   saveAddons=async()=>{
    const {localization,auth}=this.props;  
      if(this.state.extra_state=='Add'){
        var { data } = await axios.post('/api/company/service/extra', {
          extra:{          
          name:this.state.addon_name,
          description:this.state.addon_description,
          price:this.state.addon_price,
          duration:this.state.addon_duration,
          vary:this.state.can_vary,
          gender:this.state.addon_gender}
        });

        if(data.success){
          this.props.enqueueSnackbar(localization.localizedString('ADDED_SUCCESS'), { 
            variant: 'success',
          });      
          this.setState({extraDialog:false}) ;
          this.load_services();
        }
        else{
          if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
            this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
              variant: 'error',
            }); 
            await auth.get();       
          }
          else{        
            this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
              variant: 'error',
            }); 
          }
        }
      }
      else if(this.state.extra_state=='Update'){

        var { data } = await axios.put('/api/company/service/extra/'+this.state.selected_extraId, {
          extra:{         
          name:this.state.addon_name,
          description:this.state.addon_description,
          price:this.state.addon_price,
          duration:this.state.addon_duration,
          vary:this.state.can_vary,
          gender:this.state.addon_gender}
        });
        if(data.success){         
          this.props.enqueueSnackbar(localization.localizedString('UPDATED_SUCCESS'), { 
            variant: 'success',
          });    
          this.setState({extraDialog:false}) ;
          this.load_services();
        }
        else{
          if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
            this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
              variant: 'error',
            }); 
            await auth.get();       
           }
           else{        
            this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
              variant: 'error',
            }); 
           }
        }
      }
   }

   creatCategory=()=>{
    button_event=true;
    setTimeout(() => {
      button_event=false;
    }, 1000);
 
      this.setState({
        category_name:'',
        category_state:'Add',
        description:'',
        default_category:0,
        categoryDialog:true,
        expanded:'panel2'
      })
  }
  editCategoryChange=(row)=>{
    console.log(row);
    this.setState({
      selected_categoryId:row.id,
      categoryDialog:true,
      category_state:'Update',
      category_description:row.description,
      category_name:row.name,
      default_category:row.defaultServiceCategory,
    })
  }

   saveCategory=async()=>{
    const {localization,auth}=this.props;  
    if(this.state.category_state=='Add'){
        var { data } = await axios.post('/api/company/service/category', {     
          name: this.state.category_name,
          defaultServiceCategory:this.state.default_category,
          description:this.state.category_description
        }); 
        if(data.success){       
          this.props.enqueueSnackbar(localization.localizedString('ADDED_SUCCESS'), { 
            variant: 'success',
          });     
          this.load_services();
          this.setState({ categoryDialog:false}); 
        }
        else{
          if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
            this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
              variant: 'error',
            }); 
            await auth.get();       
           }
           else{        
            this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
              variant: 'error',
            }); 
           }
        }
    }
    else if(this.state.category_state=='Update'){
      var { data } = await axios.put('/api/company/service/category/'+this.state.selected_categoryId, {     
        name: this.state.category_name,
        defaultServiceCategory:this.state.default_category,
        description:this.state.category_description
      });
      if(data.success){       
        this.props.enqueueSnackbar(localization.localizedString('ADDED_SUCCESS'), { 
          variant: 'success',
        });     
        this.load_services();
        this.setState({ categoryDialog:false}); 
      }
      else{
        if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
          this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
            variant: 'error',
          }); 
          await auth.get();       
         }
         else{        
          this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
            variant: 'error',
          }); 
         }
      }
  }

   };

  serviceDelete= () => {      
    this.setState({delete_confirm:true,});
    return;     
  } 

  allItemsDelete= () => {    
    button_event=true;
    setTimeout(() => {
      button_event=false;
    }, 1000);  
    this.setState({delete_confirm_1:true,});   
  } 

  extraDelete= () => {      
    this.setState({delete_confirm:true,});
    return;     
  } 
  confirmDialogClose=async()=>{
    this.setState({ delete_confirm: false,delete_confirm_1:false });
  }

  delete_process=async()=>{
    var data;
    const {localization,auth}=this.props;   
    if(this.state.expanded=="panel1"){     
        var { data } = await axios.delete('/api/company/service/'+this.state.serviceId); 
    }
    else if(this.state.expanded=="panel2"){
       var { data } = await axios.delete('/api/company/service/category/'+this.state.selected_categoryId);
    }
    else if(this.state.expanded=="panel3"){
      var { data } = await axios.delete('/api/company/service/extra/'+this.state.selected_extraId);
   }

    if(data.success){
      this.props.enqueueSnackbar(localization.localizedString('DELETED_SUCCESS'), { 
        variant: 'success',
      });       
      this.load_services();
    }
    else{
      if(data.errorCode==2 || data.errorCode==3 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
      this.setState({delete_confirm:false,
        serviceDialog:false,
        categoryDialog:false,
        extraDialog:false        
      }); 
  }

  delete_process_1=async()=>{
    var data;
    const {localization,auth}=this.props;      
    
    if(this.state.expanded=="panel1"){     
        var { data } = await axios.post('/api/company/allservice',{deleteService:this.state.serviceSelected});
    }
    else if(this.state.expanded=="panel2"){
       var { data } = await axios.post('/api/company/service/allcategory',{deleteCategoris:this.state.selected_categories});
    }
    else if(this.state.expanded=="panel3"){
      var { data } = await axios.post('/api/company/service/allextra',{deleteExtras:this.state.selected_addons_1});
   }

    if(data.success){
      this.props.enqueueSnackbar(localization.localizedString('DELETED_SUCCESS'), { 
        variant: 'success',
      }); 
      this.setState({serviceSelected:[],selected_categories:[],selected_addons_1:[]});
      this.load_services();
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
      this.setState({delete_confirm_1:false,
        serviceDialog:false,
        categoryDialog:false,
        extraDialog:false
        
      }); 
  }
  createDiscountCard=()=>{
    button_event=true;
    setTimeout(() => {
      button_event=false;
    }, 1000);    
    this.setState({create_discount_card_st:true,expanded:'panel4'})
  }
  createGiftCard=()=>{
    button_event=true;
    setTimeout(() => {
      button_event=false;
    }, 1000);    
    this.setState({create_gift_card_st:true,expanded:'panel5'})
  }
  createDiscountCode=()=>{
    button_event=true;
    setTimeout(() => {
      button_event=false;
    }, 1000);    
    this.setState({create_discount_code_st:true,expanded:'panel6'})
  }
  isSelected = id => this.state.serviceSelected.indexOf(id) !== -1;
  isSelected_1 = id => this.state.selected_categories.indexOf(id) !== -1;
  isSelected_2 = id => this.state.selected_addons_1.indexOf(id) !== -1;
  render(){
    const { classes,localization,auth } = this.props;
    const {expanded, categories, services, selectRowId,selectRowId_2 ,
       categoryId, serviceSelected,selected_serviceId_2,
        addons,selected_addons,selectRowId_1,selected_categories,
        selected_addons_1,employees,selectRowId_3,selected_employees}=this.state;  
     
    var service_title="SERVICES";
     if(serviceSelected.length>0 && serviceSelected.length==1){
        service_title=serviceSelected.length+" SELECTED SERVICE";
     }
     else if(serviceSelected.length>1){
      service_title=serviceSelected.length+" SELECTED SERVICES";
     }

     var service_category_title="SERVICE CATEGORIES";
      if(selected_categories.length>0 && selected_categories.length==1){
        service_category_title=selected_categories.length+" SELECTED SERVICE CATEGORY";
      }
      else if(selected_categories.length>1){
        service_category_title=selected_categories.length+" SELECTED SERVICE CATEGORIES";
      }

      var addon_tile="SERVICE ADDONS";
      if(selected_addons_1.length>0 && selected_addons_1.length==1){
        addon_tile=selected_addons_1.length+" SELECTED SERVICE ADDON";
      }
      else if(selected_addons_1.length>1){
        addon_tile=selected_addons_1.length+" SELECTED SERVICE ADDONS";
      }
     
     return(
      <GridContainer>
      <GridItem xs={12} sm={12} md={12}>
        <Card>
          <CardBody className={classes.cardBody_1}>
          <GridContainer>          
              <GridItem xs={12} sm={12} md={12}>
              <ExpansionPanel
                  square
                  expanded={expanded === 'panel1'}
                  onChange={this.handleChange_1('panel1')}
              >
                <ExpansionPanelSummary className={serviceSelected.length>0?classes.summary_2:null}>              
                  
                    <Grid xs={10} item sm={10} md={10} className={classes.grid_title}>
                      <Typography variant="subtitle1" className={serviceSelected.length>0?classes.title_4:classes.title_3}>{service_title}</Typography>
                      <Typography variant="subtitle1" color="secondary" className={classes.selectedLabel}></Typography>
                    </Grid>
                    <Grid xs={2} item sm={2} md={2} className={classes.header_2}>
                    {serviceSelected.length > 0 ? (
                        <Tooltip title="Delete">
                          <IconButton aria-label="Delete"
                          onClick={this.allItemsDelete}
                          >
                            <DeleteIcon />
                          </IconButton>
                        </Tooltip>
                      ) : (
                        <Tooltip title="Filter list">
                          <IconButton
                          aria-label="Filter list"
                          onClick={this.createService}
                          >
                            <Create />
                          </IconButton>
                        </Tooltip>
                      )}                       
                        
                    </Grid>
                  
                </ExpansionPanelSummary>
                <ExpansionPanelDetails>
                  <div className={classes.cardBody_1}>                 
                    <Table className={classes.table} aria-labelledby="tableTitle">
                       <TableHead>                          
                          <TableRow>
                            <TableCell padding="checkbox">
                              <Checkbox
                                indeterminate={serviceSelected.length>0 && serviceSelected.length<services.length}
                                checked={serviceSelected.length==services.length && serviceSelected.length>0}        
                                onClick={this.headCheck}                       
                              />
                            </TableCell>
                            <TableCell   className={classes.dark_title}>
                              Service Name
                            </TableCell>
                            <TableCell className={classes.dark_title}>
                              Category
                            </TableCell>
                            <TableCell className={classes.dark_title}>
                              Extra Services
                            </TableCell>
                            <TableCell className={classes.dark_title}>
                             Employee
                            </TableCell>
                            <TableCell className={classes.dark_title}>
                              Price{"("+auth.user.currency_code+")"}
                            </TableCell>
                            <TableCell className={classes.dark_title}>
                              Duration(minutes)
                            </TableCell>
                            <TableCell className={classes.dark_title}>
                              Weight
                            </TableCell>
                            <TableCell className={classes.dark_title}>
                              Description
                            </TableCell>
                            <TableCell className={classes.dark_title}>
                              Edit
                            </TableCell>
                          </TableRow>
                        </TableHead>    
                        <TableBody>
                        {services.map(row=>{
                            return <TableRow key={row.id}>
                                    <TableCell padding="checkbox">
                                      <Checkbox checked={this.isSelected(row.id)} 
                                          onClick={()=>this.serviceClick(row.id)}
                                      />
                                    </TableCell>
                                    <TableCell className={classes.gray_title}> {row.name}</TableCell>
                                    <TableCell className={classes.gray_title} > 
                                    
                                    <FormControl className={classes.formControl_3 }>                                
                                      <Select       
                                        disableUnderline                                                                
                                        value={selectRowId!=row.id?row.serviceCategoryId:categoryId}
                                        onChange={(event)=>this.categoryChange(event,row.id)}
                                        inputProps={{
                                          name: 'categoryId',
                                          id: 'categoryId',
                                          className:classes.select_font
                                        }}
                                      >        
                                      {
                                        categories.map(item=>{
                                            return <MenuItem  key={item.id} value={item.id}> {item.name} </MenuItem >
                                        })
                                        }                             
                                        
                                      </Select>
                                    </FormControl>
                                  </TableCell> 
                                  <TableCell className={classes.gray_title}>
                                    <FormControl className={classes.formControl_2}>                                       
                                        <Select
                                          multiple
                                          disableUnderline
                                          value={selectRowId_1!=row.id?this.getAddonByService(row.id):selected_addons} 
                                          onChange={(event)=>this.handleAddonChange(event,row.id)}
                                          input={<Input id="select-multiple-checkbox" className={classes.select_font} />}
                                          renderValue={selected => selected.join(', ')}
                                          MenuProps={MenuProps}                                         
                                        >
                                          {addons.map(addon => (
                                            <MenuItem key={addon.id} value={addon.name}>
                                              <Checkbox checked={selectRowId_1!=row.id?this.getAddonByService(row.id).indexOf(addon.name) > -1:selected_addons.indexOf(addon.name) > -1} />
                                              <ListItemText primary={addon.name} />
                                            </MenuItem>
                                          ))}
                                        </Select>
                                      </FormControl>
                                  </TableCell>
                                  <TableCell>
                                      <FormControl className={classes.formControl_2}>                                       
                                        <Select
                                          multiple
                                          disableUnderline
                                          value={selectRowId_2!=row.id?this.getEmployeeByService(row.id):selected_employees} 
                                          onChange={(event)=>this.handleEmployeeChange(event,row.id)}
                                          input={<Input id="select-multiple-checkbox"  className={classes.select_font}/>}
                                          renderValue={selected => selected.join(', ')}
                                          MenuProps={MenuProps}
                                         
                                        >
                                          {employees.map(employee => (
                                            <MenuItem key={employee.id} value={employee.firstName+" "+employee.lastName}>
                                              <Checkbox checked={selectRowId_2!=row.id?this.getEmployeeByService(row.id).indexOf(employee.firstName+" "+employee.lastName) > -1:selected_employees.indexOf(employee.firstName+" "+employee.lastName) > -1} />
                                              <ListItemText primary={employee.firstName+" "+employee.lastName} />
                                            </MenuItem>
                                          ))}
                                        </Select>
                                      </FormControl>
                                  </TableCell>
                                  <TableCell align="right"  className={classes.gray_title}>
                                    {row.price}
                                  </TableCell>                                 
                                  <TableCell align="right" className={classes.gray_title}>
                                    {row.duration}
                                  </TableCell>
                                  <TableCell align="right"  className={classes.gray_title}>
                                    {row.weight}
                                  </TableCell>
                                  <TableCell  className={classes.gray_title}>
                                   {row.description}
                                  </TableCell>
                                  <TableCell  className={classes.tableCellId}>
                                        <Tooltip
                                          id="tooltip-top"
                                          title="Edit Service"
                                          placement="top"
                                          classes={{ tooltip: classes.tooltip }}
                                        >
                                          <IconButton
                                            aria-label="Edit"                                            
                                            onClick={() =>(this.editServiceChange(row))}
                                            
                                          >
                                            <Edit
                                              className={
                                                classes.tableActionButtonIcon + " " + classes.edit
                                              }
                                            />
                                          </IconButton>
                                        </Tooltip>
                                  </TableCell>
                                </TableRow>
                        })}
                        </TableBody>                  
                    </Table>
                  </div>
                </ExpansionPanelDetails>
              </ExpansionPanel>
              <ExpansionPanel
                  square
                  expanded={expanded === 'panel2'}
                  onChange={this.handleChange_1('panel2')}
              >
                <ExpansionPanelSummary>
                    <Grid xs={10} item sm={10} md={10} className={classes.grid_title}>
                          <Typography variant="subtitle1" className={selected_categories.length>0?classes.title_4:classes.title_3}>{service_category_title}</Typography>
                          <Typography variant="subtitle1" color="secondary" className={classes.selectedLabel}></Typography>
                     </Grid>
                     <Grid xs={2} item sm={2} md={2} className={classes.header_2}>
                        {selected_categories.length > 0 ? (
                            <Tooltip title="Delete">
                              <IconButton aria-label="Delete"
                              onClick={this.allItemsDelete}
                              >
                                <DeleteIcon />
                              </IconButton>
                            </Tooltip>
                          ) : (
                            <Tooltip title="Filter list">
                              <IconButton
                              aria-label="Filter list"
                              onClick={this.creatCategory}
                              >
                                <Create />
                              </IconButton>
                            </Tooltip>
                          )}
                      </Grid>
                </ExpansionPanelSummary>
                <ExpansionPanelDetails>
                  <div className={classes.cardBody_1}>                 
                    <Table className={classes.table} aria-labelledby="tableTitle">
                       <TableHead>                          
                          <TableRow>
                            <TableCell padding="checkbox">
                              <Checkbox
                                indeterminate={selected_categories.length>0 && selected_categories.length<categories.length}
                                checked={selected_categories.length==categories.length && categories.length>0}        
                                onClick={this.headCheck_1}                       
                              />
                            </TableCell>
                            <TableCell component="th"  className={classes.dark_title}>
                              Service Category Name
                            </TableCell>
                            <TableCell className={classes.dark_title}>
                              Description
                            </TableCell>
                            <TableCell className={classes.dark_title}>
                              Default Service Category
                            </TableCell>                           
                            <TableCell className={classes.dark_title}>
                              Edit
                            </TableCell>
                          </TableRow>
                        </TableHead>    
                        <TableBody>  
                        {
                            categories.map(row=>{
                             return <TableRow key={row.id}>
                               <TableCell padding="checkbox">  
                                   <Checkbox checked={this.isSelected_1(row.id)} 
                                          onClick={()=>this.categoryClick(row.id)}
                                   />                                 
                               </TableCell>
                               <TableCell className={classes.gray_title}>     
                                    {row.name}                         
                               </TableCell>
                               <TableCell className={classes.gray_title}>   
                                  {row.description}                         
                               </TableCell>
                               <TableCell className={classes.gray_title} > 
                                  {row.defaultServiceCategory?"True":"False"}                            
                               </TableCell>
                               <TableCell  className={classes.tableCellId}>
                                        <Tooltip
                                          id="tooltip-top"
                                          title="Edit Service"
                                          placement="top"
                                          classes={{ tooltip: classes.tooltip }}
                                        >
                                          <IconButton
                                            aria-label="Edit"                                            
                                            onClick={() =>(this.editCategoryChange(row))}
                                            
                                          >
                                            <Edit
                                              className={
                                                classes.tableActionButtonIcon + " " + classes.edit
                                              }
                                            />
                                          </IconButton>
                                        </Tooltip>
                                  </TableCell>
                             </TableRow>
                            })
                        }
                          
                        </TableBody>
                        </Table>
                      </div>    
                </ExpansionPanelDetails>
              </ExpansionPanel>
              <ExpansionPanel
                  square
                  expanded={expanded === 'panel3'}
                  onChange={this.handleChange_1('panel3')}
              >
                <ExpansionPanelSummary>
                    <Grid xs={10} item sm={10} md={10} className={classes.grid_title}>
                          <Typography variant="subtitle1" className={selected_addons_1.length>0?classes.title_4:classes.title_3}>{addon_tile}</Typography>
                          <Typography variant="subtitle1" color="secondary" className={classes.selectedLabel}></Typography>
                     </Grid>
                     <Grid xs={2} item sm={2} md={2} className={classes.header_2}>
                        {selected_addons_1.length > 0 ? (
                            <Tooltip title="Delete">
                              <IconButton aria-label="Delete"
                               onClick={this.allItemsDelete}
                              >
                                <DeleteIcon />
                              </IconButton>
                            </Tooltip>
                          ) : (
                            <Tooltip title="Filter list">
                              <IconButton
                              aria-label="Filter list"
                              onClick={this.createExtra}
                              >
                                <Create />
                              </IconButton>
                            </Tooltip>
                          )}
                      </Grid>
                </ExpansionPanelSummary>
                <ExpansionPanelDetails>
                 <div className={classes.cardBody_1}>                 
                    <Table className={classes.table} aria-labelledby="tableTitle">
                       <TableHead>                          
                          <TableRow>
                            <TableCell padding="checkbox">
                              <Checkbox
                                indeterminate={selected_addons_1.length>0 && selected_addons_1.length<addons.length}
                                checked={selected_addons_1.length==addons.length && addons.length>0}        
                                onClick={this.headCheck_2}                       
                              />
                            </TableCell>
                            <TableCell component="th"  className={classes.dark_title}>
                              Service Addon Name
                            </TableCell>
                            {/**
                               <TableCell className={classes.dark_title}>
                              Service Name
                            </TableCell>
                             */
                            }                         

                            <TableCell className={classes.dark_title}>
                              Price{"("+auth.user.currency_code+")"}
                            </TableCell>
                            <TableCell className={classes.dark_title}>
                              Duration (minutes)
                            </TableCell>
                            <TableCell className={classes.dark_title}>
                              Description
                            </TableCell>                                                     
                            <TableCell className={classes.dark_title}>
                              Edit
                            </TableCell>
                          </TableRow>
                        </TableHead>    
                        <TableBody>  
                        {
                            addons.map(row=>{
                              return <TableRow key={row.id}>
                                    <TableCell padding="checkbox">
                                      <Checkbox checked={this.isSelected_2(row.id)} 
                                          onClick={()=>this.addonClick(row.id)}
                                      />
                                    </TableCell>
                                    <TableCell className={classes.gray_title}> {row.name}</TableCell>
                                  {/*
                                  <TableCell> 
                                    <FormControl className={classes.formControl_2}>                                       
                                        <Select
                                          multiple
                                          disableUnderline
                                          value={selectRowId_3!=row.id?this.getServiceByAddon(row.id):selected_employees} 
                                          onChange={(event)=>this.handleEmployeeChange(event,row.id)}
                                          input={<Input id="select-multiple-checkbox" />}
                                          renderValue={selected => selected.join(', ')}
                                          MenuProps={MenuProps}
                                          className={classes.gray_title}
                                        >
                                          {services.map(service => (
                                            <MenuItem key={service.id} value={service.name}>
                                              <Checkbox checked={selectRowId_3!=row.id?this.getServiceByAddon(row.id).indexOf(service.name) > -1:selected_employees.indexOf(service.name) > -1} />
                                              <ListItemText primary={service.name} />
                                            </MenuItem>
                                          ))}
                                        </Select>
                                      </FormControl>
                                  </TableCell> 
                                  */}
                                  
                                 
                                  <TableCell   className={classes.gray_title}>
                                    {row.price}
                                  </TableCell>
                                  <TableCell  className={classes.gray_title}>
                                    {row.duration}
                                  </TableCell>
                                  <TableCell  className={classes.gray_title}>
                                   {row.description}
                                  </TableCell>
                                  <TableCell  className={classes.tableCellId}>
                                        <Tooltip
                                          id="tooltip-top"
                                          title="Edit Service Extra"
                                          placement="top"
                                          classes={{ tooltip: classes.tooltip }}
                                        >
                                          <IconButton
                                            aria-label="Edit"                                            
                                            onClick={() =>(this.editAddonChange(row))}
                                            
                                          >
                                            <Edit
                                              className={
                                                classes.tableActionButtonIcon + " " + classes.edit
                                              }
                                            />
                                          </IconButton>
                                        </Tooltip>
                                  </TableCell>
                                </TableRow>
                            })
                        }
                       </TableBody>
                     </Table>
                  </div>            
                </ExpansionPanelDetails>
              </ExpansionPanel>
            
              <ExpansionPanel
                square
                expanded={expanded === 'panel4'}
                onChange={this.handleChange_1('panel4')}
              >
              
               <ExpansionPanelSummary >
                    <Grid xs={10} item sm={10} md={10} className={classes.grid_title}>
                      <Typography variant="subtitle1" className={classes.title_3} >Discount Card</Typography>                     
                    </Grid>
                    <Grid xs={2} item sm={2} md={2} className={classes.header_2}>    
                          <Tooltip title="Filter list">
                              <IconButton
                              aria-label="Filter list"
                              onClick={this.createDiscountCard}
                              >
                                <Create />
                              </IconButton>
                            </Tooltip>                   
                    </Grid>
               </ExpansionPanelSummary>
                <ExpansionPanelDetails>
                  <div className={classes.cardBody_12}>
                      <DiscountCard
                       createState={this.state.create_discount_card_st}
                       closeCardState={this.closeDialog}              
                      ></DiscountCard>
                  </div>
                </ExpansionPanelDetails> 
              </ExpansionPanel>

              <ExpansionPanel
                square
                expanded={expanded === 'panel5'}
                onChange={this.handleChange_1('panel5')}
              >
              
               <ExpansionPanelSummary >
                    <Grid xs={10} item sm={10} md={10} className={classes.grid_title}>
                      <Typography variant="subtitle1" className={classes.title_3} >Gift Card</Typography>                     
                    </Grid>
                    <Grid xs={2} item sm={2} md={2} className={classes.header_2}>    
                          <Tooltip title="Filter list">
                              <IconButton
                              aria-label="Filter list"
                              onClick={this.createGiftCard}
                              >
                                <Create />
                              </IconButton>
                            </Tooltip>                   
                    </Grid>
               </ExpansionPanelSummary>
                <ExpansionPanelDetails>
                  <div className={classes.cardBody_12}>
                      <GiftCard
                       createState={this.state.create_gift_card_st}
                       closeCardState={this.closeDialog}              
                      ></GiftCard>
                  </div>
                </ExpansionPanelDetails> 
              </ExpansionPanel>

              <ExpansionPanel
                square
                expanded={expanded === 'panel6'}
                onChange={this.handleChange_1('panel6')}
              >
              
               <ExpansionPanelSummary >
                    <Grid xs={10} item sm={10} md={10} className={classes.grid_title}>
                      <Typography variant="subtitle1" className={classes.title_3} >Discount Code</Typography>                     
                    </Grid>
                    <Grid xs={2} item sm={2} md={2} className={classes.header_2}>    
                          <Tooltip title="Filter list">
                              <IconButton
                              aria-label="Filter list"
                              onClick={this.createDiscountCode}
                              >
                                <Create />
                              </IconButton>
                            </Tooltip>                   
                    </Grid>
               </ExpansionPanelSummary>
                <ExpansionPanelDetails>
                  <div className={classes.cardBody_12}>
                      <DiscountCode
                       createState={this.state.create_discount_code_st}
                       closeCardState={this.closeDialog}              
                      ></DiscountCode>
                  </div>
                </ExpansionPanelDetails> 
              </ExpansionPanel>
           
              </GridItem>            
           </GridContainer>          
          </CardBody>
        </Card>
      </GridItem>  
          {/** for services */}
      <Dialog
          fullWidth={true}
          maxWidth={'sm'}
          open={this.state.serviceDialog}
          onClose={this.closeDialog}
          aria-labelledby="max-width-dialog-title"         
        >      
          <DialogTitle id="simple-dialog-title" className={classes.dialog_title}>{this.state.serivice_state} Service</DialogTitle>   
          <DialogContent className={classes.dialog_2}>           
                <Grid container className={classes.dialog_3} justify={'center'}>
                    <GridItem xs={12} sm={12} md={11}>
                       <FormControl className={classes.formControl_6}>
                              <InputLabel htmlFor="age-simple">Service Category</InputLabel>
                              <Select
                                value={this.state.selected_service_category}
                                onChange={this.serviceGenderChange}
                                inputProps={{
                                  name: 'selected_service_category',
                                  id: 'selected_service_category',
                                  
                                }}
                              >
                                <MenuItem value="">
                                  <em>None</em>
                                </MenuItem>
                                {
                                  categories.map(row=>{
                                    return <MenuItem key={row.id} value={row.id}>{row.name}</MenuItem>
                                  })
                                }                                      
                              </Select>
                        </FormControl>
                    </GridItem> 

                    <GridItem xs={12} sm={12} md={11}>
                      <CustomInput                        
                        labelText="Service Name"                        
                        inputProps={{
                          value:this.state.service_name,
                        }}
                        formControlProps={{
                          required: true,
                          fullWidth: true,                         
                          value:this.state.service_name,
                          onChange: this.handleChange('service_name')
                        }}
                      />
                    </GridItem>
                    <GridItem xs={12} sm={12} md={11}>
                      <CustomInput
                        labelText="Description"                        
                        inputProps={{
                          value:this.state.service_description,
                          multiline: true,
                          rows: 3
                        }}
                        formControlProps={{                         
                          fullWidth: true,                         
                          value:this.state.service_description,
                          onChange: this.handleChange('service_description')
                        }}
                      />
                    </GridItem>
                   
                      <GridItem xs={12} sm={12} md={11}>                      
                          <CustomInput
                                labelText="Duration (minutes)"                        
                                inputProps={{
                                  value:this.state.service_duration,
                                }}
                                formControlProps={{
                                  required: true,
                                  fullWidth: true,                         
                                  value:this.state.service_duration,
                                  onChange: this.handleChange('service_duration')
                                }}
                              />
                          </GridItem>
                          <Grid item xs={12} sm={12} md={11} style={{margin:'auto'}} className={classes.canvary_1}>
                                  <FormControlLabel
                                      control={(
                                        <Checkbox
                                          tabIndex={-1}
                                          disableRipple       
                                          onClick={this.handleToggle('can_vary')}                      
                                          checked={this.state.can_vary}
                                        />
                                      )}
                                      classes={{ label: classes.label }}
                                      label={"Duration can vary"}
                                    />
                              </Grid>
                            <GridItem xs={12} sm={12} md={11}>
                            <CustomInput
                              labelText={"Price ("+auth.user.currency_code+")" }                 
                              inputProps={{
                                value:this.state.service_price,
                              }}
                              formControlProps={{
                                required: true,
                                fullWidth: true,                         
                                value:this.state.service_price,
                                onChange: this.handleChange('service_price')
                              }}
                            />
                          </GridItem>   

                          <GridItem xs={12} sm={12} md={11}>
                            <CustomInput
                              labelText={"Weight" }                 
                              inputProps={{
                                value:this.state.weight,
                              }}
                              formControlProps={{
                                required: true,
                                fullWidth: true,                         
                                value:this.state.weight,
                                onChange: this.handleChange('weight')
                              }}
                            />
                          </GridItem>                       

                          <GridItem xs={12} sm={12} md={11}>
                          <FormControl className={classes.formControl_5}>
                              <InputLabel htmlFor="age-simple">Gender</InputLabel>
                              <Select
                                value={this.state.service_gender}
                                onChange={this.serviceGenderChange}
                                inputProps={{
                                  name: 'service_gender',
                                  id: 'age-simple',
                                }}
                              >
                                <MenuItem value="">
                                  <em>None</em>
                                </MenuItem>
                                
                                <MenuItem value={'Man'}>Man</MenuItem>
                                <MenuItem value={'Woman'}>Woman</MenuItem>        
                              </Select>
                            </FormControl>
                          </GridItem>
                </Grid>           
          </DialogContent>
          <DialogActions className={classes.cardFooter}>
          <GridItem xs={12} sm={12} md={6}>
           <Button color="primary" onClick={this.serviceDelete}>Delete</Button>
          </GridItem>
          <Grid item xs={12} sm={12} md={6} className={classes.cardFooter_1}>
              <Button  onClick={this.closeDialog}  color="secondary" className={classes.button_2}>Cancel</Button>
              <Button  variant="contained" color="secondary"                   
                    onClick={this.saveService}>Save</Button>
          </Grid>
          </DialogActions>
      </Dialog>   
      {/**  */}
       {/** for category dilaog */}
       <Dialog
          fullWidth={true}
          maxWidth={'sm'}
          open={this.state.categoryDialog}
          onClose={this.closeDialog}
          aria-labelledby="max-width-dialog-title"         
        >      
          <DialogTitle id="simple-dialog-title" className={classes.dialog_title}>{this.state.category_state} Category</DialogTitle>   
          <DialogContent className={classes.dialog_2}>           
                <Grid container className={classes.dialog_3} justify={'center'}>
                   
                    <GridItem xs={12} sm={12} md={11}>
                      <CustomInput                        
                        labelText="Category Name"                        
                        inputProps={{
                          value:this.state.category_name,
                        }}
                        formControlProps={{
                          required: true,
                          fullWidth: true,                         
                          value:this.state.category_name,
                          onChange: this.handleChange('category_name')
                        }}
                      />
                    </GridItem>
                    <GridItem xs={12} sm={12} md={11}>
                      <CustomInput
                        labelText="Description"                        
                        inputProps={{
                          value:this.state.category_description,
                          multiline: true,
                          rows: 3
                        }}
                        formControlProps={{                         
                          fullWidth: true,                         
                          value:this.state.category_description,
                          onChange: this.handleChange('category_description')
                        }}
                      />
                    </GridItem>
                      <GridItem xs={12} sm={12} md={11}>
                          <FormControl className={classes.formControl_7}>
                              <InputLabel htmlFor="default_category">Default Service Category</InputLabel>
                              <Select
                                value={this.state.default_category}
                                onChange={this.serviceGenderChange}
                                inputProps={{
                                  name: 'default_category',
                                  id: 'default_category',
                                }}
                              >                                
                                <MenuItem value={1}>True</MenuItem>
                                <MenuItem value={0}>False</MenuItem> 
                              </Select>
                            </FormControl>
                          </GridItem>
                </Grid>           
          </DialogContent>
          <DialogActions className={classes.cardFooter}>
          <GridItem xs={12} sm={12} md={6}>
           <Button color="primary" onClick={this.serviceDelete}>Delete</Button>
          </GridItem>
          <Grid item xs={12} sm={12} md={6} className={classes.cardFooter_1}>
              <Button  onClick={this.closeDialog}  color="secondary" className={classes.button_2}>Cancel</Button>
              <Button  variant="contained" color="secondary"                   
                    onClick={this.saveCategory}>Save</Button>
          </Grid>
          </DialogActions>
      </Dialog>   
    {/** for Extra dialog */}
    <Dialog
          fullWidth={true}
          maxWidth={'sm'}
          open={this.state.extraDialog}
          onClose={this.closeDialog}
          aria-labelledby="max-width-dialog-title"         
        >      
          <DialogTitle id="simple-dialog-title" className={classes.dialog_title}>{this.state.extra_state} Service Extra</DialogTitle>   
          <DialogContent className={classes.dialog_2}>           
                <Grid container className={classes.dialog_3} justify={'center'}>                   

                    <GridItem xs={12} sm={12} md={11}>
                      <CustomInput                        
                        labelText="Service Extra Name"                        
                        inputProps={{
                          value:this.state.addon_name,
                        }}
                        formControlProps={{
                          required: true,
                          fullWidth: true,                         
                          value:this.state.addon_name,
                          onChange: this.handleChange('addon_name')
                        }}
                      />
                    </GridItem>
                    <GridItem xs={12} sm={12} md={11}>
                      <CustomInput
                        labelText="Description"                        
                        inputProps={{
                          value:this.state.addon_description,
                          multiline: true,
                          rows: 3
                        }}
                        formControlProps={{                         
                          fullWidth: true,                         
                          value:this.state.addon_description,
                          onChange: this.handleChange('addon_description')
                        }}
                      />
                    </GridItem>
                   
                      <GridItem xs={12} sm={12} md={11}>                      
                          <CustomInput
                                labelText="Duration (minutes)"                        
                                inputProps={{
                                  value:this.state.addon_duration,
                                }}
                                formControlProps={{
                                  required: true,
                                  fullWidth: true,                         
                                  value:this.state.addon_duration,
                                  onChange: this.handleChange('addon_duration')
                                }}
                              />
                          </GridItem>
                          <Grid item xs={12} sm={12} md={11} style={{margin:'auto'}} className={classes.canvary_1}>
                                  <FormControlLabel
                                      control={(
                                        <Checkbox
                                          tabIndex={-1}
                                          disableRipple       
                                          onClick={this.handleToggle('can_vary')}                      
                                          checked={this.state.can_vary}
                                        />
                                      )}
                                      classes={{ label: classes.label }}
                                      label={"Duration can vary"}
                                    />
                              </Grid>
                            <GridItem xs={12} sm={12} md={11}>
                            <CustomInput
                              labelText={"Price ("+auth.user.currency_code+")" }                 
                              inputProps={{
                                value:this.state.addon_price,
                              }}
                              formControlProps={{
                                required: true,
                                fullWidth: true,                         
                                value:this.state.addon_price,
                                onChange: this.handleChange('addon_price')
                              }}
                            />
                          </GridItem>   
                          <GridItem xs={12} sm={12} md={11}>
                          <FormControl className={classes.formControl_5}>
                              <InputLabel htmlFor="age-simple">Gender</InputLabel>
                              <Select
                                value={this.state.addon_gender}
                                onChange={this.serviceGenderChange}
                                inputProps={{
                                  name: 'addon_gender',
                                  id: 'age-simple',
                                }}
                              >
                                <MenuItem value="">
                                  <em>None</em>
                                </MenuItem>                                
                                <MenuItem value={'Man'}>Man</MenuItem>
                                <MenuItem value={'Woman'}>Woman</MenuItem>        
                              </Select>
                            </FormControl>
                          </GridItem>
                </Grid>           
          </DialogContent>
          <DialogActions className={classes.cardFooter}>
          <GridItem xs={12} sm={12} md={6}>
           <Button color="primary" onClick={this.extraDelete}>Delete</Button>
          </GridItem>
          <Grid item xs={12} sm={12} md={6} className={classes.cardFooter_1}>
              <Button  onClick={this.closeDialog}  color="secondary" className={classes.button_2}>Cancel</Button>
              <Button  variant="contained" color="secondary"                   
                    onClick={this.saveAddons}>Save</Button>
          </Grid>
          </DialogActions>
      </Dialog>   
      {/**  */}
      {/** delete  dialog */}
      <Dialog
        open={this.state.delete_confirm }
        onClose={this.confirmDialogClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">{"Are you sure to delete?"}</DialogTitle>
        <DialogContent>       
        </DialogContent>
        <DialogActions>
          <Button onClick={this.confirmDialogClose}  autoFocus color="primary" >
            Cancel
          </Button>
          <Button  onClick={this.delete_process} variant="contained" color="secondary" >
            Yes
          </Button>
        </DialogActions>
      </Dialog>
    {/** delete  dialog for multi delete */}
    <Dialog
        open={this.state.delete_confirm_1 }
        onClose={this.confirmDialogClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">{"Are you sure to delete?"}</DialogTitle>
        <DialogContent>       
        </DialogContent>
        <DialogActions>
          <Button onClick={this.confirmDialogClose}  autoFocus color="primary" >
            Cancel
          </Button>
          <Button  onClick={this.delete_process_1} variant="contained" color="secondary" >
            Yes
          </Button>
        </DialogActions>
      </Dialog>
      
      </GridContainer>
     )
   }
}
export default withStyles(servicesStyle)(withSnackbar(withLocalization(withAuth(Services))));
