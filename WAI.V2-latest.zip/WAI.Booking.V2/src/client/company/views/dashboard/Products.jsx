import React from 'react';
//import classNames from 'classnames';
import withStyles from '@material-ui/core/styles/withStyles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Edit from "@material-ui/icons/Edit";
import Close from "@material-ui/icons/Close";
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import Create from '@material-ui/icons/AddCircle';
import Grid from '@material-ui/core/Grid';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import axios from 'axios';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import Button from '@material-ui/core/Button';
import Checkbox from '@material-ui/core/Checkbox';
import Success from '@material-ui/icons/CheckCircle';
import Typography from '@material-ui/core/Typography';
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import DeleteIcon from '@material-ui/icons/Delete';
import { withSnackbar } from 'notistack';

//import errors from '../../../common/error_codes';
import withAuth from '../../../common/contexts/AuthContext';
import GridItem from "../../../common/components/Grid/GridItem.jsx";
import GridContainer from "../../../common/components/Grid/GridContainer.jsx";
import withLocalization from '../../../common/contexts/LocalizationContext';
import Card from "../../../common/components/Card/Card.jsx";
import CardHeader from "../../../common/components/Card/CardHeader.jsx";
import CardBody from "../../../common/components/Card/CardBody.jsx";
import CustomInput from "../../../common/components/CustomInput/CustomInput.jsx";
import CardFooter from "../../../common/components/Card/CardFooter.jsx";
//import Button from "../../../common/components/CustomButtons/Button.jsx";
import serviceProductsStyle from '../../assets/css/products';
var button_event=false;

class Products extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      addDialog: false,//category dialog
      open_dia2: false,//confirm dialog       
      categories: [],
      products: [],
      category_state: 'Add',
      product_state:'Add',
      gategoryId: '',
      deleteType: '',
      product_name: '',
      price: '',
      quantity: '',
      whole_price: '',
      bookingId: 0,
      productId: '',
      total_price: 0,
      expanded: 'panel1',
      productSelected: [],
      selectRowId:'',
      categoryId:0,
      category_dialog:false,
      category_name:'',
      delete_confirm:false,
      selected_categories:[]

    };
    this.confirmDialogClose = this.confirmDialogClose.bind(this);
    this.createProduct = this.createProduct.bind(this);
    this.saveProduct = this.saveProduct.bind(this);
    this.loadCategories = this.loadCategories.bind(this);
  }
  componentWillMount() {
    this.setState({ bookingId: this.props.bookingId });
    this.loadProducts();
    //this.loadCategories();
  }

  loadProducts = async () => {
    const { localization, auth } = this.props;
    const { data } = await axios.get('/api/company/products');
    console.log(data,'dddadfsdfadfsdf');
    //await auth.get();
    if (data.success) {
      this.setState({ products: data.products,categories:data.categories });
      var total_temp = 0;
      data.products.map(row => {
        total_temp += parseFloat(row.wholeSalePrice);
      })
      this.setState({ total_price: total_temp });
    }
    else {
      if (data.errorCode == 2 || data.errorCode == 5 || data.errorCode == 6) {
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), {
          variant: 'error',
        });
        await auth.get();
      }
      else {
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), {
          variant: 'error',
        });
      }
    }

  }
  async loadCategories() {
    const { localization, auth } = this.props;
    const { data } = await axios.get('/api/company/product/category');
    if (data.success) {
      this.setState({ categories: data.productCategories });
    }
    else {
      if (data.errorCode == 2 || data.errorCode == 5 || data.errorCode == 6) {
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), {
          variant: 'error',
        });
        await auth.get();
      }
      else {
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), {
          variant: 'error',
        });
      }
    }
  }
  editChange = (row) => {
    this.setState({
      product_state: 'Update',
      gategoryId: row.category,
      product_name: row.name,
      quantity: row.quantity,
      price: row.retailPrice,
      whole_price: row.wholeSalePrice,
      productId: row.id,
      addDialog: true
    });
  }
  createProduct() {

    button_event=true;
    setTimeout(() => {
      button_event=false;
    }, 1000);

    this.setState({
      addDialog: true,
      product_name: '',
      price: '',
      quantity: '',
      whole_price: '',
      gategoryId: '',
      productId: '',
      product_state: 'Add',
      expanded:'panel1'
    });
  }
  createCategory=()=>{
    button_event=true;
    setTimeout(() => {
      button_event=false;
    }, 1000);
    this.setState({
      category_dialog:true,
      category_name:'',
      category_state:'Add',
      expanded:'panel2',
      gategoryId:''});
  }
  productDelete = () => {
    this.setState({ delete_confirm:true })//open_dia2: true,
  }
  confirmDelete = async () => {   
    const { localization ,auth} = this.props;

    if(this.state.expanded=="panel1"){     
      var { data } = await axios.post('/api/company/products/delete',{deleteProduct:this.state.productSelected});  
    }
    if(this.state.expanded=="panel2"){     
      var { data } = await axios.post('/api/company/product/category_delete',{deleteCategory:this.state.selected_categories});  
    }
    if(data.success){
      this.props.enqueueSnackbar(localization.localizedString('DELETED_SUCCESS'), { 
        variant: 'success',
      }); 
      this.setState({productSelected:[],selected_categories:[]});
      this.loadProducts();
    }
    else{
      if(data.errorCode==2 || data.errorCode==5 || data.errorCode==3 || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
    this.setState({open_dia2:false})
  }
 /** single delete */
  delete_process=async()=>{
    const { localization ,auth} = this.props;

    console.log(this.state.categoryId);
    if(this.state.expanded=="panel1"){     
      var { data } = await axios.delete('/api/company/products/'+this.state.productId);  
    }
    if(this.state.expanded=="panel2"){     
      var { data } = await axios.delete('/api/company/product/category/'+this.state.categoryId);  
    }
    if(data.success){
      this.props.enqueueSnackbar(localization.localizedString('DELETED_SUCCESS'), { 
        variant: 'success',
      }); 
      this.setState({productSelected:[],selected_categories:[]});
      this.loadProducts();
    }
    else{
      if(data.errorCode==2 || data.errorCode==5 || data.errorCode==3 || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
    this.setState({open_dia2:false,category_dialog:false,addDialog:false,open_dia2:false,delete_confirm:false,})
  }


  dia1Close = () => {
    this.setState({ addDialog: false,category_dialog:false,open_dia2:false});
  }
  categoryDelete= () => {
    this.setState({delete_confirm:true});
    return;     
}  
  async saveProduct() {
    const { localization, auth } = this.props;
    if (this.state.product_state == 'Add') {
      var { data } = await axios.post('/api/company/product', {
        product: {
          name: this.state.product_name,
          quantity: this.state.quantity,
          category: this.state.gategoryId,
          retailPrice: this.state.price,
          wholeSalePrice: this.state.whole_price
        }
      });
      if (data.success) {
        this.props.enqueueSnackbar(localization.localizedString('ADDED_SUCCESS'), {
          variant: 'success',
        });
      }
    }
    else {
      var { data } = await axios.put('/api/company/product/' + this.state.productId, {
        product: {
          name: this.state.product_name,
          quantity: this.state.quantity,
          category: this.state.gategoryId,
          retailPrice: this.state.price,
          wholeSalePrice: this.state.whole_price
        }
      });
      if (data.success) {
        this.props.enqueueSnackbar(localization.localizedString('UPDATED_SUCCESS'), {
          variant: 'success',
        });
      }
      else {
        if (data.errorCode == 2 || data.errorCode == 5 || data.errorCode == 6) {
          this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), {
            variant: 'error',
          });
          await auth.get();
        }
        else {
          this.props.enqueueSnackbar(localization.localizedError(data.errorCode), {
            variant: 'error',
          });
        }
      }
    }

    this.setState({ addDialog: false });
    this.loadProducts();
  }
  categoryChange= (event) => {
    this.setState({
      [event.target.name]: event.target.value,
    });
  }
  handleChange = prop => event => this.setState({ [prop]: event.target.value });
  confirmDialogClose() {
    this.setState({ open_dia2: false,delete_confirm:false });
  }
  headCheck = (event) => {
    let temp = [];
    if (event.target.checked) {
      this.state.products.map(row => {
        temp.push(row.id);
      })
    }
    this.setState({ productSelected: temp });
  }
  productClick= (id) => {
    const { productSelected } = this.state;
    const selectedIndex = productSelected.indexOf(id);
    let newSelected = [];
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(productSelected, id);
    } 
    else if (selectedIndex === 0) {
      newSelected = newSelected.concat(productSelected.slice(1));
    } else if (selectedIndex === productSelected.length - 1) {
      newSelected = newSelected.concat(productSelected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        productSelected.slice(0, selectedIndex),
        productSelected.slice(selectedIndex + 1),
      );
    }
    this.setState({ productSelected: newSelected, });
  }
  categoryChange2=async (event,rid)=>{    // in service table category dropdown change
    const {localization,auth}=this.props;
    var { data } = await axios.put('/api/company/product/' + rid, {
      product: {       
        category:event.target.value,       
      }
    });
    this.loadProducts();
    this.setState({categoryId:event.target.value,selectRowId:rid});   
  }
  isSelected = id => this.state.productSelected.indexOf(id) !== -1;
  table_body = () => {
    const { classes, localization, auth } = this.props;
    const { productSelected, products,categories,categoryId,selectRowId } = this.state;
    let tbl = [];
    let trs = [];
    if (this.state.products.length == 0) {
      return <h4 className={classes.nothing_1}>There is nothing.</h4>
    }

    this.state.products.map(row => {
      trs.push(<TableRow hover
        key={row.id} >
        <TableCell padding="checkbox">
          <Checkbox checked={this.isSelected(row.id)}
            onClick={() => this.productClick(row.id)}
          />
        </TableCell>
        <TableCell className={classes.tableCell + " " + classes.gray_title} >
          {row.name}
        </TableCell>
        <TableCell className={classes.gray_title} >
            <FormControl className={classes.formControl_3 }>                                
                <Select       
                  disableUnderline                                                                
                  value={selectRowId!=row.id?row.category:categoryId}
                  onChange={(event)=>this.categoryChange2(event,row.id)}
                  inputProps={{
                    name: 'categoryId',
                    id: 'categoryId',
                    className:classes.select_font
                  }}
                >        
                {
                  categories.map(item=>{
                      return <MenuItem  key={item.id} value={item.id}> {item.name} </MenuItem >
                  })
                  }                             
                  
                </Select>
           </FormControl>
        </TableCell>
        <TableCell className={classes.gray_title} >{row.quantity}</TableCell>
        <TableCell className={classes.gray_title} >{row.retailPrice}  {auth.user.currency_code}</TableCell>
        <TableCell className={classes.gray_title}>{row.wholeSalePrice}  </TableCell>
        <TableCell className={classes.tableCellId + " " + classes.gray_title}>
          <Tooltip
            id="tooltip-top"
            title="Edit Product"
            placement="top"
            classes={{ tooltip: classes.tooltip }}
          >
            <IconButton
              aria-label="Edit"
              onClick={() => (this.editChange(row))}
            >
              <Edit
                className={
                  classes.tableActionButtonIcon + " " + classes.edit
                }
              />
            </IconButton>
          </Tooltip>
        </TableCell>

      </TableRow>);
    })

    tbl.push(<Table key={1} className={classes.table}>
      <TableHead >
        <TableRow>
          <TableCell padding="checkbox">
            <Checkbox
              indeterminate={productSelected.length > 0 && productSelected.length < products.length}
              checked={productSelected.length == products.length && productSelected.length > 0}
              onClick={this.headCheck}
            /></TableCell>
          <TableCell className={classes.tableCell + " " + classes.tableHeader_1}>Product Name</TableCell>
          <TableCell className={classes.tableHeader_1}>Category</TableCell>
          <TableCell className={classes.tableHeader_1}>Quantity</TableCell>
          <TableCell className={classes.tableHeader_1}>RetailPrice</TableCell>
          <TableCell className={classes.tableHeader_1}>WholesalePrice</TableCell>
          <TableCell className={classes.tableCellId + " " + classes.tableHeader_1}>Edit</TableCell>
        </TableRow>
      </TableHead>
      <TableBody>
        {trs}
      </TableBody>
    </Table>);
    return tbl;
  }
  categoryClick= (id) => {
    const { selected_categories } = this.state;
    const selectedIndex = selected_categories.indexOf(id);
    let newSelected = [];
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected_categories, id);
    } 
    else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected_categories.slice(1));
    } else if (selectedIndex === selected_categories.length - 1) {
      newSelected = newSelected.concat(selected_categories.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected_categories.slice(0, selectedIndex),
        selected_categories.slice(selectedIndex + 1),
      );
    }
    this.setState({ selected_categories: newSelected, });
  }

   
  headCheck_1=(event)=>{
    let temp=[];
    if(event.target.checked){
      this.state.categories.map(row=>{
        temp.push(row.id);
      })
    } 
    this.setState({selected_categories:temp});
  }

  isSelected_1 = id => this.state.selected_categories.indexOf(id) !== -1;

  category_table_body=()=>{
    const { classes,localization } = this.props;
    const {selected_categories,categories}=this.state;
    let tbl=[];
    let trs=[];
    if(this.state.categories.length==0){
      return <h4 className={classes.nothing_1}>There is nothing.</h4>
    }

    this.state.categories.map(row => {
      trs.push(<TableRow hover
      key={row.id} >
      <TableCell padding="checkbox" className={classes.tableCellId}>
        <Checkbox checked={this.isSelected_1(row.id)} 
           onClick={()=>this.categoryClick(row.id)}
            />
      </TableCell>     
      <TableCell  className={classes.gray_title} >
        {row.name}
      </TableCell>     
      <TableCell  className={classes.tableCellId+" "+classes.gray_title}>
            <Tooltip
              id="tooltip-top"
              title="Edit Category"
              placement="top"
              classes={{ tooltip: classes.tooltip }}
            >
              <IconButton
                aria-label="Edit"
              
                onClick={() =>(this.editChange1(row))}              
                
              >
                <Edit
                  className={
                    classes.tableActionButtonIcon + " " + classes.edit
                  }
                />
              </IconButton>
            </Tooltip>
      </TableCell>
     
    </TableRow>);      
    })

    tbl.push(<Table key={1} className={classes.table}>
      <TableHead >
        <TableRow>
          <TableCell padding="checkbox"  className={classes.tableCellId}>
              <Checkbox
                indeterminate={selected_categories.length>0 && selected_categories.length<categories.length}
                checked={selected_categories.length==categories.length && categories.length>0}        
                onClick={this.headCheck_1}                       
              />
          </TableCell>         
          <TableCell  className={classes.dark_title}>Category Name</TableCell>         
          <TableCell  className={classes.tableCellId +" "+classes.tableHeader_1}>Edit</TableCell>         
        </TableRow>
      </TableHead>
      <TableBody>
        {trs}
      </TableBody>
    </Table>);
    return tbl;    
  }

  handleChange_1 = panel => (event, expanded) => {
    if(button_event)
      return;
    this.setState({
      expanded: expanded ? panel : false,
    });
  };

   saveCategroy =async()=>{  
    const {localization,auth}=this.props;     
    if(this.state.category_state=='Add'){
      var { data } = await axios.post('/api/company/product/category', {     
        name: this.state.category_name,    
      }); 
      if(data.success){          
        this.props.enqueueSnackbar(localization.localizedString('ADDED_SUCCESS'), { 
          variant: 'success',
        }); 
        this.setState({ category_dialog:false });
        this.loadCategories();
      }
    }
    else{
      var { data } = await axios.put('/api/company/product/category/'+this.state.gategoryId, {     
        name: this.state.category_name,
      });
      if(data.success){ 
        this.props.enqueueSnackbar(localization.localizedString('UPDATED_SUCCESS'), { 
          variant: 'success',
        });
        this.setState({ category_dialog:false });
        this.loadCategories();
      }
    }    
    if(!data.success){
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
  }

  editChange1=(row)=>{   
    this.setState({category_state:'Update',
    category_name:row.name,
    category_dialog:true,
    categoryId:row.id
  });
  } 

  allItemsDelete=()=>{
    button_event=true;
    setTimeout(() => {
      button_event=false;
    }, 1000);  
    this.setState({open_dia2:true,});   
  }

  render() {
    const { classes, localization, auth } = this.props;
    const { expanded,productSelected ,selected_categories} = this.state;
    var product_title = "Product";   
     if(productSelected.length>0 && productSelected.length==1){
      product_title=productSelected.length+" SELECTED PRODUCT";
     }
     else if(productSelected.length>1){
      product_title=productSelected.length+" SELECTED PRODUCTS";
     }

     var product_category_title="Product Category";
     if(selected_categories.length>0 && selected_categories.length==1){
      product_category_title=selected_categories.length+" SELECTED CATEGORY";
     }
     else if(selected_categories.length>1){
      product_category_title=selected_categories.length+" SELECTED CATEGORIES";
     }
    
    return (
      <Grid container className={classes.container_1}>        

        <GridItem xs={12} sm={12} md={12}>
        <Card>
          <CardBody className={classes.cardBody_1}>        
              
          <ExpansionPanel
            square
            expanded={expanded === 'panel1'}
            onChange={this.handleChange_1('panel1')}
          >
            <ExpansionPanelSummary className={productSelected.length>0?classes.summary_2:null}>
              <Grid xs={10} item sm={10} md={10} className={classes.grid_title}>
                <Typography variant="subtitle1" className={productSelected.length>0?classes.title_4:classes.title_3} >{product_title}</Typography>
                <Typography variant="subtitle1" color="secondary" className={classes.selectedLabel}></Typography>
              </Grid>
              <Grid xs={2} item sm={2} md={2} className={classes.header_2}>
                    {productSelected.length > 0 ? (
                        <Tooltip title="Delete">
                          <IconButton aria-label="Delete"
                          onClick={this.allItemsDelete}
                          >
                            <DeleteIcon />
                          </IconButton>
                        </Tooltip>
                      ) : (
                        <Tooltip title="Filter list">
                          <IconButton
                          aria-label="Filter list"
                          onClick={this.createProduct}
                          >
                            <Create />
                          </IconButton>
                        </Tooltip>
                      )}                       
                        
              </Grid>

            </ExpansionPanelSummary>
            <ExpansionPanelDetails>
              <div className={classes.cardBody_1}>
                {this.table_body()}
              </div>
            </ExpansionPanelDetails>
          </ExpansionPanel>

          <ExpansionPanel
            square
            expanded={expanded === 'panel2'}
            onChange={this.handleChange_1('panel2')}
          >
            <ExpansionPanelSummary className={selected_categories.length>0?classes.summary_2:null}>
              <Grid xs={10} item sm={10} md={10} className={classes.grid_title}>
                <Typography variant="subtitle1" className={selected_categories.length>0?classes.title_4:classes.title_3} >{product_category_title}</Typography>
                <Typography variant="subtitle1" color="secondary" className={classes.selectedLabel}></Typography>
              </Grid>
              <Grid xs={2} item sm={2} md={2} className={classes.header_2}>
                    {selected_categories.length > 0 ? (
                        <Tooltip title="Delete">
                          <IconButton aria-label="Delete"
                          onClick={this.allItemsDelete}                          >
                            <DeleteIcon />
                          </IconButton>
                        </Tooltip>
                      ) : (
                        <Tooltip title="Filter list">
                          <IconButton
                          aria-label="Filter list"
                          onClick={this.createCategory}
                          >
                            <Create />
                          </IconButton>
                        </Tooltip>
                      )}                       
                        
              </Grid>

            </ExpansionPanelSummary>
            <ExpansionPanelDetails>
              <div className={classes.cardBody_1}>
                {this.category_table_body()}
              </div>
            </ExpansionPanelDetails>
          </ExpansionPanel>



          </CardBody>
          </Card>
       </GridItem>

        {/** for add/update product */}
        <Dialog
          fullWidth={true}
          maxWidth={'sm'}
          open={this.state.addDialog}
          onClose={this.dia1Close}
          aria-labelledby="max-width-dialog-title"
        >
          <DialogTitle id="simple-dialog-title" className={classes.dialog_title}>{this.state.product_state} Product</DialogTitle>
          <DialogContent className={classes.dialog_22}>
            <GridContainer justify={'center'}>
              <GridItem xs={12} sm={12} md={11}>
                <FormControl className={classes.formControl}>
                  <InputLabel htmlFor="age-simple">Categories</InputLabel>
                  <Select
                    value={this.state.gategoryId}
                    onChange={this.categoryChange}
                    inputProps={{
                      name: 'gategoryId',
                      id: 'age-simple',
                    }}
                  >
                    {
                      this.state.categories.map(row => (
                        <MenuItem key={row.id} value={row.id}>{row.name}</MenuItem>
                      ))
                    }

                  </Select>
                </FormControl>
              </GridItem>
              <GridItem xs={12} sm={12} md={11}>
                <CustomInput
                  labelText="Product Name"
                  inputProps={{
                    value: this.state.product_name,
                  }}
                  formControlProps={{
                    required: true,
                    fullWidth: true,
                    value: this.state.product_name,
                    onChange: this.handleChange('product_name')
                  }}
                />
              </GridItem>
              <GridItem xs={12} sm={12} md={11}>
                <CustomInput
                  labelText="Quantity"
                  inputProps={{
                    value: this.state.quantity,
                  }}
                  formControlProps={{
                    required: true,
                    fullWidth: true,
                    value: this.state.quantity,
                    onChange: this.handleChange('quantity')
                  }}
                />
              </GridItem>

              <GridItem xs={12} sm={12} md={11}>
                <CustomInput
                  labelText={"RetailPrice (" + auth.user.currency_code + ")"}
                  inputProps={{
                    value: this.state.price,
                  }}
                  formControlProps={{
                    required: true,
                    fullWidth: true,
                    value: this.state.price,
                    onChange: this.handleChange('price')
                  }}
                />
              </GridItem>

              <GridItem xs={12} sm={12} md={11} >
                <CustomInput
                  className={classes.formControl_5}
                  labelText={"WholesalePrice (" + auth.user.currency_code + ")"}
                  inputProps={{
                    value: this.state.whole_price,
                  }}
                  formControlProps={{
                    required: true,
                    fullWidth: true,
                    value: this.state.whole_price,
                    onChange: this.handleChange('whole_price')
                  }}
                />
              </GridItem>
            </GridContainer>

          </DialogContent>
          <DialogActions className={classes.cardFooter}>
            <GridItem xs={12} sm={12} md={6}>
              {
                this.state.productId != '' ? <Button color="primary" onClick={this.productDelete}>Delete</Button> : ''
              }
            </GridItem>
            <Grid item xs={12} sm={12} md={6} className={classes.cardFooter_1}>
              <Button onClick={this.dia1Close} >Cancel</Button>
              <Button variant="contained" color="secondary" className={classes.button_2} disabled={this.state.product_name.length == 0
                || this.state.price.length == 0
                || this.state.quantity.length == 0
                || this.state.whole_price.length == 0
                || this.state.gategoryId.length == 0
              }
                onClick={this.saveProduct}>Save</Button>
            </Grid>
          </DialogActions>
        </Dialog>
        
         {/**  category dialog */}
      <Dialog
          fullWidth={true}
          maxWidth={'sm'}
          open={this.state.category_dialog}
          onClose={this.dia1Close}
          aria-labelledby="max-width-dialog-title"         
        >         
          <DialogTitle id="simple-dialog-title" className={classes.dialog_title}>{this.state.category_state} Product Category</DialogTitle>  
          <DialogContent className={classes.dialog_22}>
                <GridContainer  justify={'center'}>
                    <GridItem xs={12} sm={12} md={11}>
                      <CustomInput
                        labelText="Product Category Name"
                        id="name"
                        inputProps={{
                          value:this.state.category_name,
                        }}
                        formControlProps={{
                          required: true,
                          fullWidth: true,                         
                          value:this.state.category_name,
                          onChange: this.handleChange('category_name')
                        }}
                      />
                    </GridItem>
                    
                </GridContainer>
           
                               
          </DialogContent>
          <DialogActions className={classes.cardFooter}>
          <GridItem xs={12} sm={12} md={6}>
             {
              this.state.employeeId!=''?<Button color="primary" onClick={this.categoryDelete}>Delete</Button>:''
             } 
              </GridItem>
              <Grid item xs={12} sm={12} md={6} className={classes.cardFooter_1}>               
                <Button variant="contained"   onClick={this.dia1Close}>Cancel</Button>   
                <Button color="secondary" variant="contained" className={classes.button_2}
                disabled={this.state.category_name.length==0 || !this.state.category_name}
                 onClick={this.saveCategroy}>Save</Button>
              </Grid> 
          </DialogActions>
      </Dialog>  
      {/** delete  dialog */}
      <Dialog
        open={this.state.delete_confirm }
        onClose={this.confirmDialogClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">{"Are you sure to delete?"}</DialogTitle>
        <DialogContent>       
        </DialogContent>
        <DialogActions>
          <Button onClick={this.confirmDialogClose}  autoFocus color="primary" >
            Cancel
          </Button>
          <Button  onClick={this.delete_process} variant="contained" color="secondary" >
            Yes
          </Button>
        </DialogActions>
      </Dialog>

        {/**  multiple category delete*/}
        <Dialog
          open={this.state.open_dia2}
          onClose={this.confirmDialogClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle id="alert-dialog-title">{"Are you sure to delete?"}</DialogTitle>
          <DialogContent>
          </DialogContent>
          <DialogActions>
            <Button variant="contained" onClick={this.confirmDialogClose} autoFocus>
              Cancel
          </Button>
            <Button variant="contained" onClick={this.confirmDelete} color="secondary" >
              Yes
          </Button>
          </DialogActions>
        </Dialog>

      </Grid>
    )
  }
}
export default withStyles(serviceProductsStyle)(withSnackbar(withLocalization(withAuth(Products))));
