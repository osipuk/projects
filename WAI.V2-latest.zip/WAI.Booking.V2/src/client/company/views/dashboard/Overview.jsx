import React from 'react';

export default () => (
  <div>
    <h1>Overview</h1>
  </div>
);
