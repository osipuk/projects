import React from 'react';
//import classNames from 'classnames';
import withStyles from '@material-ui/core/styles/withStyles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Success from '@material-ui/icons/CheckCircle';
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import Create from '@material-ui/icons/AddCircle';
import Grid from '@material-ui/core/Grid';
import TextField from '@material-ui/core/TextField';
import DialogTitle from '@material-ui/core/DialogTitle';
import Select from '@material-ui/core/Select';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Checkbox from '@material-ui/core/Checkbox';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import Button from '@material-ui/core/Button';
import moment from 'moment'
import {  withSnackbar } from 'notistack';
import axios from 'axios';
import withAuth from '../../../common/contexts/AuthContext';
//import withLoading from '../../../common/contexts/LoadingContext';
//import withNotifications from '../../../common/contexts/NotificationsContext';
import GridItem from "../../../common/components/Grid/GridItem.jsx";
import GridContainer from "../../../common/components/Grid/GridContainer.jsx";
import withLocalization from '../../../common/contexts/LocalizationContext';
import Card from "../../../common/components/Card/Card.jsx";
import CardHeader from "../../../common/components/Card/CardHeader.jsx";
import CardBody from "../../../common/components/Card/CardBody.jsx";
import CustomInput from "../../../common/components/CustomInput/CustomInput.jsx";
import CardFooter from "../../../common/components/Card/CardFooter.jsx";
//import Button from "../../../common/components/CustomButtons/Button.jsx";
import openHoursStyle from '../../assets/css/openhours';

class OpenHours extends React.Component {
  constructor(props){
    super (props);
    this.state={
      employees:[],      
      open_dialog_2:false,//work hours
      workHours:{},
      workhours_card:this.props.classes.service_card_disable,
      toolTip_status:this.props.classes.service_card_disable,
      employeeId:0,
      labelWidth:0,    
      monday_is_open:false,
      tuesday_is_open:false,
      wednesday_is_open:false,
      thursday_is_open:false,
      friday_is_open:false,
      saturday_is_open:false,
      sunday_is_open:false,
      monday_open_at:'10:00',
      tuesday_open_at:'10:00',
      wednesday_open_at:'10:00',
      thursday_open_at:'10:00',
      friday_open_at:'10:00',
      saturday_open_at:'10:00',
      sunday_open_at:'10:00',
      monday_close_at:'16:00',
      tuesday_close_at:'16:00',
      wednesday_close_at:'16:00',
      thursday_close_at:'16:00',
      friday_close_at:'16:00',
      saturday_close_at:'16:00',
      sunday_close_at:'16:00',
      add_command:'',
      open_dia2:false

    };
    this.loadEmployees=this.loadEmployees.bind(this);
    this.employeeChange=this.employeeChange.bind(this);
  }
  componentDidMount(){
   //this.loadEmployees();  
   this.loadWorkHours(this.props.employeeId);
  }
  async loadEmployees(){
    const {localization}=this.props;
    const { data } = await axios.get('/api/company/employee');   
    if(data.success){
      this.setState({employees:data.employees});
    }
    else{
      if(data.errorCode==2 || data.errorCode==5 || data.errorCode==3  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
  }   
  employeeChange(event){
   
    if(event.target.value=='0'){
      this.setState({workhours_card:this.props.classes.service_card_disable,
        add_command:'',
        toolTip_status:this.props.classes.service_card_disable,});
      return;
    }
    this.setState({[event.target.name]: event.target.value,add_command:''});
    this.loadWorkHours(event.target.value); 
  }
  deleteWorkHours=async()=>{   
    this.setState({open_dia2:true})

  }
  confirmCateDelete=async()=>{
    const {localization}=this.props;
    var hourId=this.state.workHours.id;
    const { data } = await axios.delete('/api/company/booking/hours/'+hourId);  
    if(data.success){     
      this.props.enqueueSnackbar(localization.localizedString('DELETED_SUCCESS'), { 
        variant: 'success',
      }); 
      this.setState({workHours:{},add_command:'',toolTip_status:this.props.classes.service_card_visible})
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
    this.setState({open_dia2:false})
  }
  loadWorkHours=async(employeeId)=>{
    const {localization,auth}=this.props;   
    const { data } = await axios.get('/api/company/booking/hours/'+employeeId);    
    console.log(data,'dfdfsdfsdfsdfsdfsd');
    if(data.success){
      if(data.bookingHours.length==0)     {
        this.setState({toolTip_status:this.props.classes.service_card_visible});
      }
      else{
        this.setState({toolTip_status:this.props.classes.service_card_disable});
      }
      this.setState({       
        workHours:data.bookingHours,
        monday_is_open:data.bookingHours.mondayIsOpen,
        tuesday_is_open:data.bookingHours.tuesdayIsOpen,
        wednesday_is_open:data.bookingHours.wednesdayIsOpen,
        thursday_is_open:data.bookingHours.thursdayIsOpen,
        friday_is_open:data.bookingHours.fridayIsOpen,
        saturday_is_open:data.bookingHours.saturdayIsOpen,
        sunday_is_open:data.bookingHours.sundayIsOpen,
        monday_open_at:data.bookingHours.mondayOpenAt,
        tuesday_open_at:data.bookingHours.tuesdayOpenAt,
        wednesday_open_at:data.bookingHours.wednesdayOpenAt,
        thursday_open_at:data.bookingHours.thursdayOpenAt,
        friday_open_at:data.bookingHours.fridayOpenAt,
        saturday_open_at:data.bookingHours.saturdayOpenAt,
        sunday_open_at:data.bookingHours.sundayOpenAt,
        monday_close_at:data.bookingHours.mondayCloseAt,
        tuesday_close_at:data.bookingHours.tuesdayCloseAt,
        wednesday_close_at:data.bookingHours.wednesdayCloseAt,
        thursday_close_at:data.bookingHours.thursdayCloseAt,
        friday_close_at:data.bookingHours.fridayCloseAt,
        saturday_close_at:data.bookingHours.saturdayCloseAt,
        sunday_close_at:data.bookingHours.sundayCloseAt,
      });      
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
      this.setState({workHours:{},toolTip_status:this.props.classes.service_card_visible,});     
    }    
    this.setState({workhours_card:this.props.classes.service_card_visible});
  }
  rowClick=(id)=>{
    if(id==1){
      this.setState({
        monday_is_open:!this.state.monday_is_open,        
      });
    }
    if(id==2){
      this.setState({
       tuesday_is_open:!this.state.tuesday_is_open
      });
    }
    if(id==3){
      this.setState({
       wednesday_is_open:!this.state.wednesday_is_open
      });
    }
    if(id==4){
      this.setState({
       thursday_is_open:!this.state.thursday_is_open
      });
    }
    if(id==5){
      this.setState({
      friday_is_open:!this.state.friday_is_open
      });
    }
    if(id==6){
      this.setState({
      saturday_is_open:!this.state.saturday_is_open
      });
    }
    if(id==7){
      this.setState({
       sunday_is_open:!this.state.sunday_is_open
      });
    }
    
  }
  timeChange=(event)=>{     
    var open_time =event.target.id;
    var close_time= open_time.replace("open", "close");   
    if(this.state[close_time]<event.target.value){     
      return;
    }
    this.setState({     
      [event.target.id]: event.target.value
    });
  }
  timeChange_close=(event)=>{    
    var close_time=event.target.id;    
    var open_time = close_time.replace("close", "open");    
    if(this.state[open_time]>event.target.value){     
      return;
    }
    this.setState({     
      [event.target.id]: event.target.value
    });
  }
  confirmDialogClose=()=>{
    this.setState({ open_dia2: false });
  }
  handleChange = prop => event => this.setState({ [prop]: event.target.value });
  resetChange=()=>{
    const {localization,auth}=this.props;  
    this.setState({
      monday_is_open:false,
      tuesday_is_open:false,
      wednesday_is_open:false,
      thursday_is_open:false,
      friday_is_open:false,
      saturday_is_open:false,
      sunday_is_open:false,
      monday_open_at:'10:00',
      tuesday_open_at:'10:00',
      wednesday_open_at:'10:00',
      thursday_open_at:'10:00',
      friday_open_at:'10:00',
      saturday_open_at:'10:00',
      sunday_open_at:'10:00',
      monday_close_at:'16:00',
      tuesday_close_at:'16:00',
      wednesday_close_at:'16:00',
      thursday_close_at:'16:00',
      friday_close_at:'16:00',
      saturday_close_at:'16:00',
      sunday_close_at:'16:00',
    });   
    this.props.enqueueSnackbar(localization.localizedString('RESET_SUCCESS'), { 
      variant: 'success',
    }); 

  }
  crateWrokhours=()=>{
        
        this.setState({
          toolTip_status:this.props.classes.service_card_disable,
          add_command:'Add',
          monday_is_open:false,
          tuesday_is_open:false,
          wednesday_is_open:false,
          thursday_is_open:false,
          friday_is_open:false,
          saturday_is_open:false,
          sunday_is_open:false,
          monday_open_at:'10:00',
          tuesday_open_at:'10:00',
          wednesday_open_at:'10:00',
          thursday_open_at:'10:00',
          friday_open_at:'10:00',
          saturday_open_at:'10:00',
          sunday_open_at:'10:00',
          monday_close_at:'16:00',
          tuesday_close_at:'16:00',
          wednesday_close_at:'16:00',
          thursday_close_at:'16:00',
          friday_close_at:'16:00',
          saturday_close_at:'16:00',
          sunday_close_at:'16:00',
        });     
  }
  saveWorkHours=async()=>{
    const {localization,auth}=this.props;     
    var { data } = await axios.post('/api/company/booking/hours', {
      hours:{ 
        employeeId:this.props.employeeId,
        mondayIsOpen:this.state.monday_is_open,
        tuesdayIsOpen:this.state.tuesday_is_open,
        wednesdayIsOpen:this.state.wednesday_is_open,
        thursdayIsOpen:this.state.thursday_is_open,
        fridayIsOpen:this.state.friday_is_open,
        saturdayIsOpen:this.state.saturday_is_open,
        sundayIsOpen:this.state.sunday_is_open,
        mondayOpenAt:this.state.monday_open_at,
        tuesdayOpenAt:this.state.tuesday_open_at,
        wednesdayOpenAt:this.state.wednesday_open_at,
        thursdayOpenAt:this.state.thursday_open_at,
        fridayOpenAt:this.state.friday_open_at,
        saturdayOpenAt:this.state.saturday_open_at,
        sundayOpenAt:this.state.sunday_open_at,
        mondayCloseAt:this.state.monday_close_at,
        tuesdayCloseAt:this.state.tuesday_close_at,
        wednesdayCloseAt:this.state.wednesday_close_at,
        thursdayCloseAt:this.state.thursday_close_at,
        fridayCloseAt:this.state.friday_close_at,
        saturdayCloseAt:this.state.saturday_close_at,
        sundayCloseAt:this.state.sunday_close_at,    
       }
     });
     if(data.success){      
      this.props.enqueueSnackbar(localization.localizedString('ADDED_SUCCESS'), { 
        variant: 'success',
      }); 
      this.loadWorkHours(this.props.employeeId);
     }
     else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
     }
      
    }
    updateWorkHours=async()=>{
      const {localization,auth}=this.props;     
      var { data } = await axios.put('/api/company/booking/hours', {
        hours:{
          id:this.state.workHours.id,
          employeeId:this.state.employeeId,
          mondayIsOpen:this.state.monday_is_open,
          tuesdayIsOpen:this.state.tuesday_is_open,
          wednesdayIsOpen:this.state.wednesday_is_open,
          thursdayIsOpen:this.state.thursday_is_open,
          fridayIsOpen:this.state.friday_is_open,
          saturdayIsOpen:this.state.saturday_is_open,
          sundayIsOpen:this.state.sunday_is_open,
          mondayOpenAt:this.state.monday_open_at,
          tuesdayOpenAt:this.state.tuesday_open_at,
          wednesdayOpenAt:this.state.wednesday_open_at,
          thursdayOpenAt:this.state.thursday_open_at,
          fridayOpenAt:this.state.friday_open_at,
          saturdayOpenAt:this.state.saturday_open_at,
          sundayOpenAt:this.state.sunday_open_at,
          mondayCloseAt:this.state.monday_close_at,
          tuesdayCloseAt:this.state.tuesday_close_at,
          wednesdayCloseAt:this.state.wednesday_close_at,
          thursdayCloseAt:this.state.thursday_close_at,
          fridayCloseAt:this.state.friday_close_at,
          saturdayCloseAt:this.state.saturday_close_at,
          sundayCloseAt:this.state.sunday_close_at,    
         }
       });
       if(data.success){            
          this.props.enqueueSnackbar(localization.localizedString('UPDATED_SUCCESS'), { 
            variant: 'success',
          }); 
       }
       else{
        if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
          this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
            variant: 'error',
          }); 
          await auth.get();       
         }
         else{        
          this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
            variant: 'error',
          }); 
         }
       }
       this.loadWorkHours(this.state.employeeId);
    }
    table_body=()=>{
    const { classes,localization } = this.props;

    if(Object.keys(this.state.workHours).length==0 && this.state.add_command==''){
      return <h4 className={classes.nothing_1}>The work hours was not set.</h4>
    }
    
    return <Table className={classes.table}>
              <TableHead>
                <TableRow>
                  <TableCell className={classes.tableHeader_2}>Status</TableCell>
                  <TableCell className={classes.tableHeader_2} align="left">Day</TableCell>
                  <TableCell className={classes.tableHeader_2} align="center">Open At</TableCell>
                  <TableCell className={classes.tableHeader_2} align="center">Close At</TableCell>
                  
                </TableRow>
              </TableHead>
              <TableBody>          
              <TableRow key={1} role="checkbox" hover             
              aria-checked={this.state.monday_is_open}
              selected={this.state.monday_is_open}      
              >
              <TableCell className={classes.tableCellId} >
                <Checkbox onChange={event=>this.rowClick(1)} checked={this.state.monday_is_open} />
              </TableCell>
              <TableCell component="th" scope="row" className={classes.tableCellId_2+" "+classes.gray_title}
                onClick={event=>this.rowClick(1)}
              >  Monday</TableCell>
              <TableCell align="center">
                  <TextField
                    id="monday_open_at"                   
                    type="time"
                    value={this.state.monday_open_at}
                    className={classes.textField +" "+classes.gray_title}
                    InputLabelProps={{
                      shrink: true,
                    }}
                    onChange={this.timeChange}
                    inputProps={{
                      step: 300, // 5 min
                    }}/>
              </TableCell>
              <TableCell align="center">
                  <TextField
                    id="monday_close_at"                   
                    type="time"
                    value={this.state.monday_close_at}
                    className={classes.textField +" "+classes.gray_title}
                    InputLabelProps={{
                      shrink: true,
                    }}
                    onChange={this.timeChange_close}
                    inputProps={{
                      step: 300, // 5 min                     
                    }}/>
              </TableCell>              
            </TableRow>
              {/** Tuesday */}
              <TableRow key={2} role="checkbox" hover             
              aria-checked={this.state.tuesday_is_open}
              selected={this.state.tuesday_is_open}      
              >
              <TableCell className={classes.tableCellId} >
                <Checkbox onChange={event=>this.rowClick(2)} checked={this.state.tuesday_is_open} />
              </TableCell>
              <TableCell component="th" scope="row" className={classes.tableCellId_2+" "+classes.gray_title}
                onClick={event=>this.rowClick(2)}
              >  Tuesday</TableCell>
              <TableCell align="center">
                  <TextField
                    id="tuesday_open_at"                   
                    type="time"
                    value={this.state.tuesday_open_at}
                    className={classes.textField}
                    InputLabelProps={{
                      shrink: true,
                    }}
                    onChange={this.timeChange}
                    inputProps={{
                      step: 300, // 5 min
                    }}/>
              </TableCell>
              <TableCell align="center">
                  <TextField
                    id="tuesday_close_at"                   
                    type="time"
                    value={this.state.tuesday_close_at}
                    className={classes.textField}
                    InputLabelProps={{
                      shrink: true,
                    }}
                    onChange={this.timeChange_close}
                    inputProps={{
                      step: 300, // 5 min
                    }}/>
              </TableCell>              
            </TableRow>
            {/** Wednesday */}
            <TableRow key={3} role="checkbox" hover             
              aria-checked={this.state.wednesday_is_open}
              selected={this.state.wednesday_is_open}      
            >
              <TableCell className={classes.tableCellId} >
                <Checkbox onChange={event=>this.rowClick(3)} checked={this.state.wednesday_is_open} />
              </TableCell>
              <TableCell component="th" scope="row" className={classes.tableCellId_2+" "+classes.gray_title}
                onClick={event=>this.rowClick(3)}
              >  Wednsday</TableCell>
              <TableCell align="center">
                  <TextField
                    id="wednesday_open_at"                   
                    type="time"
                    value={this.state.wednesday_open_at}
                    className={classes.textField}
                    InputLabelProps={{
                      shrink: true,
                    }}
                    onChange={this.timeChange}
                    inputProps={{
                      step: 300, // 5 min
                    }}/>
              </TableCell>
              <TableCell align="center">
                  <TextField
                    id="wednesday_close_at"                   
                    type="time"
                    value={this.state.wednesday_close_at}
                    className={classes.textField}
                    InputLabelProps={{
                      shrink: true,
                    }}
                    onChange={this.timeChange_close}
                    inputProps={{
                      step: 300, // 5 min
                    }}/>
              </TableCell>              
            </TableRow>
            {/** Thursday */}
            <TableRow key={4} role="checkbox" hover             
              aria-checked={this.state.thursday_is_open}
              selected={this.state.thursday_is_open}      
            >
              <TableCell className={classes.tableCellId} >
                <Checkbox onChange={event=>this.rowClick(4)} checked={this.state.thursday_is_open} />
              </TableCell>
              <TableCell component="th" scope="row" className={classes.tableCellId_2+" "+classes.gray_title}
                onClick={event=>this.rowClick(4)}
              >  Thursday</TableCell>
              <TableCell align="center">
                  <TextField
                    id="thursday_open_at"                   
                    type="time"
                    value={this.state.thursday_open_at}
                    className={classes.textField}
                    InputLabelProps={{
                      shrink: true,
                    }}
                    onChange={this.timeChange}
                    inputProps={{
                      step: 300, // 5 min
                    }}/>
              </TableCell>
              <TableCell align="center">
                  <TextField
                    id="thursday_close_at"                   
                    type="time"
                    value={this.state.thursday_close_at}
                    className={classes.textField}
                    InputLabelProps={{
                      shrink: true,
                    }}
                    onChange={this.timeChange_close}
                    inputProps={{
                      step: 300, // 5 min
                    }}/>
              </TableCell>              
            </TableRow>
            {/** Friday */}
            <TableRow key={5} role="checkbox" hover             
              aria-checked={this.state.friday_is_open}
              selected={this.state.friday_is_open}      
            >
              <TableCell className={classes.tableCellId} >
                <Checkbox onChange={event=>this.rowClick(5)} checked={this.state.friday_is_open} />
              </TableCell>
              <TableCell component="th" scope="row" className={classes.tableCellId_2+" "+classes.gray_title}
                onClick={event=>this.rowClick(5)}
              >  Friday</TableCell>
              <TableCell align="center">
                  <TextField
                    id="friday_open_at"                   
                    type="time"
                    value={this.state.friday_open_at}
                    className={classes.textField}
                    InputLabelProps={{
                      shrink: true,
                    }}
                    onChange={this.timeChange}
                    inputProps={{
                      step: 300, // 5 min
                    }}/>
              </TableCell>
              <TableCell align="center">
                  <TextField
                    id="friday_close_at"                   
                    type="time"
                    value={this.state.friday_close_at}
                    className={classes.textField}
                    InputLabelProps={{
                      shrink: true,
                    }}
                    onChange={this.timeChange_close}
                    inputProps={{
                      step: 300, // 5 min
                    }}/>
              </TableCell>              
            </TableRow>
            {/** Saturday */}
            <TableRow key={6} role="checkbox" hover             
              aria-checked={this.state.saturday_is_open}
              selected={this.state.saturday_is_open}      
            >
              <TableCell className={classes.tableCellId} >
                <Checkbox onChange={event=>this.rowClick(6)} checked={this.state.saturday_is_open} />
              </TableCell>
              <TableCell component="th" scope="row" className={classes.tableCellId_2+" "+classes.gray_title}
                onClick={event=>this.rowClick(6)}
              >  Saturday</TableCell>
              <TableCell align="center">
                  <TextField
                    id="saturday_open_at"                   
                    type="time"
                    value={this.state.saturday_open_at}
                    className={classes.textField}
                    InputLabelProps={{
                      shrink: true,
                    }}
                    onChange={this.timeChange}
                    inputProps={{
                      step: 300, // 5 min
                    }}/>
              </TableCell>
              <TableCell align="center">
                  <TextField
                    id="saturday_close_at"                   
                    type="time"
                    value={this.state.saturday_close_at}
                    className={classes.textField}
                    InputLabelProps={{
                      shrink: true,
                    }}
                    onChange={this.timeChange_close}
                    inputProps={{
                      step: 300, // 5 min
                    }}/>
              </TableCell>              
            </TableRow>
            {/** Sanday */}
            <TableRow key={7} role="checkbox" hover             
              aria-checked={this.state.sunday_is_open}
              selected={this.state.sunday_is_open}      
            >
              <TableCell className={classes.tableCellId} >
                <Checkbox onChange={event=>this.rowClick(7)} checked={this.state.sunday_is_open} />
              </TableCell>
              <TableCell component="th" scope="row" className={classes.tableCellId_2}
                onClick={event=>this.rowClick(7)}
              >  Sunday</TableCell>
              <TableCell align="center">
                  <TextField
                    id="sunday_open_at"                   
                    type="time"
                    value={this.state.sunday_open_at}
                    className={classes.textField}
                    InputLabelProps={{
                      shrink: true,
                    }}
                    onChange={this.timeChange}
                    inputProps={{
                      step: 300, // 5 min
                    }}/>
              </TableCell>
              <TableCell align="center">
                  <TextField
                    id="sunday_close_at"                   
                    type="time"
                    value={this.state.sunday_close_at}
                    className={classes.textField}
                    InputLabelProps={{
                      shrink: true,
                    }}
                    onChange={this.timeChange_close}
                    inputProps={{
                      step: 300, // 5 min
                    }}/>
              </TableCell>              
            </TableRow>

            </TableBody>
            </Table> 
  }
  cardFooter=()=>{
    if(Object.keys(this.state.workHours).length>0){    
    return <CardFooter>                
              <Button variant="outlined"  onClick={this.deleteWorkHours}>Delete</Button>
              <Button variant="contained" color="secondary"   onClick={this.updateWorkHours}>Update</Button>
          </CardFooter>  
    }
    else if(this.state.add_command=='Add'){
      return <CardFooter>                
            <Button variant="outlined"  onClick={this.resetChange}>Reset</Button>
            <Button variant="contained" color="secondary" onClick={this.saveWorkHours}>Save</Button>
        </CardFooter>  
    }
  }
  render(){
    const { classes,localization } = this.props;
    return(
      <Grid container className={classes.container_1}>
           <GridItem xs={2} sm={2} md={7}>             
            </GridItem>
            <Grid xs={10} item sm={10} md={5} className={classes.header_2}>               

              <Button variant="contained" 
                onClick={this.crateWrokhours}
                className={this.state.toolTip_status}
              color="secondary" >                
                  <Create
                    className={
                        classes.create
                    }
                  />
                Add Work Hours
              </Button>   
              <Button variant="outlined" 
                onClick={()=>this.props.nextPage('default')}
                 className={classes.button_2}> 
               Back
              </Button> 
          </Grid>          
        {/** work hours card */}
      <GridItem xs={12} sm={12} md={12}>
        <Card className={this.state.workhours_card}>        
           {/** <CardHeader color="primary">
          <GridContainer>
            <GridItem  xs={10} sm={10} md={10}>
              <h4 className={classes.cardTitleWhite}>Work Hours </h4>
              <p className={classes.cardCategoryWhite}>
                Please set the work hours.           
              </p>
            </GridItem>
            <Grid xs={2} item sm={2} md={2} className={classes.header_2}>
               
                  <Tooltip
                  className={this.state.toolTip_status}
                  id="tooltip-top-start"
                  title="Add Service"
                  placement="top"
                  classes={{ tooltip: classes.tooltip }}
                  >
                    <IconButton
                      aria-label="Close"
                      className={classes.tableActionButton}
                      onClick={this.crateWrokhours}
                    >
                      <Create
                        className={
                           classes.create
                        }
                      />
                    </IconButton>
                  </Tooltip>
                   
            </Grid>          
           </GridContainer>
          </CardHeader>*/}
       
          <CardBody className={classes.cardBody_1}>
              {this.table_body()}    
          </CardBody>
          {this.cardFooter()}
        </Card>
      </GridItem> 
      {/** delete category dialog */}
      <Dialog
        open={this.state.open_dia2}
        onClose={this.confirmDialogClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">{"Are you sure to delete?"}</DialogTitle>
        <DialogContent>       
        </DialogContent>
        <DialogActions>
          <Button onClick={this.confirmDialogClose} variant="subtitle1" color="secondary" autoFocus>
            Cancel
          </Button>
          <Button  onClick={this.confirmCateDelete} variant="contained" color="secondary" >
            Yes
          </Button>
        </DialogActions>
      </Dialog>
     </Grid>
    )
  }
}
export default withStyles(openHoursStyle)(withSnackbar(withLocalization(withAuth(OpenHours))));
