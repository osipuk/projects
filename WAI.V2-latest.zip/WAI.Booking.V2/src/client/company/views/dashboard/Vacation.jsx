import React from 'react';
//import classNames from 'classnames';
import withStyles from '@material-ui/core/styles/withStyles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Success from '@material-ui/icons/CheckCircle';
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import Edit from "@material-ui/icons/Edit";
import Close from "@material-ui/icons/Close";
import Create from '@material-ui/icons/AddCircle';
import Grid from '@material-ui/core/Grid';
import TextField from '@material-ui/core/TextField';
import InputLabel from '@material-ui/core/InputLabel';
import DialogTitle from '@material-ui/core/DialogTitle';
import Select from '@material-ui/core/Select';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Checkbox from '@material-ui/core/Checkbox';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import moment from 'moment'
import {  withSnackbar } from 'notistack';
import MuiExpansionPanel from '@material-ui/core/ExpansionPanel';
import MuiExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import MuiExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';

import axios from 'axios';
import { DateRangePicker } from 'react-dates';
import 'react-dates/initialize';
import 'react-dates/lib/css/_datepicker.css';

import withAuth from '../../../common/contexts/AuthContext';
//import withLoading from '../../../common/contexts/LoadingContext';
import withNotifications from '../../../common/contexts/NotificationsContext';
import GridItem from "../../../common/components/Grid/GridItem.jsx";
import GridContainer from "../../../common/components/Grid/GridContainer.jsx";
import withLocalization from '../../../common/contexts/LocalizationContext';
import Card from "../../../common/components/Card/Card.jsx";
import CardHeader from "../../../common/components/Card/CardHeader.jsx";
import CardBody from "../../../common/components/Card/CardBody.jsx";
import CustomInput from "../../../common/components/CustomInput/CustomInput.jsx";
import CardFooter from "../../../common/components/Card/CardFooter.jsx";
//import Button from "../../../common/components/CustomButtons/Button.jsx";
import vacationStyle from '../../assets/css/vacation';


var today=new Date();
today=moment(today).format('YYYY-MM-DD');
//today=moment(today);
class Vacation extends React.Component {
  constructor(props){
    super (props);
    this.state={
      labelWidth:0,
      employees:[],       
      expanded:0,
      vacations:[],
      comment:'',
      fromDate:today,
      toDate:today,
      employeeId:'',
      open_dia2:false,
      open_dia3:false,
      warnningMsg:'',     
      vacation_card:this.props.classes.vacation_card_disable,//service_card_visible//vacation_card_disable
      addDialog:false,
      vacation_state:'Add',
      vacationId:'',
      focusedInput:null,
      dialog_class:true,
      startDate:null,
      endDate:null

    };
    this.loadEmployees=this.loadEmployees.bind(this);    
  }
  componentDidMount(){
  //this.loadEmployees();
  this.employeeChange_1(this.props.employeeId);
 
 
  }
  async loadEmployees(){
    const {localization,auth}=this.props;
    const { data } = await axios.get('/api/company/employee');   
    if(data.success){
      this.setState({employees:data.employees});
      //this.employeeChange_1(this.props.employeeId);
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
  }   
 
  handleChange = panel => async (event, expanded) => { 
    console.log(panel,'ddd');
    this.loadVacation(panel);
    this.setState({
      expanded: expanded ? panel : false,
      employeeId:panel
    });
  };
  loadVacation=async(employeeId)=>{
    const {localization,auth}=this.props; 
    
    const { data } = await axios.get('/api/company/vacation/employee/'+employeeId);    
    console.log(data,employeeId);
    if(data.success){
          this.setState({vacations:data.vacation})
        /**
        if(data.vacation.length!=0){
           let fromDate=moment(data.vacation.fromDate).format('YYYY-MM-DD');
           let toDate=moment(data.vacation.toDate).format('YYYY-MM-DD');         
          this.setState({
            fromDate:(fromDate=='1899-11-30' || fromDate=='0000-00-00')?'':fromDate,
            toDate:(toDate=='1899-11-30' ||toDate=='0000-00-00') ?'':toDate,
            comment:data.vacation.comment
          })
        }        
        else{      
          this.setState({
            fromDate:'',
            toDate:'',
            comment:''
          })
        } */
       
    }
    else{
     
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
  }
  someChange = prop => event => this.setState({ [prop]: event.target.value });
  someText=()=>{
    console.log('this is the text');
  }
  saveChanges=async(employeeId)=>{
    const {localization,auth}=this.props;        
    const{fromDate,toDate,comment,vacation_state,vacationId}=this.state;
    if(fromDate=='' || toDate==''){
      this.props.enqueueSnackbar(localization.localizedString('INCORRECT_VACATION_DATE'), { 
        variant: 'warning',
      }); 
      return;
    }

    if(vacation_state=='Add'){
      var { data } = await axios.post('/api/company/vacation/employee/'+employeeId,{
        vacation:{
          fromDate:fromDate,
          toDate:toDate,
          comment:comment
        }
      });
      console.log(data)
    }
    else if(vacation_state=='Update'){
      var { data } = await axios.put('/api/company/vacation/'+vacationId,{
        vacation:{
          fromDate:fromDate,
          toDate:toDate,
          comment:comment,
          employeeId:employeeId
        }
      });
      
    }
    
   
    if(data.success){
      this.loadVacation(this.state.employeeId);     
      this.props.enqueueSnackbar(localization.localizedString('SAVED_SUCCESS'), { 
        variant: 'success',
      }); 
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==3 || data.errorCode==6 ){
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else if(data.errorCode==33){
         console.log(data);
         if(data.bookingAccept!=0 && data.bookingRequest!=0){
            var message=localization.localizedString('YOU_HAVE_BOTH_BOOKING_REQUEST');
            message=message.replace('xx',data.bookingRequest);
            message=message.replace('yy',data.bookingAccept);
            this.setState({warnningMsg:message,open_dia2:true})
         }
         else if(data.bookingAccept!=0 && data.bookingRequest==0){
            var message=localization.localizedString('YOU_HAVE_ONLY_BOOKING');            
            message=message.replace('yy',data.bookingAccept);
            this.setState({warnningMsg:message,open_dia2:true})
         }
         else if(data.bookingAccept==0 && data.bookingRequest!=0){
          var message=localization.localizedString('YOU_HAVE_ONLY_BOOKING_REQUEST');            
          message=message.replace('xx',data.bookingRequest);
          this.setState({warnningMsg:message,open_dia2:true})
       }    
      
       }
       else{
        if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
          this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
            variant: 'error',
          }); 
          await auth.get();       
         }
         else{        
          this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
            variant: 'error',
          }); 
         }
       }
    }
 
    this.setState({addDialog:false})

  }
  saveProcess=async()=>{
    const {localization,auth}=this.props;    
    const{fromDate,toDate,comment,vacation_state,employeeId,vacationId}=this.state;
    if(fromDate=='' || toDate==''){
      this.props.enqueueSnackbar(localization.localizedString('INCORRECT_VACATION_DATE'), { 
        variant: 'warning',
      }); 
      return;
    }
   if(vacation_state=='Add'){
    var  { data } = await axios.post('/api/company/vacation/employee/'+this.state.employeeId+'/bookcancel',{
      vacation:{
        fromDate:fromDate,
        toDate:toDate,
        comment:comment

      }
    });
   }
   else if(vacation_state=='Update'){
    var  { data } = await axios.put('/api/company/vacation/'+vacationId+'/bookcancel',{
      vacation:{
        fromDate:fromDate,
        toDate:toDate,
        comment:comment,
        employeeId:employeeId

      }
    });
   }
    
    if(data.success){
      this.loadVacation(this.state.employeeId);
      this.setState({open_dia2:false});
      this.props.enqueueSnackbar(localization.localizedString('SAVED_SUCCESS'), { 
        variant: 'success',
      }); 
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
  }
  remove=()=>{
    this.setState({fromDate:'',toDate:'',comment:''})
  }
  toDateChange=(event)=>{ 
     if(this.state.fromDate>event.target.value || today>event.target.value)
        return;
    this.setState({toDate:event.target.value});    
  }
  fromDateChange=(event)=>{
    if(this.state.toDate<event.target.value && this.state.toDate!='' || today>event.target.value)
    return;
    this.setState({fromDate:event.target.value});
  }
  confirmDialogClose=()=>{
    this.setState({ open_dia2: false,addDialog:false,open_dia3:false});
  }
  employeeChange=(event)=>{   
    if(event.target.value=='0' || event.target.value==''){
      this.setState({vacation_card:this.props.classes.vacation_card_disable,
        [event.target.name]: event.target.value,vacations:[]
      });    
      return;
    }
    this.loadVacation(event.target.value);
    this.setState({vacation_card:this.props.classes.vacation_card_visible,
      [event.target.name]: event.target.value});    
  }
  employeeChange_1=(employeeId)=>{   
    if(employeeId=='0' || employeeId==''){
      this.setState({vacation_card:this.props.classes.vacation_card_disable,
        employeeId: employeeId,vacations:[]
      });    
      return;
    }
    this.loadVacation(employeeId);
    this.setState({vacation_card:this.props.classes.vacation_card_visible,
      employeeId: employeeId});    
  }
  vacationDelete=()=>{
      this.setState({
     open_dia3:true
    })
  }
  deleteProcess=async()=>{
      const {localization,auth}=this.props;
      var { data } = await axios.delete('/api/company/vacation/'+this.state.vacationId);
      if(data.success){       
        this.props.enqueueSnackbar(localization.localizedString('DELETED_SUCCESS'), { 
          variant: 'success',
        }); 
        this.loadVacation(this.state.employeeId);
      }
      else{
        if(data.errorCode==2 || data.errorCode==3 || data.errorCode==5  || data.errorCode==6 ){        
          this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
            variant: 'error',
          }); 
          await auth.get();       
         }
         else{        
          this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
            variant: 'error',
          }); 
         }
      }
      this.setState({open_dia3:false,addDialog:false})
  }
  editChange=(row)=>{
    this.setState({
        fromDate:moment(row.fromDate).format('YYYY-MM-DD'),
        toDate:moment(row.toDate).format('YYYY-MM-DD'),
        comment:row.comment,
        vacation_state:"Update",
        addDialog:true,
        vacationId:row.id
    })
  }
  createVacation=()=>{
    this.setState({addDialog:true,
      vacation_state:'Add',
      comment:'',
      fromDate:today,
      toDate:today,
      vacationId:''
    })
  }
  table_body=()=>{
    const { classes,localization } = this.props;
    let tbl=[];
    let trs=[];
    let num=0;
    /**
    if(Object.keys(this.state.workHours).length==0 && this.state.add_command==''){
      return <h4 className={classes.nothing_1}>The work hours was not set.</h4>
    }
     */   
    this.state.vacations.map(row=>{
       num++;
        trs.push(<TableRow hover
          key={row.id} >         
          <TableCell  className={classes.tableCell+" "+classes.gray_title} >
            {num}
          </TableCell>
          <TableCell className={classes.gray_title}>{moment(row.fromDate).format('YYYY-MM-DD')}</TableCell>
          <TableCell className={classes.gray_title}>{moment(row.toDate).format('YYYY-MM-DD')}</TableCell>
          <TableCell className={classes.gray_title}>{row.comment}</TableCell>
          <TableCell  className={classes.tableCellId+" "+ classes.gray_title}>
            <Tooltip
              id="tooltip-top"
              title="Edit Product"
              placement="top"
              classes={{ tooltip: classes.tooltip }}
            >
              <IconButton
                aria-label="Edit"
               
                onClick={() =>(this.editChange(row))}                
              >
                <Edit
                  className={
                    classes.tableActionButtonIcon + " " + classes.edit
                  }
                />
              </IconButton>
             </Tooltip>
            </TableCell>            
          </TableRow>
          )
    })
    return <Table className={classes.table}>
              <TableHead>
                <TableRow>
                  <TableCell className={classes.tableHeader_2}>No.</TableCell>
                  <TableCell className={classes.tableHeader_2}>From Date</TableCell>
                  <TableCell className={classes.tableHeader_2} align="left">To Date</TableCell>
                  <TableCell className={classes.tableHeader_2} align="left">Comment</TableCell>
                  <TableCell className={classes.tableHeader_2+" "+classes.tableCellId} align="center">Edit</TableCell>
                                 
                </TableRow>
              </TableHead>
              <TableBody>      
              {trs}    
              </TableBody>
              </Table>
  }
  changeDate=(startDate,endDate)=>{    
    if(!endDate){
      console.log('dddddsdfsdfdsf');
      this.setState({dialog_class:true});
    }
    this.setState({startDate,endDate,dialog_class:true});
  }
  render(){
    const { classes,localization } = this.props;
    const { expanded,employees,dialog_class } = this.state;
    return(
      <Grid container className={classes.container_1}>   
          <GridItem xs={2} sm={2} md={7}>             
            </GridItem>
            <Grid xs={10} item sm={10} md={5} className={classes.header_2}> 
              <Button variant="contained" 
                onClick={this.createVacation}
                className={this.state.toolTip_status}
              color="secondary" >                
                  <Create
                    className={
                        classes.create
                    }
                  />
                Add Vacation
              </Button>   

              <Button variant="outlined" 
                onClick={()=>this.props.nextPage('default')}
                 className={classes.button_2}> 
               Back
              </Button> 
          </Grid>          
       {/** work hours card// vacation_card*/}
       <GridItem xs={12} sm={12} md={12}>
        <Card >
          {/**
          <CardHeader color="primary">
          <GridContainer>
            <GridItem  xs={10} sm={10} md={10}>
              <h4 className={classes.cardTitleWhite}>Vacation Setting</h4>
              <p className={classes.cardCategoryWhite}>
                Please set the vacation date          
              </p>
            </GridItem>
            <Grid xs={2} item sm={2} md={2} className={classes.header_2}>
                  <Tooltip
                  className={this.state.toolTip_status}
                  id="tooltip-top-start"
                  title="Add Service"
                  placement="top"
                  classes={{ tooltip: classes.tooltip }}
                  >
                    <IconButton
                      aria-label="Close"
                      className={classes.tableActionButton}
                      onClick={this.createVacation}
                    >
                      <Create
                        className={
                           classes.create
                        }
                      />
                    </IconButton>
                  </Tooltip>
            </Grid>
          </GridContainer>
          </CardHeader>
           */}
          <CardBody className={classes.cardBody_1}>
              {this.table_body()}
              {
                this.state.vacations.length==0?<h4 className={classes.nothing_label}>There is nothing</h4>:""
              }
          </CardBody>       
         </Card>
        </GridItem>
        
         {/** for add/update product */}
         <Dialog
          fullWidth={true}
          maxWidth={'sm'}
          open={this.state.addDialog}
          onClose={this.confirmDialogClose}
          aria-labelledby="max-width-dialog-title"         
        >         
          <DialogTitle id="simple-dialog-title" className={classes.dialog_title}>{this.state.vacation_state} Product</DialogTitle> 
          <DialogContent >
           
            <Grid
                  container  >
                           

                              <Grid xs={12} sm={12} md={12} item
                                className={classes.calander_2}
                              >
                                 <form className={classes.container} noValidate>
                                    <TextField
                                      id="date"
                                      label="Vacation From"
                                      type="date"
                                      onChange={this.fromDateChange}
                                      value={this.state.fromDate}
                                      className={classes.textField}
                                      InputLabelProps={{
                                        shrink: true,
                                      }}
                                    />
                                  </form>                                  
                              </Grid>
                             
                              <Grid
                                xs={12}
                                sm={12}
                                md={12}
                                item
                                className={classes.calander_2}
                              >
                                 <form className={classes.container} noValidate>
                                    <TextField
                                      id="date"
                                      label="Vacation To"
                                      type="date"
                                      onChange={this.toDateChange}
                                      value={this.state.toDate}
                                      className={classes.textField}
                                      InputLabelProps={{
                                        shrink: true,
                                      }}
                                    />
                                  </form>                                  
                              </Grid>                             
                              <Grid
                                xs={12}
                                sm={12}
                                md={12}
                                item
                                className={classes.formControl_5}
                              >
                                <CustomInput
                                labelText="Comment:"              
                                inputProps={{
                                value:this.state.comment,
                                multiline: true,
                                rows: 2
                                  }}
                                  formControlProps={{
                                    className:classes.customInput_1,   
                                    onChange: this.someChange('comment')
                                    }}
                                  />
                              </Grid>                             
                           </Grid>
             
                 
               
              </DialogContent>
              <DialogActions className={classes.cardFooter}>
              <GridItem xs={12} sm={12} md={6}>
                {
                  this.state.vacationId!=''?<Button color="primary" onClick={this.vacationDelete}>Delete</Button>:''
                } 
              </GridItem>
              <Grid item xs={12} sm={12} md={6} className={classes.cardFooter_1}>
                  <Button  onClick={this.confirmDialogClose}  color="secondary" className={classes.button_2}>Cancel</Button>
                  <Button  variant="contained" color="secondary"                  
                         onClick={()=>this.saveChanges(this.state.employeeId)}>Save</Button>
              </Grid>                         
              </DialogActions>
          </Dialog>
         {/** are sure category dialog */}
         <Dialog
            open={this.state.open_dia2}
            onClose={this.confirmDialogClose}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
          >
            <DialogTitle id="alert-dialog-title">{' '}</DialogTitle>
            <DialogContent> 
              <p>{this.state.warnningMsg}</p>      
            </DialogContent>
            <DialogActions>
              <Button onClick={this.confirmDialogClose} color="secondary" >
                No
              </Button>
              <Button  onClick={this.saveProcess} color="secondary" autoFocus>
                Yes
              </Button>
            </DialogActions>
          </Dialog> 
           {/** end diaolog */}  
           {/** are sure category dialog */}
            <Dialog
                open={this.state.open_dia3}
                onClose={this.confirmDialogClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
              >
                <DialogTitle id="alert-dialog-title">{' '}</DialogTitle>
                <DialogContent> 
                  <p>Are you sure to delete?</p>      
                </DialogContent>
                <DialogActions>
                  <Button onClick={this.confirmDialogClose} color="primary" autoFocus>
                    No
                  </Button>
                  <Button  onClick={this.deleteProcess} variant="contained" color="secondary" >
                    Yes
                  </Button>
                </DialogActions>
              </Dialog> 
          {/** end diaolog */}    
    </Grid>
    )
  }
}
export default withStyles(vacationStyle)(withSnackbar(withLocalization(withAuth(Vacation))));
