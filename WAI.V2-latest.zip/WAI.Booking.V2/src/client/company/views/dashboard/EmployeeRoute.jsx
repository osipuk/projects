import React from 'react';
import Employees from './Employees';
import OpenHours from './OpenHours';
import Vacation from './Vacation';

class EmployeeRoute extends React.Component {
  constructor(props){
  super (props);
    this.state={
      page:'default', 
      employeeId:0       
    };
  
  }
  componentDidMount(){
    
  }
  nextPage=(page,row)=>{
   if(page=='workhour'){
    this.setState({page:'workhour',employeeId:row.id})
   }
   else if(page=='vacation'){
      this.setState({page:'vacation',employeeId:row.id})
   }
   else {
     this.setState({page:'default'})
   }
  }
  
  renderPage=()=>{
    if(this.state.page=='vacation'){
      return  <Vacation nextPage={this.nextPage}  employeeId={this.state.employeeId}></Vacation>
    }  
    else if(this.state.page=='workhour'){
      return  <OpenHours nextPage={this.nextPage} employeeId={this.state.employeeId}></OpenHours>
    } 
    else if(this.state.page=='default'){
      return  <Employees nextPage={this.nextPage} ></Employees>
    }  
    
  }
  render(){    
    return(
      <div>
        {this.renderPage()}
      </div>
    )          
  }
}
export default EmployeeRoute;



