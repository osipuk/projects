import React from 'react';
//import classNames from 'classnames';
import withStyles from '@material-ui/core/styles/withStyles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Save from "@material-ui/icons/Save";
import Close from "@material-ui/icons/Close";
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import Success from '@material-ui/icons/CheckCircle';
import Grid from '@material-ui/core/Grid';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Button from '@material-ui/core/Button';
import axios from 'axios';
import Checkbox from '@material-ui/core/Checkbox';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import Input from '@material-ui/core/Input';

//import errors from '../../../common/error_codes';
import withAuth from '../../../common/contexts/AuthContext';
import withNotifications from '../../../common/contexts/NotificationsContext';
import GridItem from "../../../common/components/Grid/GridItem.jsx";
import GridContainer from "../../../common/components/Grid/GridContainer.jsx";
import withLocalization from '../../../common/contexts/LocalizationContext';
import Card from "../../../common/components/Card/Card.jsx";
import CardHeader from "../../../common/components/Card/CardHeader.jsx";
import CardBody from "../../../common/components/Card/CardBody.jsx";
import CustomInput from "../../../common/components/CustomInput/CustomInput.jsx";
import CardFooter from "../../../common/components/Card/CardFooter.jsx";
//import Button from "../../../common/components/CustomButtons/Button.jsx";
import serviceProductsStyle from '../../assets/css/products';

class ServiceProcuts extends React.Component {
  constructor(props){
    super (props);
    this.state={
      addDialog:false,//category dialog
      open_dia2:false,//confirm dialog       
      addService_modal:false,
      addAddon_modal:false,
      product_service:[],
      products:[],
      services:[],
      allServices:[],
      allServiceAddons:[],
      serviceAddons:[],
      category_state:'Add',
      gategoryId:'', 
      product_name:'',
      price:'',
      quantity:'',     
      bookingId:0,
      productId:0,
      total_price:0,
      product_item_ids:[],
      product_service_id:0,
      product_relation_id:0,
      services_total_price:0,
      serviceIdAdd:'',
      addonAddId:'',
      customerId:0,
      employees:[],
      employeeId:[]
    };
    this.confirmDelete=this.confirmDelete.bind(this);
    this.confirmDialogClose=this.confirmDialogClose.bind(this);
    this.createProduct=this.createProduct.bind(this);      
  }  
  componentDidMount(){   
   this.setState({bookingId:this.props.bookingId,});   
   this.products_services();
   this.loadProducts();

  }
  componentWillMount(){
    console.log(this.props.addons,'ssssssssss');
    this.setState({
      services:this.props.services,
      addons:this.props.addons,
      customerId:this.props.customerId
    });
  }

  loadProducts=async()=>{
    const { data } = await axios.get('/api/company/products');

    if(data.success){
      this.setState({products:data.products}); 
    }    
  }  
  loadBookServices=async()=>{
    const  {data} = await axios.get('/api/company/booking/'+this.state.bookingId+"/service"); 
    if(data.success){     
      this.setState({services:data.bookingServices,});
    }
  }
  loadBookAddons=async()=>{
    const  {data} = await axios.get('/api/company/booking/'+this.state.bookingId+'/extra');  
    if(data.success){
      this.setState({addons:data.bookingExtras});     
      
    }   
  }
  async products_services(){     
        const {notifications,localization,auth}=this.props;
        const { data } = await axios.get('/api/company/products_services/'+this.props.bookingId);     
      console.log(data,'dddddddddddd');
        if(data.success){
          var temps=[];
          data.products.map(row=>{
            temps.push(row.item_number);
          })

          this.setState({
            product_service:data.products,
            product_item_ids:temps,
            employees:data.employees
          });
        }
        else{      
            if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){
              notifications.show({message:localization.localizedString('YOUR_SESSION_HAS_EXPIRED')});
              await auth.get();       
            }
            else{
              notifications.show({message:localization.localizedError(data.errorCode)});
            }          
        }
  }
  saveChange=async(row)=>{
      var { data } = await axios.put('/api/company/products_services/'+row.id, {   
        product:{
                  quantity:row.quantity,                  
        }   
      });
      this.products_services();
    
  }  
  createProduct(){    
    this.setState({addDialog:true,     
      category_state:'Add'});
  }
  categoryDelete=async (val) => {
      this.setState({open_dia2:true,gategoryId:val});
      return;     
  }  
  async confirmDelete(){
        var { data } = await axios.delete('/api/company/products_services/'+this.state.product_service_id);
      
        if(data.success){
          var { data } = await axios.delete('/api/company/product_booking/'+this.state.product_relation_id);          
        }
        else{
          this.props.notifications.show({message:data.errorCode});
        }
        this.products_services();
        this.setState({open_dia2:false});
  }
  rowClickCategory(rowId){    
    this.setState({gategoryId:rowId})
  }
  dia1Close = () => {
    this.setState({ addDialog: false,addService_modal:false,addAddon_modal:false });
  }   
  
  rowProductClick=async(event,row)=>{
    console.log(event.target.checked,row);

    if(event.target.checked){
      var { data } = await axios.post('/api/company/products_services', {   
        product:{ itemName:row.name,
                  quantity:row.quantity,
                  category:row.category,
                  retailPrice:row.retailPrice,
                  wholeSalePrice:row.wholeSalePrice,
                  itemNumber:row.id    
        }   
      });

      if(data.success){
        this.setState({productId:data.product[0].id});
        var { data } = await axios.post('/api/company/product_booking', {
          product:{ bookingId:this.state.bookingId,
                    productId:this.state.productId,                 
          }   
        });
        this.setState({addDialog:false});
        this.products_services();
      }
    } 
  }
  handleChange = prop => event => this.setState({ [prop]: event.target.value });
  confirmDialogClose(){
      this.setState({ open_dia2: false });
  }
  cellEdit=(event,row)=>{   
    var temps = [];
    this.state.product_service.map(item=>{
      if(row.id==item.id){
        console.log('match');
        item.quantity=event.target.value;
        
      }
      temps.push(item);
    });
    this.setState({product_service:temps});

  }
  productDelete=(row)=>{    
    this.setState({
      open_dia2:true,
      product_service_id:row.id,
      product_relation_id:row.relationId});
  }
  serviceAdd=async()=>{
      const {notifications,localization,auth}=this.props;
      if(this.state.serviceIdAdd=='' || this.state.employeeId==''){
        return;
      }      
      console.log(this.state.bookingId,'save bookingid');
      var { data } = await axios.post('/api/company/booking/service/', {
        book_service:{ 
          serviceId:this.state.serviceIdAdd,
          bookingId:this.state.bookingId,
          customerId:this.state.customerId,
          employeeId:this.state.employeeId
        }
      });
      if(data.success){
        this.loadBookServices();
        this.setState({addService_modal:false});
        notifications.show({message: localization.localizedString('ADDED_SUCCESS'),icon:Success,color:'success'});
      }
      else{
        if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){
          notifications.show({message:localization.localizedString('YOUR_SESSION_HAS_EXPIRED')});
          await auth.get();       
        }
        else{
          notifications.show({message:localization.localizedError(data.errorCode)});
        }
      }
  }  
  addAddon=async()=>{
    const {notifications,localization,auth}=this.props;
    var service_ids=[];
    this.state.services.map(row=>{
      service_ids.push(row.sid);
    })
    const { data } = await axios.get('/api/company/service/extras/'+service_ids.join());     
    if(data.success){
      this.setState({
        allServiceAddons:data.serviceExtras, 
        addonAddId:'',
        addAddon_modal:true,
        employeeId:''        
      });    
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){
        notifications.show({message:localization.localizedString('YOUR_SESSION_HAS_EXPIRED')});
        await auth.get();       
       }
       else{
        notifications.show({message:localization.localizedError(data.errorCode)});
       }
    }
  }
  /**
   * save to the db
   */
  addonSave=async()=>{
    const {notifications,localization,auth}=this.props;
    if(this.state.addonAddId=='' || this.state.employeeId=='')
      return;
    var { data } = await axios.post('/api/company/booking/service_extra', {
      book_extra:{ 
        serviceExtraId:this.state.addonAddId,
        bookingId:this.state.bookingId,
        customerId:this.state.customerId,
        employeeId:this.state.employeeId
      }
    });

    if(data.success){
      notifications.show({message: localization.localizedString('ADDED_SUCCESS'),icon:Success,color:'success'});
      this.loadBookAddons();
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){
        notifications.show({message:localization.localizedString('YOUR_SESSION_HAS_EXPIRED')});
        await auth.get();       
       }
       else{
        notifications.show({message:localization.localizedError(data.errorCode)});
       }
    }    
    this.setState({addAddon_modal:false})
  }
  continueProcess=async()=>{
    const { classes,localization,auth,notifications } = this.props;

    var sumTotal=0
    this.state.services.map(row=>{
      sumTotal+=parseFloat(row.price);
    })
    this.state.addons.map(row=>{
      sumTotal+=parseFloat(row.price);
    })

    this.state.product_service.map(row=>{
      let price=row.retail_price==''?0:row.retail_price;
      let quantity=row.quantity==''?0:row.quantity;
      let total=parseFloat(price)*parseInt(quantity);   
      sumTotal+=total;   
    });

    var { data } = await axios.get('/api/company/payments/'+this.state.bookingId+'/booking');
    let paid_payment=0;
    if(data.success){
        data.payments.map(row=>{
          paid_payment+=parseFloat(row.paymentAmount);
        })

        if(sumTotal==paid_payment || sumTotal<paid_payment){
          var { data } = await axios.put('/api/company/booking/'+this.state.bookingId+"/completed");
          notifications.show({message: 'Payment '+this.getSumTotal()+' '+this.props.auth.user.currency_code +' has been marked as completed',icon:Success,color:'success'});
          this.props.goBeforePage('default');
        }
        else{          
          console.log('go to the payment')
          this.props.goOtherPage();
        }
    }
    //this.props.goOtherPage();
  }
  getSumTotal=()=>{
    var sumTotal=0
    this.state.services.map(row=>{
      sumTotal+=parseFloat(row.price);
    })
    this.state.addons.map(row=>{
      sumTotal+=parseFloat(row.price);
    })

    this.state.product_service.map(row=>{
      let price=row.retail_price==''?0:row.retail_price;
      let quantity=row.quantity==''?0:row.quantity;
      let total=parseFloat(price)*parseInt(quantity);   
      sumTotal+=total;   
    });
    return sumTotal=(Math.round(sumTotal*100)/100).toFixed(2);  
    //return <h4 >Total {sumTotal} {this.props.auth.user.currency_code}</h4>
  }
  showAddServiceModal=async()=>{
    const {notifications,localization,auth}=this.props;
    const { data } = await axios.get('/api/company/services');
    if(data.success){     
      this.setState({
        addService_modal:true,      
        allServices:data.services,
        serviceIdAdd:'',
        employeeId:''
      });
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){
        notifications.show({message:localization.localizedString('YOUR_SESSION_HAS_EXPIRED')});
        await auth.get();       
       }
       else{
        notifications.show({message:localization.localizedError(data.errorCode)});
       }
    }

   }
   serviceChange=async(event)=>{
    this.setState({     
      [event.target.name]: event.target.value,
    });   
  }
  editService_body=()=>{
    const { classes,localization } = this.props;
    var temp=[];   
    this.state.services.map(item=>{
      temp.push(item.sid);
    })  
    return <CardBody className={classes.cardBody_1+" "+classes.nothing_1}  >
    <GridContainer >
      <Grid xs={12} sm={12} item md={6}  >
              <FormControl className={classes.formControl_1}>
                <InputLabel htmlFor="service">Services</InputLabel>
                <Select
                  value={this.state.serviceIdAdd
                  }
                  onChange={this.serviceChange}
                  inputProps={{
                    name: 'serviceIdAdd',
                    id: 'service',
                  }}
                >
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  {
                      this.state.allServices.map(row=>{                       
                        if(temp.indexOf(row.id)==-1 ){                         
                          return <MenuItem key={row.id} value={row.id}>{row.name}</MenuItem>
                        }                       
                    })
                    }    
                      
                </Select>
              </FormControl>
      </Grid> 
      <Grid xs={12} sm={12} item md={5}  >
              <FormControl className={classes.formControl_1}>
                <InputLabel htmlFor="serviceEmployeeId">Employees</InputLabel>
                <Select
                  value={this.state.employeeId}
                  onChange={this.serviceChange}
                  inputProps={{
                    name: 'employeeId',
                    id: 'employeeId',
                  }}
                >
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  {
                      this.state.employees.map(row=>{                       
                        if(temp.indexOf(row.id)==-1 ){                         
                          return <MenuItem key={row.id} value={row.id}>{row.firstName+" "+row.lastName}</MenuItem>
                        }                       
                    })
                    }    
                      
                </Select>
              </FormControl>
      </Grid>           
     </GridContainer>
   </CardBody>
  }

  product_table_body=()=>{
    const { classes,localization } = this.props;  
    let tbl=[];
    let trs=[];    
    if(this.state.products.length==0){
      return <h4 className={classes.nothing_1}>There is nothing.</h4>
    }
    this.state.products.map(row => {
      let price=row.retailPrice==''?0:row.retailPrice;
      let quantity=row.quantity==''?0:row.quantity;
      let total=parseFloat(price)*parseInt(quantity);
      total=(Math.round(total*100)/100).toFixed(2);
      if(this.state.product_item_ids.indexOf(row.id)==-1)
      trs.push(<TableRow hover
              role="checkbox"
              key={row.id}>
              <TableCell className={classes.tableCellId} >
                        <Checkbox onChange={event=>this.rowProductClick(event,row)} checked={this.state.monday_is_open} />
              </TableCell>
              <TableCell  className={classes.tableCell} >
                {row.name}
              </TableCell>
              <TableCell  >{row.retailPrice}</TableCell>
              <TableCell >{row.quantity}</TableCell>
              <TableCell >{total}</TableCell>       
              </TableRow>);      
    })

    tbl.push(<Table key={1} className={classes.table}>
      <TableHead >
        <TableRow>  
          <TableCell className={classes.tableHeader_1}>Select</TableCell>        
          <TableCell  className={classes.tableCell+" "+classes.tableHeader_1}> Name</TableCell>
          <TableCell  className={classes.tableHeader_1}>Price</TableCell>
          <TableCell  className={classes.tableHeader_1}>Quantity</TableCell>
          <TableCell  className={classes.tableHeader_1}>Total</TableCell>          
        </TableRow>
      </TableHead>
      <TableBody>
        {trs}
      </TableBody>
    </Table>);
    return tbl;  
  }
  service_table_body=()=>{
    const { classes,localization } = this.props;
    let tbl=[];
    let trs=[];       
    this.state.services.map(row => {   
      var employeeName='';
      this.state.employees.map(item=>{
        if(item.id==row.employee_id)
          employeeName=item.firstName+" "+item.lastName;
      });
      
      trs.push(<TableRow hover
      key={row.id} >     
        <TableCell  className={classes.tableCell+" "+classes.gray_title} >
          {row.name}
        </TableCell>        
        <TableCell className={classes.gray_title}>{row.duration}</TableCell>    
        <TableCell  className={classes.gray_title}>{row.price}</TableCell>  
        <TableCell  className={classes.tableCell+" "+classes.gray_title} >
          {employeeName}
        </TableCell>        
      </TableRow>);      
      })    
      if(this.state.services.length==0){
        return '';
      }

      tbl.push(<Table key={1} className={classes.table}>
        <TableHead >
          <TableRow>          
            <TableCell  className={classes.tableCell+" "+classes.tableHeader_2}>Serives Name</TableCell>
            <TableCell  className={classes.tableHeader_2}>Time(minutes)</TableCell>  
            <TableCell  className={classes.tableHeader_2}>Price  ({this.props.auth.user.currency_code})</TableCell> 
            <TableCell  className={classes.tableCell+" "+classes.tableHeader_2}>Employee</TableCell>                  
          </TableRow>
        </TableHead>
        <TableBody>
          {trs}
        </TableBody>
      </Table>);
    return tbl;
  }
  addons_table_body=()=>{
    const { classes,localization } = this.props;
    let tbl=[];
    let trs=[];    

    if(this.state.addons.length==0){
      return '';
    }   
      this.state.addons.map(row => {   
        var employeeName="";
        this.state.employees.map(item=>{
          if(item.id==row.employeeId){
            employeeName=item.firstName+" "+item.lastName;
          }
        })    
        trs.push(<TableRow hover
        key={row.id+"a"} >      
        <TableCell  className={classes.tableCell+" "+classes.gray_title} >
          {row.name}
        </TableCell>
        <TableCell className={classes.gray_title}>{row.duration}</TableCell>
        <TableCell  className={classes.gray_title}>{row.price}</TableCell>     
        <TableCell  className={classes.tableCell+" "+classes.gray_title} >
          {employeeName}
        </TableCell>          
      </TableRow>);      
      })
   
      tbl.push(<Table key={1} className={classes.table}>
        <TableHead >
          <TableRow>          
            <TableCell  className={classes.tableCell+" "+classes.tableHeader_2}>Serive Addons Name</TableCell>
            <TableCell  className={classes.tableHeader_2}>Time(minutes)</TableCell>  
            <TableCell  className={classes.tableHeader_2}>Price ({this.props.auth.user.currency_code})</TableCell>  
            <TableCell  className={classes.tableCell+" "+classes.tableHeader_2}>Employee</TableCell>                  
          </TableRow>
        </TableHead>
        <TableBody>
          {trs}
        </TableBody>
      </Table>);
    return tbl;
  }
  editAddon_body=()=>{
    const { classes,localization } = this.props;
    var temp=[];   
    this.state.addons.map(item=>{
      temp.push(item.eid);
    })   
    return <CardBody className={classes.cardBody_1}  >
    <GridContainer >      
      <Grid xs={12} sm={12} item md={6}  >
         <FormControl className={classes.formControl_1}>
                <InputLabel htmlFor="age-simple">Service Addons</InputLabel>
                <Select
                  value={this.state.addonAddId}
                  onChange={this.serviceChange}
                  inputProps={{
                    name: 'addonAddId',
                    id: 'age-simple',
                  }}
                >
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  {
                      this.state.allServiceAddons.map(row=>{
                        if(temp.indexOf(row.id)==-1 )
                        return <MenuItem key={row.id} value={row.id}>{row.name}</MenuItem>
                      })
                    }    
                      
                </Select>
            </FormControl>
        </Grid>
        <Grid xs={12} sm={12} item md={5}  >
              <FormControl className={classes.formControl_1}>
                <InputLabel htmlFor="serviceEmployeeId">Employees</InputLabel>
                <Select
                  value={this.state.employeeId}
                  onChange={this.serviceChange}
                  inputProps={{
                    name: 'employeeId',
                    id: 'employeeId',
                  }}
                >
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  {
                      this.state.employees.map(row=>{                       
                        if(temp.indexOf(row.id)==-1 ){                         
                          return <MenuItem key={row.id} value={row.id}>{row.firstName+" "+row.lastName}</MenuItem>
                        }                       
                    })
                    }    
                      
                </Select>
              </FormControl>
      </Grid>
     </GridContainer>
   </CardBody>
  }
  product_service_table_body=()=>{
    const { classes,localization } = this.props;
    let tbl=[];
    let trs=[];   
    if(this.state.product_service.length==0)
    return null;
    this.state.product_service.map(row => {
      let price=row.retail_price==''?0:row.retail_price;
      let quantity=row.quantity==''?0:row.quantity;
      let total=parseFloat(price)*parseInt(quantity);
      total=(Math.round(total*100)/100).toFixed(2);
      trs.push(<TableRow hover
      key={row.id} >
     
      <TableCell  className={classes.tableCell} >
        {row.item_name}
      </TableCell>
      <TableCell  >{row.retail_price}</TableCell>
      <TableCell ><Input fullWidth={false} className={classes.tableCell_1} onChange={event=>(this.cellEdit(event,row))} value={row.quantity}></Input></TableCell>
      <TableCell >{total}</TableCell>
      <TableCell  className={classes.tableCellId}>
            <Tooltip
              id="tooltip-top"
              title="Edit Product"
              placement="top"
              classes={{ tooltip: classes.tooltip }}
            >
              <IconButton
                aria-label="Edit"
                className={classes.tableActionButton}  
                onClick={() =>(this.saveChange(row))}
                
              >
                <Save
                  className={
                    classes.tableActionButtonIcon + " " + classes.edit
                  }
                />
              </IconButton>
            </Tooltip>
      </TableCell>
      <TableCell  className={classes.tableCellId}>
          <Tooltip
            id="tooltip-top-start"
            title="Remove"
            placement="top"
            classes={{ tooltip: classes.tooltip }}
          >
            <IconButton
              aria-label="Close"
              className={classes.tableActionButton}
              onClick={() =>(this.productDelete(row))}
            >
              <Close
                  className={
                  classes.tableActionButtonIcon + " " + classes.close
                }
              />
            </IconButton>
          </Tooltip>
      </TableCell>       
    </TableRow>);      
    })

    tbl.push(<Table key={1} className={classes.table}>
      <TableHead >
        <TableRow>          
          <TableCell  className={classes.tableCell+" "+classes.tableHeader_1}>Product Name</TableCell>
          <TableCell  className={classes.tableHeader_1}>Price</TableCell>
          <TableCell  className={classes.tableHeader_1}>Quantity</TableCell>
          <TableCell  className={classes.tableHeader_1}>Total  {this.props.auth.user.currency_code}</TableCell>
          <TableCell  className={classes.tableCellId+" "+classes.tableHeader_1}>Edit</TableCell>
          <TableCell  className={classes.tableCellId+" "+classes.tableHeader_1}>Delete</TableCell>
        </TableRow>
      </TableHead>
      <TableBody>
        {trs}
      </TableBody>
    </Table>);
    return tbl;    
  }
  render(){
    const { classes,localization } = this.props;
     return(
      <GridContainer>
      <GridItem xs={12} sm={12} md={12}>
        <Card>
          <CardHeader color="primary">            
          <GridContainer>
            <GridItem xs={12} sm={12} md={7}>
              <h4 className={classes.cardTitleWhite}>Services and Products</h4>
              <p className={classes.cardCategoryWhite}>             
              </p>
            </GridItem>
           
            <Grid xs={12} item sm={12} md={5} className={classes.header_2}>
              <Button variant="contained" size="small" color="secondary"  onClick={this.showAddServiceModal} className={classes.margin_r}>
                Add Service
              </Button>
              <Button variant="contained" size="small" color="secondary" onClick={this.addAddon} className={classes.margin_r}>
                Add Addons
              </Button>
              <Button variant="contained" size="small" color="secondary"   onClick={this.createProduct} className={classes.margin}>
                Add Product
              </Button>                  
            </Grid>
           </GridContainer>
            
          </CardHeader>
          <CardBody className={classes.cardBody_1}>
              {this.service_table_body()}  
              {this.addons_table_body()};
              {this.product_service_table_body()}           
          </CardBody>
          <GridContainer>
              <Grid item xs={6} sm={6} md={10}>
                               
              </Grid>
              <Grid item xs={6} sm={6} md={2}>
                 <h4 >Total {this.getSumTotal()} {this.props.auth.user.currency_code}</h4>
               

              </Grid>
           </GridContainer>
          <DialogActions>              
            <Button  variant="contained" color="secondary" onClick={this.continueProcess} >Go To Payment</Button>            
           </DialogActions>  
        </Card>
      </GridItem>      
      
      {/** for add/update product */}
      <Dialog
          fullWidth={true}
          maxWidth={'md'}
          open={this.state.addDialog}
          onClose={this.dia1Close}
          aria-labelledby="max-width-dialog-title"         
        >         
          <DialogContent className={classes.dialog_2}>
            <Card className={classes.card_2}>
              <CardHeader color="success">
                <h4 className={classes.cardTitleWhite}>{this.state.serivice_state} Product</h4>
                <p className={classes.cardCategoryWhite}>                  
                </p>
              </CardHeader>
             
              <CardBody className={classes.cardBody_1}>
                      {this.product_table_body()}
              </CardBody>
              <CardFooter className={classes.cardFooter_2}>                
               <Button  variant="contained" color="secondary" onClick={this.dia1Close}>Cancel</Button>                
              </CardFooter>             
            </Card>  
          </DialogContent>         
      </Dialog>  
    {/** delete category dialog */}
      <Dialog
        open={this.state.open_dia2}
        onClose={this.confirmDialogClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">{"Are you sure to remove?"}</DialogTitle>
        <DialogContent>       
        </DialogContent>
        <DialogActions>
          <Button onClick={this.confirmDialogClose} variant="contained" color="secondary" >
            Cancel
          </Button>
          <Button  onClick={this.confirmDelete} variant="contained" color="secondary" autoFocus>
            Yes
          </Button>
        </DialogActions>
      </Dialog>
      {/** add service */}
        <Dialog
          open={this.state.addService_modal}
          onClose={this.dia1Close}
          fullWidth={true}
          maxWidth={'sm'}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
        <DialogTitle id="simple-dialog-title" className={classes.dialog_title}>Add a Service</DialogTitle>  
        <DialogContent className={classes.dialog_22}>         
                { this.editService_body()}         
        </DialogContent>
        <DialogActions className={classes.cardFooter}>
            <GridItem xs={12} sm={12} md={6}>            
            </GridItem>
            <Grid item xs={12} sm={12} md={6} className={classes.cardFooter_1}>
               <Button variant="contained"    onClick={this.dia1Close} >Cancel</Button>
              <Button variant="contained" className={classes.button_2} color="secondary" onClick={this.serviceAdd} >Save</Button>
            </Grid>
         
        </DialogActions>
      </Dialog>
      {/** end service */}
      {/** add addons */}
      <Dialog
        open={this.state.addAddon_modal}
        onClose={this.dia1Close}
        fullWidth={true}
        maxWidth={'sm'}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="simple-dialog-title" className={classes.dialog_title}>Add Service Addon</DialogTitle>  
        <DialogContent className={classes.dialog_2}>          
                { this.editAddon_body()} 
        </DialogContent>
        <DialogActions>
          <GridItem xs={12} sm={12} md={6}>            
            </GridItem>
            <Grid item xs={12} sm={12} md={6} className={classes.cardFooter_1}>
               <Button variant="contained"    onClick={this.dia1Close} >Cancel</Button>
              <Button variant="contained" className={classes.button_2} color="secondary" onClick={this.addonSave} >Save</Button>
            </Grid>          
        </DialogActions>
      </Dialog>
      </GridContainer>
     )
   }
}
export default withStyles(serviceProductsStyle)(withNotifications(withLocalization(withAuth(ServiceProcuts))));
