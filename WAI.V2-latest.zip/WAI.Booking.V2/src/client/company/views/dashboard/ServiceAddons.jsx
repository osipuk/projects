import React,{useState } from 'react';
import ReactDOM from 'react-dom';
import withStyles from '@material-ui/core/styles/withStyles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Edit from "@material-ui/icons/Edit";
import Close from "@material-ui/icons/Close";
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import Create from '@material-ui/icons/AddCircle';
import Grid from '@material-ui/core/Grid';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Select from '@material-ui/core/Select';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import Success from '@material-ui/icons/CheckCircle';
import { withSnackbar } from 'notistack';
import axios from 'axios';
import Typography from '@material-ui/core/Typography';
import withAuth from '../../../common/contexts/AuthContext';
//import withNotifications from '../../../common/contexts/NotificationsContext';
import GridItem from "../../../common/components/Grid/GridItem.jsx";
import GridContainer from "../../../common/components/Grid/GridContainer.jsx";
import withLocalization from '../../../common/contexts/LocalizationContext';
import Card from "../../../common/components/Card/Card.jsx";
import CardHeader from "../../../common/components/Card/CardHeader.jsx";
import CardBody from "../../../common/components/Card/CardBody.jsx";
import CustomInput from "../../../common/components/CustomInput/CustomInput.jsx";
import CardFooter from "../../../common/components/Card/CardFooter.jsx";
import Button from "../../../common/components/CustomButtons/Button.jsx";
import servicesStyle from '../../assets/css/services';

class ServiceAddons extends React.Component {
  constructor(props){
    super (props);
    this.state={
      open_dia1:false,//addons dialog
      open_dia2:false,//confirm dialog
      open_dia3:false,//service dialog 
      services:[],
      addons:[],
      addon_state:'Add',
      addon_name:'',
      addon_description:'',
      addon_duration:'',
      addon_price:'',
      addon_gender:'',
      addonId:0,
      serviceId:0,
      labelWidth:0,
      deleteType:'',
      can_vary:false,
      addons_card:this.props.classes.service_card_disable,     
    };
    this.createAddons=this.createAddons.bind(this);
    this.confirmCateDelete=this.confirmCateDelete.bind(this);
    this.confirmDialogClose=this.confirmDialogClose.bind(this);  
    this.serviceChange=this.serviceChange.bind(this);   
    this.saveAddons=this.saveAddons.bind(this);  
  }  
  componentWillMount(){
    this.loadServices();   
  }
  loadServices=async()=>{
       const {localization,auth}=this.props;   
       await auth.get();   
        const { data } = await axios.get('/api/company/services');        
        if(data.success){
          this.setState({services:data.services});
        }
        else{
          if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
            this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
              variant: 'error',
            }); 
            await auth.get();       
           }
           else{        
            this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
              variant: 'error',
            }); 
           }
        } 
  }
  handleToggle = prop => event => this.setState({ [prop]: event.target.checked });

  editChange=(val)=>{   
    this.setState({category_state:'Update',category_name:val,open_dia1:true});
  }
  createAddons(){
    this.setState({
      open_dia1:true,
      addon_state:'Add',
      addon_name:'',
      addon_description:'',
      addon_duration:'',
      can_vary:false,
      addon_price:'',
      addon_gender:'',      
    });
  }
  editAddon=(row)=>{
    this.setState({
      open_dia1:true,
      addon_state:'Update',
      addon_name:row.name,
      addon_description:row.description,
      addon_duration:row.duration,
      can_vary:row.vary?true:false,
      addon_price:row.price,
      addon_gender:row.gender,
      addonId:row.id      
    });
  }
  addonDelete=async (val) => {
    this.setState({open_dia2:true,addonId:val,deleteType:'addon'});
    return;     
  }
  async confirmCateDelete(){
     const {localization,auth}=this.props; 
      var { data } = await axios.delete('/api/company/service/extra/'+this.state.addonId);
      if(data.success){       
        this.props.enqueueSnackbar(localization.localizedString('DELETED_SUCCESS'), { 
          variant: 'success',
        });  
        const { data } = await axios.get('/api/company/service/extra/'+this.state.serviceId);
        if(data.success){
          this.setState({addons:data.serviceExtras});
        }
        else{
          if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
            this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
              variant: 'error',
            }); 
            await auth.get();       
           }
           else{        
            this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
              variant: 'error',
            }); 
           }          
        }
        this.setState({open_dia2:false});
      }   
  } 
  dia1Close = () => {
    this.setState({ open_dia1: false });
  } 
  handleChange = prop => event => this.setState({ [prop]: event.target.value });
  confirmDialogClose(){
      this.setState({ open_dia2: false });
  }
  async saveAddons(){  
    const {localization,auth}=this.props;  
    if(this.state.addon_state=='Add'){
      var { data } = await axios.post('/api/company/service/extra', {
        extra:{ 
        serviceId:this.state.serviceId,
        name:this.state.addon_name,
        description:this.state.addon_description,
        price:this.state.addon_price,
        duration:this.state.addon_duration,
        vary:this.state.can_vary,
        gender:this.state.addon_gender}
      });

      if(data.success){
        this.props.enqueueSnackbar(localization.localizedString('ADDED_SUCCESS'), { 
          variant: 'success',
        });       
      }
      else{
        if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
          this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
            variant: 'error',
          }); 
          await auth.get();       
         }
         else{        
          this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
            variant: 'error',
          }); 
         }
      }

    }
    else{
      var { data } = await axios.put('/api/company/service/extra/'+this.state.addonId, {
        extra:{ 
        serviceId:this.state.serviceId,
        name:this.state.addon_name,
        description:this.state.addon_description,
        price:this.state.addon_price,
        duration:this.state.addon_duration,
        vary:this.state.can_vary,
        gender:this.state.addon_gender}
      });
      if(data.success){         
        this.props.enqueueSnackbar(localization.localizedString('UPDATED_SUCCESS'), { 
          variant: 'success',
        });    
      }
      else{
        if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
          this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
            variant: 'error',
          }); 
          await auth.get();       
         }
         else{        
          this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
            variant: 'error',
          }); 
         }
      }  
    }
    const { data } = await axios.get('/api/company/service/extra/'+this.state.serviceId);
      if(data.success){
        this.setState({addons:data.serviceExtras});
      }
      else{
        if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
          this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
            variant: 'error',
          }); 
          await auth.get();       
         }
         else{        
          this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
            variant: 'error',
          }); 
         }
        return;
      }

    this.setState({
      open_dia1:false,
    });

  }
  serviceGenderChange=(event)=>{
    this.setState({
      [event.target.name]: event.target.value,
    });
  }
  viewAddons=async(serviceId)=>{
    const { data } = await axios.get('/api/company/service/extra/'+serviceId);     
      if(data.success){
        this.setState({addons:data.serviceExtras});
      }
      else{
        if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
          this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
            variant: 'error',
          }); 
          await auth.get();       
         }
         else{        
          this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
            variant: 'error',
          }); 
         }
        return;
      }    

    this.setState({
      addons_card:this.props.classes.service_card_visible,
      serviceId:serviceId
    });
  }
  serviceDelete=async (val) => {      
      this.setState({open_dia2:true,serviceId:val,deleteType:'service'});
      return;     
  } 
  serviceChange(event){    
      if(event.target.value!='0'){
        this.viewAddons(event.target.value,'');
      }
      else{
        this.setState({addons_card:this.props.classes.service_card_disable});
      }

      this.setState({     
        [event.target.name]: event.target.value,
      });

  }
  table_body=()=>{
    const { classes,localization,auth } = this.props;
    let tbl=[];
    let trs=[];
    if(this.state.addons.length==0){
      return <h4 className={classes.nothing_1}>There is nothing.</h4>
    }

    this.state.addons.map(row => {
      trs.push(
        <TableRow key={row.id}>
        <TableCell >
          {row.name}
        </TableCell>
        <TableCell  component="th" scope="row">{row.description}</TableCell>
        <TableCell align="center">{row.price} {auth.user.currency_code}</TableCell>
        <TableCell align="right">{row.duration}</TableCell>
        <TableCell align="center">{row.vary?'Yes':'No'}</TableCell> 
        <TableCell align="right">{row.gender}</TableCell>        
        <TableCell  className={classes.tableCellId}>
              <Tooltip
                id="tooltip-top"
                title="Edit Service"
                placement="top"
                classes={{ tooltip: classes.tooltip }}
              >
                <IconButton
                  aria-label="Edit"
                  className={classes.tableActionButton}                               
                  onClick={() =>(this.editAddon(row))}
                >
                  <Edit
                    className={
                      classes.tableActionButtonIcon + " " + classes.edit
                    }
                  />
                </IconButton>
              </Tooltip>
        </TableCell>
        <TableCell  className={classes.tableCellId}>
            <Tooltip
              id="tooltip-top-start"
              title="Delete"
              placement="top"
              classes={{ tooltip: classes.tooltip }}
            >
              <IconButton
                aria-label="Close"
                className={classes.tableActionButton}
                onClick={() =>(this.addonDelete(row.id))}
              >
                <Close
                  className={
                    classes.tableActionButtonIcon + " " + classes.close
                  }
                />
              </IconButton>
            </Tooltip>
        </TableCell>
      </TableRow>
      )      
    });

    tbl.push(
          <Table className={classes.table} key={1}>
              <TableHead>
                  <TableRow>
                    <TableCell className={classes.tableHeader_2}>Name</TableCell>
                    <TableCell className={classes.tableHeader_2} >Description</TableCell>
                    <TableCell className={classes.tableHeader_2} align="center">Price</TableCell>
                    <TableCell className={classes.tableHeader_2} align="right">Duration</TableCell>
                    <TableCell className={classes.tableHeader_3} align="right"> Duration can vary</TableCell>
                    <TableCell className={classes.tableHeader_2} align="right">Gender</TableCell>                   
                    <TableCell  className={classes.tableCellId+ " "+classes.tableHeader_2}>Edit</TableCell>
                    <TableCell  className={classes.tableCellId+ " "+classes.tableHeader_2}>Delete</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {trs}
                </TableBody>
            </Table>
    );
    
    return tbl;

  }
  render(){
    const { classes,localization,auth } = this.props;
    
     return(
      <GridContainer>
      <GridItem xs={12} sm={12} md={12}>
        <Card>
          {/**
          <CardHeader color="primary">            
          <GridContainer>
            <GridItem xs={12} sm={12} md={12}>
              <h4 className={classes.cardTitleWhite}>Services</h4>
              <p className={classes.cardCategoryWhite}>
                Please select a Service.
              </p>
            </GridItem>     
                  
           </GridContainer>            
          </CardHeader>
           */}
          <CardBody className={classes.cardBody_1}>
          <GridContainer>
              <GridItem xs={12} sm={12} md={12}>             
                <FormControl variant="outlined" className={classes.formControl_1}>                 
                    <Select
                      value={this.state.serviceId}
                      onChange={this.serviceChange}
                      input={
                        <OutlinedInput labelWidth={this.state.labelWidth}  name="serviceId" id="outlined-age-simple" />
                      }                     
                    > 
                    <MenuItem value="0">
                        <em> Services  </em>
                    </MenuItem>
                    {
                      this.state.services.map(row=>(
                        <MenuItem key={row.id} value={row.id}>{row.name}</MenuItem>
                      ))
                    }                   
                    </Select>
              </FormControl>
            </GridItem>            
           </GridContainer>          
          </CardBody>
        </Card>
      </GridItem>
      {/** Addons card */}
      <GridItem xs={12} sm={12} md={12}>
        <Card className={this.state.addons_card}>
          <CardHeader color="success">
          <GridContainer>
            <GridItem xs={10} sm={10} md={10}>
              <h4 className={classes.cardTitleWhite}>Service Addons </h4>
              <p className={classes.cardCategoryWhite}>                
              </p>
            </GridItem>
            <Grid xs={2} item sm={2} md={2} className={classes.header_2}>
                  <Tooltip
                  id="tooltip-top-start"
                  title="Add Service"
                  placement="top"
                  classes={{ tooltip: classes.tooltip }}
                  >
                    <IconButton
                      aria-label="Close"
                      className={classes.tableActionButton}
                      onClick={this.createAddons}
                    >
                      <Create
                        className={
                           classes.create
                        }
                      />
                    </IconButton>
                  </Tooltip>
            </Grid>
           </GridContainer>
          </CardHeader>
          <CardBody className={classes.cardBody_1}>
             {this.table_body()}
          </CardBody>
        </Card>
      </GridItem>            
     {/** for addons dialog */} 
     <Dialog
          fullWidth={true}
          maxWidth={'sm'}
          open={this.state.open_dia1}
          onClose={this.dia1Close}
          aria-labelledby="max-width-dialog-title"         
        >         
          <DialogContent className={classes.dialog_2}>
            <Card className={classes.card_2}>
              <CardHeader color="success">
                <h4 className={classes.cardTitleWhite}>{this.state.addon_state} Addon</h4>
                <p className={classes.cardCategoryWhite}>                  
                </p>
              </CardHeader>
             
              <CardBody className={classes.cardBody_1}>
                <GridContainer  justify={'center'}>
                    <GridItem xs={12} sm={12} md={12}>
                      <CustomInput
                        labelText="Name"                        
                        inputProps={{
                          value:this.state.addon_name,
                        }}
                        formControlProps={{
                          required: true,
                          fullWidth: true,                         
                          value:this.state.addon_name,
                          onChange: this.handleChange('addon_name')
                        }}
                      />
                    </GridItem>
                    <GridItem xs={12} sm={12} md={12}>
                      <CustomInput
                        labelText="Description"                        
                        inputProps={{
                          value:this.state.addon_description,
                          multiline: true,
                          rows: 3
                        }}
                        formControlProps={{                         
                          fullWidth: true,                         
                          value:this.state.addon_description,
                          onChange: this.handleChange('addon_description')
                        }}
                      />
                    </GridItem>
                   
                      <GridItem xs={12} sm={12} md={12}>
                      <GridContainer  justify={'center'}>
                        <GridItem xs={12} sm={12} md={5}>
                            <CustomInput
                              labelText="Duration (minutes)"                        
                              inputProps={{
                                value:this.state.addon_duration,
                              }}
                              formControlProps={{
                                required: true,
                                fullWidth: true,                         
                                value:this.state.addon_duration,
                                onChange: this.handleChange('addon_duration')
                              }}
                            />
                          </GridItem>
                          <Grid item xs={12} sm={12} md={6} style={{margin:'auto'}}>
                               <FormControlLabel
                                      control={(
                                        <Checkbox
                                          tabIndex={-1}
                                          disableRipple       
                                          onClick={this.handleToggle('can_vary')}                      
                                          checked={this.state.can_vary}
                                        />
                                      )}
                                      classes={{ label: classes.label }}
                                      label={"Duration can vary"}
                                    />
                          </Grid>

                            <GridItem xs={12} sm={12} md={6}>
                            <CustomInput
                              labelText={"Price ("+auth.user.currency_code+")" }                       
                              inputProps={{
                                value:this.state.addon_price,
                              }}
                              formControlProps={{
                                required: true,
                                fullWidth: true,                         
                                value:this.state.addon_price,
                                onChange: this.handleChange('addon_price')
                              }}
                            />
                          </GridItem>                         

                          <GridItem xs={12} sm={12} md={6}>
                          <FormControl className={classes.formControl}>
                              <InputLabel htmlFor="age-simple">Gender</InputLabel>
                              <Select
                                value={this.state.addon_gender}
                                onChange={this.serviceGenderChange}
                                inputProps={{
                                  name: 'addon_gender',
                                  id: 'age-simple',
                                }}
                              >
                                <MenuItem value="">
                                  <em>None</em>
                                </MenuItem>
                                <MenuItem value={'Man'}>Man</MenuItem>
                                <MenuItem value={'Woman'}>Woman</MenuItem>        
                              </Select>
                            </FormControl>
                          </GridItem>
                            </GridContainer>
                      </GridItem>     
                </GridContainer>
              </CardBody>
              <CardFooter>                
                <Button color="success" onClick={this.dia1Close}>Cancel</Button>
                <Button color="success"
                disabled={this.state.addon_name.length==0 || this.state.addon_price.length==0 || this.state.addon_duration.length==0}
                 onClick={this.saveAddons}>Save</Button>
              </CardFooter>             
            </Card>  
          </DialogContent>
      </Dialog>
        
{/** delete category dialog */}
      <Dialog
        open={this.state.open_dia2}
        onClose={this.confirmDialogClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">{"Are you sure to delete?"}</DialogTitle>
        <DialogContent>       
        </DialogContent>
        <DialogActions>
          <Button onClick={this.confirmDialogClose} color="primary" >
            Cancel
          </Button>
          <Button  onClick={this.confirmCateDelete} color="primary" autoFocus>
            Yes
          </Button>
        </DialogActions>
      </Dialog>

      </GridContainer>
     )
   }
}
export default withStyles(servicesStyle)(withSnackbar(withLocalization(withAuth(ServiceAddons))));
