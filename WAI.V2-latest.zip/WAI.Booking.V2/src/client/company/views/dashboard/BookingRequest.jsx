import React from 'react';
import moment from 'moment'
import BigCalendar from 'react-big-calendar';
import withStyles from '@material-ui/core/styles/withStyles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Edit from "@material-ui/icons/Edit";
import Close from "@material-ui/icons/Close";
import Visibility from "@material-ui/icons/Visibility";
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import Done from '@material-ui/icons/Done';
import Grid from '@material-ui/core/Grid';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Select from '@material-ui/core/Select';

import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';

import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import ListSubheader from '@material-ui/core/ListSubheader';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import TextField from '@material-ui/core/TextField';
import ButtonN from '@material-ui/core/Button';
import Success from '@material-ui/icons/CheckCircle';
import axios from 'axios';
import {  withSnackbar } from 'notistack';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import Typography from '@material-ui/core/Typography';
import withAuth from '../../../common/contexts/AuthContext';
import withNotifications from '../../../common/contexts/NotificationsContext';
import GridItem from "../../../common/components/Grid/GridItem.jsx";
import GridContainer from "../../../common/components/Grid/GridContainer.jsx";
import withLocalization from '../../../common/contexts/LocalizationContext';
import Card from "../../../common/components/Card/Card.jsx";
import CardHeader from "../../../common/components/Card/CardHeader.jsx";
import CardBody from "../../../common/components/Card/CardBody.jsx";
import CustomInput from "../../../common/components/CustomInput/CustomInput.jsx";
import CardFooter from "../../../common/components/Card/CardFooter.jsx";
import Button from "../../../common/components/CustomButtons/Button.jsx";

const localizer = BigCalendar.momentLocalizer(moment) // or globalizeLocalizer
let allViews=Object.keys(BigCalendar.Views).map(k => BigCalendar.Views[k]);

import bookingStyle from '../../assets/css/booking';
import '../../assets/css/calendarStyle.css';
import Bookings from './Bookings';
import BookingRoute from './BookingRoute';

var button_event=false;
class BookingRequest extends React.Component {
  constructor(props){
  super (props);
  this.state={eventLists:[],
    detail_modal:false,
    booking_from:'',
    booking_to:'',       
    firstName:'',
    lastName:'',
    customerPhone:'',
    customerBooking_time:'',
    bookingPrice:0,
    bookingTotal_time:'',
    bookings:[],
    services:[],
    serviceAddons:[],
    serviceAddons_1:[],
    serviceId:0,
    bookingExtraId:0,//when addons is edited
    serviceIdEdit:'',
    addonId:'',
    created_time:'',
    bookingStatus:'',
    duration:'',
    status:'Stayed away',
    labelWidth:0,
    customerId:0,
    zipCode:'',
    city:'',
    address:'',
    gender:'',
    title:'',
    note:'',
    bookingId:0,
    viewStatus:'default',
    editAddon_modal:false,
    addService_modal:false,
    editService_modal:false,
    editable:false,
    addAddon_modal:false,
    changeBookingTime_modal:false,
    email:'',
    employeeId:0,
    changedBookingFrom:'',
    employeeName:'',
    bookingServices:[],
    bookingExtras:[],
    allServices:[],
    allServiceAddons:[],
    bookingServiceId:0,
    booking_status:true,
    expanded:'panel1',
    employees:[],
    addonEmployeeId:''
    
  };
  this.showDetailBook=this.showDetailBook.bind(this);
}
  componentDidMount(){
    this.loadBookingData();
    //this.loadCountryInf();
  }
  loadBookingData=async()=>{
    const {notifications,localization,auth}=this.props;     
    const { data } = await axios.get('/api/company/booking'); 
    console.log(data,'booking requrest')      ;
    if(data.success){
      let bookings=data.bookings;      
      this.setState({bookings:bookings});
      let eventLists=[];
      bookings.map(row => {
        var event={};
        event.id=row.id;
        event.title=row.first_name+" "+row.last_name;
        event.start=new Date(row.book_from);
        event.end=new Date(row.book_to);        
        eventLists.push(event);
     });
     this.setState({eventLists:eventLists,
      bookingServices:data.bookingServices,
      bookingExtras:data.bookingExras,
      employees:data.employees
    });
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
  }
  loadCountryInf=async()=>{
    const {notifications,localization}=this.props;  
    const { data } = await axios.get('/api/company/country');    
    if(data.success){
      localStorage.setItem("currency_code",data.country[0].currency_code);
      localStorage.setItem("phone_code",data.country[0].country_phone_code);
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
  } 
  /**
   * return:{
   * @id:booking_extra_id
   * name:serviceAddon name
   * }
   */
  loadServiceAddons=async()=>{
    const  {data} = await axios.get('/api/company/booking/'+this.state.bookingId+'/extra');  
    if(data.success){
      this.setState({serviceAddons:data.bookingExtras});
      var total_price=this.state.bookingPrice;
      this.state.serviceAddons.map(row=>{
        total_price+=parseFloat(row.price);
      })
      total_price=total_price*1000;
      total_price=Math.floor(total_price);
      this.setState({bookingPrice:(total_price/1000).toFixed(2)});      
    }
  }
  loadCustomer=async()=>{
       const  {data} = await axios.get('/api/customer/'+this.state.customerId);
         if(data.success){
            this.setState({firstName:data.customer.firstName,
            lastName:data.customer.lastName,
            customerPhone:localStorage.getItem('phone_code')+" "+data.customer.phone,
            zipCode:data.customer.zipCode,
            city:data.customer.city,
            address:data.customer.address1+ " " +data.customer.address2,            
            gender:data.customer.gender,
            email:data.customer.email
            });
         }

  }
  getEmployeeInf=async()=>{
      const  {data} = await axios.get('/api/company/employee/'+this.state.employeeId);    
       if(data.success){
        this.setState({employeeName:data.employee.name});
      }
  }
  showDetailBook(row){   
          var bookingFrom=moment(row.book_from);
          var bookingTo=moment(row.book_to);
          var created_on=moment(row.created_on) ; 
          
          this.setState({
            detail_modal:true,
            bookingId:row.id,
            changedBookingFrom:moment(row.book_from).format('YYYY-MM-DD')+"T"+moment(row.book_from).format('HH:mm'),
            booking_from:bookingFrom.format('YYYY-MM-DD')+"T"+bookingFrom.format('HH:mm'),
            booking_to:row.book_to,//bookingTo.format('HH:mm'),
            created_time:created_on.format('YYYY-MM-DD HH:mm'),
            bookingStatus:row.status,
            duration:row.duration,
            status:row.status,
            serviceId:row.service_id,
            customerId:row.customer_id,
            title:row.first_name+" "+row.last_name,             
            note:row.note==null?'':row.note,
            employeeId:row.employee_id
        });
      
      this.loadServices(row.id); 
  }
  loadServices=async(bookingId)=>{ 
    const {notifications,localization,auth}=this.props;   
    const  {data} = await axios.get('/api/company/booking/'+bookingId+"/service"); 
    
    if(data.success){
      var total_price=0;
      data.bookingServices.map(row=>{
        total_price+=parseFloat(row.price);
      })
      this.setState({services:data.bookingServices,
        bookingPrice:total_price});

        this.loadCustomer();
        this.loadServiceAddons();
        this.getEmployeeInf();
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }   
  }
  bookingTimeChange=async()=>{ 
    const {notifications,localization}=this.props;
    var temp_time=this.state.changedBookingFrom.split('T');
    temp_time=temp_time[1];//hour : minutes
    temp_time=temp_time.split(':');
    temp_time= parseInt(temp_time[0]*60)+parseInt(temp_time[1]);
    var bookingTo_temp=parseInt(temp_time)+parseInt(this.state.duration);
    bookingTo_temp=this.time_convert(bookingTo_temp);
    var bookingTo=this.state.changedBookingFrom.split('T')[0]+"T"+bookingTo_temp
   
     var { data } = await axios.put('/api/company/booking/'+this.state.bookingId+"/update", {
       booking:{ 
         bookFrom:this.state.changedBookingFrom,
         bookTo:bookingTo
       }
     }); 
     if(data.success){
       this.props.enqueueSnackbar(localization.localizedString('SAVED_SUCCESS'), { 
        variant: 'success',
      }); 
       this.setState({booking_from:data.booking.bookFrom,booking_to:data.booking.bookTo});
       this.loadBookingData();
     }
     else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
     }
     this.setState({changeBookingTime_modal:false});
   }
  handleChange_1 = panel => (event, expanded) => {
    if(button_event)
      return;
    this.setState({
      expanded: expanded ? panel : false,
    });
  };

  time_convert=(num)=>{ 
    var hours = Math.floor(num / 60);  
    var minutes = num % 60;
    minutes= minutes > 9 ? "" + minutes: "0" + minutes;
    return hours + ":" + minutes;         
  }
  detailModal_close=()=>{
    this.setState({ detail_modal: false,viewStatus:'default' });
  }
  editAddonModal_close=()=>{
    this.setState({editAddon_modal:false,addAddon_modal:false});
  }
  editServiceModal_close=()=>{
    this.setState({editService_modal:false,addService_modal:false});
  }
  handleChange = prop => event => this.setState({ [prop]: event.target.value });
  addonChange=(event)=>{
    this.setState({
      [event.target.name]: event.target.value,
    });
  }
  serviceChange=async(event)=>{
    this.setState({     
      [event.target.name]: event.target.value,
    });   
  }
  acceptBooking=async(id)=>{
    const {localization}=this.props;
     var { data } = await axios.put('/api/company/booking/'+id+'/accept');
     if(data.success){
      this.props.enqueueSnackbar(localization.localizedString('ACCEPTED_SUCCESS'), { 
        variant: 'success',
      });  
      this.loadBookingData();
      var temp_val=this.state.booking_status;
      this.setState({booking_status:temp_val?false:true});
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }     
  }
  denyBooking=async(id)=>{
    const {localization}=this.props;
    var { data } = await axios.put('/api/company/booking/'+id+'/reject');   
    if(data.success){
      this.props.enqueueSnackbar(localization.localizedString('CANCELED_SUCCESS'), { 
        variant: 'success',
      }); 
      this.loadBookingData();
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
  }
  bookTimeChange=(event)=>{   
    this.setState({     
      [event.target.name]: event.target.value,
    });
  }
  changeBookingTime_close=()=>{    
    this.setState({changeBookingTime_modal:false});
  }
   addonUpdate=async()=>{
    const {notifications,localization,auth}=this.props;     
    var { data } = await axios.put('/api/company/booking/extra/'+this.state.bookingExtraId, {
      book_extra:{ 
        serviceExtraId:this.state.addonId,
      }
    });
    
    if(data.success){
      this.setState({serviceId:this.state.serviceIdEdit});
      this.props.enqueueSnackbar(localization.localizedString('UPDATED_SUCCESS'), { 
        variant: 'success',
      }); 
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
    this.loadServices(this.state.bookingId);   
    this.setState({editAddon_modal:false});
  }
  addonEdit=async(row)=>{
    const {localization,auth}=this.props;  
    var service_ids=[];
    this.state.services.map(row=>{
      service_ids.push(row.sid);
    })
    const { data } = await axios.get('/api/company/service/extras/'+service_ids.join());    
    if(data.success){
      this.setState({allServiceAddons:data.serviceExtras,       
        addonId:row.eid,
        bookingExtraId:row.id,       
        viewStatus:'addon',
        editAddon_modal:true,
        addonEmployeeId:row.employeeId
      });    
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
  }
   /**
   * save to the db
   */
  addonAdd=async()=>{
    const {notifications,localization,auth}=this.props;
    if(this.state.addonId=='')
      return;
    var { data } = await axios.post('/api/company/booking/service_extra', {
      book_extra:{ 
        serviceExtraId:this.state.addonId,
        bookingId:this.state.bookingId,
        customerId:this.state.customerId,
        employeeId:this.state.addonEmployeeId
      }
    });

    if(data.success){
      this.props.enqueueSnackbar(localization.localizedString('ADDED_SUCCESS'), { 
        variant: 'success',
      }); 
      this.loadServiceAddons();
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }    
    this.setState({addAddon_modal:false})
  }
  serviceEdit=async(row)=>{ 
    const {localization,auth}=this.props;
    const { data } = await axios.get('/api/company/services');
    if(data.success){
      this.setState({
        editService_modal:true,
        //serviceIdEdit:row.id,
        serviceIdEdit:row.sid,
        bookingServiceId:row.id,
        serviceEmployeeId:row.employee_id,
        allServices:data.services
      });
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){       
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        });       
       }
    }
  }

  serviceAdd=async()=>{
    const {localization,auth}=this.props;
    if(this.state.serviceIdEdit==''){
      return;
    }
    
    var { data } = await axios.post('/api/company/booking/service/', {
      book_service:{ 
        serviceId:this.state.serviceIdEdit,
        bookingId:this.state.bookingId,
        customerId:this.state.customerId
      }
    });
    if(data.success){
      this.loadServices(this.state.bookingId);      
      this.setState({addService_modal:false});
      this.props.enqueueSnackbar(localization.localizedString('ADDED_SUCCESS'), { 
        variant: 'success',
      }); 
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }

  }
  serviceUpdate=async()=>{
    const {localization,auth}=this.props;    
    var { data } = await axios.put('/api/company/booking/service/'+this.state.bookingServiceId, {
      book_service:{ 
        serviceId:this.state.serviceIdEdit,
        employeeId:this.state.serviceEmployeeId
      }
    });

    if(data.success){
      this.props.enqueueSnackbar(localization.localizedString('UPDATED_SUCCESS'), { 
        variant: 'success',
      }); 
      this.setState({serviceId:this.state.serviceIdEdit});
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){       
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        });       
       }
       return;
    }
    this.loadServices(this.state.bookingId);   
    this.setState({editService_modal:false});
  }
  updateBooking=async(status)=>{
    if(status=="COMPLETED"){
      this.props.goOtherPage(this.state.bookingId,this.state.services,this.state.serviceAddons);
    }   
     var { data } = await axios.put('/api/company/booking/'+this.state.bookingId, {
      booking:{ 
        status:status,
      }
    });  
    if(data.success){
      this.loadBookingData();
    }
    this.setState({detail_modal:false});
    
  }
  saveChange=async()=>{
    const {notifications,localization,auth}=this.props;
    var { data } = await axios.put('/api/company/booking/'+this.state.bookingId+"/update", {
      booking:{ 
        note:this.state.note,
      }
    });
    if(data.success){
      this.props.enqueueSnackbar(localization.localizedString('SAVED_SUCCESS'), { 
        variant: 'success',
      }); 
      this.loadBookingData();
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
    //this.setState({detail_modal:false});
  }
 
  addAddon=async()=>{
    const {localization,auth}=this.props;
    var service_ids=[];
    this.state.services.map(row=>{
      service_ids.push(row.sid);
    })
    const { data } = await axios.get('/api/company/service/extras/'+service_ids.join());  
    if(data.success){
      this.setState({
        allServiceAddons:data.serviceExtras, 
        addonId:'',
        addAddon_modal:true        
      });    
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }

  }
  addService=async()=>{  
    const {localization,auth}=this.props;
    const { data } = await axios.get('/api/company/services');   
    if(data.success){     
      this.setState({
        addService_modal:true,      
        allServices:data.services,
        serviceIdEdit:'',
        serviceEmployeeId:''
      });
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }    
  }
  deleteBookAddon=async()=>{
    const {localization,auth}=this.props;
    const { data } = await axios.delete('/api/company/booking/service_extra/'+this.state.bookingExtraId); 
    if(data.success){
      this.loadServiceAddons();       
      this.props.enqueueSnackbar(localization.localizedString('DELETED_SUCCESS'), { 
        variant: 'success',
      }); 
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
    this.setState({editAddon_modal:false});
  }

  deleteBookService=async()=>{
    const {localization,auth}=this.props;
    const { data } = await axios.delete('/api/company/booking/service/'+this.state.bookingServiceId);
    if(data.success){
      this.loadServices(this.state.bookingId);
      this.props.enqueueSnackbar(localization.localizedString('DELETED_SUCCESS'), { 
        variant: 'success',
      });   
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
    this.setState({editService_modal:false});
  }
  cardBody=()=>{
    const { classes,localization } = this.props;    
    let bookingPrice=0;

    this.state.services.map(item=>{
      bookingPrice+=parseFloat(item.price);
    })

    this.state.serviceAddons.map(row=>{
      bookingPrice+=parseFloat(row.price);
    })
    bookingPrice=bookingPrice*1000;
    bookingPrice=Math.floor(bookingPrice);
    bookingPrice=(bookingPrice/1000).toFixed(2);    

      return <CardBody className={classes.cardBody_1}  >
      <Grid container className={classes.container_1} >
        <Grid item  xs={12} sm={12} item md={5} style={{paddingTop: '0px !important'}}>
            <List style={{paddingTop: '0px !important'}}>
            <ListItem alignItems="flex-start" style={{paddingTop: '0px !important'}}>
            
            <ListItemText
            style={{paddingTop: '0px !important'}}
              primary={
                <ListSubheader style={{color: '#000', paddingLeft: '0px', fontSize: '1.5rem'}}>
              General
              </ListSubheader>}
              secondary={
                <React.Fragment>
                  <Typography component="span" style={{display: 'inline',}} color="textPrimary">
                    Booking Status: {this.state.status}
                  </Typography>
                  <br/>
                  <Typography component="span" style={{display: 'inline',}} color="textPrimary">
                    Assigned Employee: {this.state.employeeName}
                  </Typography>
                  <br/>
                  <Typography component="span" style={{display: 'inline',}} color="textPrimary">
                    Created at: {this.state.created_time}
                  </Typography>
                  <br/>
                  <Typography component="span" style={{display: 'inline',}} color="textPrimary">
                    Booking time: {moment(this.state.booking_from).format('YYYY-MM-DD HH:mm')} ~ {moment(this.state.booking_to).format('HH:mm')}
                  </Typography>                  
                  <br/>
                </React.Fragment>
                
              }
            />
            </ListItem>
            {
              (this.state.status=="AWAITING RESPONSE" || this.state.status=="ACCEPTED") && <Button color="primary" className={classes.button_3} onClick={()=>this.setState({changeBookingTime_modal:true})} >Change booking time</Button>

            }

            <ListItem alignItems="flex-start">
            <ListItemText
              primary={
                <ListSubheader style={{color: '#000', paddingLeft: '0px', fontSize: '1.5rem'}}>
              Customer
              </ListSubheader>}
              secondary={
                <React.Fragment>
                  <Typography component="span" style={{display: 'inline',}} color="textPrimary">
                    Id: {this.state.customerId}
                  </Typography>
                  <br/>
                  <Typography component="span" style={{display: 'inline',}} color="textPrimary">
                    Name: {this.state.firstName} {this.state.lastName}  
                  </Typography>
                  <br/>
                  <Typography component="span" style={{display: 'inline',}} color="textPrimary">
                    Phone: {this.state.customerPhone}
                  </Typography>
                  <br/>
                  <Typography component="span" style={{display: 'inline',}} color="textPrimary">
                    Email: {this.state.email}
                  </Typography>
                </React.Fragment>
              }
            />
            </ListItem>
            </List>
            <Grid container className={classes.container_1} >              
              <Grid xs={12} sm={12} item md={12} >
                      <CustomInput
                          labelText="Add a comment to the booking"                        
                          inputProps={{
                          value:this.state.note,
                          multiline: true,
                          rows: 2,
                         
                        }}
                       
                        formControlProps={{                                              
                          className:classes.customInput_4,   
                          onChange: this.handleChange('note')
                        }}
                      />                 
            </Grid>
            <Grid xs={12} sm={12} item md={12} >
            {
              (this.state.status=="AWAITING RESPONSE" || this.state.status=="ACCEPTED") && <Button color="primary" className={classes.button_3} onClick={this.saveChange} >Save comment</Button>
            }
            
            </Grid>
            </Grid>

        </Grid>
        <Grid item  xs={12} sm={12} item md={7} className={classes.container_1}>          
            <Grid container className={classes.container_2}  >              
              <Grid xs={12} sm={12} item md={4} >
                 <Typography style={{fontSize: '1.5rem', color: '#000'}} className={classes.label_2}>Services</Typography>
              </Grid> 
              {
                (this.state.status=="AWAITING RESPONSE" || this.state.status=="ACCEPTED") && <Grid xs={12} sm={12} item md={8} >
                <Button  
                color="primary" 
                className={classes.button_2}
                onClick={this.addService}
                >
                  Add Services                 
                </Button>     
                <Button  
                color="primary" 
                className={classes.button_2}
                onClick={this.addAddon}
                >
                  Add Service Addons                 
                </Button>     
              </Grid>    
              }
              
            </Grid>
            <Grid container className={classes.container_1} >              
              <Grid xs={12} sm={12} item md={12} >
              {this.serviceTable_body()} 
              </Grid>               
              <Grid xs={12} sm={12} item md={12} >
              {this.addonsTable_body()} 
              </Grid>
            </Grid>
            <Grid container className={classes.container_1} >              
              <Grid xs={12} sm={12} item md={12} className={classes.gridCell_Total}>
              <Typography variant="body1" className={classes.label_2}>Total {bookingPrice} {localStorage.getItem('currency_code')}</Typography>
              </Grid>
            </Grid>
        </Grid>        
    </Grid>                
  </CardBody> 
   
  }
  editAddon_body=()=>{
    const { classes,localization } = this.props;
    var temp=[];   
    this.state.serviceAddons.map(item=>{
      temp.push(item.eid);
    })   
    return <CardBody className={classes.cardBody_1}  >
    <Grid container className={classes.dialog_3} justify={'center'} >      
      <Grid xs={12} sm={12} item md={6}  >
         <FormControl className={classes.formControl_1}>
                <InputLabel htmlFor="age-simple">Service Addons</InputLabel>
                <Select
                  value={this.state.addonId}
                  onChange={this.addonChange}
                  inputProps={{
                    name: 'addonId',
                    id: 'age-simple',
                  }}
                >
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  {
                      this.state.allServiceAddons.map(row=>{
                       // if(temp.indexOf(row.id)==-1 )
                        return <MenuItem key={row.id} value={row.id}>{row.name}</MenuItem>
                      })
                    }    
                      
                </Select>
            </FormControl>
        </Grid>
        <Grid xs={12} sm={12} item md={5}  >
              <FormControl className={classes.formControl_1}>
                <InputLabel htmlFor="serviceEmployeeId">Employees</InputLabel>
                <Select
                  value={this.state.addonEmployeeId}
                  onChange={this.serviceChange}
                  inputProps={{
                    name: 'addonEmployeeId',
                    id: 'addonEmployeeId',
                  }}
                >
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  {
                      this.state.employees.map(row=>{                       
                        if(temp.indexOf(row.id)==-1 ){                         
                          return <MenuItem key={row.id} value={row.id}>{row.firstName+" "+row.lastName}</MenuItem>
                        }                       
                    })
                    }    
                      
                </Select>
              </FormControl>
      </Grid>      
     </Grid>
   </CardBody>
  }
  addAddon_body=()=>{
    const { classes,localization } = this.props;
    var temp=[];   
    this.state.serviceAddons.map(item=>{
      temp.push(item.eid);
    })   
    return <CardBody className={classes.cardBody_1}  >
    <Grid className={classes.dialog_3} justify={'center'} container >      
      <Grid xs={12} sm={12} item md={6}  >
         <FormControl className={classes.formControl_1}>
                <InputLabel htmlFor="age-simple">Service Addons</InputLabel>
                <Select
                  value={this.state.addonId}
                  onChange={this.addonChange}
                  inputProps={{
                    name: 'addonId',
                    id: 'age-simple',
                  }}
                >
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  {
                      this.state.allServiceAddons.map(row=>{
                        if(temp.indexOf(row.id)==-1 )
                        return <MenuItem key={row.id} value={row.id}>{row.name}</MenuItem>
                      })
                    }    
                      
                </Select>
            </FormControl>
        </Grid>
        <Grid xs={12} sm={12} item md={5}  >
              <FormControl className={classes.formControl_1}>
                <InputLabel htmlFor="serviceEmployeeId">Employees</InputLabel>
                <Select
                  value={this.state.addonEmployeeId}
                  onChange={this.serviceChange}
                  inputProps={{
                    name: 'addonEmployeeId',
                    id: 'addonEmployeeId',
                  }}
                >
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  {
                      this.state.employees.map(row=>{                       
                        if(temp.indexOf(row.id)==-1 ){                         
                          return <MenuItem key={row.id} value={row.id}>{row.firstName+" "+row.lastName}</MenuItem>
                        }                       
                    })
                    }    
                      
                </Select>
              </FormControl>
      </Grid>      
     </Grid>
   </CardBody>
  }
  addService_body=()=>{
    const { classes,localization } = this.props;
    var temp=[];   
    this.state.services.map(item=>{
      temp.push(item.sid);
    })       
    return <CardBody className={classes.cardBody_1}  >
    <Grid container className={classes.dialog_3} justify={'center'} >
      <Grid xs={12} sm={12} item md={6}  >
              <FormControl className={classes.formControl_1}>
                <InputLabel htmlFor="service">Services</InputLabel>
                <Select
                  value={this.state.serviceIdEdit}
                  onChange={this.serviceChange}
                  inputProps={{
                    name: 'serviceIdEdit',
                    id: 'service',
                  }}
                >
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  {
                      this.state.allServices.map(row=>{                       
                        if(temp.indexOf(row.id)==-1 ){                         
                          return <MenuItem key={row.id} value={row.id}>{row.name}</MenuItem>
                        }                       
                    })
                    }    
                      
                </Select>
              </FormControl>
      </Grid> 
      <Grid xs={12} sm={12} item md={5}  >
              <FormControl className={classes.formControl_1}>
                <InputLabel htmlFor="serviceEmployeeId">Employees</InputLabel>
                <Select
                  value={this.state.serviceEmployeeId}
                  onChange={this.serviceChange}
                  inputProps={{
                    name: 'serviceEmployeeId',
                    id: 'serviceEmployeeId',
                  }}
                >
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  {
                      this.state.employees.map(row=>{                       
                        if(temp.indexOf(row.id)==-1 ){                         
                          return <MenuItem key={row.id} value={row.id}>{row.firstName+" "+row.lastName}</MenuItem>
                        }                       
                    })
                    }    
                      
                </Select>
              </FormControl>
      </Grid>      
     </Grid>
   </CardBody>
  }
  editService_body=()=>{
    const { classes,localization } = this.props;
    var temp=[];   
    this.state.services.map(item=>{
      temp.push(item.sid);
    })       
    return <CardBody className={classes.cardBody_1}  >
    <Grid container className={classes.dialog_3} justify={'center'} >
      <Grid xs={12} sm={12} item md={6}  >
              <FormControl className={classes.formControl_1}>
                <InputLabel htmlFor="service">Services</InputLabel>
                <Select
                  value={this.state.serviceIdEdit}
                  onChange={this.serviceChange}
                  inputProps={{
                    name: 'serviceIdEdit',
                    id: 'service',
                  }}
                >
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  {
                      this.state.allServices.map(row=>{                       
                       // if(temp.indexOf(row.id)==-1 ){                         
                          return <MenuItem key={row.id} value={row.id}>{row.name}</MenuItem>
                       // }                       
                    })
                    }    
                      
                </Select>
              </FormControl>
      </Grid> 
      <Grid xs={12} sm={12} item md={5}  >
              <FormControl className={classes.formControl_1}>
                <InputLabel htmlFor="serviceEmployeeId">Employees</InputLabel>
                <Select
                  value={this.state.serviceEmployeeId}
                  onChange={this.serviceChange}
                  inputProps={{
                    name: 'serviceEmployeeId',
                    id: 'serviceEmployeeId',
                  }}
                >
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  {
                      this.state.employees.map(row=>{                       
                        //if(temp.indexOf(row.id)==-1 ){                         
                          return <MenuItem key={row.id} value={row.id}>{row.firstName+" "+row.lastName}</MenuItem>
                       // }                       
                    })
                    }    
                      
                </Select>
              </FormControl>
      </Grid>      
     </Grid>
   </CardBody>
  }
  addonsTable_body=()=>{
    let tbl=[];
    let trs=[];
    var employeeName=''; 
    const { classes,localization } = this.props;
    this.state.serviceAddons.map(row=>{
      this.state.employees.map(item=>{
        if(item.id==row.employeeId){
          employeeName=item.firstName+" "+item.lastName;
        }
      })
      trs.push(<TableRow key={row.id}>
        <TableCell className={classes.tableCellId_1+" "+classes.gray_title}>{row.name}</TableCell>
        <TableCell className={classes.tableCellId+" "+classes.gray_title}>{row.duration}</TableCell>
        <TableCell className={classes.tableCellId+" "+classes.gray_title} >{row.price}</TableCell>
        <TableCell className={classes.gray_title} >{employeeName}</TableCell>
        <TableCell className={classes.tableCellId+" "+classes.gray_title} >
        
                <IconButton
                  aria-label="Edit"
                  className={classes.tableActionButton}                  
                  onClick={() =>(this.addonEdit(row))}
                  disabled={this.state.editable}
                >
                  <Edit                   
                    className={
                      this.state.editable?classes.edit1:classes.edit
                    }
                  />
                </IconButton>              
            </TableCell>
                        
          </TableRow>);      
        })

         tbl.push(<Table className={classes.table} key={1}>
          <TableHead>
            <TableRow>
                <TableCell className={classes.tableHeader_2+ " "+ classes.tableCellId_1}>Service Addon</TableCell>
                <TableCell className={classes.tableHeader_2+ " "+classes.tableCellId}>Time</TableCell>
                <TableCell className={classes.tableHeader_2+ " "+classes.tableCellId}>Price</TableCell>
                <TableCell className={classes.tableHeader_2}>Employee</TableCell>
                <TableCell className={classes.tableHeader_2+" "+classes.tableCellId} >Edit</TableCell>                                              
            </TableRow>
          </TableHead>                              
          <TableBody>
          {trs}
          </TableBody>
        </Table>);
        if( this.state.serviceAddons.length==0){
          return null
        }
        else{
          return tbl;
        }
  }
  serviceTable_body=()=>{
    let tbl=[];
    let trs=[];
    const { classes,localization } = this.props;
    var employeeName=''; 
    this.state.services.map(row=>{   
      this.state.employees.map(item=>{         
        if(item.id==row.employee_id){
          employeeName=item.firstName+" "+item.lastName;
        }
      })  
      trs.push(<TableRow key={row.id}>
        <TableCell className={classes.tableCellId_1+" "+classes.gray_title}>{row.name}</TableCell>
        <TableCell className={classes.tableCellId+" "+classes.gray_title}>{row.duration}</TableCell>
        <TableCell className={classes.tableCellId+" "+classes.gray_title} >{row.price}</TableCell>
        <TableCell className={classes.tableCellId_1+" "+classes.gray_title}>{employeeName}</TableCell>
        <TableCell className={classes.tableCellId+" "+classes.gray_title} >
        
                <IconButton
                  aria-label="Edit"                               
                  onClick={() =>(this.serviceEdit(row))}
                  disabled={this.state.editable}
                >
                  <Edit                   
                    className={
                      this.state.editable?classes.edit1:classes.edit
                    }
                  />
                </IconButton>              
            </TableCell> 
                              
          </TableRow>);      
        })

         tbl.push(<Table className={classes.table} key={1}>
          <TableHead>
            <TableRow>
                <TableCell className={classes.tableHeader_2+ " "+ classes.tableCellId_1}>Services</TableCell>
                <TableCell className={classes.tableHeader_2+ " "+classes.tableCellId}>Time</TableCell>
                <TableCell className={classes.tableHeader_2+ " "+classes.tableCellId}>Price</TableCell>
                <TableCell className={classes.tableHeader_2}>Employee</TableCell>
                <TableCell className={classes.tableHeader_2+" "+classes.tableCellId} >Edit</TableCell>
                                             
            </TableRow>
          </TableHead>                              
          <TableBody>
          {trs}
          </TableBody>
        </Table>);
        if( this.state.services.length==0){
          return null
        }
        else{
          return tbl;
        }
        
         
  }
  footerAction=()=>{
    const { classes,localization } = this.props;
  
   return  <DialogActions>
        <Grid container className={classes.container_1} >
        <Grid item  xs={12} sm={12} item md={6} className={classes.footerCommand_2} >
          <Typography variant="body1" className={classes.label_2}>Created On:  <span className={classes.span_1}>{this.state.created_time}</span></Typography>
        </Grid>        
        <Grid item  xs={12} sm={12} item md={6}  className={classes.footerCommand_1}> 
            <Button color="success"   onClick={this.detailModal_close} >Cancel</Button>
            {/** <Button color="primary"   onClick={this.saveChange} >Save Changes</Button> */}
          </Grid>
        </Grid>          
          </DialogActions>
    
  }
  table_body=()=>{
    const { classes,localization } = this.props;    
    let tbl=[];
    let trs=[];
   
    const{bookingServices,bookings,bookingExtras}=this.state;
     bookings.map((row,index) => {
      const bookingFrom = moment(row.book_from);      
      const bookingTo = moment(row.book_to);
      var services_temp=[];
      var extras_temp=[];
      var num=index+1;
      if(row.status=='AWAITING RESPONSE'){
        
        bookingServices.map(item=>{
         if( item.booking_id==row.id){
          services_temp.push(item.name);
         }
        })

        bookingExtras.map(item=>{
          if(item.booking_id==row.id){
            extras_temp.push(item.name);
          }
        })

        trs.push(<TableRow hover
          key={row.id} >
          <TableCell  className={classes.tableCell+" "+classes.gray_title} >
            {row.id}
          </TableCell>
          <TableCell  className={classes.tableCell+" "+classes.gray_title} >
            {row.first_name + " "+ row.last_name}
          </TableCell>
          <TableCell className={classes.gray_title}>{bookingFrom.format('YYYY-MM-DD HH:mm')} ~ {bookingTo.format('HH:mm')}</TableCell>
          <TableCell  className={classes.gray_title}>{services_temp.join()}</TableCell>      
          <TableCell className={classes.gray_title} >{extras_temp.join()}</TableCell>  

          <TableCell  className={classes.tableCellId}>
                <ButtonN variant="contained" 
                      size="small" color="secondary"
                      className={classes.margin}
                      onClick={() =>(this.acceptBooking(row.id))}                                           
                  >
                     Accept
                  </ButtonN>              
          </TableCell>
          <TableCell  className={classes.tableCellId}>
              
            <ButtonN variant="contained" 
                size="small" color="primary"
                className={classes.margin}
                onClick={() =>(this.denyBooking(row.id))}                                           
            >
                    Deny
            </ButtonN>
            {/**
              <Tooltip
                id="tooltip-top-start"
                title="Deny Booking Request"
                placement="top"
                classes={{ tooltip: classes.tooltip }}
              >
                <IconButton
                  aria-label="Deny"
                  className={classes.tableActionButton}
                  onClick={() =>(this.denyBooking(row.id))}
                >
                  <Close
                    className={
                      classes.tableActionButtonIcon + " " + classes.close
                    }
                  />
                </IconButton>
              </Tooltip>
               */}
          </TableCell>
          <TableCell  className={classes.tableCellId}>
              <Tooltip
                id="tooltip-top-start"
                title="Edit"
                placement="top"
                classes={{ tooltip: classes.tooltip }}
              >
                <IconButton
                  aria-label="Edit"
                 
                  onClick={() =>(this.showDetailBook(row))}
                >
                  <Edit
                    className={
                      classes.tableActionButtonIcon + " " + classes.edit
                    }
                  />
                </IconButton>
              </Tooltip>
          </TableCell>
        </TableRow>); 
      }
       

    })

    tbl.push(<Table key={1} className={classes.table}>
      <TableHead >
        <TableRow>
          <TableCell  className={classes.tableCellId+" "+classes.tableHeader_1}>No</TableCell>     
          <TableCell  className={classes.tableCell+" "+classes.tableHeader_1}>Customer Name</TableCell>
          <TableCell  className={classes.tableHeader_1}>Booking Time</TableCell>
          <TableCell  className={classes.tableHeader_1}>Services</TableCell>
          <TableCell  className={classes.tableHeader_1}>Service Addons</TableCell>
          <TableCell  className={classes.tableCellId+" "+classes.tableHeader_1}>Accept</TableCell>
          <TableCell  className={classes.tableCellId+" "+classes.tableHeader_1}>Deny</TableCell>
          <TableCell  className={classes.tableCellId+" "+classes.tableHeader_1}>Edit</TableCell>
        </TableRow>
      </TableHead>
      <TableBody>
        {trs}
      </TableBody>
    </Table>);

    if(trs.length==0){
      return <h4 className={classes.nothing_1}>There is nothing.</h4>
    }
    return tbl;    
  }
  render(){
    const { classes,localization } = this.props;
    const {expanded}=this.state;
    return(
      <GridContainer>
      <GridItem xs={12} sm={12} md={12}>
        <Card>          
          <CardBody className={classes.cardBody_1}>
            <ExpansionPanel
                square
                expanded={expanded === 'panel1'}
                onChange={this.handleChange_1('panel1')}
              >
             <ExpansionPanelSummary >
                    <Grid xs={10} item sm={10} md={10} className={classes.grid_title}>
                      <Typography variant="subtitle1" className={classes.title_3} >Booking Request</Typography>                     
                    </Grid>
                    <Grid xs={2} item sm={2} md={2} className={classes.header_2}>                       
                    </Grid>
              </ExpansionPanelSummary>
              <ExpansionPanelDetails>
               <div className={classes.cardBody_1}>
                { this.table_body()}
                </div>
            </ExpansionPanelDetails>
           </ExpansionPanel>
           <ExpansionPanel
                square
                expanded={expanded === 'panel2'}
                onChange={this.handleChange_1('panel2')}
              >
             <ExpansionPanelSummary >
                    <Grid xs={10} item sm={10} md={10} className={classes.grid_title}>
                      <Typography variant="subtitle1" className={classes.title_3} >Booking</Typography>                     
                    </Grid>
                    <Grid xs={2} item sm={2} md={2} className={classes.header_2}>                       
                    </Grid>
              </ExpansionPanelSummary>
              <ExpansionPanelDetails>
               <div className={classes.cardBody_12}>
                <BookingRoute bookingStatus={this.state.booking_status}></BookingRoute>
                </div>
            </ExpansionPanelDetails>
           </ExpansionPanel>
          </CardBody>
        </Card>
        </GridItem>
      {/** detail booking */}
        <Dialog
        open={this.state.detail_modal}
        onClose={this.detailModal_close}
        fullWidth={true}
        maxWidth={'md'}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        
        <DialogContent className={classes.dialog_2}>
          <Card className={classes.card_2}  >
                <CardHeader color="primary">
                  <h4 className={classes.cardTitleWhite}>Detail View {this.state.title}</h4>
                  <p className={classes.cardCategoryWhite}>                  
                  </p>
                </CardHeader>
                { this.cardBody() }
          </Card>
        </DialogContent>
        {this.footerAction()}
      </Dialog>  
      {/** add addons */}
      <Dialog
        open={this.state.addAddon_modal}
        onClose={this.editAddonModal_close}
        fullWidth={true}
        maxWidth={'sm'}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="simple-dialog-title" className={classes.dialog_title}>Add Service Addon1</DialogTitle>  
        <DialogContent className={classes.dialog_2}>          
                { this.addAddon_body()} 
        </DialogContent>
        
        <DialogActions className={classes.cardFooter}>
          <GridItem xs={12} sm={12} md={6} >            
          </GridItem>
          <Grid xs={12} item sm={12} md={6} className={classes.cardFooter_1}>
            <Button color="success"  className={classes.button_2} onClick={this.editAddonModal_close} >Cancel</Button>
            <Button color="success" className={classes.button_2}  onClick={this.addonAdd} >Save</Button>
           </Grid>
        </DialogActions>   
       
      </Dialog>     
      {/** edit addons */}
      <Dialog
        open={this.state.editAddon_modal}
        onClose={this.editAddonModal_close}
        fullWidth={true}
        maxWidth={'sm'}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
         <DialogTitle id="simple-dialog-title" className={classes.dialog_title}>Update Service Addon</DialogTitle>  
        <DialogContent className={classes.dialog_2}>         
                { this.editAddon_body()}         
        </DialogContent>
        <DialogActions  className={classes.cardFooter}>
          <GridItem xs={12} sm={12} md={6}>
             <Button  color="success"  className={classes.button_2} onClick={this.deleteBookAddon}>Delete</Button>
          </GridItem>
          <Grid item xs={12} sm={12} md={6} className={classes.cardFooter_1}>
            <Button color="success" className={classes.button_2} onClick={this.editAddonModal_close} >Cancel</Button>
            <Button color="success" className={classes.button_2} onClick={this.addonUpdate} >Update</Button>
          </Grid>         
        </DialogActions>

      </Dialog>
        {/** add services */}
        <Dialog
        open={this.state.addService_modal}
        onClose={this.editServiceModal_close}
        fullWidth={true}
        maxWidth={'sm'}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
         <DialogTitle id="simple-dialog-title" className={classes.dialog_title}>Add Service</DialogTitle> 
        <DialogContent className={classes.dialog_2}>        
                { this.addService_body()}         
        </DialogContent>
        <DialogActions  className={classes.cardFooter}>
           <GridItem xs={12} sm={12} md={6} >            
          </GridItem>
          <Grid xs={12} item sm={12} md={6} className={classes.cardFooter_1}>
            <Button color="success"  className={classes.button_2} onClick={this.addServiceModal_close} >Cancel</Button>
            <Button color="success" className={classes.button_2}  onClick={this.serviceAdd} >Save</Button>
           </Grid>
        </DialogActions>
      </Dialog>
       {/** edit services */}
       <Dialog
        open={this.state.editService_modal}
        onClose={this.editServiceModal_close}
        fullWidth={true}
        maxWidth={'sm'}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >      
        <DialogTitle id="simple-dialog-title" className={classes.dialog_title}>Update Service</DialogTitle>    
        <DialogContent className={classes.dialog_2}>         
                { this.editService_body()}
        </DialogContent>       
        <DialogActions className={classes.cardFooter}>
          <GridItem xs={12} sm={12} md={6} >
             <Button  color="success" className={classes.button_2} onClick={this.deleteBookService}>Delete</Button>
          </GridItem>
          <Grid xs={12} item sm={12} md={6} className={classes.cardFooter_1}>
            <Button color="success"  className={classes.button_2} onClick={this.editServiceModal_close} >Cancel</Button>
            <Button color="success" className={classes.button_2}  onClick={this.serviceUpdate} >Update</Button>
           </Grid>
        </DialogActions>

      </Dialog>
      {/** change booking time */}
      <Dialog
        open={this.state.changeBookingTime_modal}
        onClose={this.changeBookingTime_close}
        fullWidth={true}
        maxWidth={'sm'}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        
        <DialogContent className={classes.dialog_2}>
          <Card className={classes.card_2}  >
                <CardHeader color="info">
                  <h4 className={classes.cardTitleWhite}>Change Booking Time</h4>
                  <p className={classes.cardCategoryWhite}>                  
                  </p>
                </CardHeader>
                <CardBody className={classes.cardBody_1+" "+classes.nothing_1}  >
                <GridContainer >
                  <Grid xs={12} sm={12} item md={12}  >
                  <form className={classes.container} noValidate>
                    <TextField
                      id="bookingTime"
                      label="Booking From"
                      type="datetime-local"
                      onChange={this.handleChange('changedBookingFrom')}     
                      defaultValue={this.state.changedBookingFrom}
                      className={classes.textFieldDate}
                      InputLabelProps={{
                        shrink: true,
                      }}
                    />
                  </form>
                  </Grid>
               </GridContainer>
               </CardBody>
          </Card>
        </DialogContent>
        <DialogActions>
          <Button color="success"   onClick={this.changeBookingTime_close} >Cancel</Button>
           <Button color="success" onClick={this.bookingTimeChange} >Save changes</Button>
        </DialogActions>
      </Dialog>


      </GridContainer>      
    )
  }
}
export default withStyles(bookingStyle)(withSnackbar(withLocalization(withAuth(BookingRequest))));



