import React from 'react';
//import classNames from 'classnames';
import withStyles from '@material-ui/core/styles/withStyles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Edit from "@material-ui/icons/Edit";
import Close from "@material-ui/icons/Close";
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import Create from '@material-ui/icons/AddCircle';
import Grid from '@material-ui/core/Grid';
//import TextField from '@material-ui/core/TextField';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
//import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import MenuItem from '@material-ui/core/MenuItem';
import Select from '@material-ui/core/Select';
import Button from '@material-ui/core/Button';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import FormControl from '@material-ui/core/FormControl';
import {  withSnackbar } from 'notistack';
import InputLabel from '@material-ui/core/InputLabel';
import axios from 'axios';
//import errors from '../../../common/error_codes';
import withAuth from '../../../common/contexts/AuthContext';
//import withLoading from '../../../common/contexts/LoadingContext';
import withNotifications from '../../../common/contexts/NotificationsContext';
import GridItem from "../../../common/components/Grid/GridItem.jsx";
import GridContainer from "../../../common/components/Grid/GridContainer.jsx";
import withLocalization from '../../../common/contexts/LocalizationContext';
import Card from "../../../common/components/Card/Card.jsx";
import CardHeader from "../../../common/components/Card/CardHeader.jsx";
import CardBody from "../../../common/components/Card/CardBody.jsx";
import CustomInput from "../../../common/components/CustomInput/CustomInput.jsx";
import CardFooter from "../../../common/components/Card/CardFooter.jsx";
//import Button from "../../../common/components/CustomButtons/Button.jsx";
import openHoursStyle from '../../assets/css/openhours';

class Employees extends React.Component {
  constructor(props){
    super (props);
    this.state={
      empoyees:[],
      open_dialog_1:false,//employee
      open_dia2:false,//delete dialog
      employee_name:'',
      empoyee_state:'Add',      
      profile_path:'',
      employeeId:'',
      workHours:[],
      last_name:'',
      userType:3,
      resiger_user:false,
      email:'',
      password:''
    };
    this.loadEmployees=this.loadEmployees.bind(this);
  }
  componentWillMount(){
    this.loadEmployees();
  }
  async loadEmployees(){
    const {localization,auth}=this.props;
    const { data } = await axios.get('/api/company/employee');      
    if(data.success){
      this.setState({empoyees:data.employees});
    }
    else{     
      if(data.errorCode==2 || data.errorCode==5 || data.errorCode==3   || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
  }
  createEmployee=()=>{
    this.setState({
      open_dialog_1:true,
      employee_name:'',
      last_name:'',
      profile_path:'',
      empoyee_state:'Add',
      employeeId:'',
      email:'',
      password:'',
      userType:3,
      resiger_user:false
    });
  }
  dia1Close=()=>{
    this.setState({ open_dialog_1: false });
  }
  confirmDialogClose=()=>{
    this.setState({ open_dia2: false,});
  }
  saveEmployee=async()=>{
    const {localization,auth}=this.props;
    if(this.state.empoyee_state=='Add'){
      var { data } = await axios.post('/api/company/employee', {
        employee:{ 
          firstName:this.state.employee_name,
          lastName:this.state.last_name,
          profilePicturePath:this.state.profile_path?this.state.profile_path:'',
          email:this.state.email?this.state.email:'',
          password:this.state.password?this.state.password:'',
          roleId:this.state.userType
        }
      }); 

      if(data.success){      
        this.props.enqueueSnackbar(localization.localizedString('ADDED_SUCCESS'), { 
          variant: 'success',
        });       
      }
      else{
        if(data.errorCode==2 || data.errorCode==5 || data.errorCode==3 || data.errorCode==6 ){        
          this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
            variant: 'error',
          }); 
          await auth.get();       
         }
         else{        
          this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
            variant: 'error',
          }); 
         }
      }
     
    }
    else{
      var { data } = await axios.put('/api/company/employee/'+this.state.employeeId, {
        employee:{ 
          firstName:this.state.employee_name,
          lastName:this.state.last_name,
          profilePicturePath:this.state.profile_path,
          email:this.state.email,
          password:this.state.password,
          roleId:this.state.userType}
      }); 
      if(data.success){       
        this.props.enqueueSnackbar(localization.localizedString('UPDATED_SUCCESS'), { 
          variant: 'success',
        });       
      }
      else{
        if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
          this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
            variant: 'error',
          }); 
          await auth.get();       
         }
         else{        
          this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
            variant: 'error',
          }); 
         }
      }  
    }
    this.setState({open_dialog_1:false,});
    this.loadEmployees();
    
  } 
  editEmployee=(row)=>{
    this.setState({
      open_dialog_1:true,
      employeeId:row.id,
      employee_name:row.firstName,
      last_name:row.lastName,
      profile_path:row.profilePicturePath,
      empoyee_state:'Update',
      email:row.email,
      password:'******',
      userType:row.roleId,
      resiger_user:row.email!=''?true:false
    });
  }
  employeeDelete=()=>{
    this.setState({ open_dia2:true });
  }
   deleteProcess=async()=>{
    const {localization,auth}=this.props;
    const { data } = await axios.delete('/api/company/employee/'+this.state.employeeId);
    if(data.success){    
      this.props.enqueueSnackbar(localization.localizedString('DELETED_SUCCESS'), { 
        variant: 'success',
      }); 
      this.loadEmployees();         
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
    this.setState({open_dia2:false,open_dialog_1:false})

  }
  handleToggle = prop => event => {
    if(!event.target.checked){
      this.setState({email:'',password:'',[prop]: event.target.checked});
    }
    else{
      this.setState({ [prop]: event.target.checked })};
    }
    
  handleChange = prop => event => this.setState({ [prop]: event.target.value });
  employee_tbody=()=>{
    const { classes,localization } = this.props;
     if(this.state.empoyees.length==0){
       return <h4 className={classes.nothing_1}>There is nothing.</h4>
     }
     let table=[];
     let trs=[];
     this.state.empoyees.map(row => { 
      trs.push(
      <TableRow key={row.id} hover>
      <TableCell  className={classes.tableCellId+" "+ classes.gray_title} >{row.id}</TableCell>
      <TableCell  className={classes.gray_title} >
        {row.firstName+" "+row.lastName}
      </TableCell>
      <TableCell  className={classes.tableCell +" "+classes.gray_title} >
        {row.roleId=='3'?'Employee':'Freelancer'}
      </TableCell> 
      <TableCell  className={classes.tableCell +" "+classes.gray_title} >
        {row.profilePicturePath}
      </TableCell>    
      <TableCell  className={classes.tableCell}>
          <Button   size="small" variant="contained" 
          className={classes.button_1} onClick={()=>this.props.nextPage('workhour',row)}>
            Work Hours
          </Button>
      </TableCell>
      <TableCell  className={classes.tableCell}>
          <Button size="small" 
          variant="contained" 
          className={classes.button_1}
          onClick={()=>this.props.nextPage('vacation',row)}
          >
            Vacation
          </Button>
      </TableCell>
      <TableCell  className={classes.tableCellId}>
            <Tooltip
              id="tooltip-top"
              title="Edit Employee"
              placement="top"
              classes={{ tooltip: classes.tooltip }}
            >
              <IconButton
                aria-label="Edit"
               
                onClick={() =>(this.editEmployee(row))}              
                
              >
                <Edit
                  className={
                    classes.tableActionButtonIcon + " " + classes.edit
                  }
                />
              </IconButton>
            </Tooltip>
      </TableCell>
      
    </TableRow>);
     });
       table.push(<Table key={1} className={classes.table}>
      <TableHead>
        <TableRow >
          <TableCell  className={classes.tableCellId+" "+classes.tableHeader_1}>ID</TableCell>
          <TableCell  className={classes.tableCell+" "+classes.tableHeader_1}>Employee Name</TableCell>
          <TableCell  className={classes.tableCell+" "+classes.tableHeader_1}>User Type</TableCell>
          <TableCell  className={classes.tableCell+" "+classes.tableHeader_1}>Profile Picture Path</TableCell>   
          <TableCell  className={classes.tableCell+" "+classes.tableHeader_1}></TableCell>  
          <TableCell  className={classes.tableCell+" "+classes.tableHeader_1}></TableCell>      
          <TableCell  className={classes.tableCellId+" "+classes.tableHeader_1}>Edit</TableCell>
          
        </TableRow>
      </TableHead>
      <TableBody>
        {trs}
     </TableBody>
    </Table>);

    return table;
  }
  render(){
    const { classes,localization } = this.props;
    return(
      <Grid container className={classes.container_1}>
            <GridItem xs={2} sm={2} md={8}>             
            </GridItem>
            <Grid xs={10} item sm={10} md={4} className={classes.header_2}>
              <Button variant="contained" 
                onClick={this.createEmployee}
              color="secondary" className={classes.button}>                
                  <Create
                    className={
                        classes.create
                    }
                  />
                Add Employee
              </Button>   
          </Grid>    
      <GridItem xs={12} sm={12} md={12}>
        <Card>
         {/**
          <CardHeader color="primary">            
          <GridContainer>
            <GridItem xs={10} sm={10} md={10}>
              <h4 className={classes.cardTitleWhite}>Employees</h4>
              <p className={classes.cardCategoryWhite}>             
              </p>
            </GridItem>
            <Grid xs={2} item sm={2} md={2} className={classes.header_2}>
                  <Tooltip
                  id="tooltip-top-start"
                  title="Add Category"
                  placement="top"
                  classes={{ tooltip: classes.tooltip }}
                  >
                    <IconButton
                      aria-label="Close"
                      className={classes.tableActionButton}
                      onClick={this.createEmployee}
                    >
                      <Create
                        className={
                           classes.create
                        }
                      />
                    </IconButton>
                  </Tooltip>                 
            </Grid>
           </GridContainer>            
          </CardHeader>
          */}

          <CardBody className={classes.cardBody_1}>          
              {this.employee_tbody()}
         </CardBody>
         </Card>
      </GridItem>
    {/** dialog for employee */}
      <Dialog
          fullWidth={true}
          maxWidth={'sm'}
          open={this.state.open_dialog_1}
          onClose={this.dia1Close}
          aria-labelledby="max-width-dialog-title"         
        >         
          <DialogTitle id="simple-dialog-title" className={classes.dialog_title}>{this.state.empoyee_state} Employee</DialogTitle>   
          <DialogContent className={classes.dialog_22}>
           
                <GridContainer  justify={'center'}>
                    <Grid item xs={12} sm={12} md={11}>
                      <CustomInput
                        labelText="First Name"
                        id="firstName"
                        inputProps={{
                          value:this.state.employee_name,
                        }}
                        formControlProps={{
                          required: true,
                          fullWidth: true,                         
                          value:this.state.employee_lastname,
                          onChange: this.handleChange('employee_name')
                        }}
                      />
                    </Grid>
                    <Grid item xs={12} sm={12} md={11}>
                      <CustomInput
                        labelText="Last Name"
                        id="lastName"
                        inputProps={{
                          value:this.state.last_name,
                        }}
                        formControlProps={{
                          required: true,
                          fullWidth: true,                         
                          value:this.state.last_name,
                          onChange: this.handleChange('last_name')
                        }}
                      />
                    </Grid>
                    <Grid item xs={12} sm={12} md={11} className={classes.formControl_5} >
                      <CustomInput
                        labelText="Profile Picture"
                        id="profile_picture"
                        inputProps={{
                          value:this.state.profile_path,
                        }}
                        formControlProps={{                       
                          fullWidth: true,                         
                          value:this.state.profile_path,
                          onChange: this.handleChange('profile_path')
                        }}
                      />
                    </Grid>
                    <Grid item xs={12} sm={12} md={6}>
                      <FormControl className={classes.formControl_6}>
                            <InputLabel htmlFor="age-simple">User Type</InputLabel>
                            <Select
                              value={this.state.userType}
                              onChange={this.handleChange('userType')}
                              inputProps={{
                                name: 'userType',
                                id: 'age-simple',
                              }}
                            >
                              <MenuItem value={3}>Employee</MenuItem>
                              <MenuItem value={4}>Freelancer</MenuItem>        
                            </Select>
                      </FormControl>
                    </Grid>
                    <Grid item xs={12} sm={12} md={5} >
                          <FormControlLabel
                                control={(
                                  <Checkbox
                                    tabIndex={-1}
                                    disableRipple       
                                    onClick={this.handleToggle('resiger_user')}                      
                                    checked={this.state.resiger_user}
                                  />
                                )}
                                classes={{ label: classes.label }}
                                label={"Register user"}
                          />
                    </Grid>
                   {
                    this.state.resiger_user? <Grid item xs={12} sm={12} md={11} >
                      <CustomInput
                        labelText="Email"
                        id="email"
                        inputProps={{
                          value:this.state.email,
                        }}
                        formControlProps={{
                          required: true,
                          fullWidth: true,                         
                          value:this.state.email,
                          onChange: this.handleChange('email')
                        }}
                      />
                    </Grid>:''
                   }
                   {
                    this.state.resiger_user?<Grid item xs={12} sm={12} md={11} className={classes.formControl_5}>
                      <CustomInput
                        labelText="Password"
                        id="password"
                        inputProps={{
                          type: 'password',
                          value:this.state.password,
                        }}
                        formControlProps={{
                          required: true,
                          fullWidth: true,                         
                          value:this.state.password,
                          onChange: this.handleChange('password')
                        }}
                      />
                    </Grid>:''
                   }
                    
                </GridContainer> 
          </DialogContent>
          <DialogActions className={classes.cardFooter}>
              <GridItem xs={12} sm={12} md={6}>
             {
              this.state.employeeId!=''?<Button color="primary" onClick={this.employeeDelete}>Delete</Button>:''
             } 
              </GridItem>
              <Grid item xs={12} sm={12} md={6} className={classes.cardFooter_1}>
                  <Button  onClick={this.dia1Close}  color="secondary" >Cancel</Button>
                  <Button  variant="contained" color="secondary"  className={classes.button_2} disabled={this.state.employee_name.length==0 }                
                        onClick={this.saveEmployee}>Save</Button>
              </Grid>          
          </DialogActions>
      </Dialog> 
      {/** delete category dialog */}
      <Dialog
        open={this.state.open_dia2}
        onClose={this.confirmDialogClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">{"Are you sure to delete?"}</DialogTitle>
        <DialogContent>       
        </DialogContent>
        <DialogActions>
          <Button onClick={this.confirmDialogClose} color="primary" autoFocus>
            Cancel
          </Button>
          <Button  onClick={this.deleteProcess} variant="contained" color="secondary" >
            Yes
          </Button>
        </DialogActions>
      </Dialog>     

     </Grid>
    )
  }
}
export default withStyles(openHoursStyle)(withSnackbar(withLocalization(withAuth(Employees))));
