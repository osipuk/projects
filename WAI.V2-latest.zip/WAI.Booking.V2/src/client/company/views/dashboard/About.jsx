import React from 'react';
//import classNames from 'classnames';
import withStyles from '@material-ui/core/styles/withStyles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Edit from "@material-ui/icons/Edit";
import Close from "@material-ui/icons/Close";
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import Create from '@material-ui/icons/AddCircle';
import Grid from '@material-ui/core/Grid';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Success from '@material-ui/icons/CheckCircle';

import Typography from '@material-ui/core/Typography';
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';

import Select from '@material-ui/core/Select';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import axios from 'axios';
import Button from '@material-ui/core/Button';
import {  withSnackbar } from 'notistack';

import withAuth from '../../../common/contexts/AuthContext';
//import withNotifications from '../../../common/contexts/NotificationsContext';
import GridItem from "../../../common/components/Grid/GridItem.jsx";
import GridContainer from "../../../common/components/Grid/GridContainer.jsx";
import withLocalization from '../../../common/contexts/LocalizationContext';
import Card from "../../../common/components/Card/Card.jsx";
import CardHeader from "../../../common/components/Card/CardHeader.jsx";
import CardBody from "../../../common/components/Card/CardBody.jsx";
import CustomInput from "../../../common/components/CustomInput/CustomInput.jsx";
import CardFooter from "../../../common/components/Card/CardFooter.jsx";
//import Button from "../../../common/components/CustomButtons/Button.jsx";
//import Button from '@material-ui/core/Button';
import aboutStyle from '../../assets/css/about';
var button_event=false;

class About extends React.Component {
  constructor(props){
    super (props);
    this.state={
      abouts:[],
      languages:[],
      open_dialog_1:false,//employee
      open_dia2:false,//delete dialog
      about:'',
      about_state:'Add',    
      language:1,
      workHours:[],
      aboutId:'',
      expanded:'panel1',
      terms:[],
      open_dialog_2:false,
      termId:'',
      term:'',
      terms_state:'Add'
    };    
  }
  componentWillMount(){
    this.loadAbouts();    
    this.loadLanguages();
  }

  loadLanguages=async()=>{
    const {localization}=this.props;
    const { data } = await axios.get('/api/company/languages');       
    if(data.success){
      this.setState({languages:data.languages});      
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }    
  }
  loadAbouts=async()=>{
    const {localization,auth}=this.props;
    const { data } = await axios.get('/api/company/about');  
    console.log(data)  ;
    if(data.success){
      this.setState({abouts:data.abouts,terms:data.terms});      
    }
    else{

      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
  }
  createAbout=()=>{
    button_event=true;
    setTimeout(() => {
      button_event=false;
    }, 1000);
    this.setState({
      open_dialog_1:true,
      employee_name:'',
      about:'',
      expanded:'panel1',
      about_state:'Add',
      aboutId:''
    });
  }
  dia1Close=()=>{
    this.setState({ open_dialog_1: false,open_dialog_2:false });
  }
  confirmDialogClose=()=>{
    this.setState({ open_dia2: false,});
  }
  saveDescription=async()=>{
    const {localization,auth}=this.props;
    if(this.state.about_state=='Add'){
      var { data } = await axios.post('/api/company/about', {
        about:{ 
          about:this.state.about,
          languageId:this.state.language}
      });
      if(data.success){
        this.setState({open_dialog_1:false,}); 
        this.loadAbouts(); 
        this.props.enqueueSnackbar(localization.localizedString('ADDED_SUCCESS'), { 
          variant: 'success',
        });              
      }
      else{
        if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
          this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
            variant: 'error',
          }); 
          await auth.get();       
         }
         else{        
          this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
            variant: 'error',
          }); 
         }
      }
    }
    else{
      var { data } = await axios.put('/api/company/about/'+this.state.aboutId, {
        about:{ 
          about:this.state.about,
          languageId:this.state.language
          }
      }); 
      if(data.success){
        this.setState({open_dialog_1:false,}); 
        this.loadAbouts();
        this.props.enqueueSnackbar(localization.localizedString('UPDATED_SUCCESS'), { 
          variant: 'success',
        });     
      }
      else{
        if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
          this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
            variant: 'error',
          }); 
          await auth.get();       
         }
         else{        
          this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
            variant: 'error',
          }); 
         }
      }  
    }
    
    
  } 
  editAbout=(row,languageId)=>{
    this.setState({
      open_dialog_1:true,
      aboutId:row.id,      
      about:row.about,
      language:languageId,
      about_state:'Update'
    });
  }
  aboutDelete=()=>{
    this.setState({ pen_dia2:true });
  }

  editTerms=(row,languageId)=>{
    this.setState({
      open_dialog_2:true,
      termId:row.id,
      term:row.terms,
      language:languageId,
      terms_state:'Update'
    });
  }

  createTerm=()=>{    
    button_event=true;
    setTimeout(() => {
      button_event=false;
    }, 1000);
      this.setState({
        open_dialog_2:true,    
        term:'',
        terms_state:'Add',
        termId:'',
        expanded:'panel2'
      });
   
  }
  deleteProcess=async()=>{
    const {localization,auth}=this.props;
    const { data } = await axios.delete('/api/company/about/'+this.state.aboutId);
    if(data.success){
      this.props.enqueueSnackbar(localization.localizedString('DELETED_SUCCESS'), { 
        variant: 'success',
      }); 
      this.loadAbouts();       
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
    this.setState({open_dia2:false});
  }
  handleChange = prop => event => this.setState({ [prop]: event.target.value });
  languageChange=event=>{
    this.setState({language:event.target.value});
  }

  handleChange_1 = panel => (event, expanded) => {
    if(button_event)
      return;
    this.setState({
      expanded: expanded ? panel : false,
    });
  };

  about_tbody=()=>{
    const { classes,localization } = this.props;
    const {abouts,languages}=this.state;
     if(abouts.length==0){
       return <h4 className={classes.nothing_1}>There is nothing.</h4>
     }
     let table=[];
     let trs=[];
     abouts.map(row => { 
      let language='';
      let languageId=1;
      languages.map(item=>{
        if(item.id==row.languageId){
          language=item.name;
          languageId=item.id;
        }
      })
      trs.push(
      <TableRow key={row.id} hover>
      <TableCell  className={classes.tableCellId+" "+classes.gray_title} >{row.id}</TableCell>
      <TableCell  className={classes.tableCell+" "+classes.gray_title} >
        {row.about}
      </TableCell>
      <TableCell  className={classes.tableCell+" "+classes.gray_title} >
        {language}
      </TableCell>      
      <TableCell  className={classes.tableCellId+" "+classes.gray_title}>
            <Tooltip
              id="tooltip-top"
              title="Edit Category"
              placement="top"
              classes={{ tooltip: classes.tooltip }}
            >
              <IconButton
                aria-label="Edit"               
                onClick={() =>(this.editAbout(row,languageId))} 
                
              >
                <Edit
                  className={
                    classes.tableActionButtonIcon + " " + classes.view
                  }
                />
              </IconButton>
            </Tooltip>
      </TableCell>
     
    </TableRow>);
     });
       table.push(<Table key={1} className={classes.table}>
      <TableHead>
        <TableRow >
          <TableCell  className={classes.tableCellId+" "+classes.tableHeader_1}>ID</TableCell>
          <TableCell  className={classes.tableCell+" "+classes.tableHeader_1}>Description</TableCell>
          <TableCell  className={classes.tableCell+" "+classes.tableHeader_1}>Laguage</TableCell>
          <TableCell  className={classes.tableCellId+" "+classes.tableHeader_1}>Edit</TableCell>
         
        </TableRow>
      </TableHead>
      <TableBody>
        {trs}
     </TableBody>
    </Table>);

    return table;
  }

  terms_body=()=>{
    const { classes,localization } = this.props;
    const {terms,languages}=this.state;
     if(terms.length==0){
       return <h4 className={classes.nothing_1}>There is nothing.</h4>
     }
     let table=[];
     let trs=[];
     terms.map(row => { 
      let language='';
      let languageId=1;
      languages.map(item=>{
        if(item.id==row.languageId){
          language=item.name;
          languageId=item.id;
        }
      })
      trs.push(
      <TableRow key={row.id} hover>
      <TableCell  className={classes.tableCellId+" "+classes.gray_title} >{row.id}</TableCell>
      <TableCell  className={classes.tableCell+" "+classes.gray_title} >
        {row.terms}
      </TableCell>
      <TableCell  className={classes.tableCell+" "+classes.gray_title} >
        {language}
      </TableCell>      
      <TableCell  className={classes.tableCellId+" "+classes.gray_title}>
            <Tooltip
              id="tooltip-top"
              title="Edit Terms of Service"
              placement="top"
              classes={{ tooltip: classes.tooltip }}
            >
              <IconButton
                aria-label="Edit"             
                onClick={() =>(this.editTerms(row,languageId))}              
                
              >
                <Edit
                  className={
                    classes.tableActionButtonIcon + " " + classes.view
                  }
                />
              </IconButton>
            </Tooltip>
      </TableCell>     
    </TableRow>);
     });
       table.push(<Table key={1} className={classes.table}>
      <TableHead>
        <TableRow >
          <TableCell  className={classes.tableCellId+" "+classes.tableHeader_1}>ID</TableCell>
          <TableCell  className={classes.tableCell+" "+classes.tableHeader_1}>Terms of Service</TableCell>
          <TableCell  className={classes.tableCell+" "+classes.tableHeader_1}>Laguage</TableCell>
          <TableCell  className={classes.tableCellId+" "+classes.tableHeader_1}>Edit</TableCell>        
        </TableRow>
      </TableHead>
      <TableBody>
        {trs}
     </TableBody>
    </Table>);

    return table;
  }
  saveTerms=async()=>{
    console.log(this.state.terms_state);
    const {localization,auth}=this.props;
    if(this.state.terms_state=='Add'){
      var { data } = await axios.post('/api/company/termsofservice', {
        terms:{ 
          terms:this.state.term,
          languageId:this.state.language}
      });
      if(data.success){
        this.setState({open_dialog_2:false,}); 
        this.loadAbouts();
        this.props.enqueueSnackbar(localization.localizedString('ADDED_SUCCESS'), { 
          variant: 'success',
        });              
      }
      else{
        if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
          this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
            variant: 'error',
          }); 
          await auth.get();       
         }
         else{        
          this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
            variant: 'error',
          }); 
         }
      }
    }
    else{
      var { data } = await axios.put('/api/company/termsofservice/'+this.state.termId, {
        terms:{ 
          terms:this.state.term,
          languageId:this.state.language
          }
      }); 
      if(data.success){
        this.setState({open_dialog_2:false,}); 
        this.loadAbouts();
        this.props.enqueueSnackbar(localization.localizedString('UPDATED_SUCCESS'), { 
          variant: 'success',
        });     
      }
      else{
        if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
          this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
            variant: 'error',
          }); 
          await auth.get();       
         }
         else{        
          this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
            variant: 'error',
          }); 
         }
      }  
    }  
  } 

  deleteTerms=async()=>{
    const {localization,auth}=this.props;
    const { data } = await axios.delete('/api/company/termsofservice/'+this.state.termId);
    if(data.success){
      this.props.enqueueSnackbar(localization.localizedString('DELETED_SUCCESS'), { 
        variant: 'success',
      }); 
      this.loadAbouts();       
    }
    else{
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
    }
    this.setState({open_dia2:false,open_dialog_2:false});
  }

  render(){
    const { classes,localization } = this.props;
    const {expanded}=this.state;
    var about_title = "About";   
    return(
      <Grid container className={classes.container_1}>
          <GridItem xs={2} sm={2} md={8}>             
          </GridItem>
          <Grid xs={10} item sm={10} md={4} className={classes.header_2}>
            <Button variant="contained" 
              onClick={this.createEmployee}
              color="secondary" className={classes.button}>                
                <Create
                  className={
                      classes.create
                }
                />
              Add Product
            </Button>   
        </Grid>    
       <GridItem xs={12} sm={12} md={12}>
        <Card>         
          <CardBody className={classes.cardBody_1}>    
              <ExpansionPanel
                square
                expanded={expanded === 'panel1'}
                onChange={this.handleChange_1('panel1')}
              >
                  <ExpansionPanelSummary >
                    <Grid xs={10} item sm={10} md={10} className={classes.grid_title}>
                      <Typography variant="subtitle1" className={classes.title_3} >{about_title}</Typography>                     
                    </Grid>
                    <Grid xs={2} item sm={2} md={2} className={classes.header_2}>
                        <Tooltip title="Filter list">
                          <IconButton
                          aria-label="Filter list"
                          onClick={this.createAbout}
                          >
                            <Create />
                          </IconButton>
                        </Tooltip>
                    </Grid>
                  </ExpansionPanelSummary>
                  <ExpansionPanelDetails>
                    <div className={classes.cardBody_1}>
                      {this.about_tbody()}
                    </div>
                </ExpansionPanelDetails>
              </ExpansionPanel>      

              <ExpansionPanel
                square
                expanded={expanded === 'panel2'}
                onChange={this.handleChange_1('panel2')}
              >
                  <ExpansionPanelSummary >
                    <Grid xs={10} item sm={10} md={10} className={classes.grid_title}>
                      <Typography variant="subtitle1" className={classes.title_3} >Terms of Service</Typography>                     
                    </Grid>
                    <Grid xs={2} item sm={2} md={2} className={classes.header_2}>
                        <Tooltip title="Filter list">
                          <IconButton
                          aria-label="Filter list"
                          onClick={this.createTerm}
                          >
                            <Create />
                          </IconButton>
                        </Tooltip>
                    </Grid>
                  </ExpansionPanelSummary>
                  <ExpansionPanelDetails>
                    <div className={classes.cardBody_1}>
                      {this.terms_body()}
                    </div>
                </ExpansionPanelDetails>
              </ExpansionPanel>      
             
         </CardBody>
         </Card>
      </GridItem>
    {/** dialog for about */}
      <Dialog
          fullWidth={true}
          maxWidth={'sm'}
          open={this.state.open_dialog_1}
          onClose={this.dia1Close}
          aria-labelledby="max-width-dialog-title"         
        >         
          <DialogTitle id="simple-dialog-title" className={classes.dialog_title}>{this.state.about_state} About</DialogTitle>
          <DialogContent className={classes.dialog_22}>
                <GridContainer  justify={'center'}>
                    <GridItem xs={12} sm={12} md={11}>
                            <FormControl className={classes.formControl}>
                              <InputLabel htmlFor="age-simple">Language</InputLabel>
                              <Select
                                value={this.state.language}
                                onChange={this.languageChange}
                                inputProps={{
                                  name: 'addon_gender',
                                  id: 'age-simple',
                                }}
                              >                                                            

                                {this.state.languages.map(row=>(
                                  <MenuItem key={row.id} value={row.id}>{row.name}</MenuItem>
                                ))}
                               
                                   
                              </Select>
                           </FormControl>
                    </GridItem>
                    <GridItem xs={12} sm={12} md={11}>
                      <CustomInput
                                labelText="About Description"              
                                inputProps={{
                                value:this.state.about,
                                multiline: true,
                                rows: 5
                              }}
                              formControlProps={{
                                className:classes.customInput_1,   
                                onChange: this.handleChange('about')
                              }}
                       />
                    </GridItem>
                </GridContainer>                
          </DialogContent>
          <DialogActions className={classes.cardFooter}>
                  <GridItem xs={12} sm={12} md={6}>
                    {
                      this.state.aboutId != '' ? <Button color="primary" onClick={this.aboutDelete}>Delete</Button> : ''
                    }
                  </GridItem>
                  <Grid item xs={12} sm={12} md={6} className={classes.cardFooter_1}>
                    <Button onClick={this.dia1Close} >Cancel</Button>
                    <Button variant="contained" color="secondary" className={classes.button_2}   disabled={this.state.about.length==0}
                      onClick={this.saveDescription}>Save</Button>
                  </Grid>
            </DialogActions>
      </Dialog> 

      {/** dialog for Terms of service */}
      <Dialog
          fullWidth={true}
          maxWidth={'sm'}
          open={this.state.open_dialog_2}
          onClose={this.dia1Close}
          aria-labelledby="max-width-dialog-title"         
        >         
          <DialogTitle id="simple-dialog-title" className={classes.dialog_title}>{this.state.about_state} Terms of Service</DialogTitle>
          <DialogContent className={classes.dialog_22}>
                <GridContainer  justify={'center'}>
                    <GridItem xs={12} sm={12} md={11}>
                            <FormControl className={classes.formControl}>
                              <InputLabel htmlFor="age-simple">Language</InputLabel>
                              <Select
                                value={this.state.language}
                                onChange={this.languageChange}
                                inputProps={{
                                  name: 'addon_gender',
                                  id: 'age-simple',
                                }}
                              >                                                            

                                {this.state.languages.map(row=>(
                                  <MenuItem key={row.id} value={row.id}>{row.name}</MenuItem>
                                ))}
                               
                                   
                              </Select>
                           </FormControl>
                    </GridItem>
                    <GridItem xs={12} sm={12} md={11}>
                      <CustomInput
                                labelText="Terms of Services"              
                                inputProps={{
                                value:this.state.term,
                                multiline: true,
                                rows: 5
                              }}
                              formControlProps={{
                                className:classes.customInput_1,   
                                onChange: this.handleChange('term')
                              }}
                       />
                    </GridItem>
                </GridContainer>                
          </DialogContent>
          <DialogActions className={classes.cardFooter}>
                  <GridItem xs={12} sm={12} md={6}>
                    {
                      this.state.termId != '' ? <Button color="primary" onClick={this.deleteTerms}>Delete</Button> : ''
                    }
                  </GridItem>
                  <Grid item xs={12} sm={12} md={6} className={classes.cardFooter_1}>
                    <Button onClick={this.dia1Close} >Cancel</Button>
                    <Button variant="contained" color="secondary" className={classes.button_2}   disabled={this.state.term.length==0}
                      onClick={this.saveTerms}>Save</Button>
                  </Grid>
            </DialogActions>
      </Dialog> 

      {/** delete category dialog */}
      <Dialog
        open={this.state.open_dia2}
        onClose={this.confirmDialogClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">{"Are you sure to delete?"}</DialogTitle>
        <DialogContent>       
        </DialogContent>
        <DialogActions>
          <Button onClick={this.confirmDialogClose} color="secondary" >
            Cancel
          </Button>
          <Button  variant="contained" onClick={this.deleteProcess} color="secondary" autoFocus>
            Yes
          </Button>
        </DialogActions>
      </Dialog>     

     </Grid>
    )
  }
}
export default withStyles(aboutStyle)(withSnackbar(withLocalization(withAuth(About))));
