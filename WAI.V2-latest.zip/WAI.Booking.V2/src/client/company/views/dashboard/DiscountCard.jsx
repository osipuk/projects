import React from 'react';
import moment from 'moment'
import withStyles from '@material-ui/core/styles/withStyles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Success from '@material-ui/icons/CheckCircle';
import Select from "@material-ui/core/Select";
import InputLabel from "@material-ui/core/InputLabel";
import FormControl from "@material-ui/core/FormControl";
import MenuItem from "@material-ui/core/MenuItem";
import Grid from '@material-ui/core/Grid';
import Tooltip from "@material-ui/core/Tooltip";
import IconButton from "@material-ui/core/IconButton";
import Edit from "@material-ui/icons/Edit";
import Button from '@material-ui/core/Button';
import axios from 'axios';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import { withSnackbar } from 'notistack';
import Typography from '@material-ui/core/Typography';
import withAuth from '../../../common/contexts/AuthContext';
import GridItem from "../../../common/components/Grid/GridItem.jsx";
import GridContainer from "../../../common/components/Grid/GridContainer.jsx";
import withLocalization from '../../../common/contexts/LocalizationContext';
import CustomInput from "../../../common/components/CustomInput/CustomInput.jsx";
//import Button from "../../../common/components/CustomButtons/Button.jsx";
import servicesStyle from '../../assets/css/services';

class DiscountCard extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      discountModal: false,
      dialog_state: 'Add',
      active: true,
      discoutService: '',
      discoutExtra: '',
      services: [],
      extras: [],
      numberOfServices: '',
      price: '',
      discountCards: [],
      rowSelected: [],
      serviceId: '',
      extraId: '',
      selectRowId: '',
      delete_confirm: false
    };
  }
  componentWillReceiveProps(nowprops) {
    if (nowprops.createState) {
      this.setState({
        discountModal: nowprops.createState,
        dialog_state: 'Add',
        discoutService: '',
        discoutExtra: '',
        numberOfServices: '',
        price: ''
      });
    }
  }

  componentWillMount = async () => {
    this.loadDiscountCard();
  }
  loadDiscountCard = async () => {
    const { data } = await axios.get('/api/company/discount_card/getall');
    if (data.success) {
      this.setState({
        services: data.services,
        extras: data.extras,
        discountCards: data.discountCards
      })
    }
  }
  saveDsicountCard = async () => {
    const { localization, auth } = this.props;
    if (this.state.discoutExtra == '' && this.state.discoutService == '') {
      return;
    }
    var data = {};
    if (this.state.dialog_state == 'Add') {
      var { data } = await axios.post('/api/company/discount_card/save', {
        discountCard: {
          numberOfServices: this.state.numberOfServices,
          price: this.state.price,
          serviceId: this.state.discoutService,
          serviceExtraId: this.state.discoutExtra,
          active: this.state.active,
          serviceType: this.state.discoutExtra == '' ? '0' : '1'
        }
      }
      );
      if (data.success) {
        this.props.enqueueSnackbar(localization.localizedString('ADDED_SUCCESS'), {
          variant: 'success',
        });
      }
    }
    else if (this.state.dialog_state == 'Update') {
      var { data } = await axios.put('/api/company/discount_card/update/' + this.state.selectRowId, {
        discountCard: {
          numberOfServices: this.state.numberOfServices,
          price: this.state.price,
          serviceId: this.state.discoutService,
          serviceExtraId: this.state.discoutExtra,
          active: this.state.active,
          serviceType: this.state.discoutExtra == '' ? '0' : '1'
        }
      }
      );
      if (data.success) {
        this.props.enqueueSnackbar(localization.localizedString('UPDATED_SUCCESS'), {
          variant: 'success',
        });
      }
    }

    this.setState({ discountModal: false, selectRowId: '' });
    this.loadDiscountCard();
    if (!data.success) {
      if (data.errorCode == 2 || data.errorCode == 5 || data.errorCode == 6) {
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), {
          variant: 'error',
        });
        await auth.get();
      }
      else {
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), {
          variant: 'error',
        });
      }
    }
  }

  discountCardDelete = () => {
    this.setState({ delete_confirm: true });
  }
  delete_process = async () => {
    const { localization, auth } = this.props;
    var { data } = await axios.delete('/api/company/discount_card/delete/' + this.state.selectRowId);
    if (data.success) {
      this.props.enqueueSnackbar(localization.localizedString('DELETED_SUCCESS'), {
        variant: 'success',
      });
      this.loadDiscountCard();
    }
    else {
      if (data.errorCode == 2 || data.errorCode == 3 || data.errorCode == 5 || data.errorCode == 6) {
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), {
          variant: 'error',
        });
        await auth.get();
      }
      else {
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), {
          variant: 'error',
        });
      }
    }
    this.setState({ delete_confirm: false, discountModal: false })
  }

  discountIdserviceChange = async (event, rid) => {
    const { localization, auth } = this.props;
    var { data } = await axios.put('/api/company/discount_card/update/' + rid, {
      discountCard: {
        serviceId: event.target.value,
        serviceExtraId: '',
        serviceType: '0'
      }
    });

    if (!data.success) {
      if (data.errorCode == 2 || data.errorCode == 5 || data.errorCode == 6) {
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), {
          variant: 'error',
        });
        await auth.get();
      }
      else {
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), {
          variant: 'error',
        });
      }
    }
    this.setState({ serviceId: event.target.value, selectRowId: rid, extraId: '' });
    this.loadDiscountCard();

  }
  discountIdExtraChange = async (event, rid) => {
    const { localization, auth } = this.props;
    var { data } = await axios.put('/api/company/discount_card/update/' + rid, {
      discountCard: {
        serviceId: '',
        serviceExtraId: event.target.value,
        serviceType: '1'
      }
    });

    if (!data.success) {
      if (data.errorCode == 2 || data.errorCode == 5 || data.errorCode == 6) {
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), {
          variant: 'error',
        });
        await auth.get();
      }
      else {
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), {
          variant: 'error',
        });
      }
    }
    this.setState({ extraId: event.target.value, selectRowId: rid, serviceId: '' });
    this.loadDiscountCard();
  }

  handleChange = prop => event => this.setState({ [prop]: event.target.value });
  handleToggle = prop => event => this.setState({ [prop]: event.target.checked });
  serviceChange = (event) => {
    this.setState({
      [event.target.name]: event.target.value, discoutExtra: ''
    });
  }
  extraChange = (event) => {
    this.setState({
      [event.target.name]: event.target.value, discoutService: ''
    });
  }
  closeDialog = () => {
    this.props.closeCardState();
    this.setState({ discountModal: false, delete_confirm: false });
  }
  rowClick = () => {

  }
  table_body = () => {
    const { classes, localization } = this.props;
    let tbl = [];
    let trs = [];
  }

  changeActive = async (event, rid) => {
    var checked = event.target.checked;
    const { localization, auth } = this.props;
    var { data } = await axios.put('/api/company/discount_card/update/' + rid, {
      discountCard: {
        active: checked ? 1 : 0
      }
    });

    if (!data.success) {
      if (data.errorCode == 2 || data.errorCode == 5 || data.errorCode == 3 || data.errorCode == 6) {
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), {
          variant: 'error',
        });
        await auth.get();
      }
      else {
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), {
          variant: 'error',
        });
      }
    }
    //this.setState({extraId:event.target.value,selectRowId:rid,serviceId:''});
    this.loadDiscountCard();
  }
  editDiscountCard = (row) => {
    this.setState({
      discountModal: true,
      dialog_state: 'Update',
      discoutService: row.serviceId,
      discoutExtra: row.serviceExtraId,
      numberOfServices: row.numberOfServices,
      price: row.price,
      active: row.active ? true : false,
      selectRowId: row.id
    });
  }
  isSelected = id => this.state.rowSelected.indexOf(id) !== -1;
  render() {
    const { classes, localization, auth } = this.props;
    const { discountCards, serviceId, extraId, services, selectRowId, extras } = this.state;
    return (
      <GridContainer>
        <GridItem xs={12} sm={12} md={12}>
          <Table className={classes.table} aria-labelledby="tableTitle">
            <TableHead>
              <TableRow>
                <TableCell padding="checkbox">
                </TableCell>
                <TableCell className={classes.dark_title}>
                  Number of Services
                  </TableCell>
                <TableCell className={classes.dark_title}>
                  Price ({auth.user.currency_code})
                  </TableCell>
                <TableCell className={classes.dark_title}>
                  Service
                  </TableCell>
                <TableCell className={classes.dark_title}>
                  Service Extra
                  </TableCell>
                <TableCell className={classes.dark_title}>
                  Active
                  </TableCell>
                <TableCell className={classes.dark_title}>
                  Edit
                 </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {discountCards.map(row => {
                return <TableRow key={row.id}>
                  <TableCell padding="checkbox">
                    <Checkbox checked={this.isSelected(row.id)}
                      onClick={() => this.rowClick(row.id)}
                    />
                  </TableCell>
                  <TableCell className={classes.gray_title}> {row.numberOfServices}</TableCell>
                  <TableCell className={classes.gray_title}> {row.price}</TableCell>
                  <TableCell className={classes.gray_title}>
                    <FormControl className={classes.formControl_3}>
                      <Select
                        disableUnderline
                        value={selectRowId != row.id ? row.serviceId : serviceId}
                        onChange={(event) => this.discountIdserviceChange(event, row.id)}
                        inputProps={{
                          name: 'serviceId',
                          id: 'serviceId',
                          className: classes.select_font
                        }}
                      >
                        {
                          services.map(item => {
                            return <MenuItem key={item.id} value={item.id}> {item.name} </MenuItem >
                          })
                        }

                      </Select>
                    </FormControl>
                  </TableCell>
                  <TableCell className={classes.gray_title}>
                    <FormControl className={classes.formControl_3}>
                      <Select
                        disableUnderline
                        value={selectRowId != row.id ? row.serviceExtraId : extraId}
                        onChange={(event) => this.discountIdExtraChange(event, row.id)}
                        inputProps={{
                          name: 'extraId',
                          id: 'extraId',
                          className: classes.select_font
                        }}
                      >
                        {
                          extras.map(item => {
                            return <MenuItem key={item.id} value={item.id}> {item.name} </MenuItem >
                          })
                        }

                      </Select>
                    </FormControl>
                  </TableCell>
                  <TableCell className={classes.gray_title}>
                    <Checkbox checked={row.active ? true : false}
                      onClick={(event) => this.changeActive(event, row.id)}
                    />
                  </TableCell>
                  <TableCell className={classes.tableCellId}>
                    <Tooltip
                      id="tooltip-top"
                      title="Edit Service"
                      placement="top"
                      classes={{ tooltip: classes.tooltip }}
                    >
                      <IconButton
                        aria-label="Edit"
                        onClick={() => (this.editDiscountCard(row))}

                      >
                        <Edit
                          className={
                            classes.tableActionButtonIcon + " " + classes.edit
                          }
                        />
                      </IconButton>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              })}

            </TableBody>

          </Table>

          {/** for modal */}
          <Dialog
            fullWidth={true}
            maxWidth={'sm'}
            open={this.state.discountModal}
            onClose={this.closeDialog}
            aria-labelledby="max-width-dialog-title"
          >
            <DialogTitle id="simple-dialog-title" className={classes.dialog_title}>{this.state.dialog_state} Discount Card</DialogTitle>
            <DialogContent className={classes.dialog_2}>
              <Grid container className={classes.dialog_3} justify={'center'}>
                <Grid item xs={12} sm={12} md={10}>
                  <CustomInput
                    labelText="Number of Services"
                    inputProps={{
                      value: this.state.numberOfServices,
                    }}
                    formControlProps={{
                      required: true,
                      fullWidth: true,
                      value: this.state.numberOfServices,
                      onChange: this.handleChange('numberOfServices')
                    }}
                  />
                </Grid>
                <Grid item xs={12} sm={12} md={10}>
                  <CustomInput
                    labelText="Price"
                    inputProps={{
                      value: this.state.price,
                    }}
                    formControlProps={{
                      required: true,
                      fullWidth: true,
                      value: this.state.price,
                      onChange: this.handleChange('price')
                    }}
                  />
                </Grid>
                <Grid item xs={12} sm={12} md={10}>
                  <FormControl className={classes.formControl_8}>
                    <InputLabel htmlFor="discoutService">Services</InputLabel>
                    <Select
                      value={this.state.discoutService}
                      onChange={this.serviceChange}
                      inputProps={{
                        name: 'discoutService',
                        id: 'discoutService',
                      }}
                    >
                      <MenuItem value="">
                        <em>None</em>
                      </MenuItem>
                      {this.state.services.map(row => {
                        return <MenuItem key={row.id} value={row.id}>{row.name}</MenuItem>
                      })}
                    </Select>
                  </FormControl>
                </Grid>

                <Grid item xs={12} sm={12} md={10}>
                  <FormControl className={classes.formControl_2}>
                    <InputLabel htmlFor="discoutExtra">Service Extras</InputLabel>
                    <Select
                      value={this.state.discoutExtra}
                      onChange={this.extraChange}
                      inputProps={{
                        name: 'discoutExtra',
                        id: 'discoutExtra',
                      }}
                    >
                      <MenuItem value="">
                        <em>None</em>
                      </MenuItem>
                      {this.state.extras.map(row => {
                        return <MenuItem key={row.id} value={row.id}>{row.name}</MenuItem>
                      })}
                    </Select>
                  </FormControl>
                </Grid>

                <Grid item xs={12} sm={12} md={11} style={{ margin: 'auto' }} className={classes.active}>
                  <FormControlLabel
                    control={(
                      <Checkbox
                        tabIndex={-1}
                        disableRipple
                        onClick={this.handleToggle('active')}
                        checked={this.state.active}
                      />
                    )}
                    classes={{ label: classes.label }}
                    label={"Active"}
                  />
                </Grid>
              </Grid>
            </DialogContent>
            <DialogActions className={classes.cardFooter}>
              <GridItem xs={12} sm={12} md={6}>
                <Button color="primary" onClick={this.discountCardDelete}>Delete</Button>
              </GridItem>
              <Grid item xs={12} sm={12} md={6} className={classes.cardFooter_1}>
                <Button onClick={this.closeDialog} color="secondary" className={classes.button_2}>Cancel</Button>
                <Button variant="contained" color="secondary"
                  onClick={this.saveDsicountCard}>Save</Button>
              </Grid>
            </DialogActions>
          </Dialog>
          {/**  */}
          {/** delete  dialog */}
          <Dialog
            open={this.state.delete_confirm}
            onClose={this.closeDialog}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
          >
            <DialogTitle id="alert-dialog-title">{"Are you sure to delete?"}</DialogTitle>
            <DialogContent>
            </DialogContent>
            <DialogActions>
              <Button onClick={this.closeDialog} autoFocus color="primary" >
                Cancel
                      </Button>
              <Button onClick={this.delete_process} variant="contained" color="secondary" >
                Yes
                      </Button>
            </DialogActions>
          </Dialog>
        </GridItem>
      </GridContainer>
    )
  }
}
export default withStyles(servicesStyle)(withSnackbar(withLocalization(withAuth(DiscountCard))));



