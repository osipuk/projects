import React from 'react';
//import classNames from 'classnames';
import withStyles from '@material-ui/core/styles/withStyles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Edit from "@material-ui/icons/Edit";
import Close from "@material-ui/icons/Close";
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import Create from '@material-ui/icons/AddCircle';
import Grid from '@material-ui/core/Grid';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import axios from 'axios';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import Typography from '@material-ui/core/Typography';

//import errors from '../../../common/error_codes';
import withAuth from '../../../common/contexts/AuthContext';
import withNotifications from '../../../common/contexts/NotificationsContext';
import GridItem from "../../../common/components/Grid/GridItem.jsx";
import GridContainer from "../../../common/components/Grid/GridContainer.jsx";
import withLocalization from '../../../common/contexts/LocalizationContext';
import Card from "../../../common/components/Card/Card.jsx";
import CardHeader from "../../../common/components/Card/CardHeader.jsx";
import CardBody from "../../../common/components/Card/CardBody.jsx";
import CustomInput from "../../../common/components/CustomInput/CustomInput.jsx";
import CardFooter from "../../../common/components/Card/CardFooter.jsx";
//import Button from "../../../common/components/CustomButtons/Button.jsx";
import Button from '@material-ui/core/Button';
import serviceProductsStyle from '../../assets/css/products';

class ProductsPay extends React.Component {
  constructor(props){
    super (props);
    this.state={
      addDialog:false,//category dialog 
      products:[],
      cards:[],
      category_state:'Add',
      gategoryId:'',     
      deleteType:'',
      product_name:'',
      price:'',
      quantity:'',
      whole_price:'',
      bookingId:0,
      productId:0,
      total_price:0,
      amount_in_cash:'',
      amount_card:'',
      paymentId:'',
      saved_payId:0,//payments table id,
      sumTotal:0,
      flagAdded:false,
      bookServices:[],
      bookAddons:[],
      paidAmount:[],
      amount_visible:false
    };
    
    this.confirmDialogClose=this.confirmDialogClose.bind(this);
  }  
  componentDidMount(){
   this.setState({bookingId:this.props.bookingId});  
   this.loadProducts(); 
   this.loadCards();   
  }

  loadPayments=async()=>{
    const { data } = await axios.get('/api/company/payments/'+this.props.bookingId);
    console.log(data,'payments');
    if(data.success){
      this.setState({
        amount_card:data.payments.paymentAmount,
        amount_in_cash:data.payments.cashAmount,
        paymentId:data.payments.paymentMethodId,
        ///flagAdded:true,
        saved_payId:parseInt(data.payments.id)    
      })     
    }
  }
  loadProducts=async()=>{
    const {notifications,localization,auth}=this.props;
    const { data } = await axios.get('/api/company/products_services/'+this.props.bookingId);       
    if(data.success){
      this.setState({products:data.products});
      var total_temp=0;
      data.products.map(row=>{
        total_temp+=parseFloat(row.wholeSalePrice);
      })

      this.setState({total_price:total_temp});
      this.loadBookInf();    

    }
    else{
         
      if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){
        notifications.show({message:localization.localizedString('YOUR_SESSION_HAS_EXPIRED')});
        await auth.get();       
       }
       else{
        notifications.show({message:localization.localizedError(data.errorCode)});
       }
    }

  }

  loadBookInf=async()=>{
    const  {data} = await axios.get('/api/company/bookedservices/upfront/'+this.state.bookingId);   
   
    console.log(data);
    if(data.success){ 

      data.payments.map(row=>{
       
        if(row.paymentType==0){
            this.setState({     
              amount_card:row.paymentAmount,        
              amount_in_cash:row.cashAmount,
              paymentId:row.paymentMethodId,
              flagAdded:true,
              saved_payId:parseInt(row.id) 
            })
        }
      })

      this.setState({bookServices:data.bookingServices,bookAddons:data.bookingExtras,paidAmount:data.payments});
    }
  }
 
 
  loadCards=async()=>{
    const { data } = await axios.get('/api/company/cards');   
    console.log(data, 'cards');
    if(data.success){
      this.setState({cards:data.cards});
    }
  } 
  paymentChange=(event)=>{
   
    if(event.target.value==''){
      this.setState({
        amount_visible:false
      });
    }
    else{
      this.setState({
        amount_visible:true
      });
    }
    this.setState({
      [event.target.name]: event.target.value,
    });
  }
  handleChange = prop => event =>{
    this.setState({ [prop]: event.target.value })
  };
  confirmDialogClose(){
      this.setState({ open_dia2: false });
  }
  getSumTotal=()=>{   
    const { classes,localization } = this.props;
    const {bookAddons,bookServices,products}=this.state;
    var sumTotal=0

    bookAddons.map(row=>{
      sumTotal+=parseFloat(row.price);      
    })

    bookServices.map(row=>{
      sumTotal+=parseFloat(row.price);      
    })

    products.map(row=>{
      let price=row.retail_price==''?0:row.retail_price;
      let quantity=row.quantity==''?0:row.quantity;
      let total=parseFloat(price)*parseInt(quantity);   
      sumTotal+=total;   
    });
    return sumTotal=(Math.round(sumTotal*100)/100).toFixed(2);
   
  }
  getMissing=()=>{
    const { classes,localization } = this.props;
    let missing=this.checkMissing();
    return <span className={classes.span_1}> {missing.toFixed(2)} {localStorage.getItem('currency_code')}</span>
  }
  checkMissing=()=>{    
    let card_amount=this.state.amount_card==''?0:this.state.amount_card;
    let cash_amount=this.state.amount_in_cash==''?0:this.state.amount_in_cash;
    let sumTotal=0; // upfront
        
   /**
    this.state.products.map(row=>{
      let price=row.retail_price==''?0:row.retail_price;
      let quantity=row.quantity==''?0:row.quantity;
      let total=parseFloat(price)*parseInt(quantity);   
      sumTotal+=total;   
    });
      **/
     this.state.paidAmount.map(item=>{
       
      sumTotal+=item.paymentType?parseFloat(item.paymentAmount):0;
     });
    //let missing=this.getSumTotal()-parseFloat(card_amount)-parseFloat(cash_amount);
    let missing=this.getSumTotal()-parseFloat(sumTotal)-parseFloat(card_amount)-parseFloat(cash_amount);
    return missing;
  }
  missingError=()=>{
    const { classes,localization } = this.props;
    let missing=this.checkMissing();
    if(missing!=0 ){
      return <Grid container className={classes.label_7}>
              <Grid item xs={12} sm={12} md={12} >
                  <Typography variant="body1" className={classes.label_3}>You are missing {missing.toFixed(2)} {localStorage.getItem('currency_code')}. It's therefore not possible to mark the booking as completed. </Typography>
              </Grid>                     
            </Grid>
    }
    else{
      return null;
    }
    
  }
  addAmounts=async()=>{   
     if(this.state.saved_payId==0){
        var { data } = await axios.post('/api/company/payments', {
            payments:{ paymentMethodId:this.state.paymentId,
                      bookingId:this.state.bookingId,
                      cashAmount:this.state.amount_in_cash,
                      paymentAmount:this.state.amount_card,
                      totalAmount:this.getSumTotal(),
                      paymentType:0,
                      customerId:this.props.customerId        
            }   
        });
        if(data.success){
          this.setState({saved_payId:parseInt(data.payments.id),flagAdded:true});
            this.loadBookInf();
        }
     }
     else{
          var { data } = await axios.put('/api/company/payments/'+this.state.saved_payId, {
                payments:{ paymentMethodId:this.state.paymentId,                         
                          cashAmount:this.state.amount_in_cash,
                          paymentAmount:this.state.amount_card,      
                }
          });
         // this.props.notifications.show({message:"updated successfully"});
     }    
     
  }
  checkCardStatus=()=>{
    
    if(this.state.amount_card!='' && this.state.paymentId==0){
      console.log(this.state.amount_card,this.state.paymentId);
      return true
    }
    else if(this.state.amount_card=='' && this.state.amount_in_cash=='' && this.state.paymentId==0){
      return true;
    }
    else{
      return false
    }
  }
  
  getCardType=()=>{
    const { classes,localization } = this.props;
    let cardName='';
    this.state.cards.map(row=>{
      if(row.id==this.state.paymentId){        
        cardName=row.name+":";
        
      }
    })
    return  <Typography variant="body1" className={classes.label_3}>{cardName} </Typography>
    
  }
  completed=async()=>{ 
    var { data } = await axios.put('/api/company/booking/'+this.state.bookingId+"/completed");
    this.props.goBeforePage('default');
  }
  table_body=()=>{
    const { classes,localization } = this.props;
    let tbl=[];
    let trs=[];
    if(this.state.products.length==0){
      return <h4 className={classes.nothing_1}></h4>
    }

    this.state.products.map(row => {
      let price=row.retail_price==''?0:row.retail_price;
      let quantity=row.quantity==''?0:row.quantity;
      let total=parseFloat(price)*parseInt(quantity);
      total=(Math.round(total*100)/100).toFixed(2);

      trs.push(<TableRow hover
      key={row.id} onClick={()=>(this.rowClickCategory(row.id))}>
     
      <TableCell  className={classes.tableCell} >
        {row.item_name}
      </TableCell>
      <TableCell  >{row.retail_price}</TableCell>
      <TableCell >{row.quantity}</TableCell>
      <TableCell >{total}</TableCell>     
    </TableRow>);      
    })

    tbl.push(<Table key={1} className={classes.table}>
      <TableHead >
        <TableRow>          
          <TableCell  className={classes.tableCell+" "+classes.tableHeader_1}> Name</TableCell>
          <TableCell  className={classes.tableHeader_1}>Price</TableCell>
          <TableCell  className={classes.tableHeader_1}>Quantity</TableCell>
          <TableCell  className={classes.tableHeader_1}>Total</TableCell>          
        </TableRow>
      </TableHead>
      <TableBody>
        {trs}
      </TableBody>
    </Table>);
    return tbl;    
  }
  paymentMethod=()=>{
    const { classes,localization } = this.props;    
     let temp=[];
      this.state.paidAmount.map(item=>{      
        let payment_method='';
        this.state.cards.map(row=>{
          if(row.id==item.paymentMethodId)
            payment_method=row.name;
        })
        temp.push(<Grid key={item.id} container className={classes.label_5}>
                    <Grid item xs={6} sm={6} md={6} >
                    {payment_method}:
                  </Grid>
                  <Grid item xs={6} sm={6} md={6} >
                      <Typography variant="body1" className={classes.label_3}><span className={classes.span_1}>  {item.paymentAmount} {this.props.auth.user.currency_code}</span></Typography>
                  </Grid>
               </Grid>);
      });

      return temp;
     
  }
  getPaymentName=()=>{
    var paymentName='';
    this.state.cards.map(row=>{
      if(row.id==this.state.paymentId){
        paymentName=row.name;
      }
    })
    return paymentName;
  }
  render(){
    const { classes,localization } = this.props; 

     return(
      <GridContainer>
      <GridItem xs={12} sm={12} md={12}>
        <Card>
          <CardHeader color="primary">            
          <GridContainer>
            <GridItem xs={10} sm={10} md={10}>
              <h4 className={classes.cardTitleWhite}>Services and Products</h4>
              <p className={classes.cardCategoryWhite}>             
              </p>
            </GridItem>
            <Grid xs={2} item sm={2} md={2} className={classes.header_2}>                 
            </Grid>
           </GridContainer>
            
          </CardHeader>
          <CardBody >
              <div className={classes.cardBody_1}>
              {this.table_body()}     
              </div>
              <GridContainer>
              <Grid item xs={12} sm={12} md={7}>
                  <Grid container className={classes.nothing_1}>
                    <Grid item xs={12} sm={12} md={6} >
                      <CustomInput
                          labelText="Amount in Cash"
                          id="name"
                          inputProps={{
                            type:'number',
                            value:this.state.amount_in_cash,
                          }}
                          formControlProps={{
                            required: false,
                            className:classes.customInput,                          
                            value:this.state.amount_in_cash,
                            onChange: this.handleChange('amount_in_cash')
                          }}
                        />        
                    </Grid>
                  </Grid>

                  <Grid container className={classes.nothing_1}>
                   
                    <Grid item xs={12} sm={12} md={6} >
                      <FormControl className={classes.formControl}>
                        <InputLabel htmlFor="age-simple">Payment Method</InputLabel>
                          <Select
                            value={this.state.paymentId}
                            onChange={this.paymentChange}
                            inputProps={{
                              name: 'paymentId',
                              id: 'age-simple',
                            }}
                          >           
                           <MenuItem value="">
                            <em>None</em>
                          </MenuItem>                
                           {this.state.cards.map(row=>{
                             if(row.is_online!=1)
                             return <MenuItem key={row.id} value={row.id}>{row.name}</MenuItem>
                           })}

                          </Select>
                       </FormControl>
                    </Grid>
                    <Grid item xs={12} sm={12} md={6} >                     
                     {this.state.paymentId!=''?<CustomInput
                          labelText="Amount in other payment method"
                          id="name"                          
                          inputProps={{
                            type:'number',
                            value:this.state.amount_card,
                          }}
                          formControlProps={{
                            required: false,
                            className:classes.customInput_1,                          
                            value:this.state.amount_card,
                            onChange: this.handleChange('amount_card')
                          }}
                        />:''} 
                    </Grid>
                  </Grid>

                  <Grid container>
                    <Grid item xs={12} sm={12} md={6} className={classes.addButton}>
                      <Button onClick={() =>(this.addAmounts())} 
                      variant="contained"
                      disabled={this.checkCardStatus()}
                      color="secondary"   >{this.state.saved_payId?"Update":"Add"} Amounts</Button> 
                    </Grid>
                  </Grid>
                         
              </Grid>
              <Grid item xs={12} sm={12} md={5} className={classes.container_2}>  
                  <Grid container className={classes.label_1}>
                        <Grid item xs={7} sm={7} md={6} >
                          <Typography variant="body1" className={classes.label_2}>Total to be paid:</Typography>
                      </Grid>
                      <Grid item xs={5} sm={5} md={6}>
                          <Typography variant="body1" className={classes.label_2}> <span className={classes.span_2}>{this.getSumTotal()} {this.props.auth.user.currency_code}</span></Typography>
                      </Grid>
                  </Grid>
               
                  {/**this.paymentMethod() */}
                  
                    {/**
                  <Grid container className={classes.label_4}>
                        <Grid item xs={6} sm={6} md={6} >
                         {this.getCardType()}
                      </Grid>
                      <Grid item xs={6} sm={6} md={6} >
                          <Typography variant="body1" className={classes.label_3}><span className={classes.span_1}> {this.state.amount_card==''?0:this.state.amount_card} {this.props.auth.user.currency_code}</span></Typography>
                      </Grid>
                  </Grid>  
                   */}
                
                 
              
                  <Grid container className={classes.label_5}>
                        <Grid item xs={6} sm={6} md={6} >
                          <Typography variant="body1" className={classes.label_3}>Cash: </Typography>
                      </Grid>
                      <Grid item xs={6} sm={6} md={6} >
                          <Typography variant="body1" className={classes.label_3}><span className={classes.span_1}> {this.state.amount_in_cash==''?0:this.state.amount_in_cash} {localStorage.getItem('currency_code')}</span></Typography>
                      </Grid>
                  </Grid>
                    {
                      this.state.paymentId!=''?<Grid container className={classes.label_6}>
                        <Grid item xs={6} sm={6} md={6} >
                          <Typography variant="body1" className={classes.label_3}>{this.getPaymentName()}</Typography>
                          </Grid>
                          <Grid item xs={6} sm={6} md={6} >
                              <Typography variant="body1" className={classes.label_3}><span className={classes.span_1}> {this.state.amount_card==''?0:this.state.amount_card} {localStorage.getItem('currency_code')}</span></Typography>
                          </Grid>
                      </Grid>:''
                    }
                  

                  <Grid container className={classes.label_6}>
                        <Grid item xs={6} sm={6} md={6} >
                          <Typography variant="body1" className={classes.label_3}>Missing: </Typography>
                      </Grid>
                      <Grid item xs={6} sm={6} md={6} >
                          <Typography variant="body1" className={classes.label_3}>{this.getMissing()}</Typography>
                      </Grid>
                  </Grid>
                  {this.missingError()}

              </Grid>
            </GridContainer>
            <CardFooter className={classes.cardFooter_2}>
                <Button color="secondary" variant="contained" onClick={()=>(this.props.goBeforePage('products'))}  className={classes.backBtn}>Back</Button>
                <Button color="secondary" variant="contained" onClick={this.completed} disabled={this.checkMissing().toFixed(2)!='0.00' ||  this.state.flagAdded==false}  >Finish</Button>  
            </CardFooter>
          </CardBody>
          
        </Card>
      </GridItem> 

      </GridContainer>
     )
   }
}
export default withStyles(serviceProductsStyle)(withNotifications(withLocalization(withAuth(ProductsPay))));
