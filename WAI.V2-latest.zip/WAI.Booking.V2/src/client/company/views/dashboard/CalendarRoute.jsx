import React from 'react';
import Calendar from './Calendar';
import ServiceProcuts from './ServiceProducts';
import ProductsPay from './ProductsPay';
import { timingSafeEqual } from 'crypto';
class CalendarRoute extends React.Component {
  constructor(props){
  super (props);
    this.state={
      page:'default',//products//calendar
      bookingId:0,
      services:[],
      addons:[],
      customerId:0     
    };
    this.goNextPage=this.goNextPage.bind(this);
    this.goPaymentPage=this.goPaymentPage.bind(this);
  }
  componentDidMount(){
    
  }
  goNextPage(bookingId,services,addons,customerId){
    this.setState({
      page:'products',
      bookingId:bookingId,
      services:services,
      addons:addons, 
      customerId:customerId   
    });
  }
  goPaymentPage(){
    this.setState({
      page:'goPay',
      });
  }
  goBeforePage=(page)=>{
    this.setState({
      page:page,
      });
  }
  renderPage=()=>{
    if(this.state.page=='default'){
      return  <Calendar goOtherPage={this.goNextPage} history={this.props.history}></Calendar>
    }    
    else if(this.state.page=='products'){
      return <ServiceProcuts 
      goBeforePage={this.goBeforePage}
      goOtherPage={this.goPaymentPage} 
      addons={this.state.addons} 
      services={this.state.services} 
      customerId={this.state.customerId}        
      bookingId={this.state.bookingId}/>        
      
    }
    else if(this.state.page=='goPay' ){
      return <ProductsPay goBeforePage={this.goBeforePage} bookingId={this.state.bookingId} customerId={this.state.customerId}></ProductsPay>
    }
    
  }
  render(){    
    return(
      <div>
        {this.renderPage()}
      </div>
    )          
  }
}
export default CalendarRoute;



