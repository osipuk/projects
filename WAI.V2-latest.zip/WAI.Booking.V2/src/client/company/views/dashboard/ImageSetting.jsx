import React from 'react';
//import classNames from 'classnames';
import withStyles from '@material-ui/core/styles/withStyles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Edit from "@material-ui/icons/Edit";
import Close from "@material-ui/icons/Close";
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import Create from '@material-ui/icons/AddCircle';
import Grid from '@material-ui/core/Grid';
import GridList from "@material-ui/core/GridList";
import GridListTile from "@material-ui/core/GridListTile";
import GridListTileBar from "@material-ui/core/GridListTileBar";
import StarBorderIcon from "@material-ui/icons/StarBorder";
import {DropzoneDialog} from 'material-ui-dropzone'
import {  withSnackbar } from 'notistack';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import FormControl from '@material-ui/core/FormControl';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import MenuItem from '@material-ui/core/MenuItem';
import InputLabel from '@material-ui/core/InputLabel';
import Select from '@material-ui/core/Select';
import axios from 'axios';
import Success from '@material-ui/icons/CheckCircle';
//import errors from '../../../common/error_codes';
import withAuth from '../../../common/contexts/AuthContext';
import withNotifications from '../../../common/contexts/NotificationsContext';
import GridItem from "../../../common/components/Grid/GridItem.jsx";
import GridContainer from "../../../common/components/Grid/GridContainer.jsx";
import withLocalization from '../../../common/contexts/LocalizationContext';
import Card from "../../../common/components/Card/Card.jsx";
import CardHeader from "../../../common/components/Card/CardHeader.jsx";
import CardBody from "../../../common/components/Card/CardBody.jsx";
import CustomInput from "../../../common/components/CustomInput/CustomInput.jsx";
import CardFooter from "../../../common/components/Card/CardFooter.jsx";
import Button from "../../../common/components/CustomButtons/Button.jsx";
import imagesStyle from '../../assets/css/images';

class ImageSetting extends React.Component {
  constructor(props){
    super (props);
    this.state={
      cellHeight: 215,
      files: [],
      images:[],
      open:false,
      imageIndex:''      
    };
  }  
  componentDidMount(){
    this.loadImages();
  }  
  handleClose() {
    this.setState({
      open:false,      
    });
    }

    async handleSave(files) {
        const {notifications,localization,auth}=this.props;
        const formData = new FormData();
        const config = {
          headers: {
              'content-type': 'multipart/form-data',
              'data':this.state.imageIndex
          }
       };
        formData.append('slideImage', files[0]);
        formData.append('imageIndex', this.state.imageIndex);
        formData.imageIndex=this.state.imageIndex;
       
       // return;
        const {data} = await axios.post('/api/company/upload_image',formData ,config);     
        this.loadImages();   
      
        if(data.success){
          this.props.enqueueSnackbar(localization.localizedString('UPLOADED_SUCCESS'), { 
            variant: 'success',
          }); 
        }
        else{
          if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
            this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
              variant: 'error',
            }); 
            await auth.get();       
           }
           else{        
            this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
              variant: 'error',
            }); 
           }
        }
    
        this.setState({
            files: files, 
            open: false
        });
    }
   upload=(img)=> {
        this.setState({
            open: true,
            imageIndex:img
        });
    }
   loadImages=async()=>{
        const {localization,auth}=this.props;   
        const { data } = await axios.get('/api/company/upload_image');    
        console.log(data.images);
        if(data.success){
          this.setState({images:data.images==null?[]:data.images});
        }
        else{
          if(data.errorCode==2 || data.errorCode==5  || data.errorCode==6 ){        
            this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
              variant: 'error',
            }); 
            await auth.get();       
           }
           else{        
            this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
              variant: 'error',
            }); 
           }
        }
      
  }
  render(){
    const { classes,localization } = this.props;
    const {images}=this.state;
     return(
      <GridContainer>
      <GridItem xs={12} sm={12} md={12}>
        <Card>
         {/**
          <CardHeader color="primary">            
          <GridContainer>
            <GridItem xs={10} sm={10} md={10}>
              <h4 className={classes.cardTitleWhite}>Category</h4>
              <p className={classes.cardCategoryWhite}>             
              </p>
            </GridItem> 
           </GridContainer>
            
          </CardHeader> */}
          <CardBody className={classes.cardBody_1}>
          <GridContainer>
            <Grid item xs={12} sm={12} md={6} className={classes.tess}>
              <GridList
                spacing={1}
                cellHeight={this.state.cellHeight}
                className={classes.gridList}
                cols={2}
              >
                <GridListTile
                  key={"2"}
                  cols={2}
                  rows={2}
                  onClick={()=>this.upload('image1')}
                  className={classes.mainPicture}
                >
                   
                    <img
                      src={images.image1?images.image1:"https://material-ui.com/static/images/grid-list/breakfast.jpg"}
                      alt={"main"}
                      className={classes.thms1}
                    />
                   
               
                  <GridListTileBar
                    title="Please click to upload the image."
                    subtitle={<span>Slide image ID: 1</span>}
                    titlePosition="bottom"
                    actionIcon={
                      <IconButton className={classes.white_icon}>
                        <StarBorderIcon />
                      </IconButton>
                    }
                    actionPosition="left"
                    className={classes.profile_images2}
                  />
                </GridListTile>
              </GridList>
              <DropzoneDialog                   
                    open={this.state.open}
                    onSave={this.handleSave.bind(this)}
                    acceptedFiles={['image/jpeg', 'image/png', 'image/bmp']}
                    showPreviews={true}
                    maxFileSize={3000000}
                    filesLimit={1}
                    onClose={this.handleClose.bind(this)}
                />             
            </Grid>
            <Grid item xs={12} sm={12} md={6} className={classes.tess}>
              <GridList
                  spacing={0}
                  cellHeight={this.state.cellHeight}
                  className={classes.gridList}
                  cols={2}
                >
                    <GridListTile
                      className={classes.tess}
                      key={2}
                      cols={1}
                      className={classes.subPicture}   
                      onClick={()=>this.upload('image2')}                  
                    >
                     
                        <img
                          src={images.image2?images.image2:"https://material-ui.com/static/images/grid-list/breakfast.jpg"}
                          alt={"slide image 1"}
                          className={classes.item_img}
                        />
                      
                      <GridListTileBar
                        title="Please click to upload the image."
                        titlePosition="bottom"
                        actionPosition="left"
                        subtitle={<span>Slide image ID: 2</span>}
                        className={classes.profile_images}
                      />
                    </GridListTile>
                    <GridListTile
                      className={classes.tess}
                      key={3}
                      cols={1}
                      onClick={()=>this.upload('image3')}
                      className={classes.subPicture}                     
                    >
                      <div className={classes.thms}>
                        <img
                          src={images.image3?images.image3:"https://material-ui.com/static/images/grid-list/breakfast.jpg"}
                          alt={"slide image 1"}
                          className={classes.item_img}
                        />
                      </div>
                      <GridListTileBar
                        title="Please click to upload the image."
                        titlePosition="bottom"
                        actionPosition="left"
                        subtitle={<span>Slide image ID: 3</span>}
                        className={classes.profile_images}
                      />
                    </GridListTile>
                    <GridListTile
                      className={classes.tess}
                      key={4}
                      cols={1}
                      onClick={()=>this.upload('image4')}
                      className={classes.subPicture}                     
                    >
                      <div className={classes.thms}>
                        <img
                          src={images.image4?images.image4:"https://material-ui.com/static/images/grid-list/breakfast.jpg"}
                          alt={"slide image 1"}
                          className={classes.item_img}
                        />
                      </div>
                      <GridListTileBar
                        title="Please click to upload the image."
                        titlePosition="bottom"
                        actionPosition="left"
                        subtitle={<span>Slide image ID: 4</span>}
                        className={classes.profile_images}
                      />
                    </GridListTile>
                    <GridListTile
                      className={classes.tess}
                      key={5}
                      cols={1}
                      className={classes.subPicture}   
                      onClick={()=>this.upload('image5')}                  
                    >
                      <div className={classes.thms}>
                        <img
                          src={images.image5?images.image5:"https://material-ui.com/static/images/grid-list/breakfast.jpg"}
                          alt={"slide image 1"}
                          className={classes.item_img}
                        />
                      </div>
                      <GridListTileBar
                        title="Please click to upload the image."
                        titlePosition="bottom"
                        actionPosition="left"
                        subtitle={<span>Slide image ID: 5</span>}
                        className={classes.profile_images}
                      />
                    </GridListTile>
                </GridList>
            </Grid>
            </GridContainer>
          </CardBody>
        </Card>
      </GridItem>
      </GridContainer>
     )
   }
}
export default withStyles(imagesStyle)(withSnackbar(withLocalization(withAuth(ImageSetting))));
