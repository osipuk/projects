import React from 'react';

import withStyles from '@material-ui/core/styles/withStyles';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import Success from '@material-ui/icons/CheckCircle';
import axios from 'axios';
import TextField from '@material-ui/core/TextField';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import { withSnackbar } from 'notistack';
import InputAdornment from '@material-ui/core/InputAdornment';
//import PlacesAutocomplete, { geocodeByAddress, getLatLng } from 'react-places-autocomplete'
import PropTypes from 'prop-types';
import Tabs from '@material-ui/core/Tabs';
import Paper from '@material-ui/core/Paper';
import Input from '@material-ui/core/Input';
import Switch from '@material-ui/core/Switch';

import Tab from '@material-ui/core/Tab';
import Divider from '@material-ui/core/Divider';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Geocode from "react-geocode";
import withLocalization from '../../../common/contexts/LocalizationContext';
import withAuth from '../../../common/contexts/AuthContext';
import GridContainer from '../../../common/components/Grid/GridContainer';
import GridItem from '../../../common/components/Grid/GridItem';

import Card from '../../../common/components/Card/Card';
import CardBody from '../../../common/components/Card/CardBody';
import CardHeader from '../../../common/components/Card/CardHeader';
import CardFooter from '../../../common/components/Card/CardFooter';
import CustomInput from '../../../common/components/CustomInput/CustomInput';
import Button from '@material-ui/core/Button';
//import SignupButton from '../../../common/containers/SignupButton/SignupButton';
import settingPageStyle from '../../assets/css/settings';
import landingPageStyle from "../../../p/assets/jss/views/landingPage";
//import signupPageStyle from '../../../common/assets/jss/material-react/views/loginPage';

Geocode.setApiKey("AIzaSyDTCQc8JvRvCS5z-AZPv3UpX1HxesohbFs");

function TabContainer(props) {
  return (
    <Typography component="div" style={{ padding: 8 * 3 }}>
      {props.children}
    </Typography>
  );
}

TabContainer.propTypes = {
  children: PropTypes.node.isRequired,
};



(function () {
  var days = [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday"
  ];
  var months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
  ];

  Date.prototype.getMonthName = function () {
    return months[this.getMonth()];
  };
  Date.prototype.getDayName = function () {
    return days[this.getDay()];
  };
})();

class Setting extends React.Component {
  state = {
    email: '',
    password: '',
    new_password: '',
    firstName: '',
    lastName: '',
    phone: '',
    companyName: '',
    zipCode: '',
    city: '',
    country: '',
    address: '',
    cvr: '',
    smsSenderName: '',
    customUrl: '',
    lockBookingXHourBefore: 12,
    bookLatestXHourBefore: 0,
    acceptBookingAutomatically: false,
    paymentUpfront: false,
    country: [],
    countryId: 0,
    companyId: 0,
    interval: 30,
    description: '',
    faceBookUrl: '',
    twitterUrl: '',
    instagramUrl: '',
    websiteUrl: '',
    tabValue: 0,
    paypal_key: '',//payment setting
    strip: '',
    coin_payment: '',
    masterCard: false,
    visa: false,
    dankort: false,
    cash: false,
    paypal: false,
    american_express: false,
    maestro: false,
    bitcoin: false,
    paymentSettingId: 0,
    email_is_verified: false,
    phone_is_verified: false,
    holidays: [],
    selectedHolidays: [],
    holidayWorks: [],
    lat: 0,
    lng: 0,
    bussinessEmail:''
  };

  componentWillMount() {
    this.loadCompanyProfile();
  }
  loadCountryInf = async () => {
    const { data } = await axios.get('/api/company/countrys');
    if (data.success) {
      this.setState({ country: data.country });
    }
  }
  loadCompanyProfile = async () => {
    var { data } = await axios.get('/api/company');
    console.log(data);
    const { localization, auth } = this.props;
    if (data.success) {
      this.setState({
        email: data.company.email,
        password: '',
        new_password: '',
        companyId: data.company.id,
        firstName: data.company.first_name ? data.company.first_name : '',
        lastName: data.company.last_name ? data.company.last_name : '',
        phone: data.company.phone,
        companyName: data.company.company_name ? data.company.company_name : '',
        zipCode: data.company.zip_code ? data.company.zip_code : '',
        city: data.company.city ? data.company.city : '',
        country: data.company.country_name,
        address: data.company.address ? data.company.address : '',
        cvr: data.company.cvr ? data.company.cvr : '',
        customUrl: data.company.custom_url ? data.company.custom_url : '',
        countryId: data.company.country_id,
        smsSenderName: data.company.sms_sender_name ? data.company.sms_sender_name : '',
        lockBookingXHourBefore: data.company.lock_booking_xhour_before ? data.company.lock_booking_xhour_before : '',
        bookLatestXHourBefore: data.company.book_latest_xhour_before ? data.company.book_latest_xhour_before : '',
        interval: data.company.interval,
        acceptBookingAutomatically: data.company.accept_booking_automatically ? true : false,
        paymentUpfront: data.company.payment_upfront ? true : false,
        description: data.company.description,
        faceBookUrl: data.company.facebook ? data.company.facebook : '',
        twitterUrl: data.company.twitter ? data.company.twitter : '',
        websiteUrl: data.company.website ? data.company.website : '',
        instagramUrl: data.company.instagram ? data.company.instagram : '',
        email_is_verified: data.company.email_veryfied ? true : false,
        phone_is_verified: data.company.phone_veryfied ? true : false,
        bussinessEmail:data.company.bussiness_email
      })
    }
    else {
      if (data.errorCode == 2 || data.errorCode == 5 || data.errorCode == 6) {
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), {
          variant: 'error',
        });
        await auth.get();
      }
      else {
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), {
          variant: 'error',
        });
      }
    }

    var { data } = await axios.get('/api/company/payment_setting');
    if (data.success) {
      var settings = data.settings;
      this.setState({
        paypal_key: settings.paypalKey,
        strip: settings.strip,
        coin_payment: settings.coinPayment,
        masterCard: settings.mastercard ? true : false,
        visa: settings.visa ? true : false,
        dankort: settings.dankort ? true : false,
        cash: settings.cash ? true : false,
        paypal: settings.paypal ? true : false,
        american_express: settings.americanExpress ? true : false,
        maestro: settings.maestro ? true : false,
        bitcoin: settings.bitcoin ? true : false,
        paymentSettingId: settings.id,
      })
    }

    var { data } = await axios.get('/api/company/holiday/' + auth.user.country_id + "/country");

    if (data.success) {
      let temp = [];
      data.holidayWorks.map(item => {
        if (item.isWork) {
          temp.push(item.holidayId);
        }
      })
      this.setState({ holidays: data.holidays, holidayWorks: data.holidayWorks, selectedHolidays: temp });
    }

  }
  handleChange = prop => event => this.setState({ [prop]: event.target.value });
  handleToggle = prop => event => {
    console.log(event.target);
    this.setState({ [prop]: event.target.checked })
  };
  offlineChange = (event, value) => {
    this.setState({
      [value]: event.target.checked
    });
  }
  smsNameChange = prop => event => {
    if (event.target.value.length > 11)
      return;
    this.setState({ [prop]: event.target.value })
  }

  customUrlChange = prop => event => {
    if (event.target.value.length > 15)
      return;
    this.setState({ [prop]: event.target.value })
  }

  changePassword=async()=>{

    const { localization, classes } = this.props;

    if (this.state.password =='') {
      this.props.enqueueSnackbar(localization.localizedError(28), {
        variant: 'error',
      });
      return;
    }

    if ( this.state.new_password == '') {
      this.props.enqueueSnackbar(localization.localizedError(37), {
        variant: 'error',
      });
      return;
    }

    var { data } = await axios.post('/api/company/setting/password', {
      oldpassword:this.state.password,newpassword:this.state.new_password });
      console.log(data,'result');
      if(!data.success){
       if(data.errorCode==2 || data.errorCode==5 || data.errorCode==3   || data.errorCode==6 ){        
        this.props.enqueueSnackbar(localization.localizedString('YOUR_SESSION_HAS_EXPIRED'), { 
          variant: 'error',
        }); 
        await auth.get();       
       }
       else{        
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
       }
       return;
      }
      else{
        this.props.enqueueSnackbar(localization.localizedString('UPDATED_SUCCESS'), {
          variant: 'success',
        });
        this.setState({password:'',new_password:''})
      }
  
    


  }

  //handleToggle = prop => event => this.setState({ [prop]: event.target.checked });
  update = async () => {

    let flag = 0;
    const { localization, classes } = this.props;
   

    var address = this.state.address;
    var that = this;

    await Geocode.fromAddress(this.state.address).then(
      response => {
        const { lat, lng } = response.results[0].geometry.location;
        this.setState({ lat: lat, lng: lng });
      },
      error => {
        that.props.enqueueSnackbar(localization.localizedString('INVAILID_ADDRESS'), {
          variant: 'error',
        });
        flag = 1;
        return
      }
    );
    if (flag)
      return;


    try {
      var { data } = await axios.put('/api/company/', {
        company: {
          email: this.state.email,
          password: this.state.password,
          new_password: this.state.new_password,
          companyId: this.state.companyId,
          firstName: this.state.firstName,
          lastName: this.state.lastName,
          phone: this.state.phone,
          companyName: this.state.companyName,
          zipCode: this.state.zipCode,
          city: this.state.city,
          address: this.state.address,
          cvr: this.state.cvr,
          countryId: this.state.companyId,
          smsSenderName: this.state.smsSenderName,
          lockBookingXHourBefore: this.state.lockBookingXHourBefore,
          bookLatestXHourBefore: this.state.bookLatestXHourBefore,
          acceptBookingAutomatically: false,
          paymentUpfront: this.state.paymentUpfront ? 1 : 0,
          interval: this.state.interval,
          customUrl: this.state.customUrl,
          description: this.state.description,
          facebook: this.state.faceBookUrl,
          instagram: this.state.instagramUrl,
          twitter: this.state.twitterUrl,
          website: this.state.websiteUrl,
          lat: this.state.lat,
          lng: this.state.lng,
          bussinessEmail:this.state.bussinessEmail

        }
      });
      
      if (!data.success) {
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), {
          variant: 'error',
        });
        return
      }
      if (this.state.paymentSettingId == 0) {
        var { data } = await axios.post('/api/company/payment_setting', {
          settings: {
            paypalKey: this.state.paypal_key,
            strip: this.state.strip,
            coinPayment: this.state.coin_payment,
            mastercard: this.state.masterCard,
            visa: this.state.visa ? 1 : 0,
            dankort: this.state.dankort ? 1 : 0,
            cash: this.state.cash ? 1 : 0,
            paypal: this.state.paypal ? 1 : 0,
            americanExpress: this.state.american_express ? 1 : 0,
            maestro: this.state.maestro ? 1 : 0,
            bitcoin: this.state.bitcoin ? 1 : 0
          }
        });
        if (!data.success) {
          this.props.enqueueSnackbar(localization.localizedError(data.errorCode), {
            variant: 'error',
          });
          return;
        }
      }
      else {
        var { data } = await axios.put('/api/company/payment_setting/' + this.state.paymentSettingId, {
          settings: {
            paypalKey: this.state.paypal_key,
            strip: this.state.strip,
            coinPayment: this.state.coin_payment,
            mastercard: this.state.masterCard,
            visa: this.state.visa ? 1 : 0,
            dankort: this.state.dankort ? 1 : 0,
            cash: this.state.cash ? 1 : 0,
            paypal: this.state.paypal ? 1 : 0,
            americanExpress: this.state.american_express ? 1 : 0,
            maestro: this.state.maestro ? 1 : 0,
            bitcoin: this.state.bitcoin ? 1 : 0
          }
        });
        if (!data.success) {
          this.props.enqueueSnackbar(localization.localizedError(data.errorCode), {
            variant: 'error',
          });
          return;
        }
      }
      this.props.enqueueSnackbar(localization.localizedString('SAVED_SUCCESS'), {
        variant: 'success',
      });
      this.loadCompanyProfile();
    } finally {

    }

  }
  checkRequiredFields = () => {
    const {
      email, password, firstName, lastName,
      phone, companyName, zipCode,
      city, address, smsSenderName, customUrl
    } = this.state;

    return (email && email.length > 0)
      && (password && password.length > 0)
      && (firstName && firstName.length > 0)
      && (lastName && lastName.length > 0)
      && (phone && phone.length > 0)
      && (companyName && companyName.length > 0)
      && (zipCode && zipCode.length > 0)
      && (city && city.length > 0)
      && (address && address.length > 0)
      && (customUrl && customUrl.length > 0)
      && (smsSenderName && smsSenderName.length > 0 && smsSenderName.length < 12);
  }; handleTabChange = (event, tabValue) => {
    this.setState({ tabValue });
  };

  isWorkClick = async (event, id, date) => {
    console.log(event.target.checked, id);

    const { selectedHolidays } = this.state;
    const selectedIndex = selectedHolidays.indexOf(id);
    let newSelected = [];
    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selectedHolidays, id);
    }
    else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selectedHolidays.slice(1));
    } else if (selectedIndex === selectedHolidays.length - 1) {
      newSelected = newSelected.concat(selectedHolidays.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selectedHolidays.slice(0, selectedIndex),
        selectedHolidays.slice(selectedIndex + 1),
      );
    }
    this.setState({ selectedHolidays: newSelected });


    var { data } = await axios.post('/api/company/holiday/work', {
      holiday_work: {
        holidayId: id,
        date: date,
        isWork: event.target.checked ? 1 : 0
      }
    });


  }
  isSelected = id => this.state.selectedHolidays.indexOf(id) !== -1;
  render() {
    const { localization, classes } = this.props;
    const {
      email, password,
      new_password,
      firstName, lastName,
      phone, companyName, zipCode,
      city, address, cvr, smsSenderName, country,
      lockBookingXHourBefore, bookLatestXHourBefore,
      acceptBookingAutomatically, paymentUpfront, customUrl,
      faceBookUrl, instagramUrl, twitterUrl, websiteUrl, tabValue,
      email_is_verified, phone_is_verified,
      paypal_key,
      strip,
      coin_payment,
      masterCard,
      visa,
      dankort,
      cash,
      paypal,
      american_express,
      maestro,
      bitcoin,
      bussinessEmail
    } = this.state;

    return (
      <GridContainer justify="center">
        <GridItem xs={12} sm={12} md={12} lg={8}>
          <div
            style={{ fontSize: '14.04px', fontWeight: '400', height: '20px', letterSpacing: '0.25px', marginTop: '20px', paddingTop: '10px', }}>
            General
      </div>
          <Card style={{ marginTop: '20px !important', }}>
            <CardBody style={{ padding: '0px', margin: '0px !important', }}>
              <GridContainer style={{ width: '100% !important', margin: '0px !important' }}>
                <div className={classes.cardItemGroup}>
                  <div className={classes.cardItem}>
                    <div>
                      Accept booking automatically
                </div>
                    <div className={classes.cardItemComponent}>
                      <Switch
                        checked={acceptBookingAutomatically}
                        onChange={this.handleToggle('acceptBookingAutomatically')}
                        value={acceptBookingAutomatically}
                      />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      Require payment upfront for all online bookings
                </div>
                    <div className={classes.cardItemComponent}>
                      <Switch
                        onChange={this.handleToggle('paymentUpfront')}
                        checked={paymentUpfront}
                        value={paymentUpfront}
                      />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      Custom booking link
                  <br />
                      <div className={classes.cardItemSub}>
                        https://boking.com/mysite
                  </div>
                    </div>
                    <div className={classes.cardItemComponent}>
                      <TextField id="customUrl"
                        onChange={this.customUrlChange('customUrl')}
                        value={customUrl}
                        className={classes.textfieldRoot} InputProps={{
                          classes: {
                            root: classes.textfieldRoot,
                            input: classes.textfieldInput,
                            underline: classes.textFieldUnderline,
                          }
                        }} defaultValue="Bare" margin="normal" variant="filled" />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      SMS sender name
                </div>
                    <div className={classes.cardItemComponent}>

                      <TextField id="smsSenderName"
                        onChange={this.smsNameChange('smsSenderName')}
                        value={smsSenderName}
                        className={classes.textfieldRoot} InputProps={{
                          classes: {
                            root: classes.textfieldRoot,
                            input: classes.textfieldInput,
                            underline: classes.textFieldUnderline,
                          }
                        }} defaultValue="Bare" margin="normal" variant="filled" />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      Booking interval
                </div>
                    <div className={classes.cardItemComponent}>

                      <TextField id="filled-select-currency" select

                        className={classes.textField}
                        value={this.state.interval}
                        onChange={this.handleChange('interval')}
                        InputProps={{
                          classes: {
                            root: classes.textfieldRoot,
                            input: classes.textfieldInput,
                            underline: classes.textFieldUnderline,
                          }
                        }}
                        SelectProps={{
                          MenuProps: {
                            className: classes.menu,
                          },
                        }} variant="filled">
                        <MenuItem key={15} value={15}>15 Minutes</MenuItem>
                        <MenuItem key={30} value={30}>30 Minutes</MenuItem>
                        <MenuItem key={45} value={45}>45 Minutes</MenuItem>
                        <MenuItem key={60} value={60}>60 Minutes</MenuItem>
                      </TextField>
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      Latest cancellation
                </div>
                    <div className={classes.cardItemComponent}>

                      <TextField id="filled-select-currency"
                        select
                        onChange={this.handleChange('lockBookingXHourBefore')}
                        value={this.state.lockBookingXHourBefore}
                        className={classes.textField}
                        InputProps={{
                          classes: {
                            root: classes.textfieldRoot,
                            input: classes.textfieldInput,
                            underline: classes.textFieldUnderline,
                          }
                        }}
                        SelectProps={{
                          MenuProps: {
                            className: classes.menu,
                          },
                        }}
                        variant="filled">
                        <MenuItem key={15} value={12}>12 hours</MenuItem>
                        <MenuItem key={30} value={24}>24 hours</MenuItem>
                        <MenuItem key={45} value={48}>48 hours</MenuItem>
                      </TextField>
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      Latest booking
                </div>
                    <div className={classes.cardItemComponent}>

                      <TextField id="filled-select-currency" select className={classes.textField}
                        value={this.state.bookLatestXHourBefore} onChange={this.handleChange('bookLatestXHourBefore')} InputProps={{
                          classes: {
                            root: classes.textfieldRoot,
                            input: classes.textfieldInput,
                            underline: classes.textFieldUnderline,
                          }
                        }} SelectProps={{
                          MenuProps: {
                            className: classes.menu,
                          },
                        }}
                        variant="filled">
                        <MenuItem key={1} value={1}>1 hour</MenuItem>
                        <MenuItem key={2} value={2}>2 hours</MenuItem>
                        <MenuItem key={3} value={3}>3 hours</MenuItem>
                        <MenuItem key={6} value={6}>6 hours</MenuItem>
                        <MenuItem key={12} value={12}>12 hours</MenuItem>
                        <MenuItem key={24} value={24}>24 hours</MenuItem>
                        <MenuItem key={48} value={48}>48 hours</MenuItem>
                      </TextField>
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItemFooter}>
                    <div>
                    </div>
                    <div className={classes.cardItemComponent}>

                      <Button variant="outlined" 
                      onClick={this.update}
                      className={classes.cardItemSaveBtn}>
                        Save
                      </Button>
                    </div>
                  </div>
                </div>
              </GridContainer>
            </CardBody>
          </Card>


          <div
            className={classes.cardItemGroupHeader}>
            Security
      </div>
          <Card style={{ marginTop: '20px !important', }}>
            <CardBody style={{ padding: '0px', margin: '0px !important', }}>
              <GridContainer style={{ width: '100% !important', margin: '0px !important' }}>
                <div className={classes.cardItemGroup}>

                  <div className={classes.cardItem}>
                    <div>
                      Current password
                  </div>
                    <div className={classes.cardItemComponent}>

                      <TextField id="password"
                        value={password}
                        className={classes.textfieldRoot}
                        InputProps={{
                          onChange: this.handleChange('password'),
                          type: 'password',
                          classes: {
                            root: classes.textfieldRoot,
                            input: classes.textfieldInput,
                            underline: classes.textFieldUnderline,
                          }
                        }} defaultValue="Bare" margin="normal" variant="filled" />
                    </div>
                  </div>
                  <div className={classes.cardItem}>
                    <div>
                      New password
                  </div>
                    <div className={classes.cardItemComponent}>

                      <TextField id="new_password" className={classes.textfieldRoot}
                        value={new_password}
                        InputProps={{
                          onChange: this.handleChange('new_password'),
                          type: 'password',
                          classes: {
                            root: classes.textfieldRoot,
                            input: classes.textfieldInput,
                            underline: classes.textFieldUnderline,
                          }
                        }} defaultValue="Bare" margin="normal" variant="filled" />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItemFooter}>
                    <div>

                    </div>
                    <div className={classes.cardItemComponent}>

                      <Button variant="outlined" 
                      onClick={this.changePassword}
                      className={classes.cardItemSaveBtn}>
                      
                        Change password
                        </Button>
                    </div>
                  </div>
                </div>
              </GridContainer>
            </CardBody>
          </Card>




          <div
            className={classes.cardItemGroupHeader}>
            Personal information
      </div>
          <Card style={{ marginTop: '20px !important', }}>
            <CardBody style={{ padding: '0px', margin: '0px !important', }}>
              <GridContainer style={{ width: '100% !important', margin: '0px !important' }}>
                <div className={classes.cardItemGroup}>

                  <div className={classes.cardItem}>
                    <div>
                      First name
                </div>
                    <div className={classes.cardItemComponent}>

                      <TextField id="firstName" className={classes.textfieldRoot} InputProps={{
                        onChange: this.handleChange('firstName'),
                        type: 'text',
                        value: firstName,
                        classes: {
                          root: classes.textfieldRoot,
                          input: classes.textfieldInput,
                          underline: classes.textFieldUnderline,
                        }
                      }} defaultValue="Bare" margin="normal" variant="filled" />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      Last name
                </div>
                    <div className={classes.cardItemComponent}>

                      <TextField id="lastName" className={classes.textfieldRoot} InputProps={{
                        onChange: this.handleChange('lastName'),
                        type: 'text',
                        value: lastName,
                        classes: {
                          root: classes.textfieldRoot,
                          input: classes.textfieldInput,
                          underline: classes.textFieldUnderline,
                        }
                      }} defaultValue="Bare" margin="normal" variant="filled" />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      Email
                </div>
                    <div className={classes.cardItemComponent}>

                      <TextField id="email" className={classes.textfieldRoot} InputProps={{
                        type: 'text',
                        value: email,
                        onChange: this.handleChange('email'),
                        classes: {
                          root: classes.textfieldRoot,
                          input: classes.textfieldInput,
                          underline: classes.textFieldUnderline,
                        }
                      }} defaultValue="Bare" margin="normal" variant="filled" />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      Phone
                </div>
                    <div className={classes.cardItemComponent}>

                      <TextField id="phone" className={classes.textfieldRoot}
                        InputProps={{
                          type: 'text',
                          value: phone,
                          onChange: this.handleChange('phone'),
                          classes: {
                            root: classes.textfieldRoot,
                            input: classes.textfieldInput,
                            underline: classes.textFieldUnderline,
                          }
                        }} defaultValue="Bare" margin="normal" variant="filled" />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItemFooter}>
                    <div>

                    </div>
                    <div className={classes.cardItemComponent}>

                      <Button 
                      variant="outlined"
                      onClick={this.update}
                       className={classes.cardItemSaveBtn}>
                        Save
                      </Button>
                    </div>
                  </div>
                </div>
              </GridContainer>
            </CardBody>
          </Card>




          <div
            className={classes.cardItemGroupHeader}>
            Business information
      </div>
          <Card style={{ marginTop: '20px !important', }}>
            <CardBody style={{ padding: '0px', margin: '0px !important', }}>
              <GridContainer style={{ width: '100% !important', margin: '0px !important' }}>
                <div className={classes.cardItemGroup}>

                  <div className={classes.cardItem}>
                    <div>
                      Email
                </div>
                    <div className={classes.cardItemComponent}>

                      <TextField id="bussinessEmail" className={classes.textfieldRoot}
                        InputProps={{
                          type: 'text',
                          value: bussinessEmail,
                          onChange: this.handleChange('bussinessEmail'),
                          classes: {
                            root: classes.textfieldRoot,
                            input: classes.textfieldInput,
                            underline: classes.textFieldUnderline,
                          }
                        }} defaultValue="Bare" margin="normal" variant="filled" />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      Phone
                </div>
                    <div className={classes.cardItemComponent}>

                      <TextField id="phone" className={classes.textfieldRoot} InputProps={{
                        type: 'text',
                        value: phone,
                        onChange: this.handleChange('phone'),
                        classes: {
                          root: classes.textfieldRoot,
                          input: classes.textfieldInput,
                          underline: classes.textFieldUnderline,
                        }
                      }} defaultValue="Bare" margin="normal" variant="filled" />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      Company name
                </div>
                    <div className={classes.cardItemComponent}>

                      <TextField id="companyName" className={classes.textfieldRoot} InputProps={{
                        type: 'text',
                        value: companyName,
                        onChange: this.handleChange('companyName'),
                        classes: {
                          root: classes.textfieldRoot,
                          input: classes.textfieldInput,
                          underline: classes.textFieldUnderline,
                        }
                      }} defaultValue="Bare" margin="normal" variant="filled" />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      Registration number
                </div>
                    <div className={classes.cardItemComponent}>

                      <TextField id="cvr" className={classes.textfieldRoot} InputProps={{
                        type: 'text',
                        value: cvr,
                        onChange: this.handleChange('cvr'),
                        classes: {
                          root: classes.textfieldRoot,
                          input: classes.textfieldInput,
                          underline: classes.textFieldUnderline,
                        }
                      }} defaultValue="Bare" margin="normal" variant="filled" />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      Address
                </div>
                    <div className={classes.cardItemComponent}>

                      <TextField id="address" className={classes.textfieldRoot} InputProps={{
                        type: 'text',
                        value: address,
                        onChange: this.handleChange('address'),
                        classes: {
                          root: classes.textfieldRoot,
                          input: classes.textfieldInput,
                          underline: classes.textFieldUnderline,
                        }
                      }} defaultValue="Bare" margin="normal" variant="filled" />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      Postal code
                </div>
                    <div className={classes.cardItemComponent}>

                      <TextField id="zipCode" className={classes.textfieldRoot} InputProps={{
                        type: 'text',
                        value: zipCode,
                        onChange: this.handleChange('zipCode'),
                        classes: {
                          root: classes.textfieldRoot,
                          input: classes.textfieldInput,
                          underline: classes.textFieldUnderline,
                        }
                      }} defaultValue="Bare" margin="normal" variant="filled" />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      Country
                </div>
                    <div className={classes.cardItemComponent}>

                      <TextField id="country" className={classes.textfieldRoot} InputProps={{
                        type: 'text',
                        value: country,
                        readOnly: true,
                        classes: {
                          root: classes.textfieldRoot,
                          input: classes.textfieldInput,
                          underline: classes.textFieldUnderline,
                        }
                      }} defaultValue="Bare" margin="normal" variant="filled" />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      City
                </div>
                    <div className={classes.cardItemComponent}>

                      <TextField id="city" className={classes.textfieldRoot} InputProps={{
                        type: 'text',
                        value: city,
                        onChange: this.handleChange('city'),
                        classes: {
                          root: classes.textfieldRoot,
                          input: classes.textfieldInput,
                          underline: classes.textFieldUnderline,
                        }
                      }} defaultValue="Bare" margin="normal" variant="filled" />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItemFooter}>
                    <div>

                    </div>
                    <div className={classes.cardItemComponent}>

                      <Button variant="outlined" 
                      onClick={this.update}
                      className={classes.cardItemSaveBtn}>
                        Save
                      </Button>
                    </div>
                  </div>
                </div>
              </GridContainer>
            </CardBody>
          </Card>


          <div
            className={classes.cardItemGroupHeader}>
            Social media
      </div>
          <Card style={{ marginTop: '20px !important', }}>
            <CardBody style={{ padding: '0px', margin: '0px !important', }}>
              <GridContainer style={{ width: '100% !important', margin: '0px !important' }}>
                <div className={classes.cardItemGroup}>

                  <div className={classes.cardItem}>
                    <div>
                      Facebook
                </div>
                    <div className={classes.cardItemComponent}>

                      <TextField id="faceBookUrl" className={classes.textfieldRoot} InputProps={{
                        type: 'text',
                        value: faceBookUrl,
                        onChange: this.smsNameChange('faceBookUrl'),
                        classes: {
                          root: classes.textfieldRoot,
                          input: classes.textfieldInput,
                          underline: classes.textFieldUnderline,
                        }
                      }} defaultValue="Bare" margin="normal" variant="filled" />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      Instagram
                </div>
                    <div className={classes.cardItemComponent}>

                      <TextField id="instagramUrl" className={classes.textfieldRoot} InputProps={{
                        type: 'text',
                        value: instagramUrl,
                        onChange: this.smsNameChange('instagramUrl'),
                        classes: {
                          root: classes.textfieldRoot,
                          input: classes.textfieldInput,
                          underline: classes.textFieldUnderline,
                        }
                      }} defaultValue="Bare" margin="normal" variant="filled" />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      Twitter
                </div>
                    <div className={classes.cardItemComponent}>

                      <TextField id="twitterUrl" className={classes.textfieldRoot} InputProps={{
                        type: 'text',
                        value: twitterUrl,
                        onChange: this.smsNameChange('twitterUrl'),
                        classes: {
                          root: classes.textfieldRoot,
                          input: classes.textfieldInput,
                          underline: classes.textFieldUnderline,
                        }
                      }} defaultValue="Bare" margin="normal" variant="filled" />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      Website
                </div>
                    <div className={classes.cardItemComponent}>

                      <TextField id="websiteUrl" className={classes.textfieldRoot} InputProps={{
                        type: 'text',
                        value: websiteUrl,
                        onChange: this.smsNameChange('websiteUrl'),
                        classes: {
                          root: classes.textfieldRoot,
                          input: classes.textfieldInput,
                          underline: classes.textFieldUnderline,
                        }
                      }} defaultValue="Bare" margin="normal" variant="filled" />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItemFooter}>
                    <div>

                    </div>
                    <div className={classes.cardItemComponent}>

                      <Button variant="outlined" 
                      onClick={this.update}
                      className={classes.cardItemSaveBtn}>
                        Save
                      </Button>
                    </div>
                  </div>
                </div>
              </GridContainer>
            </CardBody>
          </Card>


          <div
            className={classes.cardItemGroupHeader}>
            Online payments
      </div>
          <Card style={{ marginTop: '20px !important', }}>
            <CardBody style={{ padding: '0px', margin: '0px !important', }}>
              <GridContainer style={{ width: '100% !important', margin: '0px !important' }}>
                <div className={classes.cardItemGroup}>

                  <div className={classes.cardItem}>
                    <div>
                      Paypal API key
                </div>
                    <div className={classes.cardItemComponent}>

                      <TextField id="paypal_key" className={classes.textfieldRoot} InputProps={{
                        type: 'text',
                        value: paypal_key,
                        onChange: this.handleChange('paypal_key'),
                        classes: {
                          root: classes.textfieldRoot,
                          input: classes.textfieldInput,
                          underline: classes.textFieldUnderline,
                        }
                      }} defaultValue="Bare" margin="normal" variant="filled" />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      Stripe API key
                </div>
                    <div className={classes.cardItemComponent}>

                      <TextField id="strip" className={classes.textfieldRoot} InputProps={{
                        type: 'text',
                        value: strip,
                        onChange: this.handleChange('strip'),
                        classes: {
                          root: classes.textfieldRoot,
                          input: classes.textfieldInput,
                          underline: classes.textFieldUnderline,
                        }
                      }} defaultValue="Bare" margin="normal" variant="filled" />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      Coinpayments API key
                </div>
                    <div className={classes.cardItemComponent}>

                      <TextField id="coin_payment" className={classes.textfieldRoot} InputProps={{
                        type: 'text',
                        value: coin_payment,
                        onChange: this.handleChange('coin_payment'),
                        classes: {
                          root: classes.textfieldRoot,
                          input: classes.textfieldInput,
                          underline: classes.textFieldUnderline,
                        }
                      }} defaultValue="Bare" margin="normal" variant="filled" />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItemFooter}>
                    <div>

                    </div>
                    <div className={classes.cardItemComponent}>

                      <Button variant="outlined" 
                        onClick={this.update}
                       className={classes.cardItemSaveBtn}>
                        Save
                      </Button>
                    </div>
                  </div>
                </div>
              </GridContainer>
            </CardBody>
          </Card>




          <div
            className={classes.cardItemGroupHeader}>
            Offline payments
      </div>
          <Card style={{ marginTop: '20px !important', }}>
            <CardBody style={{ padding: '0px', margin: '0px !important', }}>
              <GridContainer style={{ width: '100% !important', margin: '0px !important' }}>
                <div className={classes.cardItemGroup}>

                  <div className={classes.cardItem}>
                    <div>
                      MasterCard
                </div>
                    <div className={classes.cardItemComponent}>

                      <Switch
                        checked={masterCard}
                        onChange={() => this.offlineChange(event, 'masterCard')}

                      />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      VISA
                </div>
                    <div className={classes.cardItemComponent}>

                      <Switch
                        checked={visa}
                        onChange={() => this.offlineChange(event, 'visa')}
                      />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      Dankort
                </div>
                    <div className={classes.cardItemComponent}>

                      <Switch checked={dankort}
                        onChange={() => this.offlineChange(event, 'dankort')} />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      Cash
                </div>
                    <div className={classes.cardItemComponent}>

                      <Switch
                        checked={cash}
                        onChange={() => this.offlineChange(event, 'cash')}
                      />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      PayPal
                </div>
                    <div className={classes.cardItemComponent}>

                      <Switch
                        checked={paypal}
                        onChange={() => this.offlineChange(event, 'paypal')}
                      />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      American Express
                </div>
                    <div className={classes.cardItemComponent}>

                      <Switch
                        checked={american_express}
                        onChange={() => this.offlineChange(event, 'american_express')}
                      />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      MaestroCard
                </div>
                    <div className={classes.cardItemComponent}>

                      <Switch
                        checked={maestro}
                        onChange={() => this.offlineChange(event, 'maestro')}
                      />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />
                  <div className={classes.cardItem}>
                    <div>
                      Bitcoin
                </div>
                    <div className={classes.cardItemComponent}>

                      <Switch
                        checked={bitcoin}
                        onChange={() => this.offlineChange(event, 'bitcoin')}

                      />
                    </div>
                  </div>
                  <Divider light className={classes.dividerStyle} />

                  <div className={classes.cardItemFooter}>
                    <div>

                    </div>
                    <div className={classes.cardItemComponent}>

                      <Button variant="outlined" 
                      onClick={this.update}
                      className={classes.cardItemSaveBtn}>
                        Save
                      </Button>
                    </div>
                  </div>
                </div>
              </GridContainer>
            </CardBody>
          </Card>






        </GridItem>
        {/**
        <GridItem xs={12} sm={12} md={12} lg={12}>
          <form className={classes.form}>
            <Card>
              <CardBody className={classes.cardBody}>
                <Tabs value={tabValue} onChange={this.handleTabChange}
                  classes={{ root: classes.tabsRoot, indicator: classes.tabsIndicator }}>
                  <Tab label="General" />
                  <Tab label="Business information" />
                  <Tab label="Social media" />
                  <Tab label="Payment Settings" />
                  <Tab label="Security" />
                  <Tab label="Holiday" />
                </Tabs>
                {tabValue === 1 && <TabContainer>
                  <GridContainer>
                    <GridItem xs={12} sm={12} md={12}>
                      <Typography variant="h5">
                        General
                  </Typography>
                    </GridItem>
                  </GridContainer>
                  <GridContainer>
                    <GridItem xs={12} sm={12} md={6}>
                      <CustomInput labelText={localization.localizedString('SIGNUP_FIRST_NAME_LABEL')} formControlProps={{
                        required: true,
                        fullWidth: true
                      }} inputProps={{
                        type: 'text',
                        value: firstName,
                        onChange: this.handleChange('firstName')
                      }} />
                    </GridItem>
                    <GridItem xs={12} sm={12} md={6}>
                      <CustomInput labelText={localization.localizedString('SIGNUP_LAST_NAME_LABEL')} formControlProps={{
                        required: true,
                        fullWidth: true
                      }} inputProps={{
                        type: 'text',
                        value: lastName,
                        onChange: this.handleChange('lastName')
                      }} />
                    </GridItem>
                    <GridItem xs={12} sm={12} md={6}>
                      <CustomInput labelText={localization.localizedString('SIGNUP_EMAIL_LABEL')} formControlProps={{
                        required: true,
                        fullWidth: true
                      }} inputProps={{
                        type: 'text',
                        value: email,
                        onChange: this.handleChange('email')
                      }} />
                    </GridItem>
                    <GridItem xs={12} sm={12} md={6}>
                      <CustomInput labelText={localization.localizedString('SIGNUP_PHONE_LABEL')} formControlProps={{
                        required: true,
                        fullWidth: true
                      }} inputProps={{
                        type: 'text',
                        value: phone,
                        onChange: this.handleChange('phone')
                      }} />
                    </GridItem>
                    <GridItem xs={12} sm={12} md={6}>
                      <CustomInput labelText={localization.localizedString('SIGNUP_COMPANY_NAME_LABEL')} formControlProps={{
                        required: true,
                        fullWidth: true
                      }} inputProps={{
                        type: 'text',
                        value: companyName,
                        onChange: this.handleChange('companyName')
                      }} />
                    </GridItem>
                    <GridItem xs={12} sm={12} md={6}>
                      <CustomInput labelText={localization.localizedString('SIGNUP_CVR_LABEL')} formControlProps={{
                        fullWidth: true
                      }} inputProps={{
                        type: 'text',
                        value: cvr,
                        onChange: this.handleChange('cvr')
                      }} />
                    </GridItem>
                  </GridContainer>
                  <GridContainer>
                    <GridItem xs={12} sm={12} md={12}>
                      <Typography variant="h5" className={classes.topPadding}>
                        Address
                  </Typography>
                    </GridItem>
                  </GridContainer>
                  <GridContainer>
                    <GridItem xs={12} sm={12} md={6}>
                      <CustomInput labelText={localization.localizedString('SIGNUP_ADDRESS_LABEL')} formControlProps={{
                        required: true,
                        fullWidth: true
                      }} inputProps={{
                        type: 'text',
                        value: address,
                        onChange: this.handleChange('address')
                      }} />
                    </GridItem>
                    <GridItem xs={12} sm={12} md={6}>

                      <CustomInput labelText={localization.localizedString('SIGNUP_ZIP_CODE_LABEL')} formControlProps={{
                        required: true,
                        fullWidth: true
                      }} inputProps={{
                        type: 'text',
                        value: zipCode,
                        onChange: this.handleChange('zipCode')
                      }} />
                    </GridItem>

                    <GridItem xs={12} sm={12} md={6}>
                      <CustomInput labelText={localization.localizedString('SIGNUP_COUNTRY_LABEL')} formControlProps={{
                        required: true,
                        fullWidth: true
                      }} inputProps={{
                        type: 'text',
                        value: country,
                        readOnly: true
                      }} />
                    </GridItem>

                    <GridItem xs={12} sm={12} md={6}>
                      <CustomInput labelText={localization.localizedString('SIGNUP_CITY_LABEL')} formControlProps={{
                        required: true,
                        fullWidth: true
                      }} inputProps={{
                        type: 'text',
                        value: city,
                        onChange: this.handleChange('city')
                      }} />
                    </GridItem>

                    <GridItem xs={12} sm={12} md={6}>
                      <FormControlLabel control={(<Checkbox tabIndex={-1} disableRipple checked={email_is_verified} />
                      )}
                        classes={{ label: classes.label }}
                        label={email_is_verified ? "Email was veryfied" : "Email not was veryfied"}
                      />
                    </GridItem>
                    <GridItem xs={12} sm={12} md={6}>
                      <FormControlLabel control={(<Checkbox tabIndex={-1} disableRipple checked={phone_is_verified} />
                      )}
                        classes={{ label: classes.label }}
                        label={phone_is_verified ? "Phone was veryfied" : "phone not was veryfied"}
                      />
                    </GridItem>
                  </GridContainer>
                </TabContainer>}
                {tabValue === 2 && <TabContainer>
                  <GridContainer>
                    <GridItem xs={12} sm={12} md={12}>
                      <Typography variant="h5">
                        Accounts
                  </Typography>
                    </GridItem>
                  </GridContainer>
                  <GridContainer>

                    <GridItem xs={12} sm={12} md={12}>
                      <CustomInput labelText={localization.localizedString('COMPANY_FACEBOOK_URL')} formControlProps={{
                        required: false,
                        fullWidth: true
                      }} inputProps={{
                        type: 'text',
                        value: faceBookUrl,
                        startAdornment: <InputAdornment position="start">https://facebook.com/</InputAdornment>,
                        onChange: this.smsNameChange('faceBookUrl')
                      }} />
                    </GridItem>
                    <GridItem xs={12} sm={12} md={12}>
                      <CustomInput labelText={localization.localizedString('COMPANY_INSTAGRAM_URL')} formControlProps={{
                        required: false,
                        fullWidth: true
                      }} inputProps={{
                        type: 'text',
                        value: instagramUrl,
                        startAdornment: <InputAdornment position="start">https://instagram.com/</InputAdornment>,
                        onChange: this.smsNameChange('instagramUrl')
                      }} />
                    </GridItem>
                    <GridItem xs={12} sm={12} md={12}>
                      <CustomInput labelText={localization.localizedString('COMPANY_TWITTER_URL')} formControlProps={{
                        required: false,
                        fullWidth: true
                      }} inputProps={{
                        type: 'text',
                        value: twitterUrl,
                        startAdornment: <InputAdornment position="start">https://twitter.com/</InputAdornment>,
                        onChange: this.smsNameChange('twitterUrl')
                      }} />
                    </GridItem>
                    <GridItem xs={12} sm={12} md={12}>
                      <CustomInput labelText={localization.localizedString('COMPANY_WEBSITE_URL')} formControlProps={{
                        required: false,
                        fullWidth: true
                      }} inputProps={{
                        type: 'text',
                        value: websiteUrl,
                        startAdornment: <InputAdornment position="start">https://</InputAdornment>,
                        onChange: this.smsNameChange('websiteUrl')
                      }} />
                    </GridItem>
                  </GridContainer>
                </TabContainer>}
                {tabValue === 0 && <TabContainer>
                  <GridContainer>

                    <GridItem xs={12} sm={12} md={6}>
                      <CustomInput labelText={localization.localizedString('COMPANY_CUSTOM_URL')} formControlProps={{
                        fullWidth: true,
                        required: true,
                      }} inputProps={{
                        type: 'text',
                        value: customUrl,
                        onChange: this.customUrlChange('customUrl')
                      }} />
                      <Typography>
                        Your booking page: <a href='https://booking.com/{customUrl}'>https://booking.com/{customUrl}</a>
                      </Typography>
                    </GridItem>
                    <GridItem xs={12} sm={12} md={6}>
                      <CustomInput labelText={localization.localizedString('SIGNUP_SMS_SENDER_NAME_LABEL')}
                        formControlProps={{
                          required: true,
                          fullWidth: true
                        }} inputProps={{
                          type: 'text',
                          value: smsSenderName,
                          onChange: this.smsNameChange('smsSenderName')
                        }} />
                      <Typography>
                        This should usually be your business name or a shortened version of it.
                  </Typography>
                    </GridItem>
                    <GridItem xs={12} sm={12} md={12}>
                      <FormControl className={classes.formControl + ' ' + classes.dropDownSettings}>
                        <InputLabel htmlFor="interval">Booking interval</InputLabel>
                        <Select className={classes.dropDownSelectSettings} value={this.state.interval}
                          onChange={this.handleChange('interval')} inputProps={{
                            name: 'interval',
                            id: 'interval',
                          }}>

                          <MenuItem key={15} value={15}>15 Minutes</MenuItem>
                          <MenuItem key={30} value={30}>30 Minutes</MenuItem>
                          <MenuItem key={45} value={45}>45 Minutes</MenuItem>
                          <MenuItem key={60} value={60}>60 Minutes</MenuItem>

                        </Select>
                      </FormControl>
                    </GridItem>
                    <GridItem xs={12} sm={12} md={12}>
                      <FormControl className={classes.formControl + ' ' + classes.dropDownSettings}>
                        <InputLabel htmlFor="lockBookingXHourBefore">
                          {localization.localizedString('SIGNUP_LOCK_BOOKING_XHOUR_BEFORE_LABEL')}</InputLabel>
                        <Select className={classes.dropDownSelectSettings} value={this.state.lockBookingXHourBefore}
                          onChange={this.handleChange('lockBookingXHourBefore')} inputProps={{
                            name: 'lockBookingXHourBefore',
                            id: 'lockBookingXHourBefore',
                          }}>

                          <MenuItem key={15} value={12}>12 hours</MenuItem>
                          <MenuItem key={30} value={24}>24 hours</MenuItem>
                          <MenuItem key={45} value={48}>48 hours</MenuItem>


                        </Select>
                      </FormControl>
                      <Typography>
                        How many hours before an appointment can a customer latest cancel the booking.
                  </Typography>
                    </GridItem>
                    <GridItem xs={12} sm={12} md={12}>
                      <CustomInput labelText={localization.localizedString('SIGNUP_BOOK_LATEST_XHOUR_BEFORE_LABEL')}
                        formControlProps={{
                          required: true,
                          fullWidth: true
                        }} inputProps={{
                          type: 'number',
                          value: bookLatestXHourBefore,
                          onChange: this.handleChange('bookLatestXHourBefore')
                        }} />
                      <Typography>
                        Specify how many hours, before a booking, a customer can request a booking.
                  </Typography>
                    </GridItem>
                    <GridItem xs={12} sm={12} md={12}>
                      <CustomInput labelText="Business description" inputProps={{
                        value: this.state.description,
                        multiline: true,
                        rows: 10
                      }} formControlProps={{
                        className: classes.customInput_4,
                        onChange: this.handleChange('description'),
                        fullWidth: true
                      }} />
                      <Typography>
                        Provide a comprehensive description about your business
                  </Typography>
                    </GridItem>


                    <GridItem xs={12} sm={12} md={12}>
                      <FormControlLabel control={(<Checkbox tabIndex={-1} disableRipple
                        onClick={this.handleToggle('acceptBookingAutomatically')} checked={acceptBookingAutomatically} />

                      )}
                        classes={{ label: classes.label }}
                        label={localization.localizedString('SIGNUP_ACCEPT_BOOKING_AUTOMATICALLY_LABEL')}
                      />
                    </GridItem>
                    <GridItem xs={12} sm={12} md={12}>
                      <FormControlLabel control={(<Checkbox tabIndex={-1} disableRipple
                        onClick={this.handleToggle('paymentUpfront')} checked={paymentUpfront} />
                      )}
                        classes={{ label: classes.label }}
                        label={localization.localizedString('SIGNUP_PAYMENT_UPFRONT_LABEL')}
                      />
                    </GridItem>
                  </GridContainer>
                </TabContainer>}
                {tabValue === 4 && <TabContainer>
                  <Grid container className={classes.GridContainer}>
                    <Grid item xs={12} sm={12} md={7}>
                      <CustomInput className={classes.textField}
                        labelText={localization.localizedString('CURRENT_PASSWORD')} formControlProps={{
                          required: true,
                          fullWidth: true
                        }} inputProps={{
                          type: 'password',
                          value: password,
                          onChange: this.handleChange('password')
                        }} />
                    </Grid>
                    <Grid item xs={12} sm={12} md={7}>
                      <CustomInput className={classes.textField} labelText={localization.localizedString('NEW_PASSWORD')}
                        formControlProps={{
                          required: true,
                          fullWidth: true
                        }} inputProps={{
                          type: 'password',
                          value: new_password,
                          onChange: this.handleChange('new_password')
                        }} />
                    </Grid>


                  </Grid>
                </TabContainer>}
                {tabValue === 3 && <TabContainer>
                  <Grid container className={classes.GridContainer}>
                    <GridItem xs={12} sm={12} md={12}>
                      <GridContainer justify="center">
                        <Grid item xs={12} sm={12} md={6}>
                          <Typography variant="h5">
                            Online Payments
                      </Typography>

                          <GridContainer>
                            <GridItem xs={12} sm={12} md={10}>
                              <CustomInput labelText={'Paypal Api Key'} formControlProps={{
                                required: false,
                                fullWidth: true,

                              }} inputProps={{
                                type: 'text',
                                value: paypal_key,
                                onChange: this.handleChange('paypal_key')
                              }} />
                            </GridItem>
                            <GridItem xs={12} sm={12} md={10}>
                              <CustomInput labelText={'Stripe'} formControlProps={{
                                required: false,
                                fullWidth: true,

                              }} inputProps={{
                                type: 'text',
                                value: strip,
                                onChange: this.handleChange('strip')
                              }} />
                            </GridItem>
                            <GridItem xs={12} sm={12} md={10}>
                              <CustomInput className={classes.online_bottom} labelText={'CoinPayment'} formControlProps={{
                                required: false,
                                fullWidth: true,

                              }} inputProps={{
                                type: 'text',
                                value: coin_payment,
                                onChange: this.handleChange('coin_payment')
                              }} />
                            </GridItem>
                          </GridContainer>

                        </Grid>

                        <Grid item xs={12} sm={12} md={6}>
                          <Typography variant="h5">
                            Offline Payments
                      </Typography>
                          <Grid container className={classes.offline_margin}>
                            <Grid item xs={12} sm={12} md={12}>
                              <FormControlLabel control={(<Checkbox tabIndex={-1} disableRipple checked={masterCard}
                                onChange={() => this.offlineChange(event, 'masterCard')}
                              />
                              )}
                                classes={{ label: classes.label }}
                                label='MasterCard'
                              />
                            </Grid>

                            <Grid item xs={12} sm={12} md={12}>
                              <FormControlLabel control={(<Checkbox tabIndex={-1} disableRipple checked={visa}
                                onChange={() => this.offlineChange(event, 'visa')}
                              />
                              )}
                                classes={{ label: classes.label }}
                                label='VISA'
                              />
                            </Grid>

                            <Grid item xs={12} sm={12} md={12}>
                              <FormControlLabel control={(<Checkbox tabIndex={-1} disableRipple checked={dankort}
                                onChange={() => this.offlineChange(event, 'dankort')}
                              />
                              )}
                                classes={{ label: classes.label }}
                                label='Dankort'
                              />
                            </Grid>

                            <Grid item xs={12} sm={12} md={12}>
                              <FormControlLabel control={(<Checkbox tabIndex={-1} disableRipple checked={cash}
                                onChange={() => this.offlineChange(event, 'cash')}
                              />)}
                                classes={{ label: classes.label }}
                                label='Cash'
                              />
                            </Grid>

                            <Grid item xs={12} sm={12} md={12}>
                              <FormControlLabel control={(<Checkbox tabIndex={-1} disableRipple checked={paypal}
                                onChange={() => this.offlineChange(event, 'paypal')}
                              />)}
                                classes={{ label: classes.label }}
                                label='PayPal'
                              />
                            </Grid>

                            <Grid item xs={12} sm={12} md={12}>
                              <FormControlLabel control={(<Checkbox tabIndex={-1} disableRipple checked={american_express}
                                onChange={() => this.offlineChange(event, 'american_express')}
                              />)}
                                classes={{ label: classes.label }}
                                label='American Express'
                              />
                            </Grid>

                            <Grid item xs={12} sm={12} md={12}>
                              <FormControlLabel control={(<Checkbox tabIndex={-1} disableRipple checked={maestro}
                                onChange={() => this.offlineChange(event, 'maestro')}
                              />)}
                                classes={{ label: classes.label }}
                                label='Maestro Card'
                              />
                            </Grid>

                            <Grid item xs={12} sm={12} md={12}>
                              <FormControlLabel control={(<Checkbox tabIndex={-1} disableRipple checked={bitcoin}
                                onChange={() => this.offlineChange(event, 'bitcoin')}
                              />
                              )}
                                classes={{ label: classes.label }}
                                label='Bitcoin'
                              />
                            </Grid>
                          </Grid>
                        </Grid>
                      </GridContainer>
                    </GridItem>
                  </Grid>
                </TabContainer>}

                {tabValue === 5 && <TabContainer>
                  <Table key={1} className={classes.table}>
                    <TableHead>
                      <TableRow>
                        <TableCell className={classes.tableCellId + " " + classes.tableHeader_1}>No.</TableCell>
                        <TableCell className={classes.tableHeader_1}>Day</TableCell>
                        <TableCell className={classes.tableHeader_1}>Date</TableCell>
                        <TableCell className={classes.tableHeader_1}>Holiday Native Name</TableCell>
                        <TableCell className={classes.tableHeader_1}>Holiday English Name</TableCell>
                        <TableCell className={classes.tableCellId + " " + classes.tableHeader_1}>Work</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {
                        this.state.holidays.map((row, index) => {
                          let num = index + 1;
                          var now = new Date(row.date);
                          const isSelected = this.isSelected(row.id);
                          return <TableRow hover key={row.id} >
                            <TableCell  >
                              {num}
                            </TableCell>
                            <TableCell  >
                              {now.getDayName()}
                            </TableCell>
                            <TableCell  >
                              {row.date}
                            </TableCell>
                            <TableCell  >
                              {row.holidayNativeName}
                            </TableCell>
                            <TableCell  >
                              {row.holidayEnglishName}
                            </TableCell>
                            <TableCell className={classes.tableCellId}>
                              <Checkbox
                                tabIndex={-1}
                                checked={isSelected}
                                onChange={event => this.isWorkClick(event, row.id, row.date)}
                              />
                            </TableCell>
                          </TableRow>
                        })
                      }
                    </TableBody>
                  </Table>
                </TabContainer>}
              </CardBody>
              <CardFooter className={classes.cardFooterBycustomer_1}>
                <Grid item xs={12} sm={12} md={12} className={classes.buttonPadding}>
                  <Button onClick={() => (this.update())}
                    disabled={!this.checkRequiredFields()}>Save changes</Button>
                </Grid>
              </CardFooter>
            </Card>
          </form>
        </GridItem>
         */}
      </GridContainer>


    );
  }
}
export default withStyles(landingPageStyle)(withSnackbar(withLocalization(withAuth(Setting))));