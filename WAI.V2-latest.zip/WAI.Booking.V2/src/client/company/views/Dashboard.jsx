import React from 'react';
import { Switch, Route, Redirect } from 'react-router-dom';
import withStyles from '@material-ui/core/styles/withStyles';
import {  withSnackbar } from 'notistack';

import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';

import PerfectScrollbar from 'perfect-scrollbar';
import 'perfect-scrollbar/css/perfect-scrollbar.css';
import Header from 'common/components/Header/Header';
import Footer from 'common/components/Footer/Footer';
import Sidebar from 'common/components/Sidebar/Sidebar';

import withLocalization from 'common/contexts/LocalizationContext';
import withAuth from 'common/contexts/AuthContext';
//import withNotifications from 'common/contexts/NotificationsContext';
import dashboardStyle from 'common/assets/jss/material-react/layouts/dashboardStyle';

import dashboardRoutes from '../routes/dashboard';

import sidebarBg from '../assets/img/sidebarBg.jpg';


class Dashboard extends React.Component {
  state = {
    mobileOpen: false
  };

  componentDidMount() {
    const {notifications,localization,auth}=this.props;
    console.log(auth,auth.user.email_veryfied,auth.user.emailVeryfied,'this is auth');
    if(auth.user.email_veryfied==0 || auth.user.emailVeryfied==0){
      this.props.enqueueSnackbar(localization.localizedString('YOU_HAVE_NOT_VERYFIED_EMAIL'), { 
        variant: 'warning',
      });    
    }
    if (navigator.platform.indexOf('Win') > -1) {
      const ps = new PerfectScrollbar(this.refs.mainPanel);
    }
    window.addEventListener('resize', this.resize);
  }

  componentDidUpdate(prevProps, prevState, snapshot) {   
    const { history: prevHistory } = prevProps;
    const { history } = this.props;
    const { mobileOpen } = this.state;

    if (history.location.pathname !== prevHistory.location.pathname) {
      this.refs.mainPanel.scrollTop = 0;
      if (mobileOpen) {
        this.setState({ mobileOpen: false });
      }
    }
  }

  componentWillUnmount() {
    window.removeEventListener('resize', this.resize);
  }

  handleDrawerToggle = () => this.setState(state => ({ mobileOpen: !state.mobileOpen }));

  resize = () => {
    if (window.innerWidth >= 960) {
      this.setState({ mobileOpen: false });
    }
  };

  routes = props => (
    <Switch>
      {dashboardRoutes(props).map((prop, key) => {
        if (prop.redirect) {
          return <Redirect from={prop.path} to={prop.to} key={key} />;
        }
        return <Route path={prop.path} component={prop.component} key={key} />;
      })}
    </Switch>
  );

  render() {
    const {
      classes, localization,history, ...rest
    } = this.props;
    const { mobileOpen } = this.state;

    const localizedRoutes = dashboardRoutes({ localization ,history});

    return (
      <div className={classes.wrapper}>
        <Sidebar
          routes={localizedRoutes}
          image={sidebarBg}
          handleDrawerToggle={this.handleDrawerToggle}
          open={mobileOpen}
          color="primary"
          {...rest}
        />
        <div className={classes.mainPanel} ref="mainPanel">
         
          <Header           
            routes={localizedRoutes}
            history={history}
            handleDrawerToggle={this.handleDrawerToggle}
            {...rest}
          
          />
       
        {/**
        <AppBar position="static">
        <Toolbar>
          <IconButton className={classes.menuButton} color="inherit" aria-label="Menu">
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" color="inherit" className={classes.grow}>
            News
          </Typography>
          <Button color="inherit">Login</Button>
        </Toolbar>
      </AppBar>
    */}
          <div className={classes.content}>
            <div className={classes.container}>{this.routes({ localization })}</div>
          </div>
          <Footer />
        </div>
      </div>
    );
  }
}

export default withStyles(dashboardStyle)(withSnackbar(withLocalization(withAuth(Dashboard))));
