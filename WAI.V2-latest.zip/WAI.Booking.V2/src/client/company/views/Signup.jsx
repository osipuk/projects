import React from 'react';

import Link from 'react-router-dom/es/Link';
import withStyles from '@material-ui/core/styles/withStyles';
import axios from 'axios';
import Grid from '@material-ui/core/Grid';
import Check from '@material-ui/icons/Check';
import TextField from '@material-ui/core/TextField';
import Button from "@material-ui/core/Button";
import InputAdornment from '@material-ui/core/InputAdornment';
import Icon from "@material-ui/core/Icon";
import LockOutlined from '@material-ui/icons/LockOutlined';
import EmailOutlined from '@material-ui/icons/EmailOutlined';
import Typography from '@material-ui/core/Typography';
import {  withSnackbar } from 'notistack';
import ReactPhoneInput from 'react-phone-input-mui';
import withLocalization from 'common/contexts/LocalizationContext';
import withAuth from 'common/contexts/AuthContext';
import GridContainer from 'common/components/Grid/GridContainer';
import GridItem from 'common/components/Grid/GridItem';
import Card from 'common/components/Card/Card';
import CardBody from 'common/components/Card/CardBody';
import withNotifications from 'common/contexts/NotificationsContext';
import Success from '@material-ui/icons/CheckCircle';
import CardFooter from 'common/components/Card/CardFooter';
import CustomInput from 'common/components/CustomInput/CustomInput';
import SignupButton from 'common/containers/SignupButton/SignupButton';
import signupPageStyle from 'common/assets/jss/material-react/views/loginPage';
import landingPageStyle from "../../p/assets/jss/views/landingPage";
import bgImage from '../assets/img/businessBg.jpg';

class SignupPage extends React.Component {
  state = {
    email: '',
    password: '',
    confirm_password:'',    
    country:["dk"],
    countries:[],
    phone: '',
    dialCode:'',
    userData:{},
    password_error:false,
    email_error:false,
    verifyCode_error:false,
    cardState:'signUp',
    verifyCode:'',
    resend_btn:false,
    pre_phone:''
  };

  componentWillMount(){
    const {auth}=this.props;    
    if(auth.isAuth){
      this.setState({cardState:'verify',
            email:auth.user.email,
            phone:auth.user.phone
     });
    }   
  }
  componentDidMount(){
    this.loadCountryInf();
  }
  componentDidUpdate(prevProps, prevState, snapshot) {
    const { auth: { isAuth: prevIsAuth, user: prevUser } } = prevProps;
    const { auth: { isAuth: newIsAuth, user: newUser }, history } = this.props;    
    if (!prevIsAuth && newIsAuth && !prevUser && newUser) {
      history.push('/');
    }    
    else if(newUser && newIsAuth){
      if(newUser.phone_veryfied)
        history.push('/');
    }
  }
  handleChange = prop => event => this.setState({ [prop]: event.target.value,
    email_error:false, 
    password_error:false,
    verifyCode_error:false});

  handleToggle = prop => event => this.setState({ [prop]: event.target.checked });
  checkRequiredFields = () => {
    const {
      email, password,confirm_password,
      phone,
    } = this.state;

    return (email && email.length > 0)
      && (password && password.length > 0)
      && (password && confirm_password==password)    
      && (phone && phone.length > 0);     
  };
  loadCountryInf=async()=>{
    const { data } = await axios.get('/api/company/countrys');       
    if(data.success){
      var temp=[];    
      data.country.map(row=>{
        temp.push(row.country_prefix);       
      });     
      this.setState({country:temp,countries:data.country,});    
    }     
  }
  handleOnChange=(val,event)=>{      
    this.setState({phone:val,
      dialCode:"+"+event.dialCode,      
    });   
  }
  signUp=async()=>{
    const {notifications,localization}=this.props;
    var countryId=1;
      this.state.countries.map(row=>{
        if(row.country_phone_code==this.state.dialCode){
          countryId=row.id;
        }
      });
     var phone_number=this.state.phone.substring(3,15);

     if(this.state.email==''){
       this.setState({email_error:true});
       return;
     }
     if(this.state.password!=this.state.confirm_password){
       this.setState({password_error:true});      
       this.props.enqueueSnackbar(localization.localizedString('NOT_MATCHED_PASSWORD'), { 
        variant: 'error',
       }); 
       return;
     }
     else if(this.state.password==''){
        this.setState({password_error:true});
        return;
     }
     var userData={company:{
       email:this.state.email,
       password:this.state.password,
       countryId:countryId,
       phone:phone_number.replace(/\s+/g, ''),
       type:'company'
     }}  

     const { data } = await axios.post('/api/company/signup',  userData );
     if(data.success){
       this.setState({cardState:'verify'});
     }
     else{     
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
     }    
  }
  resendKey=async()=>{
    const {notifications,localization}=this.props;
    var userData={user:{
      email:this.state.email,     
      type:'company'
    }}
    this.setState({resend_btn:true});
    setTimeout(() => this.setState({resend_btn:false}), 30000);

    const { data } = await axios.post('/api/company/resend',  userData );    
    if(data.success){
      this.props.enqueueSnackbar(localization.localizedString('SENT_SUCCESS'), { 
        variant: 'success',
      });   
    }
    else{
      this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
        variant: 'error',
      }); 
    }
  }
  submitVerifyCode=async()=>{  
      const {localization}=this.props;
        var userData={email:this.state.email,verifyCode:this.state.verifyCode,type:'company'};
        const result = await this.props.auth.signup(userData); 
        console.log(result);
        if (!result.success) {        
          this.props.enqueueSnackbar(localization.localizedError(result.errorCode), { 
            variant: 'error',
          }); 
        }
        else{          
          this.props.enqueueSnackbar(localization.localizedString('PHONE_VERIFY_WAS_SUCCESS'), { 
            variant: 'success',
          }); 
        }
      
  }

  cardBody=()=>{   
    if(this.state.cardState!='signUp'){
      return this.verifyBody();
    }
    else{
      return this.signup_body();
    }
  }
  verifyBody=()=>{
    const { localization, classes,auth } = this.props;
    var pre_code="";
    if(auth.isAuth){
      this.state.countries.map(row=>{
        if(row.id==auth.user.country_id){
          pre_code=row.country_phone_code+" "+this.state.phone;
        }
        if(row.id==auth.user.countryId){
          pre_code=row.country_phone_code+" "+this.state.phone;
        }
      });
    }
    else{
      pre_code=this.state.phone;
    }
     return <Card>    
     <CardBody className={classes.cardBody}>
       <Grid container className={classes.GridContainer}>
              <GridItem xs={12} sm={12} md={12}>
                <Typography  variant="h4" gutterBottom className={classes.signTitle}>
                  Phone Verify
                </Typography>
                                         
                <Typography component="p">
                  Please enter the code sent to your phone {pre_code}
                </Typography> 
              </GridItem>
        </Grid>
       <Grid container justify="center" className={classes.GridContainer}>
         <Grid item xs={12} sm={12} md={12}>
         <br></br>
          <TextField
            error={this.state.verifyCode_error}
            id="outlined-name"
            label="Verify Code"
            InputLabelProps={{
                  classes: {
                    root: classes.cssLabel,
                    focused: classes.cssFocused,
                  },
                }}
                InputProps={{
                  classes: {
                    root: classes.cssOutlinedInput,
                    focused: classes.cssFocused,
                    //notchedOutline: classes.notchedOutline,                    
                  },
            }}
            className={classes.textField}
            value={this.state.verifyCode}
            onChange={this.handleChange('verifyCode')}
            margin="normal"
            fullWidth
          />
         </Grid>
         </Grid>
        </CardBody>
        <CardFooter className={classes.cardFooterBycustomer_1}>
            <Button onClick={() =>(this.submitVerifyCode())}                      
              variant="contained"
              color="secondary"             
            >Submit</Button>
            <Button         
            disabled={this.state.resend_btn}                                      
              onClick={()=>this.resendKey()}
            >          
            Resend
          </Button>   
        </CardFooter>
        </Card>

  }
  signup_body=()=>{
    const { localization, classes } = this.props;
    const {email, password, confirm_password,phone} = this.state;

    return <Card>    
      <CardBody className={classes.cardBody}>
      <Grid container className={classes.GridContainer}>
            <Grid item xs={12} sm={12} md={12}>
              <Typography  variant="h3" gutterBottom className={classes.signTitle}>
              {localization.localizedString('SIGNUP_FORM_TITLE')}
              <br/>
              </Typography>
                <Typography component="p">
                It's free and you will have access to all our features :-) Start accepting Dankort, MasterCard, VISA and PayPal in no time wthout any costs.
                </Typography>   
          </Grid>
      </Grid>
      <div className={classes.loginFormLayout}>
        <Grid container className={classes.GridContainer}>
          <Grid item xs={12} sm={12} md={12}>                        
            <TextField
               error={this.state.email_error}
                id="email"
                label={localization.localizedString('SIGNUP_EMAIL_LABEL')}
                InputLabelProps={{
                  required: true,
                      classes: {
                        root: classes.cssLabel,
                        focused: classes.cssFocused,
                      },
                    }}
                    InputProps={{
                      type: 'text',
                      classes: {
                        root: classes.cssOutlinedInput,
                        focused: classes.cssFocused,
                        underline: classes.cssUnderline,                    
                      },endAdornment: (
                        <InputAdornment position="end">
                          <Icon>
                            <EmailOutlined className={classes.inputIconsColor} />
                          </Icon>
                        </InputAdornment>
                      ),
                }}
                className={classes.textField}
                value={email}
                onChange={this.handleChange('email')}
                margin="normal"
                fullWidth
              />
          </Grid>
          </Grid>
        <Grid container className={classes.GridContainer}>
          <Grid item xs={12} sm={12} md={12}>                       
            <TextField
                error={this.state.password_error}
                id="password"
                label={localization.localizedString('SIGNUP_PASSWORD_LABEL')}
                InputLabelProps={{
                    required: true,
                      classes: {
                        root: classes.cssLabel,
                        focused: classes.cssFocused,
                      },
                    }}
                    InputProps={{
                      type: 'password',
                      classes: {
                        root: classes.cssOutlinedInput,
                        focused: classes.cssFocused,
                        underline: classes.cssUnderline,                    
                      },
                      endAdornment: (
                        <InputAdornment position="end">
                          <Icon>
                            <LockOutlined className={classes.inputIconsColor} />
                          </Icon>
                        </InputAdornment>
                      ),
                }}
                className={classes.textField}
                value={password}
                onChange={this.handleChange('password')}
                margin="normal"
                fullWidth
              />
          </Grid>
          </Grid>
        <Grid container className={classes.GridContainer}>
          <Grid item xs={12} sm={12} md={12}> 
             <TextField
                id="confirm_password"
                error={this.state.password_error}
                label={localization.localizedString('SIGNUP_CONFIRM_PASSWORD_LABEL')}
                InputLabelProps={{
                    required: true,
                      classes: {
                        root: classes.cssLabel,
                        focused: classes.cssFocused,
                      },
                    }}
                    InputProps={{
                      type: 'password',
                      classes: {
                        root: classes.cssOutlinedInput,
                        focused: classes.cssFocused,
                        underline: classes.cssUnderline,                    
                      },
                }}
                className={classes.textField}
                value={confirm_password}
                onChange={this.handleChange('confirm_password')}
                margin="normal"
                fullWidth
              />
          </Grid>
        </Grid>
        <Grid container className={classes.GridContainer2}>
            <Grid item xs={12} sm={12} md={12} >
            <Typography component="p" className={classes.PhoneLabel}>
              Business phone *
            </Typography>   
            <ReactPhoneInput 
                defaultCountry={'dk'} 
                onlyCountries={this.state.country}
                regions={'europe'}
                component={TextField}   
                onChange={this.handleOnChange}
                value={phone}
                countryCodeEditable={false}
                />
           </Grid>
        </Grid>
        </div>
      </CardBody>
      <CardFooter className={classes.cardFooterBycustomer_1}>
      <Grid item xs={12} sm={12} md={6} lg={6} xl={6}>                    
      <Button onClick={() =>(this.signUp())}       
        style={{fontSize: '0.875rem', fontWeight: '600'}}               
        variant="contained"
        color="secondary"                    
        className={classes.button}>Sign up</Button>  

      </Grid>
      <Grid item xs={12} sm={12} md={6} lg={6} xl={6}  style={{textAlign:'right'}}>
            <Link to="/login">
              BACK
            </Link>
          </Grid>
      </CardFooter>    
  </Card>
  }
  render() {
    const { localization, classes } = this.props;
   
    return (
      <div
        className={classes.pageHeader}
        style={{
          backgroundImage: `url(${bgImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'top center'
        }}
      >
        <div
          className={classes.containerSignup}
        >
          <GridContainer
          justify="center">
            <GridItem xs={12}>
              {this.cardBody()}
            </GridItem>
          </GridContainer>
        </div>
      </div>
    );
  }
}

export default withStyles(landingPageStyle)(withSnackbar(withLocalization(withAuth(SignupPage))));

