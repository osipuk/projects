import React from 'react';

import Link from 'react-router-dom/es/Link';

import withStyles from '@material-ui/core/styles/withStyles';
import InputAdornment from '@material-ui/core/InputAdornment';
import axios from 'axios';
import Grid from '@material-ui/core/Grid';
import {withSnackbar } from 'notistack';
import EmailOutlined from '@material-ui/icons/EmailOutlined';
import LockOutlined from '@material-ui/icons/LockOutlined';
import Checkbox from '@material-ui/core/Checkbox';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import withLocalization from 'common/contexts/LocalizationContext';
import withNotifications from 'common/contexts/NotificationsContext';
import withAuth from 'common/contexts/AuthContext';
import GridContainer from 'common/components/Grid/GridContainer';
import GridItem from 'common/components/Grid/GridItem';
import Card from 'common/components/Card/Card';
import CardBody from 'common/components/Card/CardBody';
import CardHeader from 'common/components/Card/CardHeader';
import CardFooter from 'common/components/Card/CardFooter';
import CustomInput from 'common/components/CustomInput/CustomInput';
import Success from '@material-ui/icons/CheckCircle';

import landingPageStyle from "../../p/assets/jss/views/landingPage";

import bgImage from '../assets/img/businessBg.jpg';
import Typography from '@material-ui/core/Typography';
import TextField from '@material-ui/core/TextField';

class Verify extends React.Component {
  state = {
    veryfied_stats:'Proccessing....',
    type:'company'
  };
  
  async componentWillMount  () {
    const {history,localization}=this.props;
    const {id}=this.props.match.params;    
    if(id!=''){
      var  {data} = await axios.get('/api/company/email_verify/'+id);
      if(data.success){
        this.props.enqueueSnackbar(localization.localizedString('EMAIL_VERYFIED_SUCCESS'), { 
          variant: 'success',
        }); 
        this.setState({veryfied_stats:'Email was veryfied successfully'});
        history.push('/');
      }
      else{       
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
        this.setState({veryfied_stats:'Invalid Registration Email Token.'});
      }
    }
    else{
      this.setState({veryfied_stats:'Invalid Registration Email Token.'});
    }
    
  }
 
  render() {
    const { localization, classes } = this.props;
   

    return (
      <div
        className={classes.pageHeader}
        style={{
          backgroundImage: `url(${bgImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'top center'
        }}
      >
        <div className={classes.containerSignup}>
          <GridContainer justify="center">
            <GridItem xs={12}>
              <Card>
                <form className={classes.form}>
                  <CardBody className={classes.cardBody}>
                  <Grid container className={classes.GridContainer}>
                        <Grid item xs={12} sm={12} md={12}>
                          <Typography  variant="h5" gutterBottom className={classes.signTitle}>
                          {this.state.veryfied_stats}
                          <br/>
                          </Typography>
                          <Typography component="p">                           
                          </Typography>   
                      </Grid>
                  </Grid>
                  <div className={classes.loginFormLayout}>  
                  </div>
                  </CardBody>
                  <CardFooter className={classes.cardFooterBycustomer_1}>  
                      <Grid item xs={12} sm={12} md={12} lg={12} xl={12}  style={{textAlign:'right'}}>
                        <Link to="/signup">
                          {localization.localizedString('LOGIN_CREATE_COMPANY_LINK')}
                        </Link>
                      </Grid>
                   
                  </CardFooter>
                </form>
              </Card>
            </GridItem>
          </GridContainer>
        </div>
      </div>
    );
  }
}

export default withStyles(landingPageStyle)(withSnackbar(withLocalization(withAuth(Verify))));
