import React from 'react';

import Link from 'react-router-dom/es/Link';

import withStyles from '@material-ui/core/styles/withStyles';
import InputAdornment from '@material-ui/core/InputAdornment';
import axios from 'axios';
import Grid from '@material-ui/core/Grid';
import {withSnackbar } from 'notistack';
import EmailOutlined from '@material-ui/icons/EmailOutlined';
import LockOutlined from '@material-ui/icons/LockOutlined';
import Checkbox from '@material-ui/core/Checkbox';
import Icon from '@material-ui/core/Icon';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Typography from '@material-ui/core/Typography';
import TextField from '@material-ui/core/TextField';
import Button from "@material-ui/core/Button";
import Success from '@material-ui/icons/CheckCircle';
import withLocalization from 'common/contexts/LocalizationContext';
import withNotifications from 'common/contexts/NotificationsContext';
import withAuth from 'common/contexts/AuthContext';
import GridContainer from 'common/components/Grid/GridContainer';
import GridItem from 'common/components/Grid/GridItem';
import Card from 'common/components/Card/Card';
import CardBody from 'common/components/Card/CardBody';
import CardHeader from 'common/components/Card/CardHeader';
import CardFooter from 'common/components/Card/CardFooter';
import CustomInput from 'common/components/CustomInput/CustomInput';
import landingPageStyle from "../../p/assets/jss/views/landingPage";

import bgImage from '../assets/img/businessBg.jpg';

class ResetPassword extends React.Component {
  state = {   
    type:'company',
    password:'',
    confirm_password:'',
    error1:false,
    error2:false,
   
  };
  
  async componentWillMount  () {
    const {history,localization}=this.props;
    const {id}=this.props.match.params;    

      var  {data} = await axios.get('/api/company/token_check/'+id);
      if(!data.success){  
        this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
          variant: 'error',
        }); 
        history.push('/');        
      }   
    
  }
  passwordSubmit=async()=>{
    const {localization,history}=this.props;
    const {password,confirm_password}=this.state;
    
    if(password==''){
      this.setState({error1:true});
      return;
    }
    if(confirm_password==''){
      this.setState({error2:true});
      return;
    }
    if(password!=confirm_password){
      this.props.enqueueSnackbar(localization.localizedString('NOT_MATCHED_PASSWORD'), { 
        variant: 'error',
      }); 
      this.setState({error2:true,error1:true});
     return;
    }
    var  {data} = await axios.post('/api/company/password_reset/'+this.props.match.params.id,
      {       
        password:password
     });  

     if(data.success){
      this.props.enqueueSnackbar(localization.localizedString('PASSWORD_RESET_SUCCESS'), { 
        variant: 'success',
      }); 
      history.push('/');
     }
     else{
      this.props.enqueueSnackbar(localization.localizedError(data.errorCode), { 
        variant: 'error',
      }); 
     }

  }
  handleChange = prop => event =>{
     if(this.state.password.length!=0){
       this.setState({error1:false});
     }
     if(this.state.confirm_password.length!=0){
      this.setState({error3:false});
    }
    this.setState({ [prop]: event.target.value });
  } 

  render() {
    const { localization, classes } = this.props;
    const {password,confirm_password,error1,error2}=this.state;

    return (
      <div
        className={classes.pageHeader}
        style={{
          backgroundImage: `url(${bgImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'top center'
        }}
      >
        <div className={classes.containerSignup}>
          <GridContainer justify="center">
            <GridItem xs={12}>
              <Card>
                <form className={classes.form}>
                <CardBody className={classes.cardBody}>
                  <Grid container className={classes.GridContainer}>
                        <Grid item xs={12} sm={12} md={12}>
                          <Typography  variant="h4" gutterBottom className={classes.signTitle}>
                           Change your password
                          <br/>
                          </Typography>
                            <Typography component="p">
                           
                            </Typography>   
                      </Grid>
                  </Grid>
                  <div className={classes.loginFormLayout}>
                    <Grid container className={classes.GridContainer}>
                      <Grid item xs={12} sm={12} md={12}>   
                    <TextField
                      id="password"
                      label={localization.localizedString('LOGIN_PASSWORD_LABEL')}
                      error={error1}
                      InputLabelProps={{
                        required: true,
                          classes: {
                            root: classes.cssLabel,
                            focused: classes.cssFocused,
                          },
                        }}
                        InputProps={{
                          type: 'password',
                          classes: {
                            root: classes.cssOutlinedInput,
                            focused: classes.cssFocused,
                            underline: classes.cssUnderline,                    
                          },
                          endAdornment: (
                            <InputAdornment position="end">
                              <Icon>
                                <LockOutlined className={classes.inputIconsColor} />
                              </Icon>
                            </InputAdornment>
                          ),
                    }}

                      className={classes.textField}
                      onChange={this.handleChange('password')}
                      value={password}
                      margin="normal"
                      fullWidth
                    />
                    </Grid>
                    </Grid>
                    <Grid container className={classes.GridContainer}>
                      <Grid item xs={12} sm={12} md={12}>  
                            <TextField
                               id="confirm_password"
                               error={error2}
                              label={localization.localizedString('SIGNUP_CONFIRM_PASSWORD_LABEL')}
                              InputLabelProps={{
                                required: true,
                                  classes: {
                                    root: classes.cssLabel,
                                    focused: classes.cssFocused,
                                  },
                                }}
                                InputProps={{
                                  type: 'password',
                                  classes: {
                                    root: classes.cssOutlinedInput,
                                    focused: classes.cssFocused,
                                    underline: classes.cssUnderline,                    
                                  },
                                  endAdornment: (
                                    <InputAdornment position="end">
                                      <Icon>
                                        <LockOutlined className={classes.inputIconsColor} />
                                      </Icon>
                                    </InputAdornment>
                                  ),
                            }}
                              value={confirm_password}
                              onChange={this.handleChange('confirm_password')}                             
                              className={classes.textField}
                              margin="normal"
                              fullWidth
                            />
                          </Grid>                         
                        <Grid  item xs={12} sm={12} md={12} style={{textAlign:'right'}}>
                          <Link to="/Login">
                            Already have login and password? Sign in
                          </Link>
                         
                          </Grid>
                      </Grid>

                      </div>
                    </CardBody>
                  <CardFooter className={classes.cardFooterBycustomer_1}>  
                      <Grid item xs={12} sm={12} md={12} lg={12} xl={12}  style={{textAlign:'left'}}>
                        <Button
                            variant="contained"
                            color="secondary"                       
                            className={classes.button}
                            onClick={this.passwordSubmit}
                            >
                            Change your password
                          </Button>
                      </Grid>
                   
                  </CardFooter>
                </form>
              </Card>
            </GridItem>
          </GridContainer>
        </div>
      </div>
    );
  }
}

export default withStyles(landingPageStyle)(withSnackbar(withLocalization(withAuth(ResetPassword))));
