import React from 'react';
import ReactDOM from 'react-dom';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';
import { SnackbarProvider, withSnackbar } from 'notistack';
import { HashRouter, Route, Switch } from 'react-router-dom';
import { LocalizationProvider } from 'common/contexts/LocalizationContext';
import { AuthProvider } from 'common/contexts/AuthContext';
import { NotificationsProvider } from 'common/contexts/NotificationsContext';
import { LoadingProvider } from 'common/contexts/LoadingContext';
import ProtectedRoute from 'common/containers/ProtectedRoute/ProtectedRoute';
import UserLoader from 'common/containers/UserLoader/UserLoader';
import Dashboard from './views/Dashboard';
import EmailVerify from './views/Verify';
import ResetPassword from './views/ResetPassword';
import Login from './views/Login';
import Signup from './views/Signup';

import { login, logout, signup } from './api/auth';
import { get } from './api/company';

import 'common/assets/css/material-react.css';

class App extends React.Component {
  state = {
    loading: true
  };

  onFinished = () => {
    this.setState({ loading: false });
  };

  render() {
    const { loading } = this.state;

    return (
      <HashRouter>
        <LocalizationProvider lang="en">
          
          <LoadingProvider>
            <AuthProvider
              login={login}
              logout={logout}
              signup={signup}
              get={get}
            >
            
              <NotificationsProvider>
                {loading ? (
                  <UserLoader onFinished={this.onFinished} />
                ) : (
                  <SnackbarProvider 
                        maxSnack={2}
                        action={[
                        <IconButton
                          key="close"
                          aria-label="Close"
                          color="inherit"                                              
                        >
                          <CloseIcon style={{fontSize:16}} />
                        </IconButton>,
                      ]}
                     >
                  <Switch>
                    <Route exact path="/password_reset/:id" component={ResetPassword} />           
                    <Route exact path="/email_verify/:id" component={EmailVerify} />
                    <Route exact path="/login" component={Login} />
                    <Route exact path="/signup" component={Signup} />
                    <ProtectedRoute path="/" component={Dashboard} loginURL="/login" />                    
                  </Switch>
                 </SnackbarProvider>
                 
                )}
              </NotificationsProvider>
             
            </AuthProvider>
          </LoadingProvider>
          
        </LocalizationProvider>
      </HashRouter>
    );
  }
}

ReactDOM.render(<App />, document.getElementById('root'));
