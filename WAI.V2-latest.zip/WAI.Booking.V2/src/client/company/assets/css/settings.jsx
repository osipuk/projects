//import { container } from '../../material-react';
//import customCheckboxRadioSwitch from '../customCheckboxRadioSwitch';

import {
  defaultFont,
  primaryColor,
  dangerColor,
  warningColor,
  successColor,
  infoColor,
  grayColor

} from "../../../common/assets/jss/material-react.jsx";

const settingPageStyle = {
  container: {
    //...container,
    zIndex: '2',
    position: 'relative',
    paddingTop: '20vh',
    color: '#FFFFFF'
  },
  cardHidden: {
    opacity: '0',
    transform: 'translate3d(0, -60px, 0)'
  },
  cardBody_1:{
    padding: '0.9375rem 47px !important'
  },
  pageHeader: {
    minHeight: '100vh',
    height: 'auto',
    display: 'inherit',
    position: 'relative',
    margin: '0',
    padding: '0',
    border: '0',
    alignItems: 'center',
    '&:before': {
      background: 'rgba(0, 0, 0, 0.5)'
    },
    '&:before,&:after': {
      position: 'absolute',
      zIndex: '1',
      width: '100%',
      height: '100%',
      display: 'block',
      left: '0',
      top: '0',
      content: '""'
    },
    '& footer li a,& footer li a:hover,& footer li a:active': {
      color: '#FFFFFF'
    },
    '& footer': {
      position: 'absolute',
      bottom: '0',
      width: '100%',
    }
  },
  form: {
    margin: '0'
  },
  cardHeader: {
    width: 'auto',
    textAlign: 'center',
    marginLeft: '20px',
    marginRight: '20px',
    marginTop: '-40px',
    padding: '20px 0',
    marginBottom: '15px'
  },
  socialIcons: {
    maxWidth: '24px',
    marginTop: '0',
    width: '100%',
    transform: 'none',
    left: '0',
    top: '0',
    height: '100%',
    lineHeight: '41px',
    fontSize: '20px'
  },
  divider: {
    marginTop: '30px',
    marginBottom: '0px',
    textAlign: 'center'
  },
  cardFooter: {
    paddingTop: '0rem',
    border: '0',
    borderRadius: '6px',
    justifyContent: 'flex-end !important',
    textAlign: 'center'
  },
  socialLine: {
    marginTop: '1rem',
    textAlign: 'center',
    padding: '0'
  },
  inputIconsColor: {
    color: '#495057'
  },
  formControl:{
    marginTop:'27px',
    width:'170px'
  },
  uncheckedIcon:{
    border:'1px solid  rgba(0,0,0,0.54)',
    borderRadius:'3px',
    padding:'9px',
    width:'20px',
    height:'20px'
  },
  checkedIcon:{
    border:'1px solid  rgba(0,0,0,0.54)',
    borderRadius:'3px',
    width:'20px',
    height:'20px'
  },
  customInput_4:{
    width:'100%'
  },
  label_1:{
    marginTop:0,
  },
  offline_label:{
    margin:'auto',
  },
  offline_margin:{
    marginTop:'40px !important'
  },
  online_bottom:{
    marginBottom:'30px !important'
  }, 
};

export default settingPageStyle;
