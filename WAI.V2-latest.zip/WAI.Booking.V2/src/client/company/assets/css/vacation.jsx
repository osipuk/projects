import {
  defaultFont,
  primaryColor,
  dangerColor,
  warningColor,
  successColor,
  infoColor,
  grayColor

} from "../../../common/assets/jss/material-react.jsx";

const vacationStyle =theme => ({

  container_1:{
    marginTop:'30px !important',
  },
  cardCategoryWhite: {
    "&,& a,& a:hover,& a:focus": {
      color: "rgba(255,255,255,.62)",
      margin: "0",
      fontSize: "14px",
      marginTop: "0",
      marginBottom: "0"
    },
    "& a,& a:hover,& a:focus": {
      color: "#FFFFFF"
    }
  },
  cardTitleWhite: {
    color: "#FFFFFF",
    marginTop: "0px",
    minHeight: "auto",
    fontWeight: "300",
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    marginBottom: "3px",
    textDecoration: "none",
    "& small": {
      color: "#777",
      fontSize: "65%",
      fontWeight: "400",
      lineHeight: "1"
    }
  },
  root: {
    width: '100%',
    marginTop: theme.spacing.unit * 3,
    overflowX: 'auto',
  },
  label_1:{
    marginTop:'20px',
    //textAlign:'center'
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 220,
    textAlign:'left',
    "& input": {
      textAlign:'left',
    }
  },
  customInput_1:{
    marginTop:'0px',
    minWidth: '100%',
  },
  grid_1:{
    margin:'auto',
    textAlign:'center'
  },
  saveChanges:{
    marginRight:'10px'
  },
  formControl_1: {
    margin: theme.spacing.unit,
    minWidth: 190,    
  },
  vacation_card_disable:{
    visibility:'hidden'
  },
  vacation_card_visible:{
    visibility:'visible'
  },
  tableHeader_2:{
    color:'#000000'
  },
  tableCellId:{
    width:'20px !important',
    padding: '4px 20px 4px 20px !important'
  },
  cardBody_1:{
    overflowX:'auto'
  },
  tableActionButton: {
    width: "27px",
    height: "27px",
    padding: "0"
  },
  edit: {
    backgroundColor: "transparent",
    color: '#525252',
    boxShadow: "none"
  },
  close: {
    backgroundColor: "transparent",
    color: dangerColor,
    boxShadow: "none"
  },
  create: {
    backgroundColor: "transparent",
    color: '#FFF',
    boxShadow: "none",
    width: "27px",
    height: "27px",
    padding: "0"
  },
  tableActionButton: {
    width: "27px",
    height: "27px",
    padding: "0"
  },
  header_2:{
    textAlign:'right',
    paddingRight: '15px',
    margin: 'auto'
  },
  dialog_2:{
    padding:'0px !important'
  },
  card_2:{
    marginBottom:'0px !important'
  },
  nothing_label:{
    textAlign:'center',
    marginTop:'15px'
  },
  nothing:{
     padding:'0px !important'
  },
  gray_title:{
    color:'#525252 !important'
  },
  dark_title:{
    color:'#000000 !important'
  },
  button_2:{
    marginLeft:'10px'
  },
  cardFooter:{
    padding: '20px 15px 20px 15px',
    backgroundColor:'#edf5f8',
    margin:'0px',
    borderTop: '1px solid #d0d7da'
  },
  cardFooter_1:{
    textAlign:'right'
  },
  formControl_5:{       
    marginBottom:'30px !important'
  },
});


export default vacationStyle;
