import {
  defaultFont,
  primaryColor,
  dangerColor,
  warningColor,
  successColor,
  infoColor,
  grayColor

} from "../../../common/assets/jss/material-react.jsx";

const customerStyle =theme => ({

 
  cardCategoryWhite: {
    "&,& a,& a:hover,& a:focus": {
      color: "rgba(255,255,255,.62)",
      margin: "0",
      fontSize: "14px",
      marginTop: "0",
      marginBottom: "0"
    },
    "& a,& a:hover,& a:focus": {
      color: "#FFFFFF"
    }
  },
  cardTitleWhite: {
    color: "#FFFFFF",
    marginTop: "0px",
    minHeight: "auto",
    fontWeight: "300",
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    marginBottom: "3px",
    textDecoration: "none",
    "& small": {
      color: "#777",
      fontSize: "65%",
      fontWeight: "400",
      lineHeight: "1"
    }
  },
  root: {
    width: '100%',
    marginTop: theme.spacing.unit * 3,
    overflowX: 'auto',
  },
  table: {
   // minWidth: 700,   
  },
  cardBody_1:{
    overflowX:'auto'
  },
  cardBody_2:{
    marginTop:'15px !important',
    //marginBottom:'0px !important'
  },
  tableCellId:{
    width:'20px !important',
    padding: '4px 20px 4px 20px !important'
  }, 
  tableHeader_1:{
    color:'#000000'
  },
  tableHeader_2:{
    color:successColor
  },
  tableCell:{
    //padding: '4px 17px 4px 17px !important'
  },
  tableCell_1:{
    width:'45px !important',
    "& input": {
      textAlign:'center !important',
    }  
  },
  edit: {
    backgroundColor: "transparent",
    color: '#0000008a',
    boxShadow: "none"
  },
  view:{
    backgroundColor: "transparent",
    color: infoColor,
    boxShadow: "none"
  },
  close: {
    backgroundColor: "transparent",
    color: dangerColor,
    boxShadow: "none"
  },
  create: {
    backgroundColor: "transparent",
    color: '#FFF',
    boxShadow: "none",
    width: "27px",
    height: "27px",
    padding: "0"
  },
tableActionButton: {
    width: "27px",
    height: "27px",
    padding: "0"
  },
  header_2:{
    textAlign:'right',
    paddingRight: '15px',
    margin: 'auto'
  },
  dialog_2:{
    padding:'0px !important'
  },
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 120,
    width:200,
    textAlign:'left !important',
   
  },  
  addButton:{
    marginTop:'30px',
    paddingLeft: '45px'
  },
  nothing_1:{
    textAlign:'center'
  },
  customInput:{
    width: '200px',
    marginTop:'35px'
  },
  customInput_1:{
    width: '100%',
    //marginTop:'25px'
    marginTop:'10px !important'
  },
  customInput_2:{
    width: '100%',
    //marginTop:'25px'
    marginTop:'1px !important'
  },
  container_2:{
    paddingLeft:'30px'
  },
  cardFooter_2:{
    justifyContent:'flex-end', 
  },
  dark_title:{
    color:'#000000 !important'
  },
  gray_title:{
    color:'#525252 !important'
  },
  cardFooter:{
    padding: '20px 15px 20px 15px',
    backgroundColor:'#edf5f8',
    margin:'0px',
    borderTop: '1px solid #d0d7da'
  },
  cardFooter_1:{
    textAlign:'right'
  },
});


export default customerStyle;
