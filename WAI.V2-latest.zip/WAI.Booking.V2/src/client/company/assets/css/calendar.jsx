import {
  defaultFont,
  primaryColor,
  dangerColor,
  warningColor,
  successColor,
  infoColor,
  grayColor

} from "../../../common/assets/jss/material-react.jsx";

const calendarStyle =theme => ({

 
  cardCategoryWhite: {
    "&,& a,& a:hover,& a:focus": {
      color: "rgba(255,255,255,.62)",
      margin: "0",
      fontSize: "14px",
      marginTop: "0",
      marginBottom: "0"
    },
    "& a,& a:hover,& a:focus": {
      color: "#FFFFFF"
    }
  },
  cardTitleWhite: {
    color: "#FFFFFF",
    marginTop: "0px",
    minHeight: "auto",
    fontWeight: "300",
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    marginBottom: "3px",
    textDecoration: "none",
    "& small": {
      color: "#777",
      fontSize: "65%",
      fontWeight: "400",
      lineHeight: "1"
    }
  },
  cardBody_1:{
    overflowX:'auto',
    marginTop:'10px'
   
  },
  dialog_2:{
    padding:'0px !important',
    paddingBottom:'30px !important'
  },

  root: {
    width: '100%',
    marginTop: theme.spacing.unit * 3,
    overflowX: 'auto',
  },
  table: {
   // minWidth: 700,   
  },
  
  card_2:{
    marginBottom:'0px !important'
  },
  tableCellId:{
    width:'20px !important',
    padding: '4px 20px 4px 20px !important'
  },
  tableCellId_1:{    
    padding: '4px 0px !important'
  },
  footerCommand_1:{
    textAlign:'right !important'
  },
  footerCommand_2:{
    paddingLeft:'20px',
    margin: 'auto'
  },
  tableHeader_1:{
    color:primaryColor
  },
  tableHeader_2:{
    color:'#000000'
  },
  tableCell:{
    //padding: '4px 17px 4px 17px !important'
  },
  edit: {
    backgroundColor: "transparent",
    color: '#525252 !important',
    boxShadow: "none"
  },
  view:{
    backgroundColor: "transparent",
    color: infoColor,
    boxShadow: "none"
  },
  close: {
    backgroundColor: "transparent",
    color: dangerColor,
    boxShadow: "none"
  },
  create: {
    backgroundColor: "transparent",
    color: '#FFF',
    boxShadow: "none",
    width: "27px",
    height: "27px",
    padding: "0"
  },
tableActionButton: {
    width: "27px",
    height: "27px",
    padding: "0"
  },
  header_2:{
    textAlign:'right',
    paddingRight: '15px',
    margin: 'auto'
  },
  
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 120,
    marginTop:'7px !important'
  },
  formControl_1: {
    //margin: theme.spacing.unit,
    minWidth: 200,    
  },

  service_card_disable:{
    visibility:'hidden'
  },
  service_card_visible:{
    visibility:'visible'
  },
  nothing_1:{
    textAlign:'center'
  },
  textFieldDate:{
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    minWidth:210,
    width: 240,
    marginTop:'5px'
  },
  timeTotextField:{
    paddingTop:'5px'
  },
  customInput_2:{
    margin:'8px 0 0 !important',
    paddingBottom:'5px',
    minWidth:'230px',
    width: '230px',
  },
  customInput_3:{
    margin:'20px 0 0 !important',
    paddingBottom:'0px',
  },
  customInput_4:{
    width: '280px',
    marginTop:'10px'
  },
  left_1:{
    textAlign:'left !important'
  },
  services_1:{
    textAlign:'left !important',
    paddingLeft: '25px',
    paddingTop:'13px'
  },
  created_1:{
    paddingTop:'15px !important'
  },
  addons_container:{
    justifyContent: 'left !important',
    padding: '0px 21px'
  },
  gridCell:{
    padding: '10px 0px !important',
  },
  gridCell_time:{
    padding: '10px 0px !important',
    textAlign:'center'
  },
  gridCell_Total:{
    paddingTop: '20px !important',
  },
  container_1:{
    padding:'0 20px',
  },
  container_2:{
    padding:'6px 20px 0px 20px',
  },
  span_1:{
    fontSize:'1rem',
    color:'#000 !important'
  },
  label_2:{
    color:'#484848'
  },
  cancelBtn: {
    backgroundColor: '#ff6000', 
    marginLeft: '15px',
    marginRight: '15px',
    boxShadow: '0px 1px 5px 0px rgba(0,0,0,0.2), 0px 2px 2px 0px rgba(0,0,0,0.14), 0px 3px 1px -2px rgba(0,0,0,0.12)',
    '&:hover,&:focus': {
      backgroundColor: 'rgb(226, 93, 13) !important',
    },
  },
  fixed_size_square: {
    display: 'table',
    height: '18px',
    paddingLeft: '10px',
    paddingRight: '10px',
    display: 'inline-block',
    marginRight: '10px',
    borderRadius: '5px',
  },
  fixed_size_square_span: {
      display: 'table-cell',
      textAlign: 'center',
      verticalAlign: 'middle',
      fontSize: '13px',
      fontWeight: '500',
      display: 'grid',
      lineHeight: '18px',
  },
  fixed_size_square_span_p: {
    display: 'inline-block',
    marginRight: '8px',
  },
  button_2:{
    padding:'3px 8px !important',
    fontSize:'0.67rem !important',
    marginRight:'10px'
  },
  gray_title:{
    color:'#525252 !important',
    padding: '0px 0px 0px 27px'
  },
  gray_title1:{
    color:'#525252 !important',    
  },
  dark_title:{
    color:'#000000 !important',
    padding: '0px 0px 0px 27px'
  },
  cardFooter:{
    padding: '20px 15px 20px 15px',
    backgroundColor:'#edf5f8',
    margin:'0px',
    borderTop: '1px solid #d0d7da'
  },
  cardFooter_1:{
    textAlign:'right'
  },
  dialog_3:{
    margin:'0px'
  },
  marginL_30:{
    marginLeft:'30px'
  }
});


export default calendarStyle;
