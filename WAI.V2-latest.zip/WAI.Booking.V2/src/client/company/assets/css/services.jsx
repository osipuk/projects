import {
  defaultFont,
  primaryColor,
  dangerColor,
  warningColor,
  successColor,
  infoColor,
  grayColor

} from "../../../common/assets/jss/material-react.jsx";

const servicesStyle =theme => ({

  container_1:{
    marginTop:'30px !important',
  },
  cardCategoryWhite: {
    "&,& a,& a:hover,& a:focus": {
      color: "rgba(255,255,255,.62)",
      margin: "0",
      fontSize: "14px",
      marginTop: "0",
      marginBottom: "0"
    },
    "& a,& a:hover,& a:focus": {
      color: "#FFFFFF"
    }
  },
  cardTitleWhite: {
    color: "#FFFFFF",
    marginTop: "0px",
    minHeight: "auto",
    fontWeight: "300",
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    marginBottom: "3px",
    textDecoration: "none",
    "& small": {
      color: "#777",
      fontSize: "65%",
      fontWeight: "400",
      lineHeight: "1"
    }
  },
  root: {
    width: '100%',
    marginTop: theme.spacing.unit * 3,
    overflowX: 'auto',
  },
  table: {
   // minWidth: 700,   
  },
  cardBody_1:{
    overflowX:'auto',
    width:'100%',
    paddingBottom:'10px'
   
  },
  card_2:{
    marginBottom:'0px !important',
    marginTop:'0px !important'
  },
  tableCellId:{
    width:'20px !important',
    padding: '4px 20px 4px 20px !important'
  },
  tableCell_2:{
    width:'245px !important',
    //padding: '4px 20px 4px 20px !important'
  },
  tableHeader_1:{
    color:primaryColor
  },
  tableHeader_2:{
    color:successColor
  },
  tableHeader_3:{
    color:successColor,
    padding: '4px 48px 4px 28px !important'
  },
  tableCell:{
    //padding: '4px 17px 4px 17px !important'
  },
  edit: {
    backgroundColor: "transparent",
    color: '#0000008a',
    boxShadow: "none"
  },
  view:{
    backgroundColor: "transparent",
    color: infoColor,
    boxShadow: "none"
  },
  close: {
    backgroundColor: "transparent",
    color: dangerColor,
    boxShadow: "none"
  },
  create: {
    backgroundColor: "transparent",
    color: '#106cc8',
    boxShadow: "none",
    width: "30px",
    height: "30px",
    padding: "0"
  },
tableActionButton: {
    width: "27px",
    height: "27px",
    padding: "0",
    marginTop: '-10px'
  },
  header_2:{
    textAlign:'right',
    paddingRight: '15px',
    margin: 'auto'
  },
  dialog_2:{
    padding:'0px !important'
  },
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 120,
    marginTop:'25px !important',
    maxWidth: 250,
  },
  formControl_1: {
    margin: theme.spacing.unit,
    minWidth: 220,    
  },
  formControl_2:{
    minWidth: 210, 
    maxWidth:230,   
  },
  formControl_3: {
    margin: '0px',
    minWidth: 120,   
    maxWidth: 150,
  },
  formControl_5:{    
    minWidth: 130,
    marginTop:'15px !important',
    maxWidth: 250,
    marginBottom:'30px !important'
  },
  formControl_6:{    
    minWidth: 250,
   // marginTop:'35px !important',
    maxWidth: 250,    
  },
  formControl_7:{    
    minWidth: 180,
    marginTop:'20px !important',
    maxWidth: 180,
    marginBottom:'30px !important'
  },
  formControl_8:{
    minWidth: 210, 
    maxWidth:230,  
    marginBottom:'25px !important',
    marginTop:'20px !important'
  },
  gray_title:{
    color:'#525252 !important',
    padding: '0px 0px 0px 27px'
  },
  dark_title:{
    color:'#000000 !important',
    padding: '0px 0px 0px 27px'
  },
  service_card_disable:{
    visibility:'hidden'
  },
  service_card_visible:{
    visibility:'visible'
  },
  nothing_1:{
    textAlign:'center'
  },
  selectedLabel:{
    marginLeft:'10px'
  },
  grid_title:{
    display:'flex'
  },
  canvary_1:{
    margin: 'auto',
    paddingTop: '25px',
    paddingLeft: '13px'
  },
  active:{
    margin: 'auto',
    paddingTop: '25px',
    paddingLeft: '25px',
    marginBottom:'30px !important',
    marginTop:'10px !important'
  },
  summary_2:{
    backgroundColor:'#fbe0ea'
  },
  title_3:{
   margin: 'auto 30px'
  },
  title_4:{
    margin: 'auto 30px',
    color:'#e10050'
  },
  cardFooter:{
    padding: '20px 15px 20px 15px',
    backgroundColor:'#edf5f8',
    margin:'0px',
    borderTop: '1px solid #d0d7da'
  },
  cardFooter_1:{
    textAlign:'right'
  },
  dialog_3:{
    margin:'0px'
  },
  button_2:{
    marginRight:'10px'
  },
  dialog_title:{
    paddingLeft: '41px',   
  },
  select_font:{
    fontSize:'0.78rem',
    color:'#525252 !important',
  },
  cardBody_12:{   
    marginTop:'10px',
    width:'100%'   
  },
  check_2:{
    marginTop:'10px',   
  },
  check_3:{
    marginTop:'15px',
    marginBottom:'15px'
  },
  formControl2:{
    marginTop:'10px !important'
  }
});


export default servicesStyle;
