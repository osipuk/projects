import {
  defaultFont,
  primaryColor,
  dangerColor,
  warningColor,
  successColor,
  infoColor,
  grayColor

} from "../../../common/assets/jss/material-react.jsx";

const openHoursStyle =theme => ({

  container_1:{
    marginTop:'30px !important',
  },
  cardCategoryWhite: {
    "&,& a,& a:hover,& a:focus": {
      color: "rgba(255,255,255,.62)",
      margin: "0",
      fontSize: "14px",
      marginTop: "0",
      marginBottom: "0"
    },
    "& a,& a:hover,& a:focus": {
      color: "#FFFFFF"
    }
  },
  cardTitleWhite: {
    color: "#FFFFFF",
    marginTop: "0px",
    minHeight: "auto",
    fontWeight: "300",
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    marginBottom: "3px",
    textDecoration: "none",
    "& small": {
      color: "#777",
      fontSize: "65%",
      fontWeight: "400",
      lineHeight: "1"
    }
  },
  root: {
    width: '100%',
    marginTop: theme.spacing.unit * 3,
    overflowX: 'auto',
  },
  tableHeader_1:{
    color:'#000000'
  },
  tableHeader_2:{
    color:'#000000'
  },
  table: {
   // minWidth: 700,   
  },
  cardBody_1:{
    overflowX:'auto'
  },
  card_2:{
    marginBottom:'0px !important'
  },
  tableCellId:{
    width:'20px !important',
    padding: '4px 20px 4px 20px !important'
  },
  tableCell:{
    //padding: '4px 17px 4px 17px !important'
  },
  tableCellId_2:{
    '&:hover,&:focus': {
      cursor:'pointer'
    },
  },
  edit: {
    backgroundColor: "transparent",
    color: '#0000008a',
    boxShadow: "none"
  },
  view:{
    backgroundColor: "transparent",
    color: infoColor,
    boxShadow: "none"
  },
  close: {
    backgroundColor: "transparent",
    color: dangerColor,
    boxShadow: "none"
  },
  create: {
    backgroundColor: "transparent",
    color: '#FFF',
    boxShadow: "none",
    width: "27px",
    height: "27px",
    padding: "0"
  },
  tableActionButton: {
    width: "27px",
    height: "27px",
    padding: "0",
    marginTop: '-10px'
  },
  header_2:{
    textAlign:'right',
    paddingRight: '15px',
    margin: 'auto'
  },
  nothing_1:{
    textAlign:'center'
  },
  dialog_2:{
    padding:'0px !important'
  },
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 120,
    marginTop:'27px !important'
  },
  formControl_1: {
    margin: theme.spacing.unit,
    minWidth: 180,    
  },
  service_card_disable:{
    visibility:'hidden'
  },
  service_card_visible:{
    visibility:'visible'
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 130,
    textAlign:'center',
    "& input": {
      textAlign:'center',
    }
  },
  gray_title:{
    color:'#525252 !important'
  },
  button_1:{
    color:'#424242'
  },
  button_2:{
    marginLeft:'10px'
  },
  dialog_3:{
    margin:'0px'
  },
  cardFooter:{
    padding: '20px 15px 20px 15px',
    backgroundColor:'#edf5f8',
    margin:'0px',
    borderTop: '1px solid #d0d7da'
  },
  cardFooter_1:{
    textAlign:'right'
  },
  formControl_5:{       
    marginBottom:'30px !important'
  },
  formControl_6:{
    minWidth: 120,
    width:150
  }
});


export default openHoursStyle;
