import {
  defaultFont,
  primaryColor,
  dangerColor,
  warningColor,
  successColor,
  infoColor,
  grayColor

} from "../../../common/assets/jss/material-react.jsx";

const createbookingStyle =theme => ({

  container_1:{
    marginTop:'30px !important',
  },
  cardCategoryWhite: {
    "&,& a,& a:hover,& a:focus": {
      color: "rgba(255,255,255,.62)",
      margin: "0",
      fontSize: "14px",
      marginTop: "0",
      marginBottom: "0"
    },
    "& a,& a:hover,& a:focus": {
      color: "#FFFFFF"
    }
  },
  cardTitleWhite: {
    color: "#FFFFFF",
    marginTop: "0px",
    minHeight: "auto",
    fontWeight: "300",
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    marginBottom: "3px",
    textDecoration: "none",
    "& small": {
      color: "#777",
      fontSize: "65%",
      fontWeight: "400",
      lineHeight: "1"
    }
  },
  root: {
    width: '100%',
    marginTop: theme.spacing.unit * 3,
    overflowX: 'auto',
  },
  table: {
    minWidth: 700,   
  },
  /**
  cardBody_1:{
    overflowX:'auto',
    width:'100%',
    paddingBottom:'10px'
   
  }, */
  card_2:{
    marginBottom:'0px !important',
    marginTop:'0px !important'
  },
  tableCellId:{
    width:'20px !important',
    padding: '4px 20px 4px 20px !important'
  },
  tableCell_2:{
    width:'245px !important',
    //padding: '4px 20px 4px 20px !important'
  },
  tableHeader_1:{
    color:primaryColor
  },
  tableHeader_2:{
    color:successColor
  },
  tableHeader_3:{
    color:successColor,
    padding: '4px 48px 4px 28px !important'
  },
  tableCell:{
    //padding: '4px 17px 4px 17px !important'
  },
  edit: {
    backgroundColor: "transparent",
    color: '#0000008a',
    boxShadow: "none"
  },
  view:{
    backgroundColor: "transparent",
    color: infoColor,
    boxShadow: "none"
  },
  close: {
    backgroundColor: "transparent",
    color: dangerColor,
    boxShadow: "none"
  },
  create: {
    backgroundColor: "transparent",
    color: '#106cc8',
    boxShadow: "none",
    width: "30px",
    height: "30px",
    padding: "0"
  },
tableActionButton: {
    width: "27px",
    height: "27px",
    padding: "0",
    marginTop: '-10px'
  },
  header_2:{
    textAlign:'right',
    paddingRight: '15px',
    margin: 'auto'
  },
  dialog_2:{
    padding:'0px !important'
  },
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 140,
     marginTop:'25px !important',
    maxWidth: 250,
  },
  formControl_1: {
    margin: theme.spacing.unit,
    minWidth: 220,
    maxWidth: 250,    
    marginTop:'20px !important',
  },
  formControl_2: {
    margin: theme.spacing.unit,
    minWidth: 220,
    maxWidth: 250,    
    marginTop:'27px !important',
  },
  gray_title:{
    color:'#525252 !important'
  },
  dark_title:{
    color:'#000000 !important'
  },
  service_card_disable:{
    visibility:'hidden'
  },
  service_card_visible:{
    visibility:'visible'
  },
  nothing_1:{
    textAlign:'center'
  },
  selectedLabel:{
    marginLeft:'10px'
  },
  grid_title:{
    display:'flex'
  },
  canvary_1:{
    margin: 'auto',
    paddingTop: '25px',
    paddingLeft: '13px'
  },
  summary_2:{
    backgroundColor:'#fbe0ea'
  },
  title_3:{
   margin: 'auto 30px'
  },
  title_4:{
    margin: 'auto 30px',
    color:'#e10050'
  },
  cardFooter:{
    padding: '20px 15px 20px 15px',
    backgroundColor:'#edf5f8',
    margin:'0px',
    borderTop: '1px solid #d0d7da',
    marginTop:'30px'
  },
  cardFooter_1:{
    textAlign:'right'
  },
  dialog_3:{
    margin:'0px'
  },
  button_2:{
    marginRight:'10px'
  },
  dialog_title:{
    paddingLeft: '41px'
  },
  root_summary: {
    minHeight: '45px !important',
    flexGrow: '1 !important',
    padding: '0px 0px 0 20px !important',
    backgroundColor:'#e5e5e5',
    boxShadow: '0 4px 20px 0px rgba(255, 255, 255, 0), 0 7px 10px -5px rgb(229, 229, 229)',
  },
  detail_3:{
    margin:'auto',    
  },
  detail_2:{
    marginTop: '15px',
    flexGrow:'1 !important',
    flexBasis:'100% !important',
  },
  cardBody_1:{
    overflowX:'auto'
  },
  detail_1: {
    display:'block !important',
    paddingTop:'0px',
    
  },
  button11: {
    fontSize: '16px',
    textTransform: 'capitalize',
    boxShadow: '0px 1px 5px 0px rgba(0, 0, 0, 0), 0px 2px 2px 0px rgba(0, 0, 0, 0), 0px 3px 1px -2px rgba(0, 0, 0, 0)',
    '&:hover': {
      backgroundColor: '#f50057',
      color: '#FFF',
    },
  },
  addon_2:{
    margin:'auto',
    textAlign:'right !important',    
  },
  dialog_1:{
    padding:'0px !important'
  },
  GridContainer:{
    padding: '5px 0px !important'
  },
  formControl_employee: {
    // margin: theme.spacing.unit,
     minWidth: 160,   
     width: '240px',
   },
   button_back:{
    marginRight:'15px'
  },
  
  calander_1:{
    boxShadow:'0 8px 30px 0 rgba(16, 36, 94, 0.2)'
  },
  calander_2:{
    borderRight: '1px solid #0000001f',
    margin:'auto',
    textAlign:'center !important'
  },
  time_2:{
    textAlign:'center',
    //height:'50%',
    borderBottom:'1px solid  #0000001f',
    padding:'25px'

  },
  time_3:{
    textAlign:'center',
    paddingLeft:'29px',
   // padding:'25px'
  },
  time_4:{
   // margin:'auto'
  },
  time_hidden:{
    visibility:'hidden'
  },
  time_visible:{
    visibility:'visible'
  },
  timBoxes:{
    listStyleType:'none',  
    padding: '15px 0 0 0',
    margin: '0',
    fontSize: '13px',
    fontWeight: 'bold',
    '& li':{
      textAlign: 'center',
        width: '57px',
        margin: '0 auto 5px auto',
        backgroundColor: '#fafafa',
        borderRadius: '3px',
        border: '1px solid #3d424533',
        padding: '5px 0',
        lineHeight: 1,
        cursor: 'pointer',
        color: '#7f8182',
        float: 'left',
       marginRight: '5px',
       '&:hover,&:focus,&:active,&:visited':{
        backgroundColor: '#eae9e8'
       }
    }
  },
  time_item:{
    backgroundColor: '#dedcdb !important'
  },
  confirm_1:{
    margin:'auto',
    textAlign:'center !important'
  },
  addon_1:{
    marginBottom:'16px !important',
   // marginTop: '10px'
  },
});


export default createbookingStyle;
