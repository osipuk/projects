import {
  defaultFont,
  primaryColor,
  dangerColor,
  warningColor,
  successColor,
  infoColor,
  grayColor

} from "../../../common/assets/jss/material-react.jsx";

const imagesStyle =theme => ({

 
  cardCategoryWhite: {
    "&,& a,& a:hover,& a:focus": {
      color: "rgba(255,255,255,.62)",
      margin: "0",
      fontSize: "14px",
      marginTop: "0",
      marginBottom: "0"
    },
    "& a,& a:hover,& a:focus": {
      color: "#FFFFFF"
    }
  },
  cardTitleWhite: {
    color: "#FFFFFF",
    marginTop: "0px",
    minHeight: "auto",
    fontWeight: "300",
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    marginBottom: "3px",
    textDecoration: "none",
    "& small": {
      color: "#777",
      fontSize: "65%",
      fontWeight: "400",
      lineHeight: "1"
    }
  },
  root: {
    width: '100%',
    marginTop: theme.spacing.unit * 3,
    overflowX: 'auto',
  },
  table: {
   // minWidth: 700,   
  },
  cardBody_1:{
    overflowX:'auto'
  },
  card_2:{
    marginBottom:'0px !important'
  },
  tableCellId:{
    width:'20px !important',
    padding: '4px 20px 4px 20px !important'
  },
  tableCell_2:{
    width:'245px !important',
    //padding: '4px 20px 4px 20px !important'
  },
  tableHeader_1:{
    color:primaryColor
  },
  tableHeader_2:{
    color:successColor
  },
  tableHeader_3:{
    color:successColor,
    padding: '4px 48px 4px 28px !important'
  },
  tableCell:{
    //padding: '4px 17px 4px 17px !important'
  },
  edit: {
    backgroundColor: "transparent",
    color: infoColor,
    boxShadow: "none"
  },
  view:{
    backgroundColor: "transparent",
    color: infoColor,
    boxShadow: "none"
  },
  close: {
    backgroundColor: "transparent",
    color: dangerColor,
    boxShadow: "none"
  },
  create: {
    backgroundColor: "transparent",
    color: '#FFF',
    boxShadow: "none",
    width: "27px",
    height: "27px",
    padding: "0"
  },
tableActionButton: {
    width: "27px",
    height: "27px",
    padding: "0"
  },
  header_2:{
    textAlign:'right',
    paddingRight: '15px',
    margin: 'auto'
  },
  dialog_2:{
    padding:'0px !important'
  },
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 120,
    marginTop:'27px !important'
  },
  formControl_1: {
    margin: theme.spacing.unit,
    minWidth: 180,    
  },
  service_card_disable:{
    visibility:'hidden'
  },
  service_card_visible:{
    visibility:'visible'
  },
  nothing_1:{
    textAlign:'center'
  },
  gridList:{
    minHeight:'120px'
  },
  tess: {
    border:'0.3px solid #000000 !important',

  },
  thms: {     
    display: 'block',    
    '&:hover,&:focus': {     
     transform: 'scale(1.05) !important',
     transition: '-ms-transform 450ms cubic-bezier(0.645, 0.045, 0.355, 1) 0s, -webkit-transform 450ms cubic-bezier(0.645, 0.045, 0.355, 1) 0s, transform 450ms cubic-bezier(0.645, 0.045, 0.355, 1) 0s !important',
     zIndex:99,
     cursor:'pointer'
   },    
 }, 
 thms1: { 
   cursor:'pointer'  
},
 item_img11: {
  width:'100% !important',
  height: '100% !important',
},
profile_images: {
  fontWeight: '400 !important',
  fontSize: '0.94rem !important',
  background:
  'linear-gradient(to top, rgba(0,0,0,0.7) 0%, ' +
  'rgba(0,0,0,0.3) 70%, rgba(0,0,0,0) 100%)',
},
});


export default imagesStyle;
