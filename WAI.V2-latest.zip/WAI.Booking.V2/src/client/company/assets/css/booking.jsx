import {
  defaultFont,
  primaryColor,
  dangerColor,
  warningColor,
  successColor,
  infoColor,
  grayColor

} from "../../../common/assets/jss/material-react.jsx";
import { fade } from '@material-ui/core/styles/colorManipulator';

const bookingStyle =theme => ({

 
  cardCategoryWhite: {
    "&,& a,& a:hover,& a:focus": {
      color: "rgba(255,255,255,.62)",
      margin: "0",
      fontSize: "14px",
      marginTop: "0",
      marginBottom: "0"
    },
    "& a,& a:hover,& a:focus": {
      color: "#FFFFFF"
    }
  },
  cardTitleWhite: {
    color: "#FFFFFF",
    marginTop: "0px",
    minHeight: "auto",
    fontWeight: "300",
    fontFamily: "'Roboto', 'Helvetica', 'Arial', sans-serif",
    marginBottom: "3px",
    textDecoration: "none",
    "& small": {
      color: "#777",
      fontSize: "65%",
      fontWeight: "400",
      lineHeight: "1"
    }
  },
  cardBody_1:{
    overflowX:'auto',
    marginTop:'10px',
    width:'100%'  
  },
  cardBody_12:{   
    marginTop:'10px',
    width:'100%'   
  },
  dialog_2:{
    padding:'0px !important'
  },

  root: {
    width: '100%',
    marginTop: theme.spacing.unit * 3,
    overflowX: 'auto',
  },  
  card_2:{
    marginBottom:'0px !important'
  },
  tableCellId:{
    width:'20px !important',
    padding: '4px 20px 4px 20px !important'
  },
  tableCellId_1:{    
    padding: '4px 0px !important'
  },
  footerCommand_1:{
    textAlign:'right !important'
  },
  footerCommand_2:{
    paddingLeft:'20px',
    margin: 'auto'
  },
  tableHeader_1:{
    color:'#000000',
    padding: '4px 20px 4px 24px; !important'
  },
  tableHeader_2:{
    color:'#000000'
  },
  tableCell:{
   padding: '4px 20px 4px 20px !important'
  },
  accept: {
    backgroundColor: "transparent",
    color: infoColor,
    boxShadow: "none"
  },
  edit:{
    backgroundColor: "transparent",
    color: '#0000008a',
    boxShadow: "none"
  },
  close: {
    backgroundColor: "transparent",
    color: dangerColor,
    boxShadow: "none"
  },
  create: {
    backgroundColor: "transparent",
    color: '#FFF',
    boxShadow: "none",
    width: "27px",
    height: "27px",
    padding: "0"
  },
tableActionButton: {
    width: "27px",
    height: "27px",
    padding: "0"
  },
  header_2:{
    textAlign:'right',
    paddingRight: '15px',
    margin: 'auto'
  },
  
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 120,
    marginTop:'7px !important'
  },
  formControl_1: {
    //margin: theme.spacing.unit,
    minWidth: 200,    
  },
  service_card_disable:{
    visibility:'hidden'
  },
  service_card_visible:{
    visibility:'visible'
  },
  nothing_1:{
    textAlign:'center'
  },
  textFieldDate:{
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    minWidth:210,
    width: 220,
    marginTop:'5px'
  },
  timeTotextField:{
    paddingTop:'5px'
  },
  customInput_2:{
    margin:'8px 0 0 !important',
    paddingBottom:'5px',
    minWidth:'230px',
    width: '230px',
  },
  customInput_3:{
    margin:'20px 0 0 !important',
    paddingBottom:'0px',
  },
  customInput_4:{
    width: '280px',
    marginTop:'10px'
  },
  left_1:{
    textAlign:'left !important'
  },
  services_1:{
    textAlign:'left !important',
    paddingLeft: '25px',
    paddingTop:'13px'
  },
  created_1:{
    paddingTop:'15px !important'
  },
  addons_container:{
    justifyContent: 'left !important',
    padding: '0px 21px'
  },
  gridCell:{
    padding: '10px 0px !important',
  },
  gridCell_time:{
    padding: '10px 0px !important',
    textAlign:'center'
  },
  gridCell_Total:{
    paddingTop: '20px !important',
  },
  container_1:{
    padding:'0 20px',
  },
  container_2:{
    padding:'6px 20px 0px 20px',
  },
  span_1:{
    fontSize:'1rem',
    color:'#000 !important'
  },
  label_2:{
    color:'#484848'
  },
  searchIcon: {
    //width: theme.spacing.unit * 9,
    width:'auto',
    height: '100%',
    position: 'absolute',
    //pointerEvents: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    '&:hover': {
     cursor:'pointer'
    },
  },
  search: {
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
   // backgroundColor: fade(theme.palette.common.white, 0.15),
  //  '&:hover': {
  //    backgroundColor: fade(theme.palette.common.white, 0.25),
  //  },
    marginLeft: 0,
    width: 'auto',
    [theme.breakpoints.up('sm')]: {
      marginLeft: theme.spacing.unit,
      width: 'auto',
    },
  },
  inputRoot: {
    color: 'inherit',
    width: '100%',
  },
  inputInput: {
    paddingTop: theme.spacing.unit,
    //paddingRight: theme.spacing.unit,
    paddingBottom: theme.spacing.unit,
    paddingLeft: theme.spacing.unit * 4,
    //transition: theme.transitions.create('width'),
    width: '100%',
    fontSize:'0.75rem'
/**
    [theme.breakpoints.up('sm')]: {
      width: 120,
      '&:focus': {
        width: 200,
      },
    },**/

    
  },
  itemSize:{
    fontSize:'0.75rem',
    color:'#000000'
  },
  inputLabel:{
    '& label': {
      fontSize:'0.75rem',
    color:'#000000'
    },
  },
  button_2:{
    padding:'3px 8px !important',
    fontSize:'0.67rem !important',
    marginRight:'10px'
  },
  button_3:{
    padding:'3px 8px !important',
    fontSize:'0.67rem !important',
   
  },
  dark_title:{
    color:'#000000 !important'
  },
  gray_title:{
    color:'#525252 !important'
  },
  dialog_3:{
    margin:'0px'
  },
  cardFooter:{
    padding: '20px 15px 20px 15px',
    backgroundColor:'#edf5f8',
    margin:'0px',
    borderTop: '1px solid #d0d7da'
  },
  cardFooter_1:{
    textAlign:'right'
  },
});


export default bookingStyle;
