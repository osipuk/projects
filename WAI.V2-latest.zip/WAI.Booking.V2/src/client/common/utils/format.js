const format = (str, ...args) => {
  let res = str;
  for (let i = 0; i < args.length; i++) {
    res = res.replace(new RegExp(`\\{${i}\\}`, 'g'), args[i]);
  }

  return res;
};

export default format;
