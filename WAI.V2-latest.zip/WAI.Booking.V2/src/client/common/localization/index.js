import moment from 'moment';
import numeral from 'numeral';
import 'numeral/locales';

import format from '../utils/format';

import en from './en';
import da from './da';

const localizedStringsMap = {
  en,
  da
};

if (!numeral.locales.da) {
  numeral.register('locale', 'da', numeral.locales['da-dk']);
}

export const langOrDef = lang => ((lang in localizedStringsMap) ? lang : 'en');

export default (lang) => {
  const l = langOrDef(lang);

  return {
    localizedDate: (...args) => moment(...args).locale(l),
    localizedNumber: (...args) => {
      numeral.locale(l);
      return numeral(...args);
    },
    localizedString: (str, ...args) => format(localizedStringsMap[l][str], ...args),
    localizedError: (code, ...args) => format(localizedStringsMap[l].ERROR_CODES[code], ...args)
  };
};
