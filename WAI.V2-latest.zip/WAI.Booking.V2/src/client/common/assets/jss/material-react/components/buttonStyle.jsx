import {
  grayColor,
  primaryColor,
  infoColor,
  successColor,
  warningColor,
  dangerColor,
  roseColor
} from '../../material-react';

const buttonStyle = {
  button: {
    color: '#FFF',
    fontSize: '16px',
    fontWeight: '500',
    borderRadius: '4px',
    textTransform: 'capitalize',
    minWidth: '64px',
    fontFamily: 'Roboto, Helvetica, Arial, sans-serif',
    minHeight: '36px',
    transition: 'background-color 250ms cubic-bezier(0.4, 0, 0.2, 1) 0ms,box-shadow 250ms cubic-bezier(0.4, 0, 0.2, 1) 0ms,border 250ms cubic-bezier(0.4, 0, 0.2, 1) 0ms',
    boxSizing: 'border-box',
    padding: '8px 16px',
  },
  primary: {
    backgroundColor: primaryColor,
    '&:hover,&:focus': {
      backgroundColor: '#4c4c4c',
    },
  },
  success: {
    backgroundColor: '#000',
  },
  danger: {
    backgroundColor: '#ff6000', 
    '&:hover,&:focus': {
      backgroundColor: 'rgb(226, 93, 13) !important',
    },
  },
};

export default buttonStyle;
