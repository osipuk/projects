import React from 'react';
import { Route, Redirect } from 'react-router-dom';

import withAuth from '../../contexts/AuthContext';

const ProtectedRoute = ({
  component: Component, loginURL, auth,history, ...rest
}) => (
  <Route
    render={({ ...props }) => {

      if(auth.isAuth){
        console.log(auth,'that is the auth');
        if(auth.user.phoneVeryfied==0 || auth.user.phone_veryfied==0){
           return  <Redirect exact to={'/signup'} />
        }
        else{
          return <Component {...props}  />
        }
      }
      else{
        return <Redirect exact to={loginURL} />
      }
        
    }}
    {...rest}
  />
);

export default withAuth(ProtectedRoute);
