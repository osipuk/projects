import React from 'react';
import PropTypes from 'prop-types';

import withStyles from '@material-ui/core/styles/withStyles';

import CircularProgress from '@material-ui/core/CircularProgress';

import withAuth from 'common/contexts/AuthContext';

const styles = {
  progress: {
    position: 'fixed',
    top: '50%',
    left: '50%',
    marginTop: '-20',
    marginLeft: '-20'
  }
};

class UserLoader extends React.Component {
  static propTypes = {
    classes: PropTypes.object.isRequired
  };

  async componentDidMount() {
    const { auth, onFinished } = this.props;   
    await auth.get();

    onFinished();
  }

  render() {
    const { classes } = this.props;

    return (
      <CircularProgress className={classes.progress} />
    );
  }
}

export default withStyles(styles)(withAuth(UserLoader));
