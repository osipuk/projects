import React from 'react';

import withAuth from '../../contexts/AuthContext';
import withLoading from '../../contexts/LoadingContext';
import withLocalization from '../../contexts/LocalizationContext';
import withNotifications from '../../contexts/NotificationsContext';

import Button from '../../components/CustomButtons/Button';

const LogoutButton = ({
  auth, localization, notifications, loading, ...rest
}) => (
  <Button
    onClick={async () => {
      notifications.hide();
      loading.show();

      try {
        const result = await auth.logout();
        if (!result.success) {
          notifications.show(localization.localizedError(result.errorCode));
        }
      } finally {
        loading.hide();
      }
    }}
    {...rest}
  >
    {localization.localizedString('LOGOUT_BTN_TITLE')}
  </Button>
);

export default withLoading(withNotifications(withLocalization(withAuth(LogoutButton))));
