import React from 'react';
import PropTypes from 'prop-types';

import withAuth from '../../contexts/AuthContext';
import withLoading from '../../contexts/LoadingContext';
import withLocalization from '../../contexts/LocalizationContext';
import withNotifications from '../../contexts/NotificationsContext';

import Button from "@material-ui/core/Button";

const LoginButton = ({
  auth, localization, notifications, loading, userData,props, ...rest
}) => (
  <Button
  style={{fontSize: '0.875rem', fontWeight: '600'}}
    onClick={async () => {
      //notifications.hide();
      loading.show();     
      try {        
        const result = await auth.login(userData);
        if (!result.success) {
         
          //notifications.show({message: localization.localizedError(result.errorCode)});
          props.enqueueSnackbar(localization.localizedError(result.errorCode), { 
                variant: 'error',
          });
          if( userData.type=='company'){
            setCookie('company_email','');
            setCookie('company_password', '');  
          }
        }
        else{                        
          if(userData.remember_me && userData.type=='company'){
            setCookie('company_email', userData.email);
            setCookie('company_password', userData.password);            
          }
          else if(!userData.remember_me && userData.type=='company'){
            setCookie('company_email','');
            setCookie('company_password', '');  
          }
         else if(userData.remember_me && userData.type=='customer'){
            setCookie('customer_email', userData.phone);
            setCookie('customer_password', userData.password);
          }
          else if(!userData.remember_me && userData.type=='customer'){
            setCookie('customer_email','');
            setCookie('customer_password','');
          }
        }
      } finally {
       loading.hide();
      }
    }}
    {...rest}
  >
    {localization.localizedString('LOGIN_BTN_TITLE')}
  </Button>
);

LoginButton.defaultProps = {
  userData: null
};

LoginButton.propTypes = {
  userData: PropTypes.oneOfType([
    // company login
    PropTypes.shape({
      email: PropTypes.string,
      password: PropTypes.string
    }),
    // customer login
    PropTypes.shape({
      phone: PropTypes.string,
      password: PropTypes.string
    })
  ])
};

function setCookie(cname,cvalue) { 
  var d = new Date();
  var exdays=30;
  d.setTime(d.getTime() + (exdays*24*60*60*1000));
 var expires = "expires=" + d.toGMTString();
 document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

export default withLoading(withNotifications(withLocalization(withAuth(LoginButton))));
