import React from 'react';
import PropTypes from 'prop-types';

import withStyles from '@material-ui/core/styles/withStyles';

import withAuth from '../../contexts/AuthContext';
import withLoading from '../../contexts/LoadingContext';
import withLocalization from '../../contexts/LocalizationContext';
import withNotifications from '../../contexts/NotificationsContext';
import Button from "@material-ui/core/Button";
import landingPageStyle from "../../../p/assets/jss/views/landingPage";
const SignupButton = ({
  auth, localization, notifications, loading, userData, ...rest
}) => (
  <Button
  style={{fontSize: '0.875rem', fontWeight: '600'}}
    variant="contained"
    color="secondary"
    onClick={async () => {
      notifications.hide();
      loading.show();

      try {
        const result = await auth.signup(userData);
        if (!result.success) {
          console.log(localization.localizedError(result.errorCode));
          notifications.show({message: localization.localizedError(result.errorCode)});
        }
      } finally {
        loading.hide();
      }
    }}
    {...rest}
  >
    {localization.localizedString('SIGNUP_BTN_TITLE')}
  </Button>
);

SignupButton.defaultProps = {
  userData: null
};

SignupButton.propTypes = {
  userData: PropTypes.oneOfType([
    // company signup
    PropTypes.shape({
      email: PropTypes.string.isRequired,
      password: PropTypes.string.isRequired,
      firstName: PropTypes.string.isRequired,
      lastName: PropTypes.string.isRequired,
      countryCode: PropTypes.string.isRequired,
      phone: PropTypes.string.isRequired,
      companyName: PropTypes.string.isRequired,
      zipCode: PropTypes.string.isRequired,
      city: PropTypes.string.isRequired,
      address: PropTypes.string.isRequired,
      cvr: PropTypes.string,
      smsSenderName: PropTypes.string.isRequired,
      lockBookingXHours: PropTypes.number.isRequired,
      bookLatestXHourBefore: PropTypes.number.isRequired,
      acceptBookingAutomatically: PropTypes.bool.isRequired,
      paymentUpfront: PropTypes.bool.isRequired
    }),
    // customer signup
  ])
};

export default withLoading(withNotifications(withLocalization(withAuth(SignupButton))));
