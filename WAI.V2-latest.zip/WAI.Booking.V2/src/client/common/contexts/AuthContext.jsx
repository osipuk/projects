import React from 'react';
import PropTypes from 'prop-types';

const AuthContext = React.createContext();

export default Component => props => (
  <AuthContext.Consumer>
    {auth => <Component {...props} auth={auth} />}
  </AuthContext.Consumer>
);

export class AuthProvider extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      isAuth: false,
      user: null,
      login: props.login,
      logout: props.logout,
      signup: props.signup,
      get: props.get
    };
  }

  login = async (userData) => {
    const { login } = this.state;

    const { success, errorCode, user } = await login(userData);
    this.setState(state => ({
      ...state, isAuth: success, user
    }));

    return { success, errorCode };
  };

  logout = async () => {
    const { logout } = this.state;

    const { success, errorCode } = await logout();
    this.setState(state => ({
      ...state, isAuth: !success, user: null
    }));

    return { success, errorCode };
  };

  signup = async (userData) => {
    const { signup } = this.state;

    const { success, errorCode, user } = await signup(userData);
    this.setState(state => ({
      ...state, isAuth: success, user
    }));

    return { success, errorCode };
  };

  get = async () => {
    const { get } = this.state;

    const { success, errorCode, user } = await get();
    this.setState(state => ({
      ...state, isAuth: success, user
    }));

    return { success, errorCode };
  };

  render() {
    const { isAuth, user } = this.state;
    const { children } = this.props;

    return (
      <AuthContext.Provider
        value={{
          isAuth,
          user,
          login: this.login,
          logout: this.logout,
          signup: this.signup,
          get: this.get
        }}
      >
        {children}
      </AuthContext.Provider>
    );
  }
}

AuthProvider.defaultProps = {
  children: []
};

AuthProvider.propTypes = {
  children: PropTypes.node,
  login: PropTypes.func.isRequired,
  logout: PropTypes.func.isRequired,
  signup: PropTypes.func.isRequired,
  get: PropTypes.func.isRequired
};
