import React from 'react';
import PropTypes from 'prop-types';

import withLocale, { langOrDef } from '../localization';

const LocalizationContext = React.createContext();

export default Component => props => (
  <LocalizationContext.Consumer>
    {localization => <Component {...props} localization={localization} />}
  </LocalizationContext.Consumer>
);

export class LocalizationProvider extends React.Component {
  constructor(props) {
    super(props);

    const lang = langOrDef(props.lang);

    this.state = {
      lang,
      ...withLocale(lang),
      changeLang: this.changeLang
    };
  }

  changeLang = (lang) => {
    const newLang = langOrDef(lang);

    this.setState(state => ({ ...state, lang: newLang, ...withLocale(newLang) }));
  };

  render() {
    const { children } = this.props;

    return (
      <LocalizationContext.Provider
        value={{
          ...this.state
        }}
      >
        {children}
      </LocalizationContext.Provider>
    );
  }
}

LocalizationProvider.defaultProps = {
  children: []
};

LocalizationProvider.propTypes = {
  lang: PropTypes.string.isRequired,
  children: PropTypes.node
};
