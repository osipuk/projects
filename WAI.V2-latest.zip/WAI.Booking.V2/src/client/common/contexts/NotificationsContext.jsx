import React from 'react';
import PropTypes from 'prop-types';

import Error from '@material-ui/icons/Error';

import Snackbar from 'common/components/Snackbar/Snackbar';
import { SnackbarProvider, withSnackbar } from 'notistack';

const NotificationsContext = React.createContext();

export default Component => props => (
  <NotificationsContext.Consumer>
    {notifications => <Component {...props} notifications={notifications} />}
  </NotificationsContext.Consumer>
);

export class NotificationsProvider extends React.Component {
  state = {
    open: false,
    icon: Error,
    color: 'danger',
    message: ''
  };

  componentWillUnmount() {
    this.hide();
  }

  show = ({ icon, color, message }) => this.setState(() => ({
    open: true, icon: icon || Error, color: color || 'danger', message: message || ''
  }));

  hide = () => this.setState(state => ({ ...state, open: false }));

  render() {
    const {
      open, icon, color, message
    } = this.state;
    const { children } = this.props;

    return (
      <NotificationsContext.Provider
        value={{
          show: this.show,
          hide: this.hide
        }}
      >
        <Snackbar
          place="tc"
          color={color}
          icon={icon}         
          message={message}
          open={open}
          closeNotification={() => this.hide()}
          close
        />
        {children}
      </NotificationsContext.Provider>
    );
  }
}

NotificationsProvider.defaultProps = {
  children: null
};

NotificationsProvider.propTypes = {
  children: PropTypes.node
};
