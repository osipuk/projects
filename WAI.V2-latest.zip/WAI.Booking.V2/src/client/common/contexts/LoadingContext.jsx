import React from 'react';
import PropTypes from 'prop-types';

import withStyles from '@material-ui/core/styles/withStyles';

import CustomLinearProgress from '../components/CustomLinearProgress/CustomLinearProgress';

const LoadingContext = React.createContext();

const styles = {
  progress: {
    display: 'inline-block',
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100%',
    zIndex: 100
  }
};

export default Component => props => (
  <LoadingContext.Consumer>
    {loading => <Component {...props} loading={loading} />}
  </LoadingContext.Consumer>
);

class Provider extends React.Component {
  static propTypes = {
    classes: PropTypes.object.isRequired,
    children: PropTypes.node
  };

  static defaultProps = {
    children: null
  };

  state = {
    loading: false
  };

  show = () => this.setState({ loading: true });

  hide = () => this.setState({ loading: false });

  render() {
    const { classes, children, ...rest } = this.props;
    const { loading } = this.state;

    return (
      <LoadingContext.Provider
        value={{
          show: this.show,
          hide: this.hide
        }}
      >
        {loading ? (
          <CustomLinearProgress
            variant="indeterminate"
            color="primary"
            classes={{
              root: classes.progress,
            }}
            {...rest}
          />
        ) : (
          <div />
        )}
        {children}
      </LoadingContext.Provider>
    );
  }
}

export const LoadingProvider = withStyles(styles)(Provider);
