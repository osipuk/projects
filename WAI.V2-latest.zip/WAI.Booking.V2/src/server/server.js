const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const errorHandler = require('errorhandler');
const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const logger = require('morgan');
const passport = require('passport');
const path = require('path');
const locale = require('locale');
const FileStore = require('session-file-store')(session);

const config = require('./config');

const initPassport = require('./auth').init;

const companyApiRouter = require('./api/company');
const customerApiRouter = require('./api/customer');

const cronTask = require('./cron').init;

class Server {
  static bootstrap() {
    return new Server();
  }

  constructor() {
    this.app = express();

    // configure
    this.config();

    // add api
    this.api();
    this.cron();
  }

  api() {
    this.app.use('/api/company', companyApiRouter);
    this.app.use('/api/customer', customerApiRouter);
  }

  cron(){
    cronTask();
  }

  config() {
    // setup proxy in production
    if (process.env.NODE_ENV === 'production') {
      this.app.set('trust proxy', true);
    }

    // session
    const sessionOptions = {
      store: new FileStore(),
      secret: '4*g_#bsy6HyDt@1',
      saveUninitialized: false,
      resave: false,
      cookie: {
        maxAge: 1000 * 60 * 60,
        httpOnly: true
      }
    };

    if (process.env.NODE_ENV === 'production') {
      sessionOptions.cookie.secure = true;
    }

    this.app.use(session(sessionOptions));

    // logger middleware
    this.app.use(logger('dev'));

    // locale
    this.app.use(locale(config.locale.supported, config.locale.default));

    // helmet middleware
    this.app.use(helmet());

    // json form parser middleware
    this.app.use(bodyParser.json());

    // query string parser middleware
    this.app.use(bodyParser.urlencoded({
      extended: true
    }));

    // cookie parser middleware
    this.app.use(cookieParser('$0m3&sE^5#n'));

    // static
    this.app.use(express.static(path.normalize(path.join(__dirname, '..', 'dist'))));

    // passport
    initPassport();

    this.app.use(passport.initialize({}));
    this.app.use(passport.session({}));

    // catch 404 and forward to error handler
    this.app.use((err, req, res, next) => {
      const error = err;
      error.status = 404;

      next(error);
    });

    // error handling
    this.app.use(errorHandler());
  }
}

module.exports = Server;
