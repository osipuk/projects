module.exports = class AppError extends Error {
  constructor(code) {
    super();

    this.name = this.constructor.name;

    Error.captureStackTrace(this, this.constructor);

    this.code = code;
  }
};
