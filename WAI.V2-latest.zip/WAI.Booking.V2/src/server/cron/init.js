var schedule = require('node-schedule');
const moment = require('moment');
const request = require('request-promise');
const errors = require('../../common/error_codes');
const AppError = require('../errors/app_error');
const config = require('../config');
const BookingController = require('../controllers').Booking;
const CompanyController = require('../controllers').Company;

const init = async () => {


  console.log('this is cron');
  var j = schedule.scheduleJob('40 * * * *', async function () { 
    var start_time = moment().startOf('day').format('YYYY-MM-DD HH:mm:ss');
    var end_time = moment().endOf('day').format('YYYY-MM-DD HH:mm:ss');
    const countries=await CompanyController.getCountrys();
    const bookings = await BookingController.findAllDateRange(
      start_time, end_time
    );
   
    var recipients = [];    
    bookings.map(row => {    
      if (row.time_zone != '') {
        var times = moment.tz(moment(), row.time_zone).format('HH:MM');
     if (times > '11:30' && times < '12:00') {
        //  if (times > '01:30' && times < '24:00') {         
          countries.map(item=>{          
            if(item.id==row.country_id){
              recipients.push({ msisdn: item.country_phone_code + row.phone });
            }
          });
         
        }
      }

    })
    console.log('this is cron', recipients);
  
    /** */
    try {
      await request.post({
        url: config.sms.api_url,
        oauth: {
          consumer_key: config.sms.consumer_key,
          consumer_secret: config.sms.consumer_secret
        },
        json: true,
        body: {
          //sender: company.smsSenderName,
          sender: "BookingSMS",
          message: `You was booked at today`,
          recipients: recipients
        }
      });
    } catch (err) {
      console.log(`Error while send sms: ${err}`);
      throw new AppError(errors.WASNT_ABLE_TO_SEND_SMS);
    }
    /*** */

  });

}
module.exports = init;