const errors = require('../../../common/error_codes');

const auth = (req, res, next) => {
  if (req.isAuthenticated()) {
    next();
    return;
  }

  res.json({
    success: false,
    errorCode: errors.AUTHENTICATION_ERROR
  });
};

const grant = type => (req, res, next) => {
  if (req.user.type === type) {
    next();
    return;
  }

  res.json({
    success: false,
    errorCode: errors.AUTHORIZATION_ERROR
  });
};

const async = fn => (req, res, next) => {
  Promise.resolve(fn(req, res, next))
    .catch((err) => {
      console.log(`Error (${err.code || 0}) - ${err.message}`);

      res.json({
        success: false,
        errorCode: err.code || errors.DB_ERROR
      });
    });
};

module.exports = {
  auth,
  grant,
  async
};
