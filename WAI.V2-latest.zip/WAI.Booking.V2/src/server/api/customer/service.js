const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');

const { Booking } = require('../../models');

const BookingController = require('../../controllers').Booking;
const BookingHoursController = require('../../controllers').BookingHours;
const CompanyController = require('../../controllers').Company;
const ServiceController = require('../../controllers').Service;
const ServiceCategoryController = require('../../controllers').ServiceCategory;
const ServiceExtraController = require('../../controllers').ServiceExtra;
const EmployeeController=require('../../controllers').Employee;
const ExtraServiceRelationsController=require('../../controllers').ExtraServiceRelatins;
const EmployeeServiceRelationsController=require('../../controllers').EmployeeServiceRelations;
const TermsController = require('../../controllers').Terms;
//const DiscountCardUserRelationController=require('../../controllers').DiscountCardUserRelation;
const DiscountCardController=require('../../controllers').DiscountCard;
const GiftCardController=require('../../controllers').GiftCard;
const DiscountCodeController=require('../../controllers').DiscountCode;

const allInfo = async (req, res) => {
 // const customerId = req.user.id;
  const companyId = req.params.id;

  /**
  const company = await CompanyController.findById(companyId);
  if (!company) {
    throw new AppError(errors.INCORRECT_COMPANY_CODE);
  }
 */
  const services = await ServiceController.findAllByCompanyId(companyId);
  
  if (!services) {
    throw new AppError(errors.DB_ERROR);
  }

  const serviceCategories = await ServiceCategoryController.findAllByCompanyId(companyId);
 
  if (!serviceCategories) {
    throw new AppError(errors.DB_ERROR);
  }

  const serviceExtras = await ServiceExtraController.findByCompanyId(companyId); 
  if (!serviceExtras) {
    throw new AppError(errors.DB_ERROR);
  }

  const employees = await EmployeeController.findAllByCompanyId(companyId); 
  if (!employees) {
    throw new AppError(errors.DB_ERROR);
  }

 const bookingHours = await BookingHoursController.findGetsByCompanyId(companyId);
 
 const extra_service_relations= await ExtraServiceRelationsController.findAllBesideDeleteByCompanyId(companyId);
 if (!extra_service_relations) {
   throw new AppError(errors.DB_ERROR);
 }

 const employee_service_relations= await EmployeeServiceRelationsController.findAllBesideDeleteByCompanyId(companyId);
 if (!employee_service_relations) {
   throw new AppError(errors.DB_ERROR);
 }

const termsService=await TermsController.findAllByCompanyId(companyId);
    var terms_service={};
    terms_service.en="";
    terms_service.dan="";
    termsService.map(row=>{
      if(row.languageId==1){
        terms_service.en=row.terms;
      }
      else{
        terms_service.dan=row.terms;
      }
    });
 
  const discountCard=await DiscountCardController.findAllActiveByCompanyId(companyId);
  const giftCard=await GiftCardController.findAllActiveByCompanyId(companyId);
  const discountCode=await DiscountCodeController.findAllActiveByCompanyId(companyId);

  res.json({
    success: true,   
    services,
    serviceCategories,
    serviceExtras,
    bookingHours,
    employees,
    extra_service_relations,
    employee_service_relations,
    terms_service,
    discountCard,
    giftCard,
    discountCode
   // activeBookings
  });
};


const getServicesByIds = async (req, res) => {
  let { ids } = req.params;
  ids=ids.split(",");
  const services = await ServiceController.findAllByIds(ids);
  if (!services) {
    throw new AppError(errors.DB_ERROR);
  }
  res.json({
    success: true,
    services
  });
};

module.exports = {
  allInfo,
  getServicesByIds
};
