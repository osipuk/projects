const passport = require('passport');
const request = require('request-promise');
const generator = require('generate-password');

const config = require('../../config');

const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');

const CompanyController = require('../../controllers').Company;
const CustomerController = require('../../controllers').Customer;
const NotificationsController=require('../../controllers').Notification;

var sent_phone=0;
const login = async (req, res, next) => {
  console.log(req.body);

  /**
  const company = await CompanyController.findById(id);
  if (!company) {
    throw new AppError(errors.INCORRECT_COMPANY_CODE);
  }
 */
  passport.authenticate('customer', {}, (err, customer) => {
    if (err) {
      console.log(`Customer authentication error: ${err}`);

      return res.json({
        success: false,
        errorCode: err.code
      });
    }
 
    if (!customer) {     
      return res.json({
        success: false,
        errorCode: errors.AUTHENTICATION_ERROR
      });
    }

    return req.login(customer, (error) => {
      if (error) {
        console.log(`Customer authentication error: ${error}`);

        return res.json({
          success: false,
          errorCode: err.code
        });
      }

      const loggedInCustomer = customer;
      delete loggedInCustomer.password;

      return res.json({
        success: true,
        customer: loggedInCustomer
      });
    });
  })(req, res, next);
};

const signup = async (req, res) => {
  const { customer } = req.body;
  //const companyId = req.params.id;

  // check fields
  if (!customer.firstName || customer.firstName === '') {
    throw new AppError(errors.INCORRECT_FIRST_NAME);
  }

  if (!customer.lastName || customer.lastName === '') {
    throw new AppError(errors.INCORRECT_LAST_NAME);
  }

  if (!customer.phone) {
    throw new AppError(errors.INCORRECT_PHONE);
  }

  
  const phone = customer.phone.replace(/\s/g, '').replace('+', '').trim();
 
  if (phone.length !== 8) {
    throw new AppError(errors.INCORRECT_PHONE);
  }
 /**

  if (!customer.gender || (customer.gender !== 'male' && customer.gender !== 'female')) {
    throw new AppError(errors.INCORRECT_GENDER);
  }
 */

  // check if phone already registered
  const existingCustomer = await CustomerController.findByPhone(phone);
  if (existingCustomer) {
    throw new AppError(errors.PHONE_ALREADY_USED);
  }

  /**
  // check if company exists
  const company = await CompanyController.findById(companyId);
  if (!company) {
    throw new AppError(errors.INCORRECT_COMPANY_CODE);
  }
 */

  // create new customer
  // create password
  const password = generator.generate({
    length: 6,
    numbers: true
  });

 
  customer.password = password;
  // set phone
  customer.phone = phone;    
  const newCustomer = await CustomerController.create(customer);
  if (!newCustomer) {
    throw new AppError(errors.DB_ERROR);
  }
 
  const country=await CustomerController.getCountryById(customer.countryId);
  // send sms with password

  var phone_number=country.country_phone_code+customer.phone;

  var notifications={};
  notifications.notifyType="SMS";
  notifications.toUser=phone_number;
  notifications.content=`Din bookingkode er: ${password}`;
  notifications.roleType="customer";

  try {
    await request.post({
      url: config.sms.api_url,
      oauth: {
        consumer_key: config.sms.consumer_key,
        consumer_secret: config.sms.consumer_secret
      },
      json: true,
      body: {
        //sender: company.smsSenderName,
        sender: "BookingSMS",
        message: `Din bookingkode er: ${password}`,      
       recipients: [{ msisdn: phone_number }]

      }
    });
  } catch (err) {
    console.log(`Error while send sms: ${err}`);
    notifications.status="failed";
    await NotificationsController.create(notifications);
    throw new AppError(errors.WASNT_ABLE_TO_SEND_SMS);
  }

  notifications.status="success";
  await NotificationsController.create(notifications);

  delete newCustomer.password;

  res.json({
    success: true,
    customer: newCustomer
  });

  // looks like we shouldn't login right after registration
  /*
  req.login(customer, (err) => {
    if (err) {
      console.log(`Customer authentication error: ${err}`);

      return res.json({
        success: false,
        errorCode: err.code
      });
    }

    const loggedInCustomer = customer;
    delete loggedInCustomer.password;

    return res.json({
      success: true,
      customer: loggedInCustomer
    });
  });
  */
};
const newpassword= async (req, res) => {
  const { phone } = req.body; 
  const existingCustomer = await CustomerController.findByPhone(phone);
  if (!existingCustomer) {
    throw new AppError(errors.PHONE_NOT_EXIST);
  }
  const verify_code = generator.generate({
    length: 6,
    numbers: true
  });

  const country=await CustomerController.getCountryById(existingCustomer.countryId);
  // send sms with password

  var phone_number=country.country_phone_code+existingCustomer.phone;
  
  existingCustomer.password=verify_code;
  var message="Your new password for "+config.website+" is "+verify_code;
  console.log(message);
  const newCustomer=await CustomerController.update(existingCustomer);

  var notifications={};
  notifications.notifyType="SMS";
  notifications.toUser=phone_number;
  notifications.content=message;
  notifications.roleType="customer";

  try {
    await request.post({
      url: config.sms.api_url,
      oauth: {
        consumer_key: config.sms.consumer_key,
        consumer_secret: config.sms.consumer_secret
      },
      json: true,
      body: {
        //sender: company.smsSenderName,
        sender: "BookingSMS", 
        message: message,      
       recipients: [{ msisdn: phone_number }]

      }
    });
  } catch (err) {
    console.log(`Error while send sms: ${err}`);
    notifications.status="failed";
    await NotificationsController.create(notifications);
    throw new AppError(errors.WASNT_ABLE_TO_SEND_SMS);
  }
  notifications.status="success";
    await NotificationsController.create(notifications);
 

  res.json({
    success: true,    
  });

}
const logout = async (req, res) => {
  req.logout();

  res.json({
    success: true
  });
};

module.exports = {
  login,
  signup,
  logout,
  newpassword
};
