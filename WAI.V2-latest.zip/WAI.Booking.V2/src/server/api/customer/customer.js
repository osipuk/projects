const generator = require('generate-password');
const moment = require('moment');
const passport = require('passport');
const request = require('request-promise');
const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');
const config = require('../../config');
const CustomerController = require('../../controllers').Customer;
const NotificationsController=require('../../controllers').Notification;

const get = async (req, res) => {
  const customerId = req.user.id;
 
  const customer = await CustomerController.findById(customerId);
 
  if (!customer) {
    throw new AppError(errors.DB_ERROR);
  }

  delete customer.password; 
  res.json({
    success: true,
    customer
  });
};

const getAllBooked= async (req, res) => {
  const companyId = req.user.id;
  const customers=await CustomerController.findByBookedByCompanyId(companyId);
  if (!customers) {
    throw new AppError(errors.DB_ERROR);
  }
  res.json({
    success: true,
    customers
  });
}

const getById = async (req, res) => {
  const customerId = req.params.id; 
  const customer = await CustomerController.findById(customerId);
  if (!customer) {
    throw new AppError(errors.DB_ERROR);
  }

  delete customer.password;

  res.json({
    success: true,
    customer
  });
};

const update = async (req, res) => {
  const { customer } = req.body;

  customer.id = req.user.id;

  //if (!customer.password) {
   // customer.password = req.user.password;   
  //}

  const updatedCustomer = await CustomerController.update(customer);
  if (!updatedCustomer) {
    throw new AppError(errors.DB_ERROR);
  }

  delete updatedCustomer.password;
  res.json({
    success: true,
    customer: updatedCustomer
  });
};

const creatComment = async (req, res) => {
  const { comment } = req.body;
  let comments={};
  
  const companyId= req.user.id;
  const customerId=req.params.id;
  comments.companyId=companyId;
  comments.customerId=customerId;
  comments.comment=comment;
  comments.modifiedAt=moment().format('YYYY-MM-DD HH:mm:ss');
  const newComment = await CustomerController.createComment(comments);
  if (!newComment) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    comment: newComment
  });
}
const getCommentByCustomerId= async (req, res) => {
  const customerId = req.params.id; 
  const companyId= req.user.id;
  const comment=await CustomerController.findCommentByCustomerId(customerId,companyId);
  if (!comment) {
    throw new AppError(errors.DB_ERROR);
  }
  res.json({
    success: true,
    comment: comment
  });
}

const changeComment= async (req, res) => {
  const { comment } = req.body;
  const commentid=req.params.id;
  var updatedComment;
  let commentArray=[];
  for (let i = 0; i < comment.length; i++) {
    //commentArray.push(new BookingExtra(0, booking.id, extras[i].id, customerId));  
  let comments={};
  comments.id=comment[i].id;
  comments.comment=comment[i].comment;
  comments.modifiedAt=moment().format('YYYY-MM-DD HH:mm:ss');
   updatedComment = await CustomerController.updateComment(comments);
  if (!updatedComment) {
    throw new AppError(errors.DB_ERROR);
  }  
}
 
  res.json({
    success: true,
    comment: updatedComment
  });
}

const phoneCheck= async (req, res) => {

  const { customer } = req.body;
  customer.id = req.user.id;

  const customerId=req.user.id;
  const phone = customer.phone.replace(/\s/g, '').replace('+', '').trim();
 
  if (phone.length !== 8) {
    throw new AppError(errors.INCORRECT_PHONE);
  }
  const existingCustomer = await CustomerController.findByPhoneAndId(phone,customerId);
  if (existingCustomer) {
    throw new AppError(errors.PHONE_ALREADY_USED);
  }
    const password = generator.generate({
      length: 6,
      numbers: true
    });
    customer.password = password;
    // set phone
    customer.phone = phone;  
    
    /**
    const updatedCustomer = await CustomerController.update(customer);
    if (!updatedCustomer) {
      throw new AppError(errors.DB_ERROR);
    }
     */

    const country=await CustomerController.getCountryById(customer.countryId);
    var phone_number=country.country_phone_code+customer.phone;

    console.log(password,'password',phone_number);
  
    var notifications={};
    notifications.notifyType="SMS";
    notifications.toUser=phone_number;
    notifications.content=`Din bookingkode er: ${password}`;
    notifications.roleType="customer";

  try {
    await request.post({
      url: config.sms.api_url,
      oauth: {
        consumer_key: config.sms.consumer_key,
        consumer_secret: config.sms.consumer_secret
      },
      json: true,
      body: {
        //sender: company.smsSenderName,
        sender: "BookingSMS",
        message: `Din bookingkode er: ${password}`,     
       recipients: [{ msisdn: phone_number }]

      }
    });
  } catch (err) {
    console.log(`Error while send sms: ${err}`);
   await NotificationsController.create(notifications);
    throw new AppError(errors.WASNT_ABLE_TO_SEND_SMS);
    throw new AppError(errors.WASNT_ABLE_TO_SEND_SMS);
  }
  
  notifications.status="success";
  await NotificationsController.create(notifications);
 // delete updatedCustomer.password;

  res.json({
    success: true,
    verify_code: password
  });

};

const getByPhone= async (req, res) => {
  console.log(req.body.customer);
  const customer=req.body.customer;
  const countryId=customer.countryId;
  const phone=customer.phone;
  const exist_customer=await CustomerController.findByPhoneAndCountryId(countryId,phone);
 
  res.json({
    success: true,
    customer:exist_customer
  });

}

const createCustomer= async (req, res) => {

  const customer=req.body.customer;
  
  const exist_customer=await CustomerController.findByPhoneAndCountryId(customer.countryId,customer.phone);
  if(exist_customer){
    res.json({
      success: true,
      customer: exist_customer
    });
  }

  const new_customer=await CustomerController.create(customer);

  if (!new_customer) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    customer: new_customer
  });
}

module.exports = {
  get,
  getById,
  update,
  phoneCheck,
  getAllBooked , 
  creatComment,
  getCommentByCustomerId,
  changeComment,
  getByPhone,
  createCustomer
};
