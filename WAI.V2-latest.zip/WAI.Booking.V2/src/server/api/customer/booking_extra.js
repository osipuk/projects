const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');

const { Booking } = require('../../models');

const CompanyController = require('../../controllers').Company;
const BookingExtraController = require('../../controllers').BookingExtra;


const getExtrasByBookingIds = async (req, res) => {
    var { ids } = req.params;
    ids=ids.split(',');  
    const extras = await BookingExtraController.findAllByBookingIds(ids);
    if (!extras) {
      throw new AppError(errors.DB_ERROR);
    }
  
    res.json({
      success: true,
      bookingExtras: extras
    });
  };

  
module.exports = {
    getExtrasByBookingIds
};
