const router = require('express').Router();

const { Customer } = require('../../models');

const mw = require('../middleware');
const auth = require('./auth');
const company = require('./company');
const booking = require('./booking');
const customer = require('./customer');
const service = require('./service');
const bookingExtra=require('./booking_extra');


router.get('/', mw.auth, mw.grant(Customer.Type), mw.async(customer.get));


// auth
//router.post('/company/:id/login', mw.async(auth.login));
//router.post('/company/:id/signup', mw.async(auth.signup));
router.post('/signup', mw.async(auth.signup));
router.post('/login', auth.login);
router.post('/logout', mw.auth, mw.grant(Customer.Type), mw.async(auth.logout));
router.post('/phone_send' ,mw.async(auth.newpassword));

// company
router.get('/company/:id', mw.async(company.get));
router.get('/company/:id/customurl', mw.async(company.getByUrl));
router.get('/company', mw.async(company.getAll));



// booking
//router.post('/employee/:id/booking/day', mw.auth, mw.grant(Customer.Type), mw.async(booking.getAllByDay)); // for one employee
router.post('/employee/booked/times', mw.auth, mw.grant(Customer.Type), mw.async(booking.getAllByDay)); // for one employee
//router.post('/employees/booking/day', mw.auth, mw.grant(Customer.Type), mw.async(booking.getAllByDay)); // for one employee

router.get('/company/:id/booking/active', mw.auth, mw.grant(Customer.Type), mw.async(booking.getAllActive));
router.put('/company/:id/booking/:bookingId/cancel', mw.auth, mw.grant(Customer.Type), mw.async(booking.cancel));
router.post('/booking/', mw.auth, mw.grant(Customer.Type), mw.async(booking.book));
// get booking . osp
//router.post('/company/:id/Oldbooking', mw.auth, mw.grant(Customer.Type), mw.async(booking.oldCreate));// old
router.post('/company/:id/booking/payment', mw.auth, mw.grant(Customer.Type), mw.async(booking.createPayment));
router.post('/company/:id/booking', mw.auth, mw.grant(Customer.Type), mw.async(booking.create));// old

router.get('/booking', mw.auth, mw.grant(Customer.Type), mw.async(booking.getBook));
router.get('/services/:ids', mw.auth, mw.grant(Customer.Type), mw.async(service.getServicesByIds));
router.get('/booking/:ids/extra', mw.auth, mw.grant(Customer.Type), mw.async(bookingExtra.getExtrasByBookingIds));

// customer
router.post('/phone', mw.auth, mw.grant(Customer.Type), mw.async(customer.phoneCheck));
router.put('/', mw.auth, mw.grant(Customer.Type), mw.async(customer.update));
router.get('/:id', mw.auth,  mw.async(customer.getById));

// service
router.get('/company/:id/services', mw.async(service.allInfo));

module.exports = router;
