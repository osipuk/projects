const moment = require('moment');

const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');

const { Booking, BookingExtra, BookingService,BookingItem } = require('../../models');

const BookingController = require('../../controllers').Booking;
const BookingExtraController = require('../../controllers').BookingExtra;
const BookingServiceController = require('../../controllers').BookingService;
const CompanyController = require('../../controllers').Company;
const EmployeeController = require('../../controllers').Employee;
const ServiceController = require('../../controllers').Service;
const ServiceExtraController = require('../../controllers').ServiceExtra;
const PaymentsController=require('../../controllers').Payments;
const BookingNotifyController=require('../../controllers').BookingNotify;
const BookingItemController=require('../../controllers').BookingItem;
const DiscountCardUserRelationController=require('../../controllers').DiscountCardUserRelation;
const BookingDiscountCardsRelationController=require('../../controllers').BookingDiscountCardsRelation;
const GiftCardController=require('../../controllers').GiftCard;
const BookingGiftCardsRelationController=require('../../controllers').BookingGiftCardRelation;
const DiscountCordController=require('../../controllers').DiscountCode;
const DiscountServiceRelationController=require('../../controllers').DiscountServiceRelation;
const DiscountServiceExtrasRelationController=require('../../controllers').DiscountServiceExtrasRelation;

const getAllActive = async(req, res) => {
    const { id } = req.params;
    const customerId = req.user.id;

    const company = await CompanyController.findById(id);
    if (!company) {
        throw new AppError(errors.INCORRECT_COMPANY_CODE);
    }

    const activeBookings = await BookingController.findAllByCustomerIdAndStatuses(
        customerId, [Booking.PENDING_STATUS, Booking.ACCEPTED_STATUS]
    );

    res.json({
        success: true,
        activeBookings
    });
};

const getAllByDay = async(req, res) => {
   // const employeeId = req.params.id;

    const day = moment(req.body.day, "YYYYMMDD");
    const employeeIds=req.body.employeeIds;
    if (!day) {
        throw new AppError(errors.INCORRECT_DATE);
    }
    
    const bookings = await BookingController.findAllByEmployeeIdAndDateRange(
        employeeIds,
        moment(req.body.day, "YYYYMMDD").startOf('day'),
        day.endOf('day')
    );
    if (!bookings) {
        throw new AppError(errors.DB_ERROR);
    }

    res.json({
        success: true,
        bookings
    });
};

const cancel = async(req, res) => {
    const companyId = req.params.id;
    const { bookingId } = req.params;

    const company = await CompanyController.findById(companyId);
    if (!company) {
        throw new AppError(errors.INCORRECT_COMPANY_CODE);
    }

    const booking = await BookingController.findById(bookingId);
    if (!booking) {
        throw new AppError(errors.INCORRECT_BOOKING_CODE);
    }

    // check if allowed to cancel
    const bookingStartDate = moment(booking.bookFrom);
    //const bookingLockDate = bookingStartDate.subtract(booking.lockBookingXHourBefore, 'hours');
    const bookingLockDate = bookingStartDate.subtract(company.lockBookingXHourBefore, 'hours');
    const now = moment();
    if (now.isSameOrAfter(bookingLockDate)) {
        throw new AppError(errors.NOT_ALLOWED_TO_CANCEL);
    }

    // cancel
    const cancelledBooking = await BookingController.cancelByIdAndCustomer(bookingId);
    if (!cancelledBooking) {
        throw new AppError(errors.DB_ERROR);
    }

    res.json({
        success: true,
        cancelledBooking
    });
};

const book = async(req, res) => {
    const customerId = req.user.id;
    const companyId = req.params.id;
    const {
        serviceId,
        extraIds,
        employeeId,
        bookFrom
    } = req.body;

    const company = await CompanyController.findById(companyId);
    if (!company) {
        throw new AppError(errors.INCORRECT_COMPANY_CODE);
    }

    const service = await ServiceController.findById(serviceId);
    if (!service) {
        throw new AppError(errors.INCORRECT_SERVICE_CODE);
    }

    const extras = await ServiceExtraController.findAllByIds(extraIds);
    if (!extras || extras.length !== extraIds.length) {
        throw new AppError(errors.INCORRECT_SERVICE_EXTRA_CODE);
    }

    const employee = await EmployeeController.findById(employeeId);
    if (!employee) {
        throw new AppError(errors.INCORRECT_EMPLOYEE_CODE);
    }

    // calculate duration according to service and service extras
    let durationHours = service.duration;
    for (let i = 0; i < extras.length; i++) {
        durationHours += extras[i].duration;
    }

    // setup booking start and end time
    const bookingStart = moment(bookFrom);
    const bookingEnd = bookingStart.add(durationHours, 'hours');

    // create booking
    const booking = await BookingController.create({
        employeeId,
        customerId,
        companyId,
        serviceId,
        bookFrom: bookingStart.format('YYYY-MM-DD HH:mm:ss'),
        bookTo: bookingEnd.format('YYYY-MM-DD HH:mm:ss')
    });
    if (!booking) {
        throw new AppError(errors.FAILED_CREATE_BOOKING);
    }

    // create booking extras
    const bookingExtraArray = [];
    for (let i = 0; i < extras.length; i++) {
        bookingExtraArray.push(new BookingExtra(0, booking.id, extras[i].id, customerId));
    }
    const bookingExtras = await BookingExtraController.createMany(bookingExtraArray);
    if (!bookingExtras || bookingExtras.length !== bookingExtraArray.length) {
        throw new AppError(errors.DB_ERROR);
    }

    res.json({
        success: true,
        booking,
        bookingExtras
    });
};

const oldCreate = async(req, res) => {
    const customerId = req.user.id;
    const companyId = req.params.id;
    const { book } = req.body;

    const {
        serviceIds,
        extraIds,
        employeeId,
        bookFrom,
        bookTo,
        duration,
        paid
    } = book;

    const company = await CompanyController.findById(companyId);
    if (!company) {
        throw new AppError(errors.INCORRECT_COMPANY_CODE);
    }

    const services = await ServiceController.findAllByIds(serviceIds);
    if (!services || services.length !== serviceIds.length) {
        throw new AppError(errors.INCORRECT_SERVICE_CODE);
    }

    const extras = await ServiceExtraController.findAllByIds(extraIds);
    if (!extras || extras.length !== extraIds.length) {
        throw new AppError(errors.INCORRECT_SERVICE_EXTRA_CODE);
    }

    const employee = await EmployeeController.findById(employeeId);
    if (!employee) {
        throw new AppError(errors.INCORRECT_EMPLOYEE_CODE);
    }

    /**
  // calculate duration according to service and service extras
  let durationHours = service.duration;
  for (let i = 0; i < extras.length; i++) {
    durationHours += extras[i].duration;
  }

  // setup booking start and end time
  const bookingStart = moment(bookFrom);
  const bookingEnd = bookingStart.add(durationHours, 'hours');
 */

    // create booking    
    const booking = await BookingController.create({
        employeeId,
        customerId,
        companyId,
        duration: duration,
        bookFrom: bookFrom,
        bookTo: bookTo,
        paid:paid
    });   
    
    if (!booking) {
        throw new AppError(errors.FAILED_CREATE_BOOKING);
    }   
    // create booking services
    const bookingServiceArray = [];
    for (let i = 0; i < services.length; i++) {
        bookingServiceArray.push(new BookingService(0, booking.id, services[i].id, customerId));
    }
    const bookingServices = await BookingServiceController.createMany(bookingServiceArray);
    /**
    console.log('servive',bookingServices)
    if (!bookingServices || bookingServices.length !== bookingServiceArray.length) {
      throw new AppError(errors.DB_ERROR);
    } */

    // create booking extras
    const bookingExtraArray = [];
    for (let i = 0; i < extras.length; i++) {
        bookingExtraArray.push(new BookingExtra(0, booking.id, extras[i].id, customerId));
    }
    const bookingExtras = await BookingExtraController.createMany(bookingExtraArray);
    /**
    if (!bookingExtras || bookingExtras.length !== bookingExtraArray.length) {
      throw new AppError(errors.DB_ERROR);
    }
     */
    var newNotify={};
    newNotify.bookingId=booking.id;
    newNotify.customerId=booking.customerId;
    newNotify.companyId=booking.companyId;
    newNotify.eventType="New booking";
    await BookingNotifyController.create(newNotify);

    res.json({
        success: true,
        booking,
    });
};

const create = async(req, res) => {
    const customerId = req.user.id;
    const companyId = req.params.id;
    const { book } = req.body;
    const {
        bookingData,      
        employeeId,
        bookFrom,
        bookTo,       
        paid,
        discountCards,
        giftCardId,
        giftCardAmountUsed,
        discountCodeId,
        discountCodeUsedAmount
    } = book;   
       
    
    const company = await CompanyController.findById(companyId);
    if (!company) {
        throw new AppError(errors.INCORRECT_COMPANY_CODE);
    }
    var duration=0;
    bookingData.map(row=>{
        duration+=parseInt(row.duration);
    })   
   
    const booking = await BookingController.create({     
        customerId,
        companyId,
        duration: duration,
        bookFrom: bookFrom,
        bookTo: bookTo,
        paid:paid
    });   
    
    if (!booking) {
        throw new AppError(errors.FAILED_CREATE_BOOKING);
    }
    
    if(giftCardId!='' && giftCardId!=0){
        var giftCard=await GiftCardController.findById(giftCardId);        
        var available_amount=parseFloat(giftCard.availableBalance)-parseFloat(giftCardAmountUsed);      
        
        var giftCard={};
        giftCard.id=giftCardId;
        giftCard.availableBalance=available_amount;
        await GiftCardController.update(giftCard);
    
        var gift_temp={};
        gift_temp.bookingId=booking.id;
        gift_temp.giftCardAmountUsed=giftCardAmountUsed;
        gift_temp.giftCardId=giftCardId;   
        await BookingGiftCardsRelationController.create(gift_temp);
    }   

    for(var k=0;k<discountCards.length;k++){
        var existRelation=await DiscountCardUserRelationController.findByIdByUserId(discountCards[k],customerId);       
        if(existRelation===null){
            var relation={};
            relation.discountCardId=discountCards[k];
            relation.used=1;
            relation.userId=customerId;
            relation.createdOn=  moment().format('YYYY-MM-DD HH:mm:ss');
           var newRelation= await DiscountCardUserRelationController.create(relation);
           var bookingRelation={};
           bookingRelation.bookingId=booking.id;
           bookingRelation.discountCardUserRelationId=newRelation.id;
          await BookingDiscountCardsRelationController.create(bookingRelation);
        }
        else{
            var relation={};
            relation.id=existRelation.id
            relation.used=parseInt(existRelation.used)+1;
            var updatedRelation=await DiscountCardUserRelationController.update(relation);
            var bookingRelation={};
            bookingRelation.bookingId=booking.id;
            bookingRelation.discountCardUserRelationId=updatedRelation.id;
           await BookingDiscountCardsRelationController.create(bookingRelation);
        }
    }


    
    const BookingItemArray = [];
    for (let i = 0; i < bookingData.length; i++) {      
        BookingItemArray.push(new BookingItem(0,booking.id, bookingData[i].employeeId, bookingData[i].serviceId,0,1,0));
        bookingData[i].extraIds.map(row=>{
            BookingItemArray.push(new BookingItem(0,booking.id, bookingData[i].employeeId, bookingData[i].serviceId,row,0,0));
        })
    }   
    //const bookingItem = await BookingItemController.createMany(BookingItemArray);

    // create booking services
    const bookingServiceArray = [];
    for (let i = 0; i < bookingData.length; i++) {
        bookingServiceArray.push(new BookingService(0, booking.id, bookingData[i].serviceId, customerId, bookingData[i].employeeId));
    }
    const bookingServices = await BookingServiceController.createMany(bookingServiceArray);

    // create booking extras
    const bookingExtraArray = [];
    for (let i = 0; i < bookingData.length; i++) {
        bookingData[i].extraIds.map(row=>{
            bookingExtraArray.push(new BookingExtra(0,booking.id,row,customerId,0,0,0,0,bookingData[i].serviceId, bookingData[i].employeeId));
        })
    } 
    const bookingExtras = await BookingExtraController.createMany(bookingExtraArray);

    var newNotify={};
    newNotify.bookingId=booking.id;
    newNotify.customerId=booking.customerId;
    newNotify.companyId=booking.companyId;
    newNotify.eventType="New booking";
    await BookingNotifyController.create(newNotify);


    if(discountCodeId!=''){
        var discountCode=await DiscountCordController.findById(discountCodeId);      
       
             var collage={};            
             for (let i = 0; i < bookingData.length; i++) {      
                collage.serviceId=bookingData[i].serviceId;
                collage.discountId=discountCodeId;
                if(discountCode.allServices){
                    await DiscountServiceRelationController.create(collage);
                }
                if(discountCode.allServiceExtras){
                        var extraIds= bookingData[i].extraIds;
                        for (var k=0;k<extraIds.length;k++){
                            var temp={};
                            temp.discountId=discountCodeId
                            temp.serviceExtraId=extraIds[k];
                            await DiscountServiceExtrasRelationController.create(temp);
                        }                    
                 }

             } 
            
        var used=parseInt(discountCode.used)+parseInt(discountCodeUsedAmount);
        var discount_temp={};
        discount_temp.id=discountCode.id;
        discount_temp.used=used;
        await DiscountCordController.update(discount_temp);

    }

    
    res.json({
        success: true,
        booking,
       
    });
   
};

const createPayment= async(req, res) => {
    const customerId = req.user.id;
    const companyId = req.params.id;
    const { payment } = req.body;
    payment.companyId=companyId;
    payment.customerId=customerId;
    const createdPayment = await PaymentsController.create(payment);
    if (!createdPayment) {
        throw new AppError(errors.DB_ERROR);
    }    
    res.json({
        success: true,
        payment,
    });

}
const getBook = async(req, res) => {
    const customerId = req.user.id;
    const bookings = await BookingController.findAllByCustomerId(customerId);
    if (!bookings) {
        throw new AppError(errors.DB_ERROR);
    }

    const bookingService = await BookingController.findAllBookingServicesByCustomerId(customerId);
    if (!bookingService) {
        throw new AppError(errors.DB_ERROR);
    }

    const bookingExtras = await BookingController.findAllBookingExtrasByCustomerId(customerId);
    if (!bookingExtras) {
        throw new AppError(errors.DB_ERROR);
    }
    res.json({
        success: true,
        bookings,
        bookingService,
        bookingExtras
    });

}


module.exports = {
    getAllActive,
    getAllByDay,
    cancel,
    book,
    getBook,
    create,
    createPayment
};