const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');

const CompanyController = require('../../controllers').Company;
const PaymentSettingController = require('../../controllers').PaymentSetting;
const ImagesController=require('../../controllers').Images;

const get = async (req, res) => {
  const { id } = req.params;

  const company = await CompanyController.findById(id);
  if (!company) {
    throw new AppError(errors.INCORRECT_COMPANY_CODE);
  }

  delete company.password;
  res.json({
    success: true,
    company
  });
};

const getByUrl = async (req, res) => {
  const { id } = req.params;
  const company = await CompanyController.findByUrl(id);
  if (!company) {
    throw new AppError(errors.INCORRECT_COMPANY_CODE);
  }
  delete company.password;

  var paymentSetting=await PaymentSettingController.findByCompanyId(company.id);

  if (!paymentSetting) {
    paymentSetting=[];
  }  

  var images=await ImagesController.findByCompanyId(company.id);

  res.json({
    success: true,
    company,
    paymentSetting,
    images
  });
};

const getAll = async (req, res) => {  
  const company = await CompanyController.getAll();
  if (!company) {
    throw new AppError(errors.DB_ERROR);
  }
  res.json({
    success: true,
    company
  });
};

module.exports = {
  get,
  getAll,
  getByUrl
};
