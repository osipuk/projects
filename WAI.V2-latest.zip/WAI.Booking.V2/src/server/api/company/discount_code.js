const moment = require('moment');
const request = require('request-promise');
const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');
const config = require('../../config');
const DiscountCodeController=require('../../controllers').DiscountCode;


const getAll = async (req, res) => {
  const companyId = req.user.id;

  const allDiscountCode=await DiscountCodeController.findAllByCompanyId(companyId);
 
  if (!allDiscountCode) {
    throw new AppError(errors.DB_ERROR);
  }
    res.json({
      success: true,    
      discountCodes:allDiscountCode
    });
};

const addDiscountCode = async (req, res) => {
  const { discountCode } = req.body;
  discountCode.businessId = req.user.id;
  discountCode.createdOn = moment().format('YYYY-MM-DD HH:mm:ss');
  const newDiscountCode = await DiscountCodeController.create(discountCode);
    if (!newDiscountCode) {
    throw new AppError(errors.DB_ERROR);
  }
  res.json({
    success: true,
    discountCode: newDiscountCode
  });
};

const editDiscountCode = async (req, res) => {
  const { discountCode } = req.body;
  discountCode.id = req.params.id;  
 
  const updateDiscountCode = await DiscountCodeController.update(discountCode);
  if (!updateDiscountCode) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    discountCode: updateDiscountCode
  });
};

const deleteDiscountCode= async (req, res) => {
  var rowId = req.params.id;  
 await DiscountCodeController.delete(rowId);
  res.json({
    success: true,   
  });
};

module.exports = {
  getAll,
  addDiscountCode ,
  editDiscountCode,
  deleteDiscountCode
};
