var compress_images = require('compress-images');
var multer = require('multer');
const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');

const ImagesController = require('../../controllers').Images;
var INPUT_path_to_your_images, OUTPUT_path;

INPUT_path_to_your_images = './src/images/unoptimized/*.{jpg,JPG,jpeg,JPEG,png,gif}';
OUTPUT_path = './src/images/';
var file_name="";
var Storage = multer.diskStorage({
  destination: function (req, file, callback) {
      callback(null, "./src/images/unoptimized/");
  },
  filename: function (req, file, callback) {
      file_name=file.fieldname + "_" + Date.now() + "_" + file.originalname;
      callback(null, file.fieldname + "_" + Date.now() + "_" + file.originalname);
  }
});

const upload = multer({
  storage: Storage,
  limits:{fileSize: 1000000},
}).single("slideImage");



const submit = async (req, res) => {  
  let images={};
  let imageIndex='';
  const companyId = req.user.id;      
   imageIndex=req.headers['data'];  
  images.companyId=companyId;
  

  upload(req, res,  function (err) {
    console.log(err);
    if (err) {
      //compress_images();  
      res.json({
        success: false
        
      }); 
      
        //return res.end("Something went wrong!");       
    }
    compress_images(INPUT_path_to_your_images, OUTPUT_path, {compress_force: false, statistic: true, autoupdate: true}, false,
      {jpg: {engine: 'mozjpeg', command: ['-quality', '60']}},
      {png: {engine: 'pngquant', command: ['--quality=20-50']}},
      {svg: {engine: 'svgo', command: '--multipass'}},
      {gif: {engine: 'gifsicle', command: ['--colors', '64', '--use-col=web']}}, async function(error, completed, statistic){
       
        if(imageIndex=='image1'){
          images.image1='./src/images/'+file_name;
        }
        else if(imageIndex=='image2'){
          images.image2='./src/images/'+file_name;
        }
        else if(imageIndex=='image3'){
          images.image3='./src/images/'+file_name;
        }
        else if(imageIndex=='image4'){
          images.image4='./src/images/'+file_name;
        }
        else if(imageIndex=='image5'){
          images.image5='./src/images/'+file_name;
        }
      
        console.log('-------------');
        
        var exitImage= await ImagesController.findByCompanyId(images.companyId);

        if(exitImage){
          images.id=exitImage.id;
          console.log(images);
          var newimage = await ImagesController.update(images);
        }
        else
        {
          var newimage = await ImagesController.create(images);
        }
        
        
        console.log('-------------',newimage);    
        res.json({
          success: true    
        });
    });
    
   //return res.end("File uploaded sucessfully!.");   
    
  });  
  
};

const get = async (req, res) => {  
  const companyId = req.user.id;      
  const images=await ImagesController.findByCompanyId(companyId);
   
  res.json({
    success: true ,
    images   
  });
};

module.exports = {
  submit,
  get
};
