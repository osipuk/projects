const moment = require('moment');
const request = require('request-promise');
const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');
const config = require('../../config');

const ServiceController = require('../../controllers').Service;
const ServiceExtraController = require('../../controllers').ServiceExtra;
const GiftCardController=require('../../controllers').GiftCard;


const getAll = async (req, res) => {
  const companyId = req.user.id;

  const allGiftCards=await GiftCardController.findAllByCompanyId(companyId);
 
  if (!allGiftCards) {
    throw new AppError(errors.DB_ERROR);
  }
    res.json({
      success: true,    
      giftCards:allGiftCards
    });
};

const addGiftCard = async (req, res) => {
  const { giftCard } = req.body;
  giftCard.businessId = req.user.id;
  const newGiftCard = await GiftCardController.create(giftCard);
    if (!newGiftCard) {
    throw new AppError(errors.DB_ERROR);
  }
  res.json({
    success: true,
    giftCard: newGiftCard
  });
};

const editGiftCard = async (req, res) => {
  const { giftCard } = req.body;
  giftCard.id = req.params.id; 
  console.log(giftCard);
  const updateGiftCard = await GiftCardController.update(giftCard);
  if (!updateGiftCard) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    giftCards: updateGiftCard
  });
};

const deleteGiftCard= async (req, res) => {
  var rowId = req.params.id;  
 await GiftCardController.delete(rowId);
  res.json({
    success: true,   
  });
};

module.exports = {
  getAll,
  addGiftCard ,
  editGiftCard,
  deleteGiftCard
};
