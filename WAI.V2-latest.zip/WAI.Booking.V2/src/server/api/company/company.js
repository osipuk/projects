const bcrypt = require('bcrypt-nodejs');
const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');

const CompanyController = require('../../controllers').Company;
const UserController=require('../../controllers').User;
const { Company } = require('../../models');

const get = async (req, res) => {
  const companyId = req.user.id;  
  const company = await CompanyController.findById(companyId); 
  if (!company) {
    throw new AppError(errors.DB_ERROR);
  }
  
  delete company.password;
  delete company.email_token;

  res.json({
    success: true,
    company
  });
};

const edit = async (req, res) => {
  const { company } = req.body;  
  company.id = req.user.id;
  
  var existingCompany = await UserController.findByEmail(company.email); 
  if (existingCompany) {
    if(existingCompany.companyId!=company.id){
      throw new AppError(errors.COMPANY_EMAIL_ALREADY_USED);
    }    
  }

  var letterNumber = /^[0-9a-zA-Z]+$/;
  if(!company.customUrl.match(letterNumber))
  {
    throw new AppError(errors.INCORRECT_CUSTOM_URL);
  } 

  var existingCompany2 = await CompanyController.findByCustomUrlAndId(company);    
  if (existingCompany2) {    
      throw new AppError(errors.CUSTOM_URL_ALREADY_USED);
  }

   
  /**
  if(company.password!='*********'){   
      if(!bcrypt.compareSync(company.password, existingCompany.password)){
        throw new AppError(errors.INCORRECT_CURRENT_PASSWORD);
      }
     company.password=bcrypt.hashSync(company.new_password);
   }
   else{
     delete company.password;
   }
 */

  const updateCompany = await CompanyController.update(company);
    
  if (!updateCompany) {
    throw new AppError(errors.DB_ERROR);
  }

  
  const updatedUser = await UserController.update1(company);    
 

  res.json({
    success: true,
    employee: updateCompany
  });
};


const getCountryInf = async (req, res) => {
  const countryId = req.user.countryId;
 

  const country = await CompanyController.findCountryinfById(countryId);
  if (!country) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    country
  });
};


const getCountrys = async (req, res) => {

  const country = await CompanyController.getCountrys();
    if (!country) {
    throw new AppError(errors.DB_ERROR);
  }
  res.json({
    success: true,
    country
  });
};


const checkPassword= async (req, res) => {
  companyId = req.user.id;  
  var old_password=req.body.oldpassword; 
  var new_password=req.body.newpassword;
  const company = await UserController.findCompanyByComapnyId(companyId);

  if(!bcrypt.compareSync(old_password, company.password)){
    throw new AppError(errors.INCORRECT_CURRENT_PASSWORD);
  }
  var user={};
  user.id=company.id;
  user.password=bcrypt.hashSync(new_password);
  const updatedUser = await UserController.update(user);   
  res.json({
    success: true,    
  });

};



module.exports = {
  get,
  getCountryInf,
  edit,
  getCountrys,
  checkPassword
};
