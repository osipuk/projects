const moment = require('moment');
const request = require('request-promise');
const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');
const config = require('../../config');
const { Booking ,BookingItem,BookingService,BookingExtra} = require('../../models');
const BookingController = require('../../controllers').Booking;
const EmployeeController=require('../../controllers').Employee;
const CustomerController=require('../../controllers').Customer;
const BookingServiceController=require('../../controllers').BookingService;
const BookingExtraController=require('../../controllers').BookingExtra;
const PaymentsController = require('../../controllers').Payments;
const CompanyController = require('../../controllers').Company;
const ServiceController = require('../../controllers').Service;
const ServiceCategoryController = require('../../controllers').ServiceCategory;
const ServiceExtraController = require('../../controllers').ServiceExtra;
const ExtraServiceRelationsController=require('../../controllers').ExtraServiceRelatins;
const EmployeeServiceRelationsController=require('../../controllers').EmployeeServiceRelations;
const BookingHoursController = require('../../controllers').BookingHours;
const BookingNotifyController=require('../../controllers').BookingNotify;
const NotificationsController=require('../../controllers').Notification;

const acceptBooking = async (req, res) => {
  const { id } = req.params;

  const acceptedBooking = await BookingController.acceptById(id);
  if (!acceptedBooking) {
    throw new AppError(errors.DB_ERROR);
  }

  const booking=await BookingController.findById(id);
  const customer_id=booking.customerId;

  const customer=await CustomerController.findById(customer_id);
  if (!customer) {
    throw new AppError(errors.DB_ERROR);
  }
  const country= await CustomerController.getCountryById(customer.countryId);

  if (!country) {
    throw new AppError(errors.DB_ERROR);
  }
  console.log(customer.phone,country.country_phone_code);

  let phone_number=country.country_phone_code+customer.phone;
  let message="Your booking was accepted."
  
  var notifications={};
  notifications.notifyType="SMS";
  notifications.toUser=phone_number;
  notifications.content=message;
  notifications.roleType="comapny";

  try {
    await request.post({
      url: config.sms.api_url,
      oauth: {
        consumer_key: config.sms.consumer_key,
        consumer_secret: config.sms.consumer_secret
      },
      json: true,
      body: {
        //sender: company.smsSenderName,
        sender: "BookingSMS",
        message: message,      
       recipients: [{ msisdn: phone_number }]

      }
    });
  } catch (err) {
    console.log(`Error while send sms: ${err}`);
    notifications.status="failed";
    await NotificationsController.create(notifications);
    throw new AppError(errors.WASNT_ABLE_TO_SEND_SMS);
  }

    notifications.status="success";
    await NotificationsController.create(notifications);
  res.json({
    success: true,
    booking: acceptedBooking
  });
};

const rejectBooking = async (req, res) => {
  const { id } = req.params;

  const rejectedBooking = await BookingController.rejectById(id);
  if (!rejectedBooking) {
    throw new AppError(errors.DB_ERROR);
  }

  const booking=await BookingController.findById(id);
  const customer_id=booking.customerId;

  const customer=await CustomerController.findById(customer_id);
  if (!customer) {
    throw new AppError(errors.DB_ERROR);
  }
  const country= await CustomerController.getCountryById(customer.countryId);

  if (!country) {
    throw new AppError(errors.DB_ERROR);
  }
  console.log(customer.phone,country.country_phone_code);

  let phone_number=country.country_phone_code+customer.phone;
  let message="Your booking was rejected."
  
  var notifications={};
  notifications.notifyType="SMS";
  notifications.toUser=phone_number;
  notifications.content=message;
  notifications.roleType="comapny";

  try {
    await request.post({
      url: config.sms.api_url,
      oauth: {
        consumer_key: config.sms.consumer_key,
        consumer_secret: config.sms.consumer_secret
      },
      json: true,
      body: {
        //sender: company.smsSenderName,
        sender: "BookingSMS",
        message: message,      
       recipients: [{ msisdn: phone_number }]

      }
    });
  } catch (err) {
    console.log(`Error while send sms: ${err}`);
    notifications.status="failed";
    await NotificationsController.create(notifications);
    throw new AppError(errors.WASNT_ABLE_TO_SEND_SMS);
  }
  notifications.status="success";
  await NotificationsController.create(notifications);
  res.json({
    success: true,
    booking: rejectedBooking
  });
};

const CompletedBooking = async (req, res) => {
  const { id } = req.params;

  const completedBooking = await BookingController.completedById(id);
  if (!completedBooking) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    booking: completedBooking
  });
};

const StayedBooking = async (req, res) => {
  const { id } = req.params;

  const completedBooking = await BookingController.stayedById(id);
  if (!completedBooking) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    booking: completedBooking
  });
};



const cancelBooking = async (req, res) => {
  const { id } = req.params;

  const cancelledBooking = await BookingController.cancelById(id);
  if (!cancelledBooking) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    booking: cancelledBooking
  });
};

const editBooking = async (req, res) => {
  const { id } = req.params;
  const {booking}=req.body;
  console.log(id,booking);
  
  const updateBooking = await BookingController.updateById(id,booking);
  if (!updateBooking) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    booking: updateBooking
  });
};

const getBookings = async (req, res) => {
  const companyId = req.user.id;
  const bookings = await BookingController.findAllByCompanyId(companyId);
  if (!bookings) {
    throw new AppError(errors.DB_ERROR);
  }

  const bookingServices = await BookingController.findAllBookingServicesByCompanyId(companyId);
  if (!bookingServices) {
    throw new AppError(errors.DB_ERROR);
  }

  const bookingExras = await BookingController.findAllBookingExtrasByCompanyId(companyId);
  if (!bookingExras) {
    throw new AppError(errors.DB_ERROR);
  }

  const employees= await EmployeeController.findAllByCompanyId(companyId);  
  res.json({
    success: true,
    bookings,
    bookingServices,
    bookingExras,
    employees
  });
};

const getBookingsByStatus = async (req, res) => {
  const companyId = req.user.id;
  const { status } = req.params;

  const bookingStatus = status.toUpperCase();
  if (!Booking.ALL_STATUSES.includes(bookingStatus)) {
    throw new AppError(errors.INCORRECT_BOOKING_STATUS);
  }

  const bookings = await BookingController.findAllByCompanyIdAndStatuses(
    companyId,
    [bookingStatus]
  );
  if (!bookings) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    bookings
  });
};

const getBookingsByDateRange = async (req, res) => {
  const companyId = req.user.id;
  const { dateRange } = req.body;

  const bookings = await BookingController.findAllByCompanyIdAndDateRange(
    companyId,
    dateRange.start,
    dateRange.end
  );
  if (!bookings) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    bookings
  });
};

const getcheckout= async (req, res) => {
  const bookingId = req.params.id;  
  const companyId = req.user.id;

  const services = await BookingServiceController.findAllByBookingId(bookingId);

  if (!services) {
    throw new AppError(errors.DB_ERROR);
  }
  const extras = await BookingExtraController.findAllByBookingId(bookingId);

  if (!extras) {
    throw new AppError(errors.DB_ERROR);
  }

  const payments = await PaymentsController.findByCompanyBookingId(companyId,bookingId);
  if (!payments) {
    throw new AppError(errors.DB_ERROR);
  }
  res.json({
    success: true,
    bookingServices: services,
    bookingExtras: extras,
    payments
  });
};

const allForBooking = async (req, res) => {
  const companyId = req.user.id;
  
  const country = await CompanyController.getCountrys();
    if (!country) {
    throw new AppError(errors.DB_ERROR);
  }

  const categories = await ServiceCategoryController.findAllByCompanyId(companyId);
  if (!categories) {
    throw new AppError(errors.DB_ERROR);
  }


  const services = await ServiceController.findAllByCompanyId(companyId);  
  if (!services) {
    throw new AppError(errors.DB_ERROR);
  }

  const serviceExtras = await ServiceExtraController.findByCompanyId(companyId); 
  if (!serviceExtras) {
    throw new AppError(errors.DB_ERROR);
  }

  const employees = await EmployeeController.findAllByCompanyId(companyId); 
  if (!employees) {
    throw new AppError(errors.DB_ERROR);
  }

 const bookingHours = await BookingHoursController.findGetsByCompanyId(companyId);
 

 
 const extra_service_relations= await ExtraServiceRelationsController.findAllBesideDeleteByCompanyId(companyId);
 if (!extra_service_relations) {
   throw new AppError(errors.DB_ERROR);
 }

 const employee_service_relations= await EmployeeServiceRelationsController.findAllBesideDeleteByCompanyId(companyId);
 if (!employee_service_relations) {
   throw new AppError(errors.DB_ERROR);
 }

  res.json({
    success: true,
    country,
    services,
    categories,
    serviceExtras,
    bookingHours,
    employees,
    extra_service_relations,
    employee_service_relations,
   
  });

}

const getAllByDay = async(req, res) => {
  // const employeeId = req.params.id;

   const day = moment(req.body.day, "YYYYMMDD");
   const employeeIds=req.body.employeeIds;
   if (!day) {
       throw new AppError(errors.INCORRECT_DATE);
   }
 
   const bookings = await BookingController.findAllByEmployeeIdAndDateRange(
       employeeIds,
       moment(req.body.day, "YYYYMMDD").startOf('day'),
       day.endOf('day')
   );
   if (!bookings) {
       throw new AppError(errors.DB_ERROR);
   }

   res.json({
       success: true,
       bookings
   });
};

const create = async(req, res) => {
  
  const companyId = req.user.id;
  const { book } = req.body;
  const {
      bookingData,      
      employeeId,
      bookFrom,
      bookTo,       
      paid,
      customerId
  } = book;
 
  console.log(book);

  const company = await CompanyController.findById(companyId);
  if (!company) {
      throw new AppError(errors.INCORRECT_COMPANY_CODE);
  }
  var duration=0;
  bookingData.map(row=>{
      duration+=parseInt(row.duration);
  })   
 
  const booking = await BookingController.create({     
      customerId,
      companyId,
      duration: duration,
      bookFrom: bookFrom,
      bookTo: bookTo,
      paid:paid
  });   
  
  if (!booking) {
      throw new AppError(errors.FAILED_CREATE_BOOKING);
  }

  const BookingItemArray = [];
  for (let i = 0; i < bookingData.length; i++) {      
      BookingItemArray.push(new BookingItem(0,booking.id, bookingData[i].employeeId, bookingData[i].serviceId,0,1,0));
      bookingData[i].extraIds.map(row=>{
          BookingItemArray.push(new BookingItem(0,booking.id, bookingData[i].employeeId, bookingData[i].serviceId,row,0,0));
      })
  }   
  //const bookingItem = await BookingItemController.createMany(BookingItemArray);

  // create booking services
  const bookingServiceArray = [];
  for (let i = 0; i < bookingData.length; i++) {
      bookingServiceArray.push(new BookingService(0, booking.id, bookingData[i].serviceId, customerId, bookingData[i].employeeId));
  }
  const bookingServices = await BookingServiceController.createMany(bookingServiceArray);

  // create booking extras
  const bookingExtraArray = [];
  for (let i = 0; i < bookingData.length; i++) {
      bookingData[i].extraIds.map(row=>{
          bookingExtraArray.push(new BookingExtra(0,booking.id,row,customerId,0,0,0,0,bookingData[i].serviceId, bookingData[i].employeeId));
      })
  } 
  const bookingExtras = await BookingExtraController.createMany(bookingExtraArray);

  var newNotify={};
  newNotify.bookingId=booking.id;
  newNotify.customerId=booking.customerId;
  newNotify.companyId=booking.companyId;
  newNotify.eventType="New booking";
  await BookingNotifyController.create(newNotify);

  
  res.json({
      success: true,
      booking,
     
  });
 
};

module.exports = {
  acceptBooking,
  rejectBooking,
  cancelBooking,
  getBookings,
  getBookingsByStatus,
  getBookingsByDateRange,
  editBooking,
  CompletedBooking,
  StayedBooking,
  getcheckout,
  allForBooking,
  getAllByDay,
  create
};
