const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');

const ServiceExtraController = require('../../controllers').ServiceExtra;

const getExtras = async (req, res) => {
  const companyId = req.user.id;
  const serviceId = req.params.id;
  const extras = await ServiceExtraController.findAllByCompanyId(companyId,serviceId);
  if (!extras) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    serviceExtras: extras
  });
};


const getExtrasByServiceIds = async (req, res) => {

  let { ids } = req.params;
  ids=ids.split(",");
  console.log(ids,'rrr5555');
  const companyId = req.user.id;

  const extras = await ServiceExtraController.findAllByServiceIds(ids);
  if (!extras) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    serviceExtras: extras
  });
};

const addExtra = async (req, res) => {
  const { extra } = req.body;  
  extra.companyId = req.user.id;
 
  const newExtra = await ServiceExtraController.create(extra);
  if (!newExtra) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    serviceExtra: newExtra
  });
};

const deleteExtra = async (req, res) => {
  const { id } = req.params;
  await ServiceExtraController.delete(id);

  res.json({
    success: true
  });
};

const deleteAllExtra= async (req, res) => {
  const { deleteExtras } = req.body;
  await ServiceExtraController.deleteAllExtra(deleteExtras);

  res.json({
    success: true
  });
};

const editExtra = async (req, res) => {
  const { extra } = req.body;
  extra.id = req.params.id;
  extra.companyId = req.user.id;

  const updatedExtra = await ServiceExtraController.update(extra);
  if (!updatedExtra) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    serviceExtra: updatedExtra
  });
};

const editExtras = async (req, res) => { // for update by ids 
  const { extras } = req.body; 
   
  var addons=extras.addons;
  var serviceId=extras.serviceId;
  console.log(serviceId); 
  const extraArray = [];
  
  var extra_all=await ServiceExtraController.findAllByIds(addons);
  extra_all.map(row=>{
    row.deleted=0;
    extraArray.push(row);
  })  

  var extra=await ServiceExtraController.findAllByServiceId(serviceId);  
 /**
  addons.map(row=>async{
    var extra=await ServiceExtraController.findAllByServiceIds(row);
   if(extra.serviceId==serviceId){
      
    }
  })
 */
  res.json({
    success: true   
  });
 
};


module.exports = {
  getExtras,
  addExtra,
  deleteExtra,
  editExtra,
  editExtras,
  getExtrasByServiceIds,
  deleteAllExtra
};
