const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');

const AboutController = require('../../controllers').About;
const TermsController = require('../../controllers').Terms;
const get = async (req, res) => {
  const { id } = req.params;

  const employee = await AboutController.findById(id);
  if (!employee) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    employee
  });
};

const getAll = async (req, res) => {
  const companyId = req.user.id;

  const abouts = await AboutController.findAllByCompanyId(companyId);
  if (!abouts) {
    throw new AppError(errors.DB_ERROR);
  }

  const terms = await TermsController.findAllByCompanyId(companyId);
  if (!terms) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    abouts,
    terms
  });
};

const create = async (req, res) => {
  const { about } = req.body;
  let companyId=req.user.id;
  about.companyId = req.user.id;

  const exitAbout=await AboutController.findByLanguageId(about.languageId,companyId);
  if (exitAbout) {
    throw new AppError(errors.LANGUAGE_ABOUT_ALREADY_EXIST);
  }

  const newAbout = await AboutController.create(about);
  if (!newAbout) {
    throw new AppError(errors.DB_ERROR);
  }
  res.json({
    success: true,
    about: newAbout
  });
};

const update = async (req, res) => {
  const { about } = req.body;
  about.id = req.params.id;
  about.companyId = req.user.id;

  const exitAbout=await AboutController.findByLanguageId(about.languageId,about.companyId);
  if (exitAbout.id!=req.params.id) {
    throw new AppError(errors.LANGUAGE_ABOUT_ALREADY_EXIST);
  }

  const updatedAbout = await AboutController.update(about);
  if (!updatedAbout) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    about: updatedAbout
  });
};

const del = async (req, res) => {
  const { id } = req.params;
  await AboutController.delete(id);

  res.json({
    success: true
  });
};


const getLanguage = async (req, res) => {
  const languages = await AboutController.findAllLanguage();
  if (!languages) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    languages
  });
};

module.exports = {
  get,
  getAll,
  create,
  update,
  del,
  getLanguage
};
