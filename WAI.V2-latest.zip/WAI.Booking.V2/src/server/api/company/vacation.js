const request = require('request-promise');
const config = require('../../config');
const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');

const VacationController = require('../../controllers').Vacation;
const BookingController = require('../../controllers').Booking;
const CustomerController=require('../../controllers').Customer;

const create = async (req, res) => {
  const { vacation } = req.body;
  let companyId=req.user.id; 
  let employeeId=req.params.id;
  vacation.companyId = companyId;
  vacation.employeeId = employeeId;

  var isBookedAccept=await BookingController.findAllByEmployeeIdAndDateRangeIsAccept(employeeId,vacation.fromDate,vacation.toDate);  
  var isBookedRequest=await BookingController.findAllByEmployeeIdAndDateRangeIsRequest(employeeId,vacation.fromDate,vacation.toDate); 

  if(isBookedAccept.length>0 || isBookedRequest.length>0){
    return res.json({
        success: false,
        errorCode: 33,
        bookingAccept:isBookedAccept.length,
        bookingRequest:isBookedRequest.length
      });
    
    }

  /**
  const exitVacation=await VacationController.findByemployeeId(employeeId);
  if (exitVacation.length!=0) {
    vacation.id=exitVacation.id;
    var newVacation = await VacationController.update(vacation);
  } 
  else{    
      var newVacation = await VacationController.create(vacation);  
  }  
 */  
  var newVacation = await VacationController.create(vacation);  
  if (!newVacation) {
    throw new AppError(errors.DB_ERROR);
  }
  res.json({
    success: true,
    vacation: newVacation
  });
};

const updateWithYes = async (req, res) => {
  const { vacation } = req.body;
  let companyId=req.user.id; 
  let vacationId=req.params.id;
  vacation.companyId = companyId;
  

  var isBookedAccept=await BookingController.findAllByEmployeeIdAndDateRangeIsAccept(vacation.employeeId,vacation.fromDate,vacation.toDate);  
  var isBookedRequest=await BookingController.findAllByEmployeeIdAndDateRangeIsRequest(vacation.employeeId,vacation.fromDate,vacation.toDate);

  var recipients =[];
  isBookedAccept.map(async (row)=>{
    
    const customer=await CustomerController.findById(row.customerId);
    if (!customer) {
      throw new AppError(errors.DB_ERROR);
    }
    const country= await CustomerController.getCountryById(customer.countryId);  
    if (!country) {
      throw new AppError(errors.DB_ERROR);
    }    
  
    let phone_number=country.country_phone_code+customer.phone;   
    recipients.push({msisdn:phone_number});

    await BookingController.cancelById(row.id);
    console.log(recipients,'idddd');
   
  })
 
  await isBookedRequest.map(async(row)=>{
    const customer=await CustomerController.findById(row.customerId);
    if (!customer) {
      throw new AppError(errors.DB_ERROR);
    }
    const country= await CustomerController.getCountryById(customer.countryId);  
    if (!country) {
      throw new AppError(errors.DB_ERROR);
    }    
  
    let phone_number=country.country_phone_code+customer.phone;   
    recipients.push({msisdn:phone_number});
    console.log(recipients,'ccccc');
     await BookingController.cancelById(row.id);    

  })
  let message="Your booking was cancelled.";
  if(recipients.length!=0){
    console.log(message);
    /**
    try {
      await request.post({
        url: config.sms.api_url,
        oauth: {
          consumer_key: config.sms.consumer_key,
          consumer_secret: config.sms.consumer_secret
        },
        json: true,
        body: {
          //sender: company.smsSenderName,
          sender: "BookingSMS",
          message: message,      
         recipients: recipients
  
        }
      });
    } catch (err) {
      console.log(`Error while send sms: ${err}`);
      throw new AppError(errors.WASNT_ABLE_TO_SEND_SMS);
    }
     */
  }
      vacation.id=vacationId;
      var newVacation = await VacationController.update(vacation);    
    if (!newVacation) {
      throw new AppError(errors.DB_ERROR);
    }
    res.json({
      success: true,
      vacation: newVacation
    });
};

const update = async (req, res) => {
  const { vacation } = req.body;
  let companyId=req.user.id;  
  let vacationId=req.params.id;
  vacation.companyId = companyId;
  vacation.id = vacationId;

  var isBookedAccept=await BookingController.findAllByEmployeeIdAndDateRangeIsAccept(vacation.employeeId,vacation.fromDate,vacation.toDate);  
  var isBookedRequest=await BookingController.findAllByEmployeeIdAndDateRangeIsRequest(vacation.employeeId,vacation.fromDate,vacation.toDate); 

  if(isBookedAccept.length>0 || isBookedRequest.length>0){
      res.json({
        success: false,
        errorCode: 33,
        bookingAccept:isBookedAccept.length,
        bookingRequest:isBookedRequest.length
      });
    }
  
var newVacation = await VacationController.update(vacation);
  if (!newVacation) {
    throw new AppError(errors.DB_ERROR);
  }
  res.json({
    success: true,
    vacation: newVacation
  });
};

const createWithYes = async (req, res) => {
  const { vacation } = req.body;
  let companyId=req.user.id; 
  let employeeId=req.params.id;
  vacation.companyId = companyId;
  vacation.employeeId = employeeId;

  var isBookedAccept=await BookingController.findAllByEmployeeIdAndDateRangeIsAccept(employeeId,vacation.fromDate,vacation.toDate);  
  var isBookedRequest=await BookingController.findAllByEmployeeIdAndDateRangeIsRequest(employeeId,vacation.fromDate,vacation.toDate);

  var recipients =[];
  isBookedAccept.map(async (row)=>{
    
    const customer=await CustomerController.findById(row.customerId);
    if (!customer) {
      throw new AppError(errors.DB_ERROR);
    }
    const country= await CustomerController.getCountryById(customer.countryId);  
    if (!country) {
      throw new AppError(errors.DB_ERROR);
    }    
  
    let phone_number=country.country_phone_code+customer.phone;   
    recipients.push({msisdn:phone_number});

    await BookingController.cancelById(row.id);
    console.log(recipients,'idddd');
   
  })
 
  await isBookedRequest.map(async(row)=>{
    const customer=await CustomerController.findById(row.customerId);
    if (!customer) {
      throw new AppError(errors.DB_ERROR);
    }
    const country= await CustomerController.getCountryById(customer.countryId);  
    if (!country) {
      throw new AppError(errors.DB_ERROR);
    }    
  
    let phone_number=country.country_phone_code+customer.phone;   
    recipients.push({msisdn:phone_number});
    console.log(recipients,'ccccc');
     await BookingController.cancelById(row.id);    

  })
  console.log(recipients.length,'ggggggggg');
  let message="Your booking was cancelled.";
  if(recipients.length!=0){
    console.log(message);
    /**
    try {
      await request.post({
        url: config.sms.api_url,
        oauth: {
          consumer_key: config.sms.consumer_key,
          consumer_secret: config.sms.consumer_secret
        },
        json: true,
        body: {
          //sender: company.smsSenderName,
          sender: "BookingSMS",
          message: message,      
         recipients: recipients
  
        }
      });
    } catch (err) {
      console.log(`Error while send sms: ${err}`);
      throw new AppError(errors.WASNT_ABLE_TO_SEND_SMS);
    }
     */
  }
  
  var newVacation = await VacationController.create(vacation); 
  if (!newVacation) {
    throw new AppError(errors.DB_ERROR);
  }
  res.json({
    success: true,
    vacation: newVacation
  });
};

const get = async (req, res) => {
  const { id } = req.params;

  const vacation = await VacationController.findByemployeeId(id);
  if (!vacation) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    vacation
  });
};

const del = async (req, res) => {
  const { id } = req.params;
   await VacationController.del(id); 
  res.json({
    success: true,   
  });
};
module.exports = {
  get,  
  create,
  update,
  createWithYes,
  del,
  updateWithYes
};
