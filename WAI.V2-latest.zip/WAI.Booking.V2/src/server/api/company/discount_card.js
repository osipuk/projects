const moment = require('moment');
const request = require('request-promise');
const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');
const config = require('../../config');

const ServiceController = require('../../controllers').Service;
const ServiceExtraController = require('../../controllers').ServiceExtra;
const DiscountCardController=require('../../controllers').DiscountCard;


const getAll = async (req, res) => {
  const companyId = req.user.id;
  const services = await ServiceController.findAllByCompanyId(companyId);
  const extras= await ServiceExtraController.findByCompanyId(companyId);
  const allDiscountCards=await DiscountCardController.findAllByCompanyId(companyId);
  if (!allDiscountCards) {
    throw new AppError(errors.DB_ERROR);
  }
    res.json({
      success: true,
      services,  
      extras,
      discountCards:allDiscountCards
    });
};

const addDiscountCard = async (req, res) => {
  const { discountCard } = req.body;
  discountCard.businessId = req.user.id;
  console.log(discountCard);
  const newDiscountCard = await DiscountCardController.create(discountCard);
    if (!newDiscountCard) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    discountCard: newDiscountCard
  });
};



const editDiscountCard = async (req, res) => {
  const { discountCard } = req.body;
  discountCard.id = req.params.id; 
  const updateDiscountCard = await DiscountCardController.update(discountCard);
  if (!updateDiscountCard) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    discountCards: updateDiscountCard
  });
};

const deleteDiscountCard= async (req, res) => {
  var rowId = req.params.id;  
 await DiscountCardController.delete(rowId);
  res.json({
    success: true,   
  });
};

module.exports = {
  getAll,
  addDiscountCard ,
  editDiscountCard,
  deleteDiscountCard
};
