const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');

const ServiceController = require('../../controllers').Service;
const ServiceCategoryController = require('../../controllers').ServiceCategory;
const ServiceExtraController = require('../../controllers').ServiceExtra;
const EmployeeController = require('../../controllers').Employee;
const ExtraServiceRelationsController=require('../../controllers').ExtraServiceRelatins;
const EmployeeServiceRelationsController=require('../../controllers').EmployeeServiceRelations;

const {ExtraServiceRelations,EmployeeServiceRelations } = require('../../models');

const getServices = async (req, res) => {
  const companyId = req.user.id;
  const categoryId = req.params.id;
  const services = await ServiceController.findAllByCompanyCategoryId(companyId,categoryId);
  if (!services) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    services
  });
};

const getAllServices = async (req, res) => {
  const companyId = req.user.id;  
  console.log(companyId,'companyId');
  const services = await ServiceController.findAllByCompanyId(companyId);
  if (!services) {
    throw new AppError(errors.DB_ERROR);
  }
  const categories = await ServiceCategoryController.findAllByCompanyId(companyId);
  if (!categories) {
    throw new AppError(errors.DB_ERROR);
  }

  const addons= await ServiceExtraController.findByCompanyId(companyId);
  if (!addons) {
    throw new AppError(errors.DB_ERROR);
  }
  const employees= await EmployeeController.findAllByCompanyId(companyId);
  if (!employees) {
    throw new AppError(errors.DB_ERROR);
  }

  const extra_service_relations= await ExtraServiceRelationsController.findAllBesideDeleteByCompanyId(companyId);
  if (!extra_service_relations) {
    throw new AppError(errors.DB_ERROR);
  }

  const employee_service_relations= await EmployeeServiceRelationsController.findAllBesideDeleteByCompanyId(companyId);
  if (!employee_service_relations) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    services,
    categories,
    addons,
    employees,
    extra_service_relations,
    employee_service_relations
  });
};


const addService = async (req, res) => {
  const { service } = req.body;
  console.log(req.user.id,service);
  service.companyId = req.user.id;

  const newService = await ServiceController.create(service);
  if (!newService) {
    throw new AppError(errors.DB_ERROR);
  }
  res.json({
    success: true,
    service: newService
  });
};

const addExtraServiceRelations = async (req, res) => {
  const { relations } = req.body;
  const companyId = req.user.id;   
  const extraIds=relations.extraIds;
  const serviceId=relations.serviceId;

  const extra_service_relations= await ExtraServiceRelationsController.findAllByCompanyId(companyId);
  
  var exist_extras=[];
  var new_extras=[];
  
  const removeAll=await ExtraServiceRelationsController.updateForRemove(serviceId);
  
  for(let i=0;i<extraIds.length;i++){  
    var flag=false;
    extra_service_relations.map(row=>{
       if(row.serviceId==serviceId && extraIds[i]==row.extraId){        
        exist_extras.push(row.extraId);
        flag=true;
       }      
    })   
    if(!flag){
      new_extras.push(new ExtraServiceRelations(0,companyId,serviceId,extraIds[i],0));
    }
  }
 
  const newRelations = await ExtraServiceRelationsController.createMany(new_extras);
  const updatedRelations = await ExtraServiceRelationsController.update(serviceId,exist_extras);

  res.json({
    success: true    
  });
};

const addServiceEmployeeRelations= async (req, res) => {
  const { relations } = req.body;
  const companyId = req.user.id;   
  const employeeIds=relations.employeeIds;
  const serviceId=relations.serviceId;

  const employee_service_relations= await EmployeeServiceRelationsController.findAllByCompanyId(companyId);
  
  var exist_employees=[];
  var new_employees=[];
  
  const removeAll=await EmployeeServiceRelationsController.updateForRemove(serviceId);
  
  for(let i=0;i<employeeIds.length;i++){  
    var flag=false;
    employee_service_relations.map(row=>{
       if(row.serviceId==serviceId && employeeIds[i]==row.employeeId){        
        exist_employees.push(row.employeeId);
        flag=true;
       }      
    })   
    if(!flag){
      new_employees.push(new EmployeeServiceRelations(0,companyId,employeeIds[i],serviceId,0));
    }
  }
 
  const newRelations = await EmployeeServiceRelationsController.createMany(new_employees);
  const updatedRelations = await EmployeeServiceRelationsController.update(serviceId,exist_employees);

  res.json({
    success: true    
  });
};

const deleteService = async (req, res) => {
  const { id } = req.params;
  await ServiceController.delete(id);

  res.json({
    success: true
  });
};

const deleteAllService = async (req, res) => {
  
  const {deleteService}=req.body;
  await ServiceController.deleteAllservice(deleteService);

  res.json({
    success: true
  });
};




const editService = async (req, res) => {
  const { service } = req.body;
  service.id = req.params.id;
  service.companyId = req.user.id;

  const updatedService = await ServiceController.update(service);
  if (!updatedService) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    service: updatedService
  });
};

module.exports = {
  getServices,
  getAllServices,
  addService,
  deleteService,
  editService,
  addExtraServiceRelations,
  addServiceEmployeeRelations,
  deleteAllService
  
};
