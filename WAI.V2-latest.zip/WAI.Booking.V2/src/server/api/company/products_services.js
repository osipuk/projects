const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');

const ProductServiceController = require('../../controllers').ProductService;
const EmployeeController = require('../../controllers').Employee;

const getProducts = async (req, res) => {
  const companyId = req.user.id;
  const categoryId = req.params.id;
  const services = await ProductServiceController.findAllByCompanyCategoryId(companyId,categoryId);
  if (!services) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    services
  });
};

const getAllProductsByBooking = async (req, res) => {
  const companyId = req.user.id;
  const bookingId=req.params.id;  
  const products = await ProductServiceController.findAllByBookingId(bookingId,companyId);
  if (!products) {
    throw new AppError(errors.DB_ERROR);
  }

  const employees=await EmployeeController.findAllByCompanyId(companyId);
  if (!employees) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    products,
    employees
  });
};


const addProduct = async (req, res) => {
  const { product } = req.body;  
  product.companyId = req.user.id;
  const newProduct = await ProductServiceController.create(product);
  if (!newProduct) {
    throw new AppError(errors.DB_ERROR);
  }
  res.json({
    success: true,
    product: newProduct
  });
};

const addProductBooking= async (req, res) => {
  const { product } = req.body;  
  //product.companyId = req.user.id;
  const newRelation = await ProductServiceController.createProductBooking(product);
  if (!newRelation) {
    throw new AppError(errors.DB_ERROR);
  }
  res.json({
    success: true,
    relation: newRelation
  });
};


const deleteProduct = async (req, res) => {
  const { id } = req.params;
  await ProductServiceController.delete(id);

  res.json({
    success: true
  });
};

const editProduct = async (req, res) => {
  const { product } = req.body;
  product.id = req.params.id;
  product.companyId = req.user.id;

  const updatedProduct = await ProductServiceController.update(product);
  if (!updatedProduct) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    service: updatedProduct
  });
};

module.exports = {
  getProducts,
  getAllProductsByBooking,
  addProduct,
  deleteProduct,
  editProduct,
  addProductBooking
};
