const generator = require('generate-password');
const passport = require('passport');
const bcrypt = require('bcrypt-nodejs');
const request = require('request-promise');
const config = require('../../config');
const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');
const nodemailer = require("nodemailer");
const crypto = require('crypto');
const validator = require("email-validator");

const CompanyController = require('../../controllers').Company;
const NotificationsController=require('../../controllers').Notification;
const UserController=require('../../controllers').User;

const login = (req, res, next) => { 
  passport.authenticate('company', {}, (err, company) => {
    if (err) {
      console.log(`Company authentication error: ${err}`);

      return res.json({
        success: false,
        errorCode: err.code
      });
    }   
    if (!company) {
      return res.json({
        success: false,
        errorCode: errors.AUTHENTICATION_ERROR
      });
    }

    return req.login(company, (error) => {
      if (error) {
        console.log(`Company authentication error: ${error}`);
        return res.json({
          success: false,
          errorCode: error.code
        });
      }

      const loggedInCompany = company;      
      delete loggedInCompany.password;

      return res.json({
        success: true,
        company: loggedInCompany
      });
    });
  })(req, res, next);
};

const signup = async (req, res) => {
  const { company } = req.body;
   
  if (!validator.validate(company.email)) {
    throw new AppError(errors.INCORRECT_EMIAIL);
  }

 // const existingCompany = await CompanyController.findByEmail(company.email);
 const existingCompany = await UserController.findByEmail(company.email);
 
  if (existingCompany) {
    throw new AppError(errors.COMPANY_EMAIL_ALREADY_USED);
  }
  const phone = company.phone.replace(/\s/g, '').replace('+', '').trim(); 
  if (phone.length !== 8) {
    throw new AppError(errors.INCORRECT_PHONE);
  }
  
  //const existingPhone = await CompanyController.findByPhone(phone);
 const existingPhone = await UserController.findByPhone(phone);
  if (existingPhone) {
    throw new AppError(errors.PHONE_ALREADY_USED);
  }  
  const verify_code = generator.generate({
    length: 6,
    numbers: true
  });
 
  company.verifyCode = verify_code;
 
 
  const country= await CompanyController.findCountryinfById(company.countryId);
  if (!country) {
    throw new AppError(errors.DB_ERROR);
  }
  
  var phone_number=country[0].country_phone_code+phone;  


  var tokenLen = 100;
  var token = crypto.randomBytes(tokenLen).toString('hex');

    var notifications={};
    notifications.notifyType="EMAIL";
    notifications.toUser=company.email;    
    notifications.roleType="comapny";

    var text = 'Please verify your email by clicking on the following link :\n\n\n '+config.website+'/company/#/email_verify/'+token;
    var subject="Please Verify Your Email";
    notifications.content=text;
    notifications.status="success";
    
   mail_sender(company.email,text,subject).catch(notifications.status="faild");
    await NotificationsController.create(notifications);

    notifications={};
    notifications.notifyType="SMS";
    notifications.toUser=phone_number;
    notifications.content=`Din bookingkode er: ${verify_code}`;
    notifications.roleType="comapny";

  try {
    await request.post({
      url: config.sms.api_url,
      oauth: {
        consumer_key: config.sms.consumer_key,
        consumer_secret: config.sms.consumer_secret
      },
      json: true,
      body: {
        //sender: company.smsSenderName,
        sender: "BookingSMS",
        message: `Din bookingkode er: ${verify_code}`,      
       recipients: [{ msisdn: phone_number }]

      }
    });
  } catch (err) {
    console.log(`Error while send sms: ${err}`);
    notifications.status="failed";
    await NotificationsController.create(notifications);
    throw new AppError(errors.WASNT_ABLE_TO_SEND_SMS);
  }

  company.emailToken=token;

  var urlLen = 15;
  var customUrl = crypto.randomBytes(urlLen).toString('hex');
  company.customUrl=customUrl;
  
  const newCompany = await CompanyController.create(company); 
  if (!newCompany) {
    
    throw new AppError(errors.DB_ERROR);
  }

  company.roleId=1;
  company.companyId=newCompany.id;  
  const newUser = await UserController.create(company);
  if (!newUser) {
    throw new AppError(errors.DB_ERROR);
  }

  notifications.status="success";
  await NotificationsController.create(notifications);

  delete newUser.password;
  delete newUser.email_token;

  res.json({
    success: true,
    company: newUser
  });  

};

const phone_verify = async (req, res) => {
  const { company } = req.body;  
  const existingCompany = await UserController.findByEmail(company.email);
  if(company.verifyCode!=existingCompany.verifyCode){
    throw new AppError(errors.INCORRECT_VERIFY_CODE);
  }
  var update={};
  update.id=existingCompany.id;
  update.phoneVeryfied=1;
  var updatedCompany= await UserController.update(update);

  var companyinf=await UserController.findByEmailWithCompany(updatedCompany.email);

  req.login(company, (error) => {
    if (error) {
      console.log(`Company authentication error: ${error}`);
      return res.json({
        success: false,
        errorCode: error.code
      });
    }

    

    //const loggedInCompany = company;
    delete updatedCompany.password;
    delete updatedCompany.verify_code;
    return res.json({
      success: true,
      company: companyinf
    });
  });

}

const phone_resend= async (req, res) => {
  const { user } = req.body;
  const existingCompany = await CompanyController.findByAllUrl(user.email);
  if (!existingCompany) {
    throw new AppError(errors.COMPANY_EMAIL_ALREADY_USED);
  }
  const verify_code = generator.generate({
    length: 6,
    numbers: true
  });

  var phone_number=existingCompany.country_phone_code+existingCompany.phone;
 
  var update={};
  update.id=existingCompany.id;
  update.verifyCode=verify_code;
  await CompanyController.update(update);

  var notifications={};
  notifications.notifyType="SMS";
  notifications.toUser=phone_number;
  notifications.content=`Din bookingkode er: ${verify_code}`;
  notifications.roleType="comapny";

  try {
    await request.post({
      url: config.sms.api_url,
      oauth: {
        consumer_key: config.sms.consumer_key,
        consumer_secret: config.sms.consumer_secret
      },
      json: true,
      body: {
        //sender: company.smsSenderName,
        sender: "BookingSMS",
        message: `Din bookingkode er: ${verify_code}`,      
       recipients: [{ msisdn: phone_number }]

      }
    });
  } catch (err) {
    notifications.status="failed";
    await NotificationsController.create(notifications);
    console.log(`Error while send sms: ${err}`);
    throw new AppError(errors.WASNT_ABLE_TO_SEND_SMS);
  }

  notifications.status="success";
  await NotificationsController.create(notifications);

  res.json({
    success: true
  });
}

const logout = async (req, res) => {
  req.logout();

  res.json({
    success: true
  });
};

const email_verify = async (req, res) => {
  var token = req.params.id;
  var existCompany = await UserController.findByToken(token);    
  if (!existCompany) {
    throw new AppError(errors.INVALID_EMAIL_TOKEN);
  }

  var update={};
  update.id=existCompany.companyId;
  update.emailVeryfied=1;
  await UserController.update1(update);
  res.json({
    success: true
  });
};

const email_send= async (req, res) => {
    const {email}=req.body;   
    const existingCompany = await CompanyController.findByAllUrl(email);
    if (!existingCompany) {
      throw new AppError(errors.EMAIL_NOT_EXIST);
    }

    
    var tokenLen = 100;
    var token = crypto.randomBytes(tokenLen).toString('hex');
  //var text = 'You\'ve received this mail because you requested a password change :\n\n\n http://localhost:3000/company/#/email_verify/'+token;
      var text = "You\'ve received this mail because you requested a password change for "+email+" on "+config.website+". \n Please click here to change your password. \n";
      text+="Or copy and paste the following url into your browser:\n\n "+config.website+"/company/#/password_reset/"+token
      var subject="Reset password instructions";

      var notifications={};
      notifications.notifyType="EMAIL";
      notifications.toUser=email;    
      notifications.roleType="comapny";
      notifications.content=text;

      mail_sender(email,text,subject).catch(notifications.status="failed");

      notifications.status="success";
      await NotificationsController.create(notifications);

     var update=existingCompany;
     update.emailToken=token;
     const updatedCompany= await CompanyController.update(update);

    res.json({
      success: true
    });

}

async function mail_sender(email,text,subject){
  // Generate test SMTP service account from ethereal.email
  // Only needed if you don't have a real mail account for testing
  //let account = await nodemailer.createTestAccount();

  try{
  // create reusable transporter object using the default SMTP transport
  let transporter = nodemailer.createTransport({
    host: config.email.server_name,
    port: 587,
    secure: false, // true for 465, false for other ports
    auth: {
      user: config.email.user_name, // generated ethereal user
      pass: config.email.password // generated ethereal password
    }
  }); 

  // setup email data with unicode symbols
  let mailOptions = {
    from: config.email.sender_email, // sender address
    to: email, // list of receivers
    subject: subject, // Subject line
    text: text, // plain text body
    //html: "<b>Hello world?</b>" // html body
  };
  // send mail with defined transport object
  let info = await transporter.sendMail(mailOptions)
  console.log("Message sent: %s", info.messageId);
} catch(err){ 
  throw new AppError(errors.WASNT_ABLE_TO_SEND_EMAIL);

}
}

const token_check = async (req, res) => {
  var token = req.params.id;
  var existCompany = await CompanyController.findByToken(token);
  if (!existCompany) {
    throw new AppError(errors.INVALID_EMAIL_TOKEN);
  }
  res.json({
    success: true
  });

}

const password_reset= async (req, res) => {
  const {password}=req.body;
  const token=req.params.id;
  var existCompany = await CompanyController.findByToken(token);
  if (!existCompany) {
    throw new AppError(errors.INVALID_EMAIL_TOKEN);
  }
  var company=existCompany;
  company.password=bcrypt.hashSync(password);
  company.emailToken="";
  const updateCompany = await CompanyController.update(company);
  if (!updateCompany) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true   
  });
 
}

module.exports = {
  login,
  signup,
  logout,
  phone_verify,
  phone_resend,
  email_verify  ,
  email_send,
  token_check,
  password_reset
  
};
