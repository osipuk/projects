const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');

const BookingHoursController = require('../../controllers').BookingHours;

const getHours = async (req, res) => {
  const companyId = req.user.id;
  const employeeId=req.params.id  
  const hours = await BookingHoursController.findAllByCompanyId(companyId,employeeId);
  if (!hours) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    bookingHours: hours
  });
};

const editHours = async (req, res) => { 
  const { hours } = req.body; 
  hours.companyId = req.user.id;  
  const updatedHours = await BookingHoursController.update(hours);
  if (!updatedHours) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    bookingHours: updatedHours
  });
};

const deleteHours = async (req, res) => { 
  const workHourId=req.params.id  
   await BookingHoursController.delete(workHourId);
   res.json({
    success: true
  });
};


const addHours = async (req, res) => { 
  const { hours } = req.body;
  hours.companyId = req.user.id;
  const newHours = await BookingHoursController.create(hours);
  if (!newHours) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    bookingHours: newHours
  });
};

module.exports = {
  getHours,
  editHours,
  addHours,
  deleteHours
};
