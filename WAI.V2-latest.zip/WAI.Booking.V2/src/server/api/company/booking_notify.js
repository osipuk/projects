const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');
const BookingNotifyController=require('../../controllers').BookingNotify;

const get = async (req, res) => {
  const { id } = req.params;

  const employee = await BookingNotifyController.findById(id);
  if (!employee) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    employee
  });
};

const getAll = async (req, res) => {
  const companyId = req.user.id;
  const BookingNotify = await BookingNotifyController.findAllByCompanyId(companyId);
  if (!BookingNotify) {
    throw new AppError(errors.DB_ERROR);
  }
  res.json({
    success: true,
    BookingNotify
  });
};


const update = async (req, res) => { 
  var BookingNotify={};
  BookingNotify.id = req.params.id;  
  BookingNotify.seen = 1;
  const updatedBookingNotify = await BookingNotifyController.update(BookingNotify);
  if (!updatedBookingNotify) {
    throw new AppError(errors.DB_ERROR);
  }
  res.json({
    success: true,
    updatedBookingNotify
  });
};



module.exports = {
  get,
  getAll, 
  update,
  
};
