const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');

const ProductController = require('../../controllers').Product;
const ProductCategoryController = require('../../controllers').ProductCategory;

const getProducts = async (req, res) => {
  const companyId = req.user.id;
  const categoryId = req.params.id;
  const services = await ProductController.findAllByCompanyCategoryId(companyId,categoryId);
  if (!services) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    services
  });
};

const getAllProducts = async (req, res) => {
  const companyId = req.user.id;  
  const products = await ProductController.findAllByCompanyId(companyId);
  if (!products) {
    throw new AppError(errors.DB_ERROR);
  }
  const categories = await ProductCategoryController.findAllByCompanyId(companyId);
  if (!categories) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    products,
    categories
  });
};


const addProduct = async (req, res) => {
  const { product } = req.body;  
  product.companyId = req.user.id;
  const newProduct = await ProductController.create(product);
  if (!newProduct) {
    throw new AppError(errors.DB_ERROR);
  }
  res.json({
    success: true,
    product: newProduct
  });
};

const addProductBooking= async (req, res) => {
  const { product } = req.body;  
  //product.companyId = req.user.id;
  const newRelation = await ProductController.createProductBooking(product);
  if (!newRelation) {
    throw new AppError(errors.DB_ERROR);
  }
  res.json({
    success: true,
    relation: newRelation
  });
};

const deleteProductBooking = async (req, res) => {
  const { id } = req.params;  
  await ProductController.deleteProductBooking(id);

  res.json({
    success: true
  });
};

const deleteService = async (req, res) => {
  const { id } = req.params;
  await ProductController.delete(id);

  res.json({
    success: true
  });
};

const editProduct = async (req, res) => {
  const { product } = req.body;
  product.id = req.params.id;
  product.companyId = req.user.id;

  const updatedProduct = await ProductController.update(product);
  if (!updatedProduct) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    service: updatedProduct
  });
};

const deleteAllProducts= async (req, res) => {
  const {deleteProduct}=req.body;
 
  await ProductController.deleteAllProduct(deleteProduct);

  res.json({
    success: true
  });
}

module.exports = {
  getProducts,
  getAllProducts,
  addProduct,
  deleteService,
  editProduct,
  addProductBooking,
  deleteProductBooking,
  deleteAllProducts
};
