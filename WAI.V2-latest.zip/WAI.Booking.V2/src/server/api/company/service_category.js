const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');

const ServiceCategoryController = require('../../controllers').ServiceCategory;

const getCategories = async (req, res) => {
  const companyId = req.user.id;

  const categories = await ServiceCategoryController.findAllByCompanyId(companyId);
  if (!categories) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    serviceCategories: categories
  });
};

const addCategory = async (req, res) => {
  const { name } = req.body;
  const companyId = req.user.id;  
  const {defaultServiceCategory}=req.body;
  const {description}=req.body;
 
  var category={};
  category.name=name;
  category.companyId=companyId; 
  category.defaultServiceCategory=defaultServiceCategory;
  category.description=description;
  if(defaultServiceCategory){
   const updated= await ServiceCategoryController.updateByCompanyId(companyId);
    if (!updated) {
      throw new AppError(errors.DB_ERROR);
    }
  }

  const newCategory = await ServiceCategoryController.create(category);
  if (!newCategory) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    serviceCategory: newCategory
  });
};

const deleteCategory = async (req, res) => {
  const { id } = req.params;
  await ServiceCategoryController.delete(id);

  res.json({
    success: true
  });
};

const deleteAllCategory = async (req, res) => {
  const {deleteCategoris}=req.body;
  await ServiceCategoryController.deleteAllCategory(deleteCategoris);

  res.json({
    success: true
  });
};

const editCategory = async (req, res) => {
  const { name } = req.body;
  const { id } = req.params;
  const companyId = req.user.id;
  const {defaultServiceCategory}=req.body;
  const {description}=req.body;

  if(defaultServiceCategory){
    const updated= await ServiceCategoryController.updateByCompanyId(companyId);
     if (!updated) {
       throw new AppError(errors.DB_ERROR);
     }
   }
   
  const updatedCategory = await ServiceCategoryController.update({ id, name, companyId,defaultServiceCategory,description });
  if (!updatedCategory) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    serviceCategory: updatedCategory
  });
};

module.exports = {
  getCategories,
  addCategory,
  deleteCategory,
  editCategory,
  deleteAllCategory
};
