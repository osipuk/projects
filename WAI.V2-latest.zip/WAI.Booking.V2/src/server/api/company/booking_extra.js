const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');

const BookingExtraController = require('../../controllers').BookingExtra;

const getExtrasByBookingId = async (req, res) => {
  const { id } = req.params;

  const extras = await BookingExtraController.findAllByBookingId(id);
  if (!extras) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    bookingExtras: extras
  });
};


const editExtraBookById = async (req, res) => {
  const { book_extra } = req.body;
  const bookExtraId=req.params.id;  
  const updateBookExtra = await BookingExtraController.update(book_extra,bookExtraId);
  if (!updateBookExtra) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    bookingHours: updateBookExtra
  });
};

const create= async (req, res) => {
  const { book_extra } = req.body;
  console.log(book_extra);
  const newBookServiceExtra = await BookingExtraController.create(book_extra);
  if (!newBookServiceExtra) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    bookServiceExtra: newBookServiceExtra    
  });
};

const del=async (req, res) => {
  const { id } = req.params;  
  await BookingExtraController.delete(id);

  res.json({
    success: true
  });
};


module.exports = {
  getExtrasByBookingId,
  editExtraBookById,
  create,
  del
  
};
