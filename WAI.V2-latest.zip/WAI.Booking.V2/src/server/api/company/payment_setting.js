const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');

const PaymentSettingController = require('../../controllers').PaymentSetting;

const addSetting = async (req, res) => {
  const { settings } = req.body;
  const companyId = req.user.id;  
  settings.companyId=companyId;
  const newPaymentSetting = await PaymentSettingController.create(settings);
  if (!newPaymentSetting) {
    throw new AppError(errors.DB_ERROR);
  }
  res.json({
    success: true,
    paymentSetting: newPaymentSetting
  });
};


const getPaymentSetting = async (req, res) => {
  const companyId = req.user.id;  
  const settings = await PaymentSettingController.findByCompanyId(companyId);
  if (!settings) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    settings
  });
};

const editPaymentSetting = async (req, res) => {
  const { settings } = req.body;
  const { id } = req.params;
  const companyId = req.user.id;
  settings.id=id;  
  const updatedSettings = await PaymentSettingController.update(settings);
  if (!updatedSettings) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    paymentSetting: updatedSettings
  });
};

module.exports = { 
  addSetting,  
  getPaymentSetting,
  editPaymentSetting
};
