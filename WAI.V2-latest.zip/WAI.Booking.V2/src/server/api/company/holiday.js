const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');

const HolidayController = require('../../controllers').Holiday;
const HolidayWorkController = require('../../controllers').HolidayWork;

const getAllHolidays = async (req, res) => {
  const country_id = req.params.id;  
  const companyId=req.user.id;
  const holidays = await HolidayController.findAllByCompanyId(country_id);
  if (!holidays) {
    throw new AppError(errors.DB_ERROR);
  }
  const holidayWorks = await HolidayWorkController.findAllByCompanyId(companyId);
  if (!holidayWorks) {
    throw new AppError(errors.DB_ERROR);
  }
  res.json({
    success: true,
    holidays,
    holidayWorks
  });
};

const createHolidayWork= async (req, res) => {
  const companyId = req.user.id;  
  const {holiday_work}  =req.body;
  holiday_work.companyId=companyId;
  console.log(holiday_work,'yyy');
  const existHolidayWork=await HolidayWorkController.findByHolidayId(holiday_work.holidayId);
  if(existHolidayWork){
    holiday_work.id=existHolidayWork.id;
    var newHolidayWork = await HolidayWorkController.update(holiday_work);
  }
  else{
    var newHolidayWork = await HolidayWorkController.create(holiday_work);
  }
  if (!newHolidayWork) {
    throw new AppError(errors.DB_ERROR);
  }
  res.json({
    success: true,
    holidayWork: newHolidayWork
  });

};

const getHolidayWork= async (req, res) => {
  const companyId = req.user.id;  
  const holidayWorks = await HolidayWorkController.findAllByCompanyId(companyId);
  if (!holidayWorks) {
    throw new AppError(errors.DB_ERROR);
  }
  res.json({
    success: true,
    holidayWorks
  });
};

module.exports = {
  getAllHolidays,
  createHolidayWork,
  

};
