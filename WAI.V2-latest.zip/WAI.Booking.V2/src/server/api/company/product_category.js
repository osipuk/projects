const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');

const ProductCategoryController = require('../../controllers').ProductCategory;

const getCategories = async (req, res) => {
  const companyId = req.user.id;

  const categories = await ProductCategoryController.findAllByCompanyId(companyId);
  if (!categories) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    productCategories: categories
  });
};

const addCategory = async (req, res) => {
  const { name } = req.body;
  const companyId = req.user.id;  
  
  const newCategory = await ProductCategoryController.create({ name, companyId });
  if (!newCategory) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    serviceCategory: newCategory
  });
};

const deleteCategory = async (req, res) => {
  const { id } = req.params;
  await ProductCategoryController.delete(id);
  res.json({
    success: true
  });
};

const editCategory = async (req, res) => {
  const { name } = req.body;
  const { id } = req.params;
  const companyId = req.user.id;

  const updatedCategory = await ProductCategoryController.update({ id, name, companyId });
  if (!updatedCategory) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    serviceCategory: updatedCategory
  });
};

const deleteAllCategory= async (req, res) => {
  const {deleteCategory}=req.body; 
  await ProductCategoryController.deleteAllCategory(deleteCategory);

  res.json({
    success: true
  });
}

module.exports = {
  getCategories,
  addCategory,
  deleteCategory,
  editCategory,
  deleteAllCategory
};
