const router = require('express').Router();

const { Company } = require('../../models');
const { Customer } = require('../../models');

const mw = require('../middleware');
const auth = require('./auth');
const company = require('./company');
const service = require('./service');
const serviceCategory = require('./service_category');
const serviceExtra = require('./service_extra');
const booking = require('./booking');
const bookingExtra = require('./booking_extra');
const bookingService = require('./booking_service');
const bookingHours = require('./booking_hours');
const employee = require('./employee');
const productCategory = require('./product_category');
const product = require('./product');
const productService = require('./products_services');
const card=require('./card');
const payments=require('./payments');
const paymentSetting=require('./payment_setting');
const  customer = require('../customer/customer');
const about=require('./about');
const terms=require('./terms');
const holiday=require('./holiday');
const vacation=require('./vacation');
const images=require('./images');
const bookingNotify=require('./booking_notify');
const discountCard=require('./discount_card');
const giftCard=require('./gift_card');
const discountCode=require('./discount_code');

// auth
router.post('/login', auth.login);
router.post('/signup', mw.async(auth.signup));
router.post('/phone_verify', mw.async(auth.phone_verify));
router.post('/resend' ,mw.async(auth.phone_resend));
router.post('/send_email' ,mw.async(auth.email_send));
router.post('/logout', mw.auth, mw.grant(Company.Type), mw.async(auth.logout));
router.get('/email_verify/:id', mw.async(auth.email_verify));
router.get('/token_check/:id', mw.async(auth.token_check));
router.get('/password_reset/:id', mw.async(auth.email_verify));
router.post('/password_reset/:id', mw.async(auth.password_reset));
// company
router.get('/', mw.auth, mw.grant(Company.Type), mw.async(company.get));
router.put('/', mw.auth, mw.grant(Company.Type), mw.async(company.edit));
router.get('/country', mw.auth, mw.grant(Company.Type), mw.async(company.getCountryInf));
router.get('/countrys',  mw.async(company.getCountrys));

// service
router.get('/services/:id', mw.auth, mw.grant(Company.Type), mw.async(service.getServices));
router.get('/services', mw.auth, mw.grant(Company.Type), mw.async(service.getAllServices)); // for the service on the admin panel
router.post('/service', mw.auth, mw.grant(Company.Type), mw.async(service.addService));
router.post('/service_extra_relations', mw.auth, mw.grant(Company.Type), mw.async(service.addExtraServiceRelations)); //add the extra service relations 
router.post('/employee_extra_relations', mw.auth, mw.grant(Company.Type), mw.async(service.addServiceEmployeeRelations)); //add the employee service relations 
router.put('/service/:id', mw.auth, mw.grant(Company.Type), mw.async(service.editService));
router.delete('/service/:id', mw.auth, mw.grant(Company.Type), mw.async(service.deleteService));
router.post('/allservice', mw.auth, mw.grant(Company.Type), mw.async(service.deleteAllService));

// service category
router.get('/service/category', mw.auth, mw.grant(Company.Type), mw.async(serviceCategory.getCategories));
router.post('/service/category', mw.auth, mw.grant(Company.Type), mw.async(serviceCategory.addCategory));
router.put('/service/category/:id', mw.auth, mw.grant(Company.Type), mw.async(serviceCategory.editCategory));
router.delete('/service/category/:id', mw.auth, mw.grant(Company.Type), mw.async(serviceCategory.deleteCategory));
router.post('/service/allcategory', mw.auth, mw.grant(Company.Type), mw.async(serviceCategory.deleteAllCategory));// for delete all

// service extra
router.get('/service/extra/:id', mw.auth, mw.grant(Company.Type), mw.async(serviceExtra.getExtras));
router.get('/service/extras/:ids', mw.auth, mw.grant(Company.Type), mw.async(serviceExtra.getExtrasByServiceIds));
router.post('/service/extra', mw.auth, mw.grant(Company.Type), mw.async(serviceExtra.addExtra));
router.put('/service/extra/:id', mw.auth, mw.grant(Company.Type), mw.async(serviceExtra.editExtra));
router.post('/service/extras', mw.auth, mw.grant(Company.Type), mw.async(serviceExtra.editExtras));
router.delete('/service/extra/:id', mw.auth, mw.grant(Company.Type), mw.async(serviceExtra.deleteExtra));
router.post('/service/allextra', mw.auth, mw.grant(Company.Type), mw.async(serviceExtra.deleteAllExtra));

// booking
router.put('/booking/:id/accept', mw.auth, mw.grant(Company.Type), mw.async(booking.acceptBooking));
router.put('/booking/:id/reject', mw.auth, mw.grant(Company.Type), mw.async(booking.rejectBooking));
router.put('/booking/:id/cancel', mw.auth, mw.grant(Company.Type), mw.async(booking.cancelBooking));
router.put('/booking/:id/completed', mw.auth, mw.grant(Company.Type), mw.async(booking.CompletedBooking));
router.put('/booking/:id/stayed_away', mw.auth, mw.grant(Company.Type), mw.async(booking.StayedBooking));
//router.put('/booking/:id', mw.auth, mw.grant(Company.Type), mw.async(booking.editBooking));// must

//change the booking time
router.put('/booking/:id/update', mw.auth, mw.grant(Company.Type), mw.async(booking.editBooking));

router.get('/booking', mw.auth, mw.grant(Company.Type), mw.async(booking.getBookings));
router.get('/booking/status/:status', mw.auth, mw.grant(Company.Type), mw.async(booking.getBookingsByStatus));
router.get('/booking/date', mw.auth, mw.grant(Company.Type), mw.async(booking.getBookingsByDateRange));

// booking services
router.get('/booking/:id/service', mw.auth, mw.grant(Company.Type), mw.async(bookingService.getServicesByBookingId));
router.put('/booking/service/:id', mw.auth, mw.grant(Company.Type), mw.async(bookingService.editServeBookById));
router.delete('/booking/service/:id', mw.auth, mw.grant(Company.Type), mw.async(bookingService.del));
router.post('/booking/service', mw.auth, mw.grant(Company.Type), mw.async(bookingService.create));
router.post('/booking/service_extra', mw.auth, mw.grant(Company.Type), mw.async(bookingExtra.create));
router.delete('/booking/service_extra/:id', mw.auth, mw.grant(Company.Type), mw.async(bookingExtra.del));

// booking extra
router.get('/booking/:id/extra', mw.auth, mw.grant(Company.Type), mw.async(bookingExtra.getExtrasByBookingId));
// booking extra update
router.put('/booking/extra/:id', mw.auth, mw.grant(Company.Type), mw.async(bookingExtra.editExtraBookById));

// booking hours
router.get('/booking/hours/:id', mw.auth, mw.grant(Company.Type), mw.async(bookingHours.getHours));
router.delete('/booking/hours/:id', mw.auth, mw.grant(Company.Type), mw.async(bookingHours.deleteHours));
router.post('/booking/hours', mw.auth, mw.grant(Company.Type), mw.async(bookingHours.addHours));
router.put('/booking/hours', mw.auth, mw.grant(Company.Type), mw.async(bookingHours.editHours));

// employee
router.get('/employee', mw.auth, mw.grant(Company.Type), mw.async(employee.getAll));
router.get('/employee/:id', mw.auth, mw.grant(Company.Type), mw.async(employee.get));
router.post('/employee', mw.auth, mw.grant(Company.Type), mw.async(employee.create));
router.put('/employee/:id', mw.auth, mw.grant(Company.Type), mw.async(employee.update));
router.delete('/employee/:id', mw.auth, mw.grant(Company.Type), mw.async(employee.del));

// product category
router.get('/product/category', mw.auth, mw.grant(Company.Type), mw.async(productCategory.getCategories));
router.post('/product/category', mw.auth, mw.grant(Company.Type), mw.async(productCategory.addCategory));
router.post('/product/category_delete', mw.auth, mw.grant(Company.Type), mw.async(productCategory.deleteAllCategory));
router.put('/product/category/:id', mw.auth, mw.grant(Company.Type), mw.async(productCategory.editCategory));
router.delete('/product/category/:id', mw.auth, mw.grant(Company.Type), mw.async(productCategory.deleteCategory));

// product table
router.get('/products', mw.auth, mw.grant(Company.Type), mw.async(product.getAllProducts));
router.post('/products/delete', mw.auth, mw.grant(Company.Type), mw.async(product.deleteAllProducts));
router.post('/product', mw.auth, mw.grant(Company.Type), mw.async(product.addProduct));
router.put('/product/:id', mw.auth, mw.grant(Company.Type), mw.async(product.editProduct));
router.delete('/products/:id', mw.auth, mw.grant(Company.Type), mw.async(product.deleteService));

//produts_services table
router.get('/products_services/:id', mw.auth, mw.grant(Company.Type), mw.async(productService.getAllProductsByBooking));// get by bookingId
router.put('/products_services/:id', mw.auth, mw.grant(Company.Type), mw.async(productService.editProduct));// get by bookingId
router.post('/products_services', mw.auth, mw.grant(Company.Type), mw.async(productService.addProduct));
router.delete('/products_services/:id', mw.auth, mw.grant(Company.Type), mw.async(productService.deleteProduct));

//BookingProductRelations
router.post('/product_booking', mw.auth, mw.grant(Company.Type), mw.async(product.addProductBooking));
router.delete('/product_booking/:id', mw.auth, mw.grant(Company.Type), mw.async(product.deleteProductBooking));

router.get('/cards', mw.auth, mw.grant(Company.Type), mw.async(card.get));

//payments on go payment page.
router.post('/payments', mw.auth, mw.grant(Company.Type), mw.async(payments.addPayments));
router.put('/payments/:id', mw.auth, mw.grant(Company.Type), mw.async(payments.editPayments));
router.get('/payments/:id/booking', mw.auth, mw.grant(Company.Type), mw.async(payments.getPaymentByBooking));//by customerId
router.get('/payment/all', mw.auth, mw.grant(Company.Type), mw.async(payments.getAll));


router.post('/payment_setting', mw.auth, mw.grant(Company.Type), mw.async(paymentSetting.addSetting));
router.put('/payment_setting/:id', mw.auth, mw.grant(Company.Type), mw.async(paymentSetting.editPaymentSetting));
router.get('/payment_setting', mw.auth, mw.grant(Company.Type), mw.async(paymentSetting.getPaymentSetting));

// employee
router.get('/customer', mw.auth, mw.grant(Company.Type), mw.async(customer.getAllBooked));
router.get('/customer/:id/comment', mw.auth, mw.grant(Company.Type), mw.async(customer.getCommentByCustomerId));
router.put('/customer/comment/:id', mw.auth, mw.grant(Company.Type), mw.async(customer.changeComment));
router.post('/customer/:id/comment', mw.auth, mw.grant(Company.Type), mw.async(customer.creatComment));
//router.put('/product_booking', mw.auth, mw.grant(Company.Type), mw.async(product.addProductBooking));

//language
router.get('/languages',  mw.async(about.getLanguage));

//About description
router.post('/about', mw.auth, mw.grant(Company.Type), mw.async(about.create));
router.put('/about/:id', mw.auth, mw.grant(Company.Type), mw.async(about.update));
router.get('/about', mw.auth, mw.grant(Company.Type), mw.async(about.getAll));
router.delete('/about/:id', mw.auth, mw.grant(Company.Type), mw.async(about.del));

//Terms of services
router.get('/termsofservice', mw.auth, mw.grant(Company.Type), mw.async(terms.getAll));
router.post('/termsofservice', mw.auth, mw.grant(Company.Type), mw.async(terms.create));
router.put('/termsofservice/:id', mw.auth, mw.grant(Company.Type), mw.async(terms.update));
router.delete('/termsofservice/:id', mw.auth, mw.grant(Company.Type), mw.async(terms.del));

// holiday
router.get('/holiday/:id/country', mw.auth, mw.grant(Company.Type), mw.async(holiday.getAllHolidays));
router.post('/holiday/work', mw.auth, mw.grant(Company.Type), mw.async(holiday.createHolidayWork));

//vacation
router.post('/vacation/employee/:id', mw.auth, mw.grant(Company.Type), mw.async(vacation.create));
router.put('/vacation/:id', mw.auth, mw.grant(Company.Type), mw.async(vacation.update));
router.delete('/vacation/:id', mw.auth, mw.grant(Company.Type), mw.async(vacation.del));
router.post('/vacation/employee/:id/bookcancel', mw.auth, mw.grant(Company.Type), mw.async(vacation.createWithYes));
router.put('/vacation/:id/bookcancel', mw.auth, mw.grant(Company.Type), mw.async(vacation.updateWithYes));
router.get('/vacation/employee/:id', mw.auth, mw.grant(Company.Type), mw.async(vacation.get));


//for checkout pay
router.get('/bookedservices/upfront/:id', mw.auth, mw.grant(Company.Type), mw.async(booking.getcheckout));

//image upload/get
router.post('/upload_image', mw.auth, mw.grant(Company.Type), mw.async(images.submit));
router.get('/upload_image', mw.auth, mw.grant(Company.Type), mw.async(images.get));

//booking notify
router.get('/booking_notify', mw.auth, mw.grant(Company.Type), mw.async(bookingNotify.getAll));
router.put('/booking_notify/:id', mw.auth, mw.grant(Company.Type), mw.async(bookingNotify.update));

//create new booking
router.get('/create_booking/getallinf', mw.auth, mw.grant(Company.Type), mw.async(booking.allForBooking));
router.post('/create_booking/getcustomer', mw.auth, mw.grant(Company.Type), mw.async(customer.getByPhone));
router.post('/create_booking/createcustomer', mw.auth, mw.grant(Company.Type), mw.async(customer.createCustomer));
router.post('/employee/booked/times', mw.auth, mw.grant(Company.Type), mw.async(booking.getAllByDay)); // for one employee
router.post('/create_booking/newbooking', mw.auth, mw.grant(Company.Type), mw.async(booking.create));

//setting password
router.post('/setting/password', mw.auth, mw.grant(Company.Type), mw.async(company.checkPassword));

//discount_card
router.get('/discount_card/getall', mw.auth, mw.grant(Company.Type), mw.async(discountCard.getAll));
router.post('/discount_card/save', mw.auth, mw.grant(Company.Type), mw.async(discountCard.addDiscountCard));
router.put('/discount_card/update/:id', mw.auth, mw.grant(Company.Type), mw.async(discountCard.editDiscountCard));
router.delete('/discount_card/delete/:id', mw.auth, mw.grant(Company.Type), mw.async(discountCard.deleteDiscountCard));

//gift Card
router.post('/gift_card/save', mw.auth, mw.grant(Company.Type), mw.async(giftCard.addGiftCard));
router.get('/gift_card/getall', mw.auth, mw.grant(Company.Type), mw.async(giftCard.getAll));
router.put('/gift_card/update/:id', mw.auth, mw.grant(Company.Type), mw.async(giftCard.editGiftCard));
router.delete('/gift_card/delete/:id', mw.auth, mw.grant(Company.Type), mw.async(giftCard.deleteGiftCard));

//discount code
router.post('/discount_code/save', mw.auth, mw.grant(Company.Type), mw.async(discountCode.addDiscountCode));
router.put('/discount_code/update/:id', mw.auth, mw.grant(Company.Type), mw.async(discountCode.editDiscountCode));
router.get('/discount_code/getall', mw.auth, mw.grant(Company.Type), mw.async(discountCode.getAll));
router.delete('/discount_code/delete/:id', mw.auth, mw.grant(Company.Type), mw.async(discountCode.deleteDiscountCode));

module.exports = router;
