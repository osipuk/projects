const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');

const PaymentsController = require('../../controllers').Payments;
//onst CustomerController=require('../../controllers').Customer;

const addPayments = async (req, res) => {
  const { payments } = req.body;
  const companyId = req.user.id;  
  payments.companyId=companyId;
  const newPayments = await PaymentsController.create(payments);
  if (!newPayments) {
    throw new AppError(errors.DB_ERROR);
  }
  res.json({
    success: true,
    payments: newPayments
  });
};

const getPaymentByBooking = async (req, res) => {
  const companyId = req.user.id;
  const bookingId = req.params.id;
  const payments = await PaymentsController.findByCompanyBookingId(companyId,bookingId);
  if (!payments) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    payments
  });
};

const getAll = async (req, res) => {
  const companyId = req.user.id;  
  const payments = await PaymentsController.findByCompanyId(companyId);
  if (!payments) {
    throw new AppError(errors.DB_ERROR);
  } 

  res.json({
    success: true,
    payments
  });
};

const editPayments = async (req, res) => {
  const { payments } = req.body;
  const { id } = req.params;
  const companyId = req.user.id;
  payments.companyId=companyId;
  payments.id=id;
  const updatePayments = await PaymentsController.update(payments);
  if (!updatePayments) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    serviceCategory: updatePayments
  });
};

module.exports = { 
  addPayments,  
  editPayments,
  getPaymentByBooking,
  getAll
};
