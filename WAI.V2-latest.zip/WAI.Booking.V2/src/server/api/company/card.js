const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');

const CardController = require('../../controllers').Card;

const get = async (req, res) => {  

  const cards = await CardController.findAll();
  if (!cards) {
    throw new AppError(errors.DB_ERROR);
  }
  
  res.json({
    success: true,
    cards
  });
};

module.exports = {
  get
};
