const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');

const TermsController = require('../../controllers').Terms;
const get = async (req, res) => {
  const { id } = req.params;

  const employee = await TermsController.findById(id);
  if (!employee) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    employee
  });
};

const getAll = async (req, res) => {
  const companyId = req.user.id;

  const terms = await TermsController.findAllByCompanyId(companyId);
  if (!terms) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    terms
  });
};

const create = async (req, res) => {
  const { terms } = req.body;
  let companyId=req.user.id;
  terms.companyId = req.user.id;

  const exitTerms=await TermsController.findByLanguageId(terms.languageId,companyId);
  if (exitTerms) {
    throw new AppError(errors.LANGUAGE_ABOUT_ALREADY_EXIST);
  }

  const newTerm= await TermsController.create(terms);
  if (!newTerm) {
    throw new AppError(errors.DB_ERROR);
  }
  res.json({
    success: true,
    terms: newTerm
  });
};

const update = async (req, res) => {
  const { terms } = req.body;
  terms.id = req.params.id;
  terms.companyId = req.user.id;
  console.log(terms,'termssdff');
  const exitTerms=await TermsController.findByLanguageId(terms.languageId,terms.companyId);
  if (exitTerms.id!=req.params.id) {
    throw new AppError(errors.LANGUAGE_ABOUT_ALREADY_EXIST);
  }

  console.log(terms,'termssdff');
  const updatedTerms = await TermsController.update(terms);
  if (!updatedTerms) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    terms: updatedTerms
  });
};

const del = async (req, res) => {
  const { id } = req.params;
  await TermsController.delete(id);

  res.json({
    success: true
  });
};


const getLanguage = async (req, res) => {
  const languages = await TermsController.findAllLanguage();
  if (!languages) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    languages
  });
};

module.exports = {
  get,
  getAll,
  create,
  update,
  del,
  getLanguage
};
