const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');

const BookingServiceController = require('../../controllers').BookingService;
const BookingExtraController = require('../../controllers').BookingExtra;

const getServicesByBookingId = async (req, res) => {
  const { id } = req.params;

  const services = await BookingServiceController.findAllByBookingId(id);
  if (!services) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    bookingServices: services
  });
};

const editServeBookById = async (req, res) => {
  const { book_service } = req.body;
  const bookServiceId=req.params.id;
  book_service.id=bookServiceId;
  const updateBookService = await BookingServiceController.update(book_service);
  if (!updateBookService) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    bookingHours: updateBookService
  });
};

const create= async (req, res) => {
  const { book_service } = req.body;
  console.log(book_service);
  const newBookService = await BookingServiceController.create(book_service);
  if (!newBookService) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    bookService: newBookService
  });
};

const del=async (req, res) => {
  const { id } = req.params;  
  var bookingService=await BookingServiceController.findById(id);
 
  await BookingServiceController.delete(id);

  await BookingExtraController.delete1(bookingService.bookingId,bookingService.serviceId);


  res.json({
    success: true
  });
};

module.exports = {
  getServicesByBookingId,
  editServeBookById,
  create,
  del
};
