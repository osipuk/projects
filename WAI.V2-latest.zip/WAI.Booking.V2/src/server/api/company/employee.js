const bcrypt = require('bcrypt-nodejs');
const errors = require('../../../common/error_codes');
const AppError = require('../../errors/app_error');

const EmployeeController = require('../../controllers').Employee;
const UserController=require('../../controllers').User;

const get = async (req, res) => {
  const { id } = req.params;

  const employee = await EmployeeController.findById(id);
  if (!employee) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    employee
  });
};

const getAll = async (req, res) => {
  const companyId = req.user.id;

  const employees = await EmployeeController.findAllByCompanyId(companyId);
  if (!employees) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    employees
  });
};

const create = async (req, res) => {
  const { employee } = req.body;
  employee.companyId = req.user.id;
  employee.roleId=3;
  const newEmployee = await UserController.create(employee);
  if (!newEmployee) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    employee: newEmployee
  });
};

const update = async (req, res) => {
  const { employee } = req.body;
  employee.id = req.params.id;
  employee.companyId = req.user.id;
  if(employee.password!='******'){
    employee.password = bcrypt.hashSync(employee.password); 
  }
  else{
    delete employee.password;
  }  

  const updatedEmployee = await EmployeeController.update(employee);
  if (!updatedEmployee) {
    throw new AppError(errors.DB_ERROR);
  }

  res.json({
    success: true,
    employee: updatedEmployee
  });
};

const del = async (req, res) => {
  const { id } = req.params;
  await EmployeeController.delete(id);

  res.json({
    success: true
  });
};

module.exports = {
  get,
  getAll,
  create,
  update,
  del
};
