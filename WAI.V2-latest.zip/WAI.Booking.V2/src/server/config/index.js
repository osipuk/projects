const db = {
    client: 'mysql2'
};

const locale = {
    supported: ['en', 'da']
};

const website='http://localhost:3000';

const sms = {
    api_url: 'https://gatewayapi.com/rest/mtsms',
    consumer_key: 'OCC0gJzeI2pJ7YU17XQ2ehqf',
    consumer_secret: 'IedcHVlF4RJILyNFcfcfP2IwoUbmQ6GeAaVvL7ad'
};

const email={
    user_name: 'AKIAJSZIMJDZQ2SBUYOA',
    password: 'BKdFEczhW9njEcWicAZRpF9UMxJ1Wz6qDVJ97PcFAu3f',
    server_name: 'email-smtp.eu-west-1.amazonaws.com',
    sender_email:'stefanj@whoamivpn.com'
};

if (process.env.NODE_ENV === 'production') {
    db.connection = {
        host: '127.0.0.1',
        port: '3306',
        user: 'root',
        password: '',
        database: 'hair'
    };

    locale.default = 'da';
} else {
    db.connection = {
        host: '127.0.0.1',
        port: '3306',
        user: 'root',
        password: '',
        database: 'hair'
    };

    locale.default = 'en';
}

const config = {
    db,
    locale,
    sms,
    email,
    website
};

module.exports = config;