const Promise = require('bluebird');
const knex = require('knex');
const bcrypt = require('bcrypt-nodejs');
const config = require('../config');
const db = knex(config.db);

/**
 * Private
 */
const impl = {  
  allRaws: (cards) => {   
    return cards;
  }
};

/**
 * Public
 */
class CardController {
  static findAll() {
    return db.select().from('payment_method')
      //.where('is_online','0')
      .orderBy('id', 'asc')     
      .then(impl.allRaws)
      .catch(Promise.reject);
  }  
  
}

module.exports = CardController;
