const knex = require('knex');

const config = require('../config');
const { Terms } = require('../models');

const db = knex(config.db);

/**
 * Private
 */
const impl = {
  single: (terms) => {
    const term = terms[0];
    if (!term) {
      return null;
    }

    return Terms.fromDBModel(term);
  },
  all: (terms) => {
    const array = [];
    terms.forEach(term => array.push(Terms.fromDBModel(term)));
    return array;
  }
};

/**
 * Public
 */
class TermsController {
  static async findById(id) {
    const terms = await db.select().from('terms').where('id', id).limit(1);
    return impl.single(terms);
  }

  static async findByLanguageId(languageId,CompanyId) {
    const terms = await db.select().from('terms')
    .where('company_id',CompanyId)
    .andWhere('language_id',languageId)
    .limit(1);
    return impl.single(terms);
  }

  static async findAllByCompanyId(companyId) {
    const terms = await db.select().from('terms').where('company_id', companyId);    
    return impl.all(terms);
  }

  static async create(terms) {   
    const id = await db.insert(Terms.toDBModel(terms)).returning('id').into('terms');
    return this.findById(id);
  }

  static async update(terms) {
    await db('terms').where('id', terms.id).update(Terms.toDBModel(terms));
    return this.findById(terms.id);
  }

  static async delete(id) {
    return db('terms').where('id', id).del();
  }

  static async findAllLanguage(){
    const languages = await db.select().from('language').orderBy('id', 'desc');    
    return languages;
  }
}

module.exports = TermsController;
