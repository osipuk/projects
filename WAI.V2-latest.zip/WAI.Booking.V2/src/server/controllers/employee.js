const knex = require('knex');
const bcrypt = require('bcrypt-nodejs');
const config = require('../config');
const { Employee } = require('../models');
const { User } = require('../models');

const db = knex(config.db);

/**
 * Private
 */
const impl = {
  single: (employees) => {
    const employee = employees[0];
    if (!employee) {
      return null;
    }

    return User.fromDBModel(employee);
  },
  all: (employees) => {
    
    const array = [];
    employees.forEach(employee => array.push(User.fromDBModel(employee)));

    return array;
  }
};

/**
 * Public
 */
class EmployeeController {
  static async findById(id) {
    const employee = await db.select().from('user')
    .where('id', id)
    .andWhere('deleted','0')
    .whereIn('role_id',['3','4'])    
    .limit(1);
    return impl.single(employee);
  }

  static async findAllByCompanyId(companyId) {    
    const employees = await db.select().from('user')
    .where('company_id', companyId)
    .andWhere('deleted','0')
    .whereIn('role_id',['3','4'])    
    return impl.all(employees);
  }

  static async create(employee) {
    const id = await db.insert(User.toDBModel(employee)).returning('id').into('user');
    return this.findById(id);
  }

  static async update(employee) {
     
    await db('user').where('id', employee.id).update(User.toDBModel(employee));
    return this.findById(employee.id);
  }

  static async delete(id) {
    //return db('employee').where('id', id).del();
    return db('user').where('id', id).update(User.toDBModel({deleted:1}))
    .catch(Promise.reject)    
  }
}

module.exports = EmployeeController;
