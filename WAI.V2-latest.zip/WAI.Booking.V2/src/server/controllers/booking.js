const Promise = require('bluebird');
const knex = require('knex');
const moment = require('moment');

const config = require('../config');
const { Booking, BookingExtra, BookingHours, BookingVersion, BookingService,BookingItem } = require('../models');

const db = knex(config.db);

/**
 * Private
 */
const impl = {
    singleBooking: (bookings) => {
        const booking = impl.singleRawBooking(bookings);
        
        if (!booking) {
            return null;
        }

        booking.id =booking.id;

        return booking;
    },
    singleRawBooking: (bookings) => {
       
        const booking = bookings[0];
        if (!booking) {
            return null;
        }
       
        return Booking.fromDBModel(booking);
    },
    allBookings: (bookings) => {
        const array = [];
        bookings.forEach((booking) => {
            const b = Booking.fromDBModel(booking);
            //b.id = b.rootId;

            array.push(b);
        });

        return array;
    },
    singleExtra: (extras) => {
        const extra = extras[0];
        if (!extra) {
            return null;
        }

        return BookingExtra.fromDBModel(extra);
    },
    allExtras: (extras) => {
        const array = [];
        extras.forEach(extra => array.push(BookingExtra.fromDBModel(extra)));
        return array;
    },
    allExtrasRaw: (extras) => {
        return extras;
    },
    allServicesRaw: (services) => {
        return services;
    },
    allServices: (services) => {
        const array = [];
        services.forEach(service => array.push(BookingService.fromDBModel(service)));
        return array;
    },
    singleBookService: (services) => {
        const service = services[0];
        if (!service) {
            return [];
        }

        return BookingService.fromDBModel(service);
    },
    allExtrasToDBModels: (extras) => {
        const array = [];
        extras.forEach(extra => array.push(BookingExtra.toDBModel(extra)));
        return array;
    },
    allServiceToDBModels: (services) => {
        const array = [];
        services.forEach(service => array.push(BookingService.toDBModel(service)));

        return array;
    },
    allBookingItemToDBModels: (items) => {
        const array = [];
        items.forEach(item => array.push(BookingItem.toDBModel(item)));
        return array;
    },
    singleHours: (hours) => {
        const hour = hours[0];
        if (!hour) {
            return [];
        }

        return BookingHours.fromDBModel(hour);
    },
    allHours: (hours) => {
        const array = [];
        hours.forEach(hour => array.push(BookingHours.fromDBModel(hour)));

        return array;
    },
};

/**
 * Public
 */
class BookingController {
    static findById(id) {
        return db.select().from('booking').where('id', id)           
            .orderBy('id', 'desc')
            .limit(1)
            .then(impl.singleBooking)
            .catch(Promise.reject);
    }

    static findAllByCompanyId(companyId) {
        return db.select('booking.*', 'customer.first_name', 'customer.last_name').from('booking')
            .leftJoin('customer', 'customer.id', 'booking.customer_id')
            .whereNull('booking.version_id')
            .andWhere('booking.company_id', companyId)            
            .catch(Promise.reject);
    }

    static findAllBookingServicesByCompanyId(companyId) {
        return db.select('booking_service.*', 'service.name').from('booking')
            .leftJoin('booking_service', 'booking.id', 'booking_service.booking_id')
            .leftJoin('service', 'service.id', 'booking_service.service_id')
            .where('booking.company_id', companyId)
            .andWhere('booking_service.deleted','0')
            .catch(Promise.reject);
    }

    static findAllBookingExtrasByCompanyId(companyId) {
        return db.select('booking_extra.*', 'service_extra.name').from('booking')
            .leftJoin('booking_extra', 'booking.id', 'booking_extra.booking_id')
            .leftJoin('service_extra', 'service_extra.id', 'booking_extra.service_extra_id')
            .where('booking.company_id', companyId)
            .andWhere('booking_extra.deleted','0')
            .andWhere('service_extra.deleted','0')
            .catch(Promise.reject);
    }

    static findAllByCustomerId(customerId) {
        return db.select().from('booking').whereNull('version_id')
            .andWhere('customer_id', customerId)
            .then(impl.allBookings)
            .catch(Promise.reject);
    }

    static findAllBookingServicesByCustomerId(customerId) {
        return db.select('booking_service.*', 'service.name', 'service.price').from('booking')
            .leftJoin('booking_service', 'booking.id', 'booking_service.booking_id')
            .leftJoin('service', 'service.id', 'booking_service.service_id')
            .where('booking.customer_id', customerId)
            .andWhere('booking_service.deleted', '0')
            .andWhere('service.deleted', '0')
            .catch(Promise.reject);
    }

    static findAllBookingExtrasByCustomerId(customerId) {
        return db.select('booking_extra.*', 'service_extra.name', 'service_extra.price').from('booking')
            .leftJoin('booking_extra', 'booking.id', 'booking_extra.booking_id')
            .leftJoin('service_extra', 'service_extra.id', 'booking_extra.service_extra_id')
            .where('booking.customer_id', customerId)
            .andWhere('booking_extra.deleted', '0')
            .andWhere('service_extra.deleted', '0')
            .catch(Promise.reject);
    }

    static findAllByCustomerIdAndStatuses(customerId, statuses) {
        return db.select().from('booking').whereNull('version_id')
            .andWhere('customer_id', customerId)
            .whereIn('status', statuses)
            .then(impl.allBookings)
            .catch(Promise.reject);
    }

    static findAllByCompanyIdAndStatuses(companyId, statuses) {
        return db.select().from('booking').whereNull('version_id')
            .andWhere('company_id', companyId)
            .whereIn('status', statuses)
            .then(impl.allBookings)
            .catch(Promise.reject);
    }

    static findAllByCompanyIdAndDateRange(companyId, start, end) {        
        const startFormatted = moment(start).format('YYYY-MM-DD HH:mm:ss');
        const endFormatted = moment(end).format('YYYY=MM-DD HH:mm:ss');
       
        return db.select().from('booking')
            .where('company_id', companyId)
            .andWhere('book_from', '>=', startFormatted)
            .andWhere('book_to', '<=', endFormatted)
            .then(impl.allBookings)
            .catch(Promise.reject);
    }
    static findAllByEmployeeIdAndDateRange(employeeIds, start, end) {

        const startFormatted = start.format('YYYY-MM-DD HH:mm:ss');
        const endFormatted = end.format('YYYY-MM-DD HH:mm:ss');
        return db.select('booking.*').from('booking')
        .leftJoin('booking_service','booking.id','booking_service.booking_id')
        .whereIn('booking_service.employee_id',employeeIds)
        .andWhere('booking.book_from', '>=', startFormatted)
        .andWhere('booking.book_to', '<=', endFormatted)
        .andWhere('booking_service.deleted','0')
        .orWhere('booking.status' ,'AWAITING RESPONSE')
        .orWhere('booking.status' ,'ACCEPTED')
        .groupBy('booking.id')
        .then(impl.allBookings)
        .catch(Promise.reject);      

    }
  /**
   *  for cron job   
   * @param {*} start 
   * @param {*} end 
   */
    static findAllDateRange(start, end) {
    
        return db.select('customer.phone','customer.country_id','country.time_zone',).from('booking')
        .leftJoin('customer','customer.id','booking.customer_id')
        .leftJoin('company','company.id','booking.company_id')
        .leftJoin('country','company.country_id','country.id')       
        .where('booking.book_from', '>=', start)
        .andWhere('booking.book_to', '<=', end)        
        .orWhere('booking.status' ,'AWAITING RESPONSE')
        .orWhere('booking.status' ,'ACCEPTED')        
        //.then(impl.allBookings)
        .catch(Promise.reject);
    }

    static findAllByEmployeeIdAndDateRangeIsAccept(employeeId, start, end) {
      
        const startFormatted = moment(start).format('YYYY-MM-DD HH:mm:ss');
        const endFormatted = moment(end).format('YYYY-MM-DD')+" 23:59:59";
        return db.select('booking.*','booking_service.employee_id').from('booking')
            .leftJoin('booking_service','booking.id','booking_service.booking_id')
            .where('booking_service.employee_id', employeeId)
            .andWhere('booking.book_from', '>=', startFormatted)
            .andWhere('booking.book_to', '<=', endFormatted)
            .andWhere('booking.status','ACCEPTED')
            .andWhere('booking_service.deleted','0')
            .groupBy('booking.id')
            .then(impl.allBookings)
            .catch(Promise.reject);
    }

    static findAllByEmployeeIdAndDateRangeIsRequest(employeeId, start, end) {
      
        const startFormatted = moment(start).format('YYYY-MM-DD HH:mm:ss');
        const endFormatted = moment(end).format('YYYY-MM-DD')+" 23:59:59";           
        return db.select('booking.*','booking_service.employee_id').from('booking')
            .leftJoin('booking_service','booking.id','booking_service.booking_id')
            .where('booking_service.employee_id', employeeId)
            .andWhere('booking.book_from', '>=', startFormatted)
            .andWhere('booking.book_to', '<=', endFormatted)           
            .andWhere('booking.status','AWAITING RESPONSE')
            .andWhere('booking_service.deleted','0')
            .then(impl.allBookings)
            .catch(Promise.reject);
    }

    static create(booking) {
        const newBooking = booking;
        newBooking.status = Booking.PENDING_STATUS;
        newBooking.createdOn = moment().format('YYYY-MM-DD HH:mm:ss');
        newBooking.rootId = null;
        newBooking.versionId = null;
        newBooking.paid=booking.paid;
        
        return db.insert(Booking.toDBModel(newBooking)).returning('id').into('booking')
            .catch(Promise.reject)
            .then(this.findById)
            .catch(Promise.reject);
        // return this.findById(id);
    }
    static async updateById(id, booking) {
        console.log(booking);
        await db('booking').where('id', id).update(Booking.toDBModel(booking));
        return this.findById(id);
    }

    static async update(booking) {
        const updatedBooking = booking;
        const bookingId = booking.rootId || booking.id;
        updatedBooking.rootId = bookingId;

        // find a booking with versionId null and rootId is booking.rootId
        // i.e. a latest previous version of booking
        const prevBooking = impl.singleRawBooking(
            await db.select().from('booking').whereNull('version_id')
            .andWhere(qb => qb.where('root_id', bookingId).orWhere('id', bookingId))
            .orderBy('id', 'desc')
            .limit(1)
        );

        prevBooking.bookingId = bookingId;
        const id = await db.insert(BookingVersion.toDBModel(prevBooking)).returning('id').into('booking_version');

        // create a new one
        //const id = await db.insert(Booking.toDBModel(updatedBooking)).returning('id').into('booking');

        // set prevBooking.versionId to the created id
        await db('booking').where('id', bookingId).update(Booking.toDBModel(updatedBooking));

        // return created company
        return this.findById(bookingId);
    }

    static async acceptById(id) {
        // find existing booking
        const booking = await this.findById(id);
        booking.status = Booking.ACCEPTED_STATUS;
        booking.approvedOn = moment().format('YYYY-MM-DD HH:mm:ss');

        // update
        return this.update(booking);
    }

    static async completedById(id) {
        // find existing booking
        const booking = await this.findById(id);
        booking.status = Booking.COMPLETED_STATUS;
        //booking.approvedOn = moment().format('YYYY-MM-DD HH:mm:ss');

        // update
        return this.update(booking);
    }

    static async stayedById(id) {
        // find existing booking
        const booking = await this.findById(id);
        booking.status = Booking.STAYED_AWAY_STATUS;

        // update
        return this.update(booking);
    }


    static async rejectById(id) {
        // find existing booking
        const booking = await this.findById(id);
        booking.status = Booking.REJECTED_STATUS;

        // update
        return this.update(booking);
    }

    static async cancelById(id) {
        // find existing booking
        const booking = await this.findById(id);
        booking.status = Booking.CANCELLED_STATUS;

        // update
        return this.update(booking);
    }
    static async cancelByIdAndCustomer(id) {
        // find existing booking
        const booking = await this.findById(id);
        booking.status = Booking.CANCELLED_STATUS_CUSTOMER;

        // update
        return this.update(booking);
    }

    static delete(id) {
        return db('booking').where('id', id).del()
            .catch(Promise.reject);
    }
}

class BookingExtraController {
    static async findById(id) {
        const extras = await db.select().from('booking_extra')
        .where('id', id)
        .andWhere('deleted','0')
        .limit(1);
        return impl.singleExtra(extras);
    }

    static async findByIds(ids) {
        const extras = await db.select().from('booking_extra').whereIn('id', ids).andWhere('deleted','0');
        return impl.allExtras(extras);
    }

    static async findAllByBookingId(bookingId) {
        const extras = await db.select('booking_extra.id','booking_extra.employee_id', 'service_extra.id as eid', 'service_extra.name', 'service_extra.price', 'service_extra.duration').from('booking_extra')
            .leftJoin('service_extra', 'booking_extra.service_extra_id', 'service_extra.id')
            .where('booking_extra.booking_id', bookingId)
            .andWhere('booking_extra.deleted','0');
        return impl.allExtras(extras);
    }

    static async findAllByBookingIds(bookingIds) {
        const extras = await db.select('booking_extra.booking_id as bid', 'service_extra.id as eid', 'service_extra.name', 'service_extra.price', 'service_extra.duration').from('booking_extra')
            .leftJoin('service_extra', 'booking_extra.service_extra_id', 'service_extra.id')
            .whereIn('booking_extra.booking_id', bookingIds)
            .andWhere('booking_extra.deleted','0');
        return impl.allExtrasRaw(extras);
    }

    static async create(extra) {
        const id = await db.insert(BookingExtra.toDBModel(extra)).returning('id').into('booking_extra');
        return this.findById(id);
    }

    static async createMany(extras) {
       const ids = await db.insert(impl.allExtrasToDBModels(extras)).returning('id').into('booking_extra');     
        return ids;
        //return this.findByIds(ids);
    }

    static async delete(id) {
        return db('booking_extra').where('id', id).update(BookingExtra.toDBModel({deleted:1}));//.del();
    }

    static async delete1(bookingId,serviceId) {
        return db('booking_extra')
        .where('service_id', serviceId)
        .andWhere('booking_id',bookingId)        
        .update(BookingExtra.toDBModel({deleted:1}));//.del();
    }
    static async update(extra, id) {
        await db('booking_extra').where('id', id).update(BookingExtra.toDBModel(extra));
        return this.findById(id);
    }
}

class BookingHoursController {
    static async findById(id) {
        const hours = await db.select().from('booking_hours').where('id', id).limit(1);
        return impl.singleHours(hours);
    }

    static async findAllByCompanyId(companyId, employeeId) {
        const hours = await db.select().from('booking_hours')
            .where('company_id', companyId)
            .andWhere('employee_id', employeeId)
            .limit(1);
        return impl.singleHours(hours);
    }
    static findGetsByCompanyId(companyId) {
        return db.select().from('booking_hours')
            .where('company_id', companyId)
            .then(impl.allHours)
            .catch(Promise.reject);

    }

    static async create(hours) {
        const id = await db.insert(BookingHours.toDBModel(hours)).returning('id').into('booking_hours');
        return this.findById(id);
    }

    static async delete(id) {
        return db('booking_hours').where('id', id).del()
            .catch(Promise.reject);
    }


    static async update(hours) {
        await db('booking_hours').where('id', hours.id).update(BookingHours.toDBModel(hours));
        return this.findById(hours.id);
    }
}

class BookingServiceController {

    static async findAllByBookingId(bookingId) {
        const services = await db.select('booking_service.id', 'service.id as sid', 'service.name', 'service.price', 'service.duration','booking_service.employee_id').from('booking_service')
            .leftJoin('service', 'booking_service.service_id', 'service.id')
            .where('booking_service.booking_id', bookingId)
            .andWhere('booking_service.deleted','0')
            .andWhere('service.deleted','0')
            ;
        return impl.allServicesRaw(services);
    }

    static async findAllByBookingIds(bookingIds) {
        const extras = await db.select('booking_extra.booking_id as bid', 'service_extra.id as eid', 'service_extra.name', 'service_extra.price', 'service_extra.duration').from('booking_extra')
            .leftJoin('service_extra', 'booking_extra.service_extra_id', 'service_extra.id')
            .whereIn('booking_extra.booking_id', bookingIds)
            .andWhere('booking_extra.deleted','0')
            .andWhere('service_extra.deleted','0')
            ;
        return impl.allExtrasRaw(extras);
    }
    static async createMany(services) {
        const ids = await db.insert(impl.allServiceToDBModels(services)).returning('id').into('booking_service');
        return ids;
    }
    static async create(services) {
        const id = await db.insert(BookingService.toDBModel(services)).returning('id').into('booking_service');
        return id;
    }
    static async findByIds(ids) {
        const services = await db.select().from('booking_service')
        .whereIn('id', ids)
        .andWhere('deleted','0');
        return impl.allServices(services);
    }
    static async findById(id) {
        const bookServices = await db.select().from('booking_service')
        .where('id', id)
        .andWhere('deleted','0')
        .limit(1);
        return impl.singleBookService(bookServices);
    }
    static async delete(id) {
        return db('booking_service').where('id', id).update(BookingService.toDBModel({deleted:1}));//.del();
    }
    static async update(booking_service) {
        await db('booking_service').where('id',booking_service.id).update(BookingService.toDBModel(booking_service));
        return this.findById(booking_service.id);
    }
}


class BookingItemController {

   
    static async createMany(items) {
        const ids = await db.insert(impl.allBookingItemToDBModels(items)).returning('id').into('booking_item');
        return ids;
    }
    static async create(services) {
        const id = await db.insert(BookingService.toDBModel(services)).returning('id').into('booking_service');
        return id;
    }
    
}

module.exports = {
    BookingController,
    BookingExtraController,
    BookingHoursController,
    BookingServiceController,
    BookingItemController
};