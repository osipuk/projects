const Promise = require('bluebird');
const knex = require('knex');

const config = require('../config');
const { Payment,PaymentSetting } = require('../models');

const db = knex(config.db);

/**
 * Private
 */
const impl = {
  singlePayments: (payments) => {
    const payment = payments[0];
    if (!payment) {
      return Promise.resolve(null);
    }

    return Payment.fromDBModel(payment);
  },
  singlePaymentSetting: (payments) => {
    const payment = payments[0];
    if (!payment) {
      return Promise.resolve(null);
    }
    return PaymentSetting.fromDBModel(payment);
  },
  allPayments: (payments) => {    
    const array = [];
    payments.forEach(payment => array.push(Payment.fromDBModel(payment)));
    return array;
  },

};

/**
 * Public
 */
class PaymentsController {
  static findById(id) {     
    return db.select().from('payment').where('id', id).limit(1)
      .then(impl.singlePayments)
      .catch(Promise.reject);
  }
  
  static create(payments) {    
    return db.insert(Payment.toDBModel(payments)).returning('id').into('payment')       
      .then(this.findById)
      .catch(Promise.reject);
  }
  static update(payments) {
    console.log(payments);
    return db('payment').where('id', payments.id).update(Payment.toDBModel(payments))
      .catch(Promise.reject)
      .then(() => this.findById(payments.id))
      .catch(Promise.reject);
  }
  static findByCompanyBookingId(companyId,bookingId){
    return db.select().from('payment').where('booking_id', bookingId)
    .andWhere('company_id',companyId) 
    .orderBy('id', 'asc')     
    .then(impl.allPayments)    
    .catch(Promise.reject);
  }  

  static findByCompanyId(companyId){
    return db.select('payment.*','customer.first_name','customer.last_name','customer.phone','payment_method.name','booking.created_on as bcreated_on').from('payment')
    .leftJoin('customer', 'customer.id', 'payment.customer_id')
    .leftJoin('payment_method','payment.payment_method_id','payment_method.id')
    .leftJoin('booking', 'booking.id', 'payment.booking_id')
    .where('payment.company_id', companyId)
    .orderBy('payment.created_on', 'desc')    
    .catch(Promise.reject);
  }  

  
 
}

class PaymentSettingController {
  static findById(id) {     
    return db.select().from('payment_settings').where('id', id).limit(1)
      .then(impl.singlePaymentSetting)
      .catch(Promise.reject);
  }
  
  static create(settings) {
    
    return db.insert(PaymentSetting.toDBModel(settings)).returning('id').into('payment_settings')    
      .then(this.findById)
      .catch(Promise.reject);
  }
  static update(settings) {
    
    return db('payment_settings').where('id', settings.id).update(PaymentSetting.toDBModel(settings))
      .catch(Promise.reject)
      .then(() => this.findById(settings.id))
      .catch(Promise.reject);
  }
  static findByCompanyId(companyId){
    return db.select().from('payment_settings').where('company_id', companyId)    
    .limit(1)
    .then(impl.singlePaymentSetting)
    .catch(Promise.reject);
  }  
  
 
}



module.exports = {
  PaymentsController,
  PaymentSettingController
};
