const Promise = require('bluebird');
const knex = require('knex');

const config = require('../config');
const {ExtraServiceRelations,EmployeeServiceRelations } = require('../models');

const db = knex(config.db);

/**
 * Private
 */
const impl = { 
  allExtraService: (rows) => {
    const array = [];
    rows.forEach(row => array.push(ExtraServiceRelations.fromDBModel(row)));
    return array;
  }, 
  
  allExtraServiceRelationToDBModels: (relations) => {
    const array = [];
    relations.forEach(relation => array.push(ExtraServiceRelations.toDBModel(relation)));
    return array;
  },
  allEmoloyeeServiceRelationToDBModels: (relations) => {
    const array = [];
    relations.forEach(relation => array.push(EmployeeServiceRelations.toDBModel(relation)));
    return array;
  },
  allEmployeeService: (rows) => {
    const array = [];
    rows.forEach(row => array.push(EmployeeServiceRelations.fromDBModel(row)));
    return array;
  }, 
  /**
  singleService: (services) => {
    const service = services[0];
    if (!service) {
      return Promise.resolve(null);
    }

    return Service.fromDBModel(service);
  },
  singleCategory: (categories) => {
    const category = categories[0];
    if (!category) {
      return Promise.resolve(null);
    }

    return ServiceCategory.fromDBModel(category);
  },
   */
};

/**
 * Public extra_service_relations
 */
class ExtraServiceRelationsController {
 
  static findAllByCompanyId(companyId) {
    return db.select().from('extra_service_relations').where('company_id', companyId)     
      .then(impl.allExtraService)
      .catch(Promise.reject);
  }

  static findAllBesideDeleteByCompanyId(companyId) {
    return db.select().from('extra_service_relations').where('company_id', companyId)     
      .andWhere('deleted','0')
      .then(impl.allExtraService)
      .catch(Promise.reject);
  }

  static async createMany(relations) {
    const ids = await db.insert(impl.allExtraServiceRelationToDBModels(relations)).returning('id').into('extra_service_relations');
    return ids;   
  }

  static async updateForRemove(serviceId) {
    return db('extra_service_relations').where('service_id', serviceId).update(ExtraServiceRelations.toDBModel({deleted:1}))
      .catch(Promise.reject);
     
  }

  static async update(serviceId,extraIds) {
    return db('extra_service_relations').whereIn('extra_id',extraIds)
    .andWhere('service_id', serviceId)
    .update(ExtraServiceRelations.toDBModel({deleted:0}))
    .catch(Promise.reject);     
  }  
}

class EmployeeServiceRelationsController {
 
  static findAllByCompanyId(companyId) {
    return db.select().from('employee_service_relations').where('company_id', companyId)     
      .then(impl.allEmployeeService)
      .catch(Promise.reject);
  }

  static findAllBesideDeleteByCompanyId(companyId) {
    return db.select().from('employee_service_relations').where('company_id', companyId)     
      .andWhere('deleted','0')
      .then(impl.allEmployeeService)
      .catch(Promise.reject);
  }

  static async createMany(relations) {
    const ids = await db.insert(impl.allEmoloyeeServiceRelationToDBModels(relations)).returning('id').into('employee_service_relations');
    return ids;   
  }

  static async updateForRemove(serviceId) {
    return db('employee_service_relations').where('service_id', serviceId).update(EmployeeServiceRelations.toDBModel({deleted:1}))
      .catch(Promise.reject);
     
  }

  static async update(serviceId,employeeIds) {
    return db('employee_service_relations').whereIn('employee_id',employeeIds)
    .andWhere('service_id', serviceId)
    .update(EmployeeServiceRelations.toDBModel({deleted:0}))
    .catch(Promise.reject);     
  }
  
}

module.exports = {
  ExtraServiceRelationsController,  
  EmployeeServiceRelationsController
};
