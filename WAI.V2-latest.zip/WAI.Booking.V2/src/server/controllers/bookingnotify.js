const Promise = require('bluebird');
const knex = require('knex');
const moment = require('moment');
const bcrypt = require('bcrypt-nodejs');
const config = require('../config');
const db = knex(config.db);
const { BookingNotify } = require('../models');
/**
 * Private
 */
const impl = {  
  
  singleBookingNotify: (bookingNotifys) => {
    const bookingNotify = bookingNotifys[0];
    if (!bookingNotify) {
      return [];
    }
    return BookingNotify.fromDBModel(bookingNotify);
  },
  allBookingNotify: (bookingNotifys) => {    
    const array = [];
    bookingNotifys.forEach((bookingNotify) => {
        const b = BookingNotify.fromDBModel(bookingNotify);
        array.push(b);
    });
    return array;
  },
 
};
/**
 * Public
 */
class BookingNotifyController {
  
  static create(bookingNotify) {    
    bookingNotify.createdAt = moment().format('YYYY-MM-DD HH:mm:ss');
    return db.insert(BookingNotify.toDBModel(bookingNotify)).returning('id').into('booking_notify')
      .catch(Promise.reject)
      .then(this.findById)
      .catch(Promise.reject);
  }
  static findAllById(id) {     
    return db.select().from('booking_notify').where('id', id)
      .then(impl.allBookingNotify)
      .catch(Promise.reject);
  }
  static findById(id) {
    return db.select().from('booking_notify').where('id', id).limit(1)
      .then(impl.singleBookingNotify)
      .catch(Promise.reject);
  } 
  
  static findAllByCompanyId(companyId) {     
    return db.select().from('booking_notify').where('company_id', companyId)
      .andWhere('seen','0')
      .then(impl.allBookingNotify)
      .catch(Promise.reject);
  }  
  static update(bookingNotify) {
    return db('booking_notify').where('id', bookingNotify.id).update(BookingNotify.toDBModel(bookingNotify))
      .catch(Promise.reject)
      .then(() => this.findById(bookingNotify.id))
      .catch(Promise.reject);
  } 
}

module.exports = BookingNotifyController;
