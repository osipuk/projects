const Promise = require('bluebird');
const knex = require('knex');

const config = require('../config');
const { Service,ServiceVersion, ServiceCategory, ServiceExtra,ServiceExtraVersion } = require('../models');

const db = knex(config.db);

/**
 * Private
 */
const impl = {
  singleService: (services) => {
    const service = services[0];
    if (!service) {
      return Promise.resolve(null);
    }

    return Service.fromDBModel(service);
  },
  allServices: (services) => {
    const array = [];
    services.forEach(service => array.push(Service.fromDBModel(service)));

    return array;
  },
  singleCategory: (categories) => {
    const category = categories[0];
    if (!category) {
      return Promise.resolve(null);
    }

    return ServiceCategory.fromDBModel(category);
  },
  allCategories: (categories) => {
    const array = [];
    categories.forEach(category => array.push(ServiceCategory.fromDBModel(category)));

    return array;
  },
  singleExtra: (extras) => {
    const extra = extras[0];
    if (!extra) {
      return Promise.resolve(null);
    }

    return ServiceExtra.fromDBModel(extra);
  },
  allExtras: (extras) => {
    const array = [];
    extras.forEach(extra => array.push(ServiceExtra.fromDBModel(extra)));

    return array;
  }
};

/**
 * Public
 */
class ServiceController {
  static findById(id) {     
    return db.select().from('service').where('id', id)
      .andWhere('deleted','0')
      .limit(1)
      .then(impl.singleService)
      .catch(Promise.reject);
  }

  static findAllByCompanyCategoryId(companyId,categoryId) {
    return db.select().from('service').where('company_id', companyId)
      .andWhere('service_category_id', categoryId)
      .andWhere('deleted','0')
      .then(impl.allServices)
      .catch(Promise.reject);
  }
  static findAllByCompanyId(companyId) {
    return db.select().from('service').where('company_id', companyId)
      .andWhere('deleted','0')
      .then(impl.allServices)
      .catch(Promise.reject);
  }

  static findAllByIds(ids) {
    return db.select().from('service').whereIn('id', ids)
     .andWhere('deleted','0')
      .then(impl.allServices)     
      .catch(Promise.reject);
  }

  static create(service) {
    return db.insert(Service.toDBModel(service)).returning('id').into('service')
      .catch(Promise.reject)
      .then(this.findById)
      .catch(Promise.reject);
  }

  static async update(service) {

    let preService= impl.singleService(
      await db.select().from('service')
         .where('id', service.id)
        .limit(1)
    );  
    if(service.price!=preService.price){
      preService.serviceId=service.id;     
      await db.insert(ServiceVersion.toDBModel(preService)).returning('id').into('service_version'); 
    } 
    return db('service').where('id', service.id).update(Service.toDBModel(service))
      .catch(Promise.reject)
      .then(() => this.findById(service.id))
      .catch(Promise.reject);
  }

  static delete(id) {

    return db('service').where('id', id).update(Service.toDBModel({deleted:1}))
    .catch(Promise.reject)
    .then(() => this.findById(id))
    .catch(Promise.reject);   
  }
  
  static deleteAllservice(ids) {

    return db('service').whereIn('id', ids).update(ServiceExtra.toDBModel({deleted:1}))
    .catch(Promise.reject)   
  }
}

class ServiceCategoryController {
  static findById(id) {
    return db.select().from('service_category').where('id', id)
      .andWhere('deleted','0')
      .limit(1)
      .then(impl.singleCategory)
      .catch(Promise.reject);
  }

  static findAllByCompanyId(companyId) {
    return db.select().from('service_category').where('company_id', companyId)
      .andWhere('deleted','0')
      .then(impl.allCategories)
      .catch(Promise.reject);
  }

  static create(category) {   
    return db.insert(ServiceCategory.toDBModel(category)).returning('id').into('service_category')    
      .catch(Promise.reject)
      .then(this.findById)
      .catch(Promise.reject);
  }

  static update(category) {     
    return db('service_category').where('id', category.id)
      .andWhere('deleted','0')
      .update(ServiceCategory.toDBModel(category))
      .catch(Promise.reject)
      .then(() => this.findById(category.id))
      .catch(Promise.reject);
  }
  static updateByCompanyId(companyId) {
    return db('service_category').where('company_id', companyId)
    .andWhere('deleted','0')
    .update({ default_service_category: 0})
      .catch(Promise.reject)
     // .then(impl.allCategories)
      .catch(Promise.reject);
  }

  static delete(id) {
    return db('service_category').where('id', id).update(ServiceCategory.toDBModel({deleted:1}))
      .catch(Promise.reject);
  }
  static deleteAllCategory(ids){   
    return db('service_category').whereIn('id', ids).update(ServiceCategory.toDBModel({deleted:1}))
    .catch(Promise.reject)
  }
}

class ServiceExtraController {
  static findById(id) {
    return db.select().from('service_extra').where('id', id)
      .andWhere('deleted','0')
      .limit(1)
      .then(impl.singleExtra)
      .catch(Promise.reject);
  }

  static findAllByIds(ids) {
    return db.select().from('service_extra').whereIn('id', ids)
     .andWhere('deleted','0')
      .then(impl.allExtras)
      .catch(Promise.reject);
  }

  static findAllByServiceIds(serviceIds){
    return db.select().from('service_extra').whereIn('service_id', serviceIds)
      .andWhere('deleted','0')
      .then(impl.allExtras)
      .catch(Promise.reject);
  }

  static findAllByServiceId(serviceId){
    return db.select().from('service_extra').where('service_id', serviceId)
      .andWhere('deleted','0')
      .then(impl.allExtras)
      .catch(Promise.reject);
  }

  static findAllByCompanyId(companyId,serviceId) {
    return db.select().from('service_extra').where('company_id', companyId).andWhere('service_id',serviceId)
      .andWhere('deleted','0')
      .then(impl.allExtras)
      .catch(Promise.reject);
  }

  static findByCompanyId(companyId) {
    return db.select().from('service_extra').where('company_id', companyId)
      .andWhere('deleted','0')
      .then(impl.allExtras)
      .catch(Promise.reject);
  }

  static create(extra) {
    return db.insert(ServiceExtra.toDBModel(extra)).returning('id').into('service_extra')
      .catch(Promise.reject)
      .then(this.findById)
      .catch(Promise.reject);
  }

  static async update(extra) {
    let preServiceExtra= impl.singleExtra (
      await db.select().from('service_extra')
         .where('id', extra.id)
        .limit(1)
    );      
   
    if(extra.price!=preServiceExtra.price){
      preServiceExtra.serviceExtraId=extra.id;     
      await db.insert(ServiceExtraVersion.toDBModel(preServiceExtra)).returning('id').into('service_extra_version'); 
    } 

    return db('service_extra').where('id', extra.id).update(ServiceExtra.toDBModel(extra))
      .catch(Promise.reject)
      .then(() => this.findById(extra.id))
      .catch(Promise.reject);
  }

  static delete(id) {
    return db('service_extra').where('id', id).update(ServiceExtra.toDBModel({deleted:1}))
    .catch(Promise.reject)    
  }

  static deleteAllExtra(ids){
    return db('service_extra').whereIn('id', ids).update(ServiceExtra.toDBModel({deleted:1}))
    .catch(Promise.reject)    
  }

}

module.exports = {
  ServiceController,
  ServiceCategoryController,
  ServiceExtraController
};
