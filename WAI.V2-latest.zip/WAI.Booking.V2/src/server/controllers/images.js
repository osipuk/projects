const Promise = require('bluebird');
const knex = require('knex');
const bcrypt = require('bcrypt-nodejs');
const config = require('../config');
const db = knex(config.db);
const { Images } = require('../models');
/**
 * Private
 */
const impl = {  
  
  singleImage: (images) => {
    const image = images[0];
    if (!image) {
      return null;
    }
    return Images.fromDBModel(image);
  }
 
};
/**
 * Public
 */
class ImagesController {
  static findById(id) {     
    return db.select().from('images').where('id', id).limit(1)
      .then(impl.singleImage)
      .catch(Promise.reject);
  } 
  static findByCompanyId(companyId) {     
    return db.select().from('images').where('company_id', companyId).limit(1)
      .then(impl.singleImage)
      .catch(Promise.reject);
  } 
  static create(images) {   
    return db.insert(Images.toDBModel(images)).returning('id').into('images')
      .catch(Promise.reject)
      .then(this.findById)
      .catch(Promise.reject);
  }
  static update(images) {
    return db('images').where('id', images.id).update(Images.toDBModel(images))
      .catch(Promise.reject)
      .then(() => this.findById(images.id))
      .catch(Promise.reject);
  }
  
}

module.exports = ImagesController;
