const Promise = require('bluebird');
const knex = require('knex');

const config = require('../config');
const { DiscountCard,DiscountCardUserRelation,BookingDiscountCardsRelation } = require('../models');

const db = knex(config.db);

/**
 * Private
 */
const impl = {
  singleDiscountCard: (discountCards) => {
    const discountCard = discountCards[0];
    if (!discountCard) {
      return Promise.resolve(null);
    }
    return DiscountCard.fromDBModel(discountCard);
  },  
  allDiscountCard: (discountCards) => {
    const array = [];
    discountCards.forEach(discountCard => array.push(DiscountCard.fromDBModel(discountCard)));
    return array;
  },  
  singleRelation: (relations) => {
    const relation = relations[0];
    if (!relation) {
      return Promise.resolve(null);
    }
    return DiscountCardUserRelation.fromDBModel(relation);
  },  
  singleBookingRelation: (relations) => {
    const relation = relations[0];
    if (!relation) {
      return Promise.resolve(null);
    }
    return BookingDiscountCardsRelation.fromDBModel(relation);
  },  
};

/**
 * Public
 */
class DiscountCardController {

  static findById(id) {     
    return db.select().from('discount_card').where('id', id)
      .andWhere('deleted','0')
      .limit(1)
      .then(impl.singleDiscountCard)
      .catch(Promise.reject);
  }
  static findAllByCompanyId(companyId) {
    return db.select().from('discount_card').where('business_id', companyId)
      .andWhere('deleted','0')
      .then(impl.allDiscountCard)
      .catch(Promise.reject);
  } 
  static findAllActiveByCompanyId(companyId) {
    return db.select().from('discount_card').where('business_id', companyId)
      .andWhere('deleted','0')
      .andWhere('active','1')
      .then(impl.allDiscountCard)
      .catch(Promise.reject);
  } 
  static create(discountCard) {
    return db.insert(DiscountCard.toDBModel(discountCard)).returning('id').into('discount_card')
      .catch(Promise.reject)
      .then(this.findById)
      .catch(Promise.reject);
  }
  static async update(discountCard) {
   
    return db('discount_card').where('id', discountCard.id).update(DiscountCard.toDBModel(discountCard))
      .catch(Promise.reject)
      .then(() => this.findById(discountCard.id))
      .catch(Promise.reject);
  }
  static delete(id) { 
    return db('discount_card').where('id', id).update(DiscountCard.toDBModel({deleted:1}))
    .catch(Promise.reject)   
  }
}

class DiscountCardUserRelationController {

  static findById(id) {     
    return db.select().from('discount_card_user_relation').where('id', id)      
      .limit(1)
      .then(impl.singleRelation)
      .catch(Promise.reject);
  }
  static findByIdByUserId(id,userId) {     
    return db.select().from('discount_card_user_relation')
      .where('discount_card_id', id)  
      .andWhere('user_id',userId)
      .limit(1)
      .then(impl.singleRelation)
      .catch(Promise.reject);
  }
  static create(discountCardRelation) {
    return db.insert(DiscountCardUserRelation.toDBModel(discountCardRelation)).returning('id').into('discount_card_user_relation')
      .catch(Promise.reject)
      .then(this.findById)
      .catch(Promise.reject);
  }
  static async update(discountCardRelation) {   
    return db('discount_card_user_relation').where('id', discountCardRelation.id).update(DiscountCardUserRelation.toDBModel(discountCardRelation))
      .catch(Promise.reject)
      .then(() => this.findById(discountCardRelation.id))
      .catch(Promise.reject);
  }
}


class BookingDiscountCardsRelationController {

  static findById(id) {     
    return db.select().from('booking_discount_cards_relation').where('id', id)      
      .limit(1)
      .then(impl.singleBookingRelation)
      .catch(Promise.reject);
  }
  static create(bookingDiscountRelation) {
    return db.insert(BookingDiscountCardsRelation.toDBModel(bookingDiscountRelation)).returning('id').into('booking_discount_cards_relation')
      .catch(Promise.reject)
      .then(this.findById)
      .catch(Promise.reject);
  }
 
}

module.exports = {
  DiscountCardController,
  DiscountCardUserRelationController,
  BookingDiscountCardsRelationController
 
};
