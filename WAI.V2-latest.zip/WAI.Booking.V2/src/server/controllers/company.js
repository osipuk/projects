const Promise = require('bluebird');
const knex = require('knex');
const bcrypt = require('bcrypt-nodejs');

const config = require('../config');
const { Company,CompanyVersion } = require('../models');

const db = knex(config.db);

/**
 * Private
 */
const impl = {
  single: (companies) => {
    const company = impl.singleRaw(companies);
    if (!company) {
      return null;
    }   
    company.id = company.id;

    return company;
  },
  singleRaw: (companies) => {
    const company = companies[0];
    if (!company) {
      return null;
    }

    return Company.fromDBModel(company);
  },
  Raw: (companies) => {
    const company = companies[0];
    if (!company) {
      return null;
    }

    return company;
  }
};

/**
 * Public
 */
class CompanyController {
  static findById(id) {
    return db.select('company.*','country.country_phone_code','country.currency_code',
    'country.name as country_name','user.email','user.phone','user.phone_veryfied','user.email_veryfied','user.first_name',
    'user.last_name','user.last_name').from('company')
      .leftJoin('country','country.id','company.country_id')
      .leftJoin('user','user.company_id','company.id')
      .where('company.id', id)
      .andWhere('user.deleted','0')     
      .orderBy('company.id', 'desc')
      .limit(1)
     .then(impl.Raw)
     .catch(Promise.reject);
  }
  static findByIdOnlyCompany(id) {
     return db.select('company.*','country.country_phone_code','country.currency_code','country.name as country_name').from('company')
       .leftJoin('country','country.id','company.country_id')
       .where('company.id', id)   
       .orderBy('company.id', 'desc')
       .limit(1)
      .then(impl.Raw)
       .catch(Promise.reject);
   }
  static findByUrl(url){
    return db.select('company.*','country.country_phone_code','country.currency_code').from('company')
          .leftJoin('country','country.id','company.country_id')
          .where('company.custom_url', url)         
          .limit(1)
          .then(impl.Raw)
          .catch(Promise.reject);
  }
  static findByAllUrl(email){
    return db.select('company.*','country.country_phone_code','country.currency_code').from('company')
          .leftJoin('country','country.id','company.country_id')
          .where('company.email', email)         
          .limit(1)
          .then(impl.Raw)
          .catch(Promise.reject);
  }
  static findCountryinfById(id){
    return db.select().from('country').where('id',id)
      .orderBy('id', 'desc')
      .limit(1)
      //.then(impl.single)
      .catch(Promise.reject);
  }

  static findByEmail(email) {
    return db.select().from('company').andWhere('email', email)
      .orderBy('id', 'desc')
      .limit(1)
      .then(impl.single)
      .catch(Promise.reject);
  }
 
 static findByPhone(phone){
    return db.select().from('company').where('phone', phone)
      .orderBy('id', 'desc')
      .limit(1)
      .then(impl.single)
      .catch(Promise.reject);
 }
  static findByCustomUrlAndId(company) {
    return db.select().from('company').where('id','!=',company.id).andWhere('custom_url', company.customUrl)
      .orderBy('id', 'desc')
      .limit(1)
      .then(impl.single)
      .catch(Promise.reject);
  } 

  static findByToken(token) {
    return db.select().from('company').where('email_token', token)     
      .limit(1)
      .then(impl.singleRaw)
      .catch(Promise.reject);
  } 
  
  static getCountrys(){
    return db.select().from('country')
      .orderBy('name', 'asc')        
      .catch(Promise.reject);
  }

  static getAll(){
    return db.select().from('company')
      .orderBy('id', 'asc')        
      .catch(Promise.reject);
  }

  static async create(company) {
    const newCompany = company;
   // newCompany.password = bcrypt.hashSync(company.password);
    newCompany.versionId = null;

    const id = await db.insert(Company.toDBModel(newCompany)).returning('id').into('company');

    return this.findByIdOnlyCompany(id);
  }

  static async update(company) {

  
    // we assume that the company.id is a rootId
    // first create a new company
    const updatedCompany = company;
    const companyId = company.rootId || company.id;
    //updatedCompany.rootId = companyId;    
   
    // find a company with versionId null and rootId is company.rootId
    // i.e. a latest previous version of company
    const prevCompany = impl.singleRaw(
      await db.select().from('company').whereNull('version_id')
        .andWhere((qb) => {
          qb.where('root_id', companyId).orWhere('id', companyId);
        })
        .orderBy('id', 'desc')
        .limit(1)
    );

    /**
    if(company.password!='*********'){
     var oldPassword = bcrypt.hashSync(company.password);
      if(prevCompany.password!=oldPassword){

      }
      company.password=bcrypt.hashSync(company.new_password);
    }
    else{
      delete company.password;
    }
     */
    
    // set prevCompany.versionId to the created id   
    await db('company').where('id', prevCompany.id).update(Company.toDBModel(updatedCompany));
    
    prevCompany.companyId=companyId;
    // create new one
    const id = await db.insert(CompanyVersion.toDBModel(prevCompany)).returning('id').into('company_version');
   
    // return created company
    return this.findById(companyId);
  }
}

module.exports = CompanyController;



