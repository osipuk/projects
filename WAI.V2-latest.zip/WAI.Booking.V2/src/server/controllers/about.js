const knex = require('knex');

const config = require('../config');
const { About } = require('../models');

const db = knex(config.db);

/**
 * Private
 */
const impl = {
  single: (abouts) => {
    const about = abouts[0];
    if (!about) {
      return null;
    }

    return About.fromDBModel(about);
  },
  all: (abouts) => {
    const array = [];
    abouts.forEach(about => array.push(About.fromDBModel(about)));

    return array;
  }
};

/**
 * Public
 */
class AboutController {
  static async findById(id) {
    const about = await db.select().from('about').where('id', id).limit(1);
    return impl.single(about);
  }

  static async findByLanguageId(languageId,CompanyId) {
    const about = await db.select().from('about')
    .where('company_id',CompanyId)
    .andWhere('language_id',languageId)
    .limit(1);
    return impl.single(about);
  }

  static async findAllByCompanyId(companyId) {
    const abouts = await db.select().from('about').where('company_id', companyId);    
    return impl.all(abouts);
  }

  static async create(about) {
    console.log(about);
    const id = await db.insert(About.toDBModel(about)).returning('id').into('about');
    return this.findById(id);
  }

  static async update(about) {
    await db('about').where('id', about.id).update(About.toDBModel(about));
    return this.findById(about.id);
  }

  static async delete(id) {
    return db('about').where('id', id).del();
  }

  static async findAllLanguage(){
    const languages = await db.select().from('language').orderBy('id', 'desc');    
    return languages;
  }
}

module.exports = AboutController;
