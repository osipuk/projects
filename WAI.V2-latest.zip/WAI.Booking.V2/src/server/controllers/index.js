const company = require('./company');
const customer = require('./customer');
const service = require('./service');
const booking = require('./booking');
const employee = require('./employee');
const product=require('./product');
const card=require('./card');
const payments=require('./payments');
const about=require('./about');
const terms=require('./terms');
const holiday=require('./holiday');
const vacation=require('./vacation'); 
const images=require('./images');
const bookingnotify=require('./bookingnotify');
const relations=require('./relations');
const notification=require('./notifications');
const user=require('./user');
const discountCard=require('./discount_card');
const giftCard=require('./gift_card');
const discountCode=require('./discount_code');

module.exports = {
  Company: company,
  User:user,
  Customer: customer,
  Service: service.ServiceController,
  ServiceCategory: service.ServiceCategoryController,
  ServiceExtra: service.ServiceExtraController,
  Booking: booking.BookingController,
  BookingExtra: booking.BookingExtraController,
  BookingService:booking.BookingServiceController,
  BookingItem:booking.BookingItemController,
  BookingHours: booking.BookingHoursController,
  Employee: employee,
  ProductCategory:product.ProductCategoryController,
  Product:product.ProductController,
  ProductService:product.ProductServiceController,
  Card:card,
  Payments:payments.PaymentsController,
  PaymentSetting:payments.PaymentSettingController,
  About:about,
  Terms:terms,
  Holiday:holiday.HolidayController,
  HolidayWork:holiday.HolidayWorkController,
  Vacation:vacation,
  Images:images,
  BookingNotify:bookingnotify,
  ExtraServiceRelatins:relations.ExtraServiceRelationsController,
  EmployeeServiceRelations:relations.EmployeeServiceRelationsController,
  Notification:notification,
  DiscountCard:discountCard.DiscountCardController,
  GiftCard:giftCard.GiftCardController,
  BookingGiftCardRelation:giftCard.BookingGiftCardsRelationController,
  DiscountCode:discountCode.DiscountCodeController,
  DiscountServiceRelation:discountCode.DiscountServiceRelationController, 
  DiscountServiceExtrasRelation:discountCode.DiscountServiceExtrasRelationController,
  BookingDiscountCardsRelation:discountCard.BookingDiscountCardsRelationController,
  DiscountCardUserRelation:discountCard.DiscountCardUserRelationController
};
