const Promise = require('bluebird');
const knex = require('knex');

const config = require('../config');
const { Holiday,HolidayWork } = require('../models');

const db = knex(config.db);

/**
 * Private
 */
const impl = {  
  
  singleHolidayWroks: (holidayWorks) => {
    const holidayWork = holidayWorks[0];
    if (!holidayWork) {
      return null;
    }

    return HolidayWork.fromDBModel(holidayWork);
  },
  allHolidays: (holidays) => {    
    const array = [];
    holidays.forEach(holiday => array.push(Holiday.fromDBModel(holiday)));
    return array;
  },
  allHolidayWorks: (holidayWorks) => {  
    const array = [];
    holidayWorks.forEach(holidayWork => array.push(HolidayWork.fromDBModel(holidayWork)));
    return array;
  },
 
};

/**
 * Public
 */
class HolidayController {
  static findById(id) {     
    return db.select().from('holiday').where('id', id).limit(1)
      .then(impl.singleService)
      .catch(Promise.reject);
  } 
  static findAllByCompanyId(country_id) {    
  return db.select().from('holiday')
    .where('country_id', country_id)
    .then(impl.allHolidays)
    .catch(Promise.reject);
  }  
}


class HolidayWorkController {
  static findById(id) {
    return db.select().from('holiday_work').where('id', id).limit(1)
      .then(impl.singleHolidayWroks)
      .catch(Promise.reject);
  }

  static findAllByCompanyId(companyId) {
    return db.select().from('holiday_work').where('company_id', companyId)
      .then(impl.allHolidayWorks)
      .catch(Promise.reject);
  }

  static create(holiday_work) {
    console.log(holiday_work,'hhhh');
    return db.insert(HolidayWork.toDBModel(holiday_work)).returning('id').into('holiday_work')
      .catch(Promise.reject)
      .then(this.findById)
      .catch(Promise.reject);
  }

  static update(holidayWork) {
    return db('holiday_work').where('id', holidayWork.id).update(HolidayWork.toDBModel(holidayWork))
      .catch(Promise.reject)
      .then(() => this.findById(holidayWork.id))
      .catch(Promise.reject);
  }

  static findByHolidayId(id) {
    return db.select().from('holiday_work').where('holiday_id', id).limit(1)
      .then(impl.singleHolidayWroks)
      .catch(Promise.reject);
  }
}

module.exports = {  
  HolidayController,
  HolidayWorkController,
  
};
