const Promise = require('bluebird');
const knex = require('knex');

const config = require('../config');
const { GiftCard,BookingGiftCardsRelation } = require('../models');

const db = knex(config.db);

/**
 * Private
 */
const impl = {
  singleGiftCard: (giftCards) => {
    const giftCard = giftCards[0];
    if (!giftCard) {
      return Promise.resolve(null);
    }
    return GiftCard.fromDBModel(giftCard);
  },  
  allGiftCard: (giftCards) => {
    const array = [];
    giftCards.forEach(giftCard => array.push(GiftCard.fromDBModel(giftCard)));
    return array;
  }, 
  singleRelation: (relations) => {
    const relation = relations[0];
    if (!relation) {
      return Promise.resolve(null);
    }
    return GiftCard.fromDBModel(relation);
  },  
};

/**
 * Public
 */
class GiftCardController {

  static findById(id) {     
    return db.select().from('gift_card').where('id', id)
      .andWhere('deleted','0')
      .limit(1)
      .then(impl.singleGiftCard)
      .catch(Promise.reject);
  }
  static create(data) {
    return db.insert(GiftCard.toDBModel(data)).returning('id').into('gift_card')
      .catch(Promise.reject)
      .then(this.findById)
      .catch(Promise.reject);
  }

  static findAllByCompanyId(companyId) {

    return db.select().from('gift_card').where('business_id', companyId)
      .andWhere('deleted','0')
      .then(impl.allGiftCard)
      .catch(Promise.reject);
  }  

  static findAllActiveByCompanyId(companyId) {
    return db.select().from('gift_card').where('business_id', companyId)
      .andWhere('deleted','0')
      .andWhere('active','1')
      .then(impl.allGiftCard)
      .catch(Promise.reject);
  } 

  static async update(data) {
   
    return db('gift_card').where('id', data.id).update(GiftCard.toDBModel(data))
      .catch(Promise.reject)
      .then(() => this.findById(data.id))
      .catch(Promise.reject);
  }
     
  static delete(id) { 
    return db('gift_card').where('id', id).update(GiftCard.toDBModel({deleted:1}))
    .catch(Promise.reject)   
  } 
}

class BookingGiftCardsRelationController {

  static findById(id) {     
    return db.select().from('booking_gift_cards_relation')
      .where('id', id)     
      .limit(1)
      .then(impl.singleRelation)
      .catch(Promise.reject);
  }
  static create(data) {
    return db.insert(BookingGiftCardsRelation.toDBModel(data)).returning('id').into('booking_gift_cards_relation')
      .catch(Promise.reject)
      .then(this.findById)
      .catch(Promise.reject);
  }
  static async update(data) {
   
    return db('booking_gift_cards_relation').where('id', data.id).update(BookingGiftCardsRelation.toDBModel(data))
      .catch(Promise.reject)
      .then(() => this.findById(data.id))
      .catch(Promise.reject);
  }
     
 
}
module.exports = {
  GiftCardController,
  BookingGiftCardsRelationController
 
};
