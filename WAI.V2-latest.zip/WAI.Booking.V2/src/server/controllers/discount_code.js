const Promise = require('bluebird');
const knex = require('knex');

const config = require('../config');
const { DiscountCode,DiscountServiceRelation,DiscountServiceExtrasRelation } = require('../models');

const db = knex(config.db);

/**
 * Private
 */
const impl = {
  singleDiscountCode: (discountCodes) => {
    const discountCode = discountCodes[0];
    if (!discountCode) {
      return Promise.resolve(null);
    }
    return DiscountCode.fromDBModel(discountCode);
  },  
  allDiscountCode: (discountCodes) => {
    const array = [];
    discountCodes.forEach(discountCode => array.push(DiscountCode.fromDBModel(discountCode)));
    return array;
  },  
};

/**
 * Public
 */
class DiscountCodeController {

  static findById(id) {     
    return db.select().from('discount').where('id', id)
      .andWhere('deleted','0')
      .limit(1)
      .then(impl.singleDiscountCode)
      .catch(Promise.reject);
  }
  static create(data) {
    return db.insert(DiscountCode.toDBModel(data)).returning('id').into('discount')
      .catch(Promise.reject)
      .then(this.findById)
      .catch(Promise.reject);
  }

  static findAllByCompanyId(companyId) {

    return db.select().from('discount').where('business_id', companyId)
      .andWhere('deleted','0')
      .then(impl.allDiscountCode)
      .catch(Promise.reject);
  }  

  static findAllActiveByCompanyId(companyId) {
    return db.select().from('discount').where('business_id', companyId)
      .andWhere('deleted','0')
      .andWhere('active','1')
      .then(impl.allDiscountCode)
      .catch(Promise.reject);
  } 

  static async update(data) {
   
    return db('discount').where('id', data.id).update(DiscountCode.toDBModel(data))
      .catch(Promise.reject)
      .then(() => this.findById(data.id))
      .catch(Promise.reject);
  }
     
  static delete(id) { 
    return db('discount').where('id', id).update(DiscountCode.toDBModel({deleted:1}))
    .catch(Promise.reject)   
  } 
}


/**
 * Public
 */
class DiscountServiceRelationController {
  static create(data) {
    return db.insert(DiscountServiceRelation.toDBModel(data)).returning('id').into('discount_services_relation')
      .catch(Promise.reject);      
  }
}
/**
 * Public
 */
class DiscountServiceExtrasRelationController {
  static create(data) {
    return db.insert(DiscountServiceExtrasRelation.toDBModel(data)).returning('id').into('discount_service_extras_relation')
      .catch(Promise.reject);      
  } 
}

module.exports = {
  DiscountCodeController, 
  DiscountServiceRelationController,
  DiscountServiceExtrasRelationController
};
