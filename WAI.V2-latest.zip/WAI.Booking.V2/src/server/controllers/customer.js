const Promise = require('bluebird');
const knex = require('knex');
const bcrypt = require('bcrypt-nodejs');
const config = require('../config');
const { Customer,CustomerVersion ,Comment} = require('../models');

const db = knex(config.db);

/**
 * Private
 */
const impl = {
  single: (customers) => {
    const customer = customers[0];
    if (!customer) {
      return Promise.resolve(null);
    }

    return Customer.fromDBModel(customer);
  },
  singleComment: (comments) => {
    const comment = comments[0];
    if (!comment) {
      return [];
    }
    return Comment.fromDBModel(comment);
  },
  allComment: (comments) => {
    const array = [];
    comments.forEach((comment) => {
        const b = Comment.fromDBModel(comment);
        array.push(b);
    });
    return array;
  },
  singleCountry: (countrys) => {
    const contry = countrys[0];
    if (!contry) {
      return Promise.resolve(null);
    }

    return contry;
  },
  allCustomers: (customers) => {
    const array = [];
    customers.forEach((customer) => {
        const b = Customer.fromDBModel(customer);        
        delete b.password;
        array.push(b);
    });

    return array;
},

};

/**
 * Public
 */
class CustomerController {
  static findById(id) {
    return db.select().from('customer').where('id', id).limit(1)
      .then(impl.single)
      .catch(Promise.reject);
  }

  static findByBookedByCompanyId(companyId) {
    return db.select('customer.*').from('customer')
    .leftJoin('booking', 'booking.customer_id', 'customer.id')
    .where('booking.company_id', companyId)
    .groupBy('customer.id')
    .then(impl.allCustomers)
    .catch(Promise.reject);
  }

  static findByPhone(phone) {
    return db.select().from('customer').where('phone', phone).limit(1)
      .then(impl.single)
      .catch(Promise.reject);
  }

  static findByPhoneAndCountryId(countryId,phone) {
    return db.select().from('customer')
      .where('phone', phone)
      .andWhere('country_id',countryId)
      .limit(1)
      .then(impl.single)
      .catch(Promise.reject);
  }

  static findByPhoneAndId(phone,id) {
    return db.select().from('customer')
    .where('phone', phone)
    .andWhere('id','!=',id)
    .limit(1)
    .then(impl.single)
    .catch(Promise.reject);
  }

  static findByVerify(password,id) {
    return db.select().from('customer')
    .where('password', password)
    .andWhere('id',id)
    .limit(1)
    .then(impl.single)
    .catch(Promise.reject);
  }

  static create(customer) {  
    //customer.password = bcrypt.hashSync(customer.password);

    return db.insert(Customer.toDBModel(customer)).returning('id').into('customer')
      .catch(Promise.reject)
      .then(this.findById)
      .catch(Promise.reject);
  }
  static createComment(comments) {     
    return db.insert(Comment.toDBModel(comments)).returning('id').into('comment')
      .catch(Promise.reject)
      .then(this.findCommentById)
      .catch(Promise.reject);
  }

  static findCommentById(id) {
    return db.select().from('comment').where('id', id).limit(1)
      .then(impl.singleComment)
      .catch(Promise.reject);
  }

  static findCommentByCustomerId(cusotmerId,companyId) {
    return db.select().from('comment')
      .where('customer_id', cusotmerId)
      .andWhere('company_id',companyId)
      .then(impl.allComment)
      .catch(Promise.reject);
  }
  static updateComment(comments){
    return db('comment').where('id', comments.id).update(Comment.toDBModel(comments))
    .catch(Promise.reject)
    .then(() => this.findCommentById(comments.id))
    .catch(Promise.reject);
  }
  static async update(customer) {
    const customerId=customer.id;   
    const preCustomer = impl.single(
      await db.select().from('customer')
      .where((qb) => {
        qb.where('id', customerId);
      })
      .orderBy('id', 'desc')
      .limit(1)
    );
    preCustomer.customerId=customerId;
    await db.insert(CustomerVersion.toDBModel(preCustomer)).returning('id').into('customer_version');
    return db('customer').where('id', customer.id).update(Customer.toDBModel(customer))
      .catch(Promise.reject)
      .then(() => this.findById(customer.id))
      .catch(Promise.reject);
  }

  static getCountryById(id){
    return db.select().from('country')
      .where('id',id)
      .limit(1)   
      .then(impl.singleCountry)  
      .catch(Promise.reject);
  }
}

module.exports = CustomerController;
