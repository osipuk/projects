const knex = require('knex');

const config = require('../config');
const { Vacation } = require('../models');

const db = knex(config.db);

/**
 * Private
 */
const impl = {
  single: (vacations) => {
    const vacation = vacations[0];
    if (!vacation) {
      return [];
    }
    return Vacation.fromDBModel(vacation);
  },
  all: (vacations) => {
    const array = [];
    vacations.forEach(vacation => array.push(Vacation.fromDBModel(vacation)));

    return array;
  }
};

/**
 * Public
 */
class VacationController {
  static async findById(id) {
    const vacation = await db.select().from('vacation').where('id', id).limit(1);
    return impl.single(vacation);
  }
  
  static async findByemployeeId(employeeId) {
    return  await db.select().from('vacation')
    .where('employee_id',employeeId)    
    .then(impl.all)
    .catch(Promise.reject);
   
  }

  static async create(vacation) {   
    const id = await db.insert(Vacation.toDBModel(vacation)).returning('id').into('vacation');
    return this.findById(id);
  }

  static async update(vacation) {
    await db('vacation').where('id', vacation.id).update(Vacation.toDBModel(vacation));
    return this.findById(vacation.id);
  }  
  static async del(id) {
    return db('vacation').where('id', id).del()
    .catch(Promise.reject);
  }  
}

module.exports = VacationController;
