const Promise = require('bluebird');
const knex = require('knex');

const config = require('../config');
const { Product, ProductCategory,ProductBook,ProductService } = require('../models');

const db = knex(config.db);

/**
 * Private
 */
const impl = {  
  
  singleCategory: (categories) => {
    const category = categories[0];
    if (!category) {
      return Promise.resolve(null);
    }

    return ProductCategory.fromDBModel(category);
  },
  allProducts: (products) => {    
    const array = [];
    products.forEach(product => array.push(Product.fromDBModel(product)));

    return array;
  },
  allProductsService: (products) => {  
    const array = [];
   // products.forEach(product => array.push(ProductService.fromDBModel(product)));   
    //return array;
    return products;
  },
 
};

/**
 * Public
 */
class ProductController {
  static findById(id) {     
    return db.select().from('product')
      .where('id', id)
      .andWhere('deleted','0')
      .limit(1)
      .then(impl.singleService)
      .catch(Promise.reject);
  }

  static findAllByCompanyCategoryId(companyId,categoryId) {
    return db.select().from('product').where('company_id', companyId).andWhere('service_category_id', categoryId)
    .andWhere('deleted','0')  
    .then(impl.allServices)
      .catch(Promise.reject);
  }
  /**
  static findAllByBookingId(bookingId) {    
    return db.select('product.*').from('product')
      .leftJoin('booking_product_relations','booking_product_relations.product_id','product.id')
      .where('booking_product_relations.booking_id', bookingId)
      .then(impl.allProducts)
      .catch(Promise.reject);
  }
  */
  static findAllByCompanyId(compnayId) {    
  return db.select().from('product')    
    .where('company_id', compnayId)
    .andWhere('deleted','0')
    .then(impl.allProducts)
    .catch(Promise.reject);
  }

  static create(product) {
    return db.insert(Product.toDBModel(product)).returning('id').into('product')
      .catch(Promise.reject)
      .then(this.findById)
      .catch(Promise.reject);
  }
  /** booking product relationship */
 static createProductBooking(product){
    return db.insert(ProductBook.toDBModel(product)).returning('id').into('booking_product_relations')
      .catch(Promise.reject)
      .then(this.findById)
      .catch(Promise.reject);
 }
 static deleteProductBooking(id) {
  return db('booking_product_relations').where('id', id).del()
    .catch(Promise.reject);
}

  static update(product) {
    return db('product').where('id', product.id).update(Product.toDBModel(product))
      .catch(Promise.reject)
      .then(() => this.findById(product.id))
      .catch(Promise.reject);
  }

  static delete(id) {
   
    return db('product').where('id', id).update(Product.toDBModel({deleted:1}))
      .catch(Promise.reject);
  }
  
  static deleteAllProduct(ids){
    return db('product').whereIn('id', ids).update(Product.toDBModel({deleted:1}))
    .catch(Promise.reject)
  }
}


class ProductCategoryController {
  static findById(id) {
    return db.select().from('product_categories')
      .where('id', id)
      .andWhere('deleted','0')
      .limit(1)
      .then(impl.singleCategory)
      .catch(Promise.reject);
  }

  static findAllByCompanyId(companyId) {
    return db.select().from('product_categories').where('company_id', companyId)
       .andWhere('deleted','0')
      .then(impl.allCategories)
      .catch(Promise.reject);
  }

  static create(category) {
    return db.insert(ProductCategory.toDBModel(category)).returning('id').into('product_categories')
      .catch(Promise.reject)
      .then(this.findById)
      .catch(Promise.reject);
  }

  static update(category) {
    return db('product_categories').where('id', category.id).update(ProductCategory.toDBModel(category))
      .catch(Promise.reject)
      .then(() => this.findById(category.id))
      .catch(Promise.reject);
  }

  static delete(id) {
    return db('product_categories').where('id', id).update(Product.toDBModel({deleted:1}))
      .catch(Promise.reject);
  }
   
  static deleteAllCategory(ids){
    return db('product_categories').whereIn('id', ids).update(ProductCategory.toDBModel({deleted:1}))
    .catch(Promise.reject)
  }
}

class ProductServiceController {
  static findById(id) {     
    return db.select().from('products').where('id', id).limit(1)
      .then(impl.singleService)
      .catch(Promise.reject);
  }

  static findAllByCompanyCategoryId(companyId,categoryId) {
    return db.select().from('products').where('company_id', companyId).andWhere('service_category_id', categoryId)
      .then(impl.allServices)
      .catch(Promise.reject);
  }
 
  static findAllByBookingId(bookingId,companyId) {    
    return db.select('products.*','booking_product_relations.id as relationId').from('products')
      .leftJoin('booking_product_relations','booking_product_relations.products_id','products.id')
      .where('booking_product_relations.booking_id', bookingId)
      .andWhere('products.company_id',companyId)
      .then(impl.allProductsService)
      .catch(Promise.reject);
  }

 /**
  static findAllByCompanyId(compnayId) {    
  return db.select().from('products')    
    .where('company_id', compnayId)
    .then(impl.allProducts)
    .catch(Promise.reject);
  }
 */
  static create(product) {
    return db.insert(ProductService.toDBModel(product)).returning('id').into('products')
      .catch(Promise.reject)
      .then(this.findById)
      .catch(Promise.reject);
  }
  /** booking product relationship */
 static createProductBooking(product){
    return db.insert(ProductBook.toDBModel(product)).returning('id').into('booking_product_relations')
      .catch(Promise.reject)
      .then(this.findById)
      .catch(Promise.reject);
 }
 static delete(id) {
  return db('products').where('id', id).del()
    .catch(Promise.reject);
}
  static update(product) {
    return db('products').where('id', product.id).update(ProductService.toDBModel(product))
      .catch(Promise.reject)
      .then(() => this.findById(product.id))
      .catch(Promise.reject);
  }

  static delete(id) {
    return db('products').where('id', id).del()
      .catch(Promise.reject);
  }
}

module.exports = {  
  ProductCategoryController,
  ProductController,
  ProductServiceController  
};
