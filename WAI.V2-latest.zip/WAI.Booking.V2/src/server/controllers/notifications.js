const Promise = require('bluebird');
const knex = require('knex');
const bcrypt = require('bcrypt-nodejs');
const config = require('../config');
const db = knex(config.db);
const { Notifications } = require('../models');
/**
 * Private
 */
const impl = {  
  
  singleNotification: (notifications) => {
    const notification = notifications[0];
    if (!notification) {
      return null;
    }
    return Notifications.fromDBModel(notification);
  }
 
};
/**
 * Public
 */
class NotificationsController {
  static findById(id) {     
    return db.select().from('notifications').where('id', id).limit(1)
      .then(impl.singleNotification)
      .catch(Promise.reject);
  } 
  static findByCompanyId(companyId) {     
    return db.select().from('notifications').where('company_id', companyId).limit(1)
      .then(impl.singleNotification)
      .catch(Promise.reject);
  } 
  static create(notifications) {   
    return db.insert(Notifications.toDBModel(notifications)).returning('id').into('notifications')
      .catch(Promise.reject)
      .then(this.findById)
      .catch(Promise.reject);
  }
  static update(notifications) {
    return db('notifications').where('id', notifications.id).update(Notifications.toDBModel(notifications))
      .catch(Promise.reject)
      .then(() => this.findById(notifications.id))
      .catch(Promise.reject);
  }
  
}

module.exports = NotificationsController;
