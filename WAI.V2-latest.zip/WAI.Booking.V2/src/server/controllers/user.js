const Promise = require('bluebird');
const knex = require('knex');
const bcrypt = require('bcrypt-nodejs');

const config = require('../config');
const { Company,User } = require('../models');

const db = knex(config.db);

/**
 * Private
 */
const impl = {
  single: (users) => {
    const user = impl.singleRaw(users);
    if (!user) {
      return null;
    }   
      return user;
  },
  singleRaw: (users) => {
    const user = users[0];
    if (!user) {
      return null;
    }
    return User.fromDBModel(user);
  },
  Raw: (companies) => {
    const company = companies[0];
    if (!company) {
      return null;
    }
    company.type="company";
    return company;
  }
};

/**
 * Public
 */
class UserController {
  static findById(id) {
    return db.select().from('user')     
      .where('id', id)   
      .orderBy('id', 'desc')
      .limit(1)
     .then(impl.singleRaw)
      .catch(Promise.reject);
  } 

  static findByEmailWithCompany(email) {
    return db.select('user.email','user.phone','user.phone_veryfied','user.email_veryfied',
    'user.first_name','user.last_name','company.id','company.cvr','company.company_name','company.zip_code','company.city',
    'company.address','company.accept_booking_automatically',' company.lock_booking_xhour_before','company.book_latest_xhour_before',
    'company.payment_upfront','company.sms_sender_name','company.country_id','company.interval','company.custom_url','company.description',
    'company.facebook','company.instagram','company.twitter', 'company.website','company.lng','company.lat','country.country_phone_code','country.currency_code').from('user')
      .leftJoin('company','user.company_id','company.id')
      .leftJoin('country','country.id','company.country_id')
      .where('user.email', email)
      .andWhere('user.deleted',0)
      .andWhere('user.role_id',1)
      .limit(1)
      .then(impl.Raw)
      .catch(Promise.reject);
  }
  
  static findCompanyByComapnyId(id) {
    return db.select().from('user').where('company_id', id)
        .andWhere('role_id','1')
      .orderBy('id', 'desc')
      .limit(1)
      .then(impl.single)
      .catch(Promise.reject);
  }

  static findByEmail(email) {
    return db.select().from('user')     
      .where('email', email)
      .andWhere('deleted',0)      
      .limit(1)
      .then(impl.single)
      .catch(Promise.reject);
  }

  static findByPhone(phone){
    return db.select().from('user').where('phone', phone)
      .orderBy('id', 'desc')
      .limit(1)
      .then(impl.single)
      .catch(Promise.reject);
 }

  static async create(user) {
    const newUser = user;
    newUser.password = bcrypt.hashSync(user.password);  
    newUser.versionId = null;
    const id = await db.insert(User.toDBModel(newUser)).returning('id').into('user');
    return this.findById(id);
  }

  static async update(company) {  
    const updatedCompany = company;
    const companyId =company.id;
   // updatedCompany.password = bcrypt.hashSync(company.password);  
    // set prevCompany.versionId to the created id   
    await db('user').where('id', company.id).update(User.toDBModel(updatedCompany));    
    return this.findById(companyId);
  }
/**
 * 
 * @param {} company 
 */
  static async update1(company) {  
    const updatedCompany = company;
    const companyId =company.id;    
    await db('user').where('company_id', company.id)
    .andWhere('role_id','1')
    .update(User.toDBModel(updatedCompany));    
    return this.findById(companyId);
  }

  
  static findByToken(token) {
    return db.select().from('user').where('email_token', token)     
      .limit(1)
      .then(impl.singleRaw)
      .catch(Promise.reject);
  } 
  
  
}

module.exports = UserController;



