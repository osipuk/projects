class Employee {
  constructor(
    id,
    companyId,
    profilePicturePath,
    name,
    deleted
  ) {
    this.id = id;
    this.companyId = companyId;
    this.profilePicturePath = profilePicturePath;
    this.name = name;
    this.deleted=deleted;
  }

  static fromDBModel(model) {
    return new Employee(
      model.id,
      model.company_id,
      model.profile_picture_path,
      model.name,
      model.deleted
    );
  }

  static toDBModel(employee) {
    return {
      // id: employee.id,
      company_id: employee.companyId,
      profile_picture_path: employee.profilePicturePath,
      name: employee.name,
      deleted:employee.deleted
    };
  }
}

module.exports = Employee;
