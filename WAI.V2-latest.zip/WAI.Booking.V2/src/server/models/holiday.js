class Holiday {
  constructor(
    id,
    day,
    date,
    holidayNativeName,
    holidayEnglishName,
    nationalHoliday,
    nonPublicHoliday,
    governmentHoliday,
    countryId  
  ) {
    this.id = id;
    this.day=day;
    this.date=date;
    this.holidayNativeName=holidayNativeName;
    this.holidayEnglishName=holidayEnglishName;
    this.nationalHoliday=nationalHoliday;
    this.nonPublicHoliday=nonPublicHoliday;
    this.governmentHoliday=governmentHoliday;
    this.countryId = countryId;    
  }

  static fromDBModel(model) {
    return new Holiday(
      model.id,
      model.day,
      model.date,
      model.holiday_native_name,
      model.holiday_english_name,
      model.national_holiday,
      model.non_public_holiday,
      model.government_holiday,
      model.country_id
    );
  }

  static toDBModel(holiday) {
    return {
      // id: serviceCategory.id,
      day: holiday.day,
      date: holiday.date,
      holiday_native_name: holiday.holidayNativeName,
      holiday_english_name: holiday.holidayEnglishName,
      national_holiday: holiday.nationalHoliday,
      non_public_holiday: holiday.nonPublicHoliday,
      government_holiday:holiday.governmentHoliday,
      country_id:countryId
    };
  }
}

class HolidayWork {
  constructor(
    id,
    holidayId,
    date,
    isWork,
    companyId,
    employeeId
  ) {
    this.id = id;
    this.holidayId = holidayId;
    this.date = date;
    this.isWork = isWork;
    this.companyId = companyId;
    this.employeeId=employeeId;
  }

  static fromDBModel(model) {
    return new HolidayWork(
      model.id,
      model.holiday_id,
      model.date,
      model.is_work,
      model.company_id,
      model.employee_id,
    );
  }

  static toDBModel(model) {
    return {
      // id: serviceCategory.id,
      holiday_id: model.holidayId,
      date: model.date,
      is_work: model.isWork,
      company_id: model.companyId,
      employee_id: model.employeeId,
    };
  }
}

module.exports = { 
  Holiday,
  HolidayWork,
 
};
