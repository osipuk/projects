/* eslint-disable key-spacing */
/* eslint-disable linebreak-style */
const bookings = require('./booking');
const employee = require('./employee');
const company = require('./company');
const user = require('./user');
const customer = require('./customer');
const customerGroup = require('./customer_group');
const services = require('./service');
const product = require('./product');
const payment = require('./payment');
const payments = require('./payments');
const comment = require('./comment');
const about = require('./about');
const terms = require('./terms');
const holiday = require('./holiday');
const vacation = require('./vacation');
const images = require('./images');
const notifications = require('./notifications');
const bookingnotify = require('./booking_notify');
const extraServiceRelations = require('./extra_service_relations');
const EmployeeServiceRelations = require('./employee_service_relations');
const discountCard = require('./discount_card');
const giftCard = require('./gift_card');
const discountCode=require('./discount_code');
//const discountCardUserRelation=require('./discount_code');

module.exports = {
  Booking: bookings.Booking,
  BookingVersion: bookings.BookingVersion,
  BookingExtra: bookings.BookingExtra,
  BookingService: bookings.BookingService,
  BookingItem: bookings.BookingItem,
  BookingHours: bookings.BookingHours,
  Employee: employee,
  Company: company.Company,
  CompanyVersion: company.CompanyVersion,
  User: user.User,
  Customer: customer.Customer,
  CustomerVersion: customer.CustomerVersion,
  CustomerGroup: customerGroup,
  Payment: payment,
  Comment: comment.Comment,
  Service: services.Service,
  ServiceVersion: services.ServiceVersion,
  ServiceExtra: services.ServiceExtra,
  ServiceExtraVersion: services.ServiceExtraVersion,
  ServiceCategory: services.ServiceCategory,
  ProductCategory: product.ProductCategory,
  Product: product.Product,
  ProductBook: product.ProductBook,
  ProductService: product.ProductService,
  Payments: payments.Payments,
  PaymentSetting: payments.PaymentSetting,
  About: about,
  Terms: terms,
  Holiday: holiday.Holiday,
  HolidayWork: holiday.HolidayWork,
  Vacation: vacation.Vacation,
  Images: images,
  Notifications: notifications.Notifications,
  BookingNotify: bookingnotify.BookingNotify,
  ExtraServiceRelations: extraServiceRelations.ExtraServiceRelations,
  EmployeeServiceRelations: EmployeeServiceRelations.EmployeeServiceRelations,
  DiscountCard: discountCard.DiscountCard,
  GiftCard:giftCard.GiftCard,
  BookingGiftCardsRelation:giftCard.BookingGiftCardsRelation,
  DiscountCode:discountCode.DiscountCode,
  DiscountServiceRelation:discountCode.DiscountServiceRelation,
  DiscountServiceExtrasRelation:discountCode.DiscountServiceExtrasRelation,
  DiscountCardUserRelation:discountCard.DiscountCardUserRelation,
  BookingDiscountCardsRelation:discountCard.BookingDiscountCardsRelation
  
};
