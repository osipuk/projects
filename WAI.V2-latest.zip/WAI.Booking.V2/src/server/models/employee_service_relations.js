class EmployeeServiceRelations {
  constructor(
    id,
    companyId,
    employeeId,
    serviceId,
    deleted
   
  ) {
    this.id = id;
    this.companyId=companyId;
    this.employeeId=employeeId;
    this.serviceId=serviceId;
    this.deleted=deleted;   
  }

  static fromDBModel(model) {
    return new EmployeeServiceRelations(
      model.id,
      model.company_id,
      model.employee_id,
      model.service_id,
      model.deleted     
    );
  }

  static toDBModel(model) {
    return {
      // id: serviceCategory.id,
      company_id:model.companyId,
      employee_id: model.employeeId,
      service_id: model.serviceId,
      deleted:model.deleted
    };
  }
}

module.exports = { 
  EmployeeServiceRelations
};
