class Terms {
  constructor(
    id,
    companyId,
    languageId,
    terms
  ) {
    this.id = id;
    this.companyId = companyId;
    this.languageId = languageId;
    this.terms = terms;
  }

  static fromDBModel(model) {
    return new Terms(
      model.id,
      model.company_id,
      model.language_id,
      model.terms
    );
  }

  static toDBModel(terms) {
    return {
      // id: employee.id,
      company_id: terms.companyId,
      language_id: terms.languageId,
      terms: terms.terms
    };
  }
}

module.exports = Terms;
