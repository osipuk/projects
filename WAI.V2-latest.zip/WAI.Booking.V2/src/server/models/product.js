class ProductCategory {
  constructor(
    id,
    companyId,
    name,
    deleted
  ) {
    this.id = id;
    this.companyId = companyId;
    this.name = name;
    this.deleted=deleted;
  }

  static fromDBModel(model) {
    return new ProductCategory(
      model.id,
      model.company_id,
      model.name,
      model.deleted

    );
  }

  static toDBModel(serviceCategory) {
    return {
      // id: serviceCategory.id,
      company_id: serviceCategory.companyId,
      name: serviceCategory.name,
      deleted:serviceCategory.deleted
    };
  }
}

class ProductBook {
  constructor(
    id,
    bookingId,
    productId
  ) {
    this.id = id;
    this.bookingId = bookingId;
    this.productId = productId;
  }

  static fromDBModel(model) {
    return new ProductBook(
      model.id,
      model.bookingId,
      model.productId
    );
  }

  static toDBModel(productBook) {
    return {
      // id: serviceCategory.id,
      booking_id: productBook.bookingId,
      products_id: productBook.productId
    };
  }
}

class Product {
  constructor(
    id,
    name,
    quantity,
    category,
    retailPrice,
    wholeSalePrice,
    companyId,
    deleted
  ) {
    this.id = id;   
    this.name = name;
    this.quantity = quantity;
    this.category = category;
    this.retailPrice = retailPrice;
    this.wholeSalePrice = wholeSalePrice;
    this.companyId=companyId;
    this.deleted=deleted;
  }

  static fromDBModel(model) {
    return new Product(
      model.id,      
      model.name,
      model.quantity,
      model.category,
      model.retail_price,
      model.whole_sale_price,
      model.company_id,   
      model.deleted
    );
  }

  static toDBModel(product) {
    return {         
      name: product.name,
      quantity: product.quantity,
      category: product.category,
      retail_price: product.retailPrice,
      whole_sale_price: product.wholeSalePrice,
      company_id:product.companyId,
      deleted:product.deleted
      
    };
  }
}

class ProductService {
  constructor(
    id,    
    itemNumber,
    itemName,
    quantity,
    category,
    retailPrice,
    wholeSalePrice,
    companyId
  ) {
    this.id = id;   
    this.itemName = itemName;
    this.itemNumber = itemNumber;
    this.quantity = quantity;
    this.category = category;
    this.retailPrice = retailPrice;
    this.wholeSalePrice = wholeSalePrice;
    this.companyId=companyId;
  }

  static fromDBModel(model) {
    return new ProductService(
      model.id,
      model.item_name,  
      model.item_number,
      model.quantity,
      model.category,
      model.retail_price,
      model.whole_sale_price,
      model.company_id,   
    );
  }

  static toDBModel(product) {
    return {         
      item_name: product.itemName,
      item_number:product.itemNumber,
      quantity: product.quantity,
      category: product.category,
      retail_price: product.retailPrice,
      whole_sale_price: product.wholeSalePrice,
      company_id:product.companyId
      
    };
  }
}

module.exports = { 
  ProductCategory,
  Product,
  ProductBook,
  ProductService
};
