class About {
  constructor(
    id,
    companyId,
    languageId,
    about
  ) {
    this.id = id;
    this.companyId = companyId;
    this.languageId = languageId;
    this.about = about;
  }

  static fromDBModel(model) {
    return new About(
      model.id,
      model.company_id,
      model.language_id,
      model.about
    );
  }

  static toDBModel(about) {
    return {
      // id: employee.id,
      company_id: about.companyId,
      language_id: about.languageId,
      about: about.about
    };
  }
}

module.exports = About;
