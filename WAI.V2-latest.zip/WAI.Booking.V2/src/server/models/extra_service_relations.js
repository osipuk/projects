class ExtraServiceRelations {
  constructor(
    id,
    companyId,
    serviceId,
    extraId,
    deleted
   
  ) {
    this.id = id;
    this.companyId=companyId;
    this.serviceId=serviceId;
    this.extraId=extraId;
    this.deleted=deleted;   
  }

  static fromDBModel(model) {
    return new ExtraServiceRelations(
      model.id,
      model.company_id,
      model.service_id,
      model.extra_id,
      model.deleted     
    );
  }

  static toDBModel(model) {
    return {
      // id: serviceCategory.id,
      company_id:model.companyId,
      service_id: model.serviceId,
      extra_id: model.extraId,
      deleted:model.deleted
    };
  }
}

module.exports = { 
  ExtraServiceRelations
};
