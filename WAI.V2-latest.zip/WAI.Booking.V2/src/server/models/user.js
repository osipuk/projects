const bcrypt = require('bcrypt-nodejs');

class User {
  constructor(
    id,   
    email,
    password,
    phone,
    phoneVeryfied,
    emailVeryfied,   
    firstName,
    lastName,
    verifyCode,
    emailToken,
    companyId,
    roleId,
    deleted,
    profilePicturePath
  ) {
    this.id = id;
    this.type = User.Type;
    this.email = email;
    this.password = password;
    this.phone = phone;
    this.phoneVeryfied = phoneVeryfied;
    this.emailVeryfied=emailVeryfied;
    this.firstName = firstName;
    this.lastName = lastName;
    this.verifyCode = verifyCode;
    this.emailToken = emailToken;
    this.companyId=  companyId;
    this.roleId=roleId;
    this.deleted=deleted;
    this.profilePicturePath=profilePicturePath;
  }

  static fromDBModel(model) {
    return new User(
      model.id,
      model.email,
      Buffer.from(model.password, 'binary').toString('utf-8'),
      model.phone,     
      model.phone_veryfied,
      model.email_veryfied,
      model.first_name,
      model.last_name,
      model.verify_code,
      model.email_token,
      model.company_id,
      model.role_id,
      model.deleted,
      model.profile_picture_path
     
    );
  }

  static toDBModel(user) {
   
    return {
      // id: company.id, // don't need to map id
      email:user.email,
      password:user.password,
      phone:user.phone,
      phone_veryfied:user.phoneVeryfied,
      email_veryfied:user.emailVeryfied,
      first_name:user.firstName,
      last_name:user.lastName,
      verify_code:user.verifyCode,
      email_token:user.emailToken,
      company_id:user.companyId,
      role_id:user.roleId,
      deleted:user.deleted,
      profile_picture_path:user.profilePicturePath
    };
  }

  validPassword(password) {    
    return bcrypt.compareSync(password, this.password);
  }

  static get Type() {
    return 'company';
  }
}

module.exports = {
  User
};

