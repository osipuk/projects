class ServiceCategory {
  constructor(
    id,
    companyId,
    name,
    defaultServiceCategory,
    description,
    deleted
  ) {
    this.id = id;
    this.companyId = companyId;
    this.name = name;
    this.defaultServiceCategory=defaultServiceCategory;
    this.description=description;
    this.deleted=deleted;
  }

  static fromDBModel(model) {
    return new ServiceCategory(
      model.id,
      model.company_id,
      model.name,
      model.default_service_category,
      model.description,
      model.deleted
    );
  }

  static toDBModel(serviceCategory) {
    return {
      // id: serviceCategory.id,
      company_id: serviceCategory.companyId,
      name: serviceCategory.name,
      default_service_category:serviceCategory.defaultServiceCategory,
      description:serviceCategory.description,
      deleted:serviceCategory.deleted
    };
  }
}

class Service {
  constructor(
    id,
    serviceCategoryId,
    companyId,
    name,
    description,
    price,
    duration,
    gender,
    vary,
    deleted,
    weight
  ) {
    this.id = id;
    this.serviceCategoryId = serviceCategoryId;
    this.companyId = companyId;
    this.name = name;
    this.description = description;
    this.price = price;
    this.duration = duration;
    this.gender = gender;
    this.vary=vary;
    this.deleted=deleted;
    this.weight=weight;
  }

  static fromDBModel(model) {
    return new Service(
      model.id,
      model.service_category_id,
      model.company_id,
      model.name,
      model.description,
      model.price,
      model.duration,
      model.gender,
      model.vary,
      model.deleted,
      model.weight
    );
  }

  static toDBModel(service) {
    return {
      // id: service.id,
      service_category_id: service.serviceCategoryId,
      company_id: service.companyId,
      name: service.name,
      description: service.description,
      price: service.price,
      duration: service.duration,
      gender: service.gender,
      vary:service.vary,
      deleted:service.deleted,
      weight:service.weight
    };
  }
}

class ServiceVersion {
  constructor(
    id,
    serviceCategoryId,
    companyId,
    name,
    description,
    price,
    duration,
    gender,
    serviceId,
    updatedAt,
    vary,
    deleted,
    weight
  ) {
    this.id = id;
    this.serviceCategoryId = serviceCategoryId;
    this.companyId = companyId;
    this.name = name;
    this.description = description;
    this.price = price;
    this.duration = duration;
    this.gender = gender;
    this.serviceId=serviceId;
    this.updatedAt=updatedAt;
    this.vary=vary;
    this.deleted=deleted;
    this.weight=weight;
  }

  static fromDBModel(model) {
    return new ServiceVersion(
      model.id,
      model.service_category_id,
      model.company_id,
      model.name,
      model.description,
      model.price,
      model.duration,
      model.gender,
      model.service_id,
      model.updated_at,
      model.vary,
      model.deleted,
      model.weight

    );
  }

  static toDBModel(service) {   
    return {
      // id: service.id,
      service_category_id: service.serviceCategoryId,
      company_id: service.companyId,
      name: service.name,
      description: service.description,
      price: service.price,
      duration: service.duration,
      gender: service.gender,
      service_id:service.serviceId,
      vary:service.vary,
      deleted:service.deleted,
      weight:service.weight
    };
  }
}

class ServiceExtra {
  constructor(
    id,
    companyId,
    serviceId,
    name,
    description,
    price,
    duration,
    gender,
    vary,
    deleted
  ) {
    this.id = id;
    this.companyId = companyId;
    this.serviceId = serviceId;
    this.name = name;
    this.description = description;
    this.price = price;
    this.duration = duration;
    this.gender = gender;
    this.vary=vary;
    this.deleted=deleted;
  }

  static fromDBModel(model) {
    return new ServiceExtra(
      model.id,
      model.company_id,
      model.service_id,
      model.name,
      model.description,
      model.price,
      model.duration,
      model.gender,
      model.vary,
      model.deleted
    );
  }

  static toDBModel(serviceExtra) {
    return {
      // id: serviceExtra.id,
      company_id: serviceExtra.companyId,
      service_id: serviceExtra.serviceId,
      name: serviceExtra.name,
      description: serviceExtra.description,
      price: serviceExtra.price,
      duration: serviceExtra.duration,
      gender: serviceExtra.gender,
      vary:serviceExtra.vary,
      deleted:serviceExtra.deleted
    };
  }
}

class ServiceExtraVersion {
  constructor(
    id,
    companyId,
    serviceId,
    name,
    description,
    price,
    duration,
    gender,
    serviceExtraId,
    updatedAt,
    vary,
    deleted
  ) {
    this.id = id;
    this.companyId = companyId;
    this.serviceId = serviceId;
    this.name = name;
    this.description = description;
    this.price = price;
    this.duration = duration;
    this.gender = gender;
    this.serviceExtraId=serviceExtraId;
    this.updatedAt=updatedAt;
    this.vary=vary;
    this.deleted=deleted;
  }

  static fromDBModel(model) {
    return new ServiceExtraVersion(
      model.id,
      model.company_id,
      model.service_id,
      model.name,
      model.description,
      model.price,
      model.duration,
      model.gender,
      model.service_extra_id,
      model.updated_at,
      model.vary,
      model.deleted
    );
  }

  static toDBModel(serviceExtra) {
    return {
      // id: serviceExtra.id,
      company_id: serviceExtra.companyId,
      service_id: serviceExtra.serviceId,
      name: serviceExtra.name,
      description: serviceExtra.description,
      price: serviceExtra.price,
      duration: serviceExtra.duration,
      gender: serviceExtra.gender,
      service_extra_id:serviceExtra.serviceExtraId,
      vary:serviceExtra.vary,
      deleted:serviceExtra.deleted
    };
  }
}

module.exports = {
  Service,
  ServiceVersion,
  ServiceCategory,
  ServiceExtra,
  ServiceExtraVersion
};
