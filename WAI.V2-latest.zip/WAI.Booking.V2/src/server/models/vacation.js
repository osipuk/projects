class Vacation {
  constructor(
    id,
    companyId,
    employeeId,
    fromDate,
    toDate,
    comment
  ) {
    this.id = id;
    this.companyId=companyId;
    this.employeeId=employeeId;
    this.fromDate=fromDate;
    this.toDate=toDate;
    this.comment=comment;
  }

  static fromDBModel(model) {
    return new Vacation(
      model.id,
      model.company_id,
      model.employee_id,
      model.from_date,
      model.to_date,
      model.comment,
    );
  }

  static toDBModel(model) {
    return {
      // id: serviceCategory.id,
      company_id: model.companyId,
      employee_id: model.employeeId,
      from_date: model.fromDate,
      to_date: model.toDate,
      comment:model.comment
    };
  }
}

module.exports = { 
  Vacation
};
