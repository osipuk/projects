class CustomerGroup {
  constructor(
    id,
    customerId,
    companyId
  ) {
    this.id = id;
    this.customerId = customerId;
    this.companyId = companyId;
  }

  static fromDBModel(model) {
    return new CustomerGroup(
      model.id,
      model.customer_id,
      model.company_id
    );
  }

  static toDBModel(customerGroup) {
    return {
      // id: customerGroup.id,
      customer_id: customerGroup.customerId,
      company_id: customerGroup.companyId
    };
  }
}

module.exports = CustomerGroup;
