class Payment {
  constructor(
    id,
    companyId,
    customerId,
    bookingId,
    paymentMethod,
    txid,
    totalAmount,
    createdOn
  ) {
    this.id = id;
    this.companyId = companyId;
    this.customerId = customerId;
    this.bookingId = bookingId;
    this.paymentMethod = paymentMethod;
    this.txid = txid;
    this.totalAmount = totalAmount;
    this.createdOn = createdOn;
  }

  static fromDBModel(model) {
    return new Payment(
      model.id,
      model.company_id,
      model.customer_id,
      model.booking_id,
      model.payment_method,
      model.txid,
      model.total_amount,
      model.created_on
    );
  }

  static toDBModel(payment) {
    return {
      // id: payment.id,
      company_id: payment.companyId,
      customer_id: payment.customerId,
      booking_id: payment.bookingId,
      payment_method: payment.paymentMethod,
      txid: payment.txid,
      total_amount: payment.totalAmount,
      created_on: payment.createdOn
    };
  }
}


/** payments */
class Payments {
  constructor(
    id,    
    cardId,
    bookingId,
    cashAmount,
    cardAmount,
    companyId
  ) {
    this.id = id;
    this.cardId = cardId;       
    this.bookingId = bookingId;
    this.cashAmount = cashAmount;
    this.cardAmount = cardAmount;
    this.companyId = companyId;
  }

  static fromDBModel(model) {
    return new Payments(
      model.id,
      model.card_id,
      model.company_id,      
      model.cash_amount,
      model.card_amount, 
      model.booking_id,  
    );
  }

  static toDBModel(payments) {
    return {
      card_id:payments.cardId,  
      company_id: payments.companyId,
      booking_id:payments.bookingId,
      cash_amount: payments.cashAmount,
      card_amount: payments.cardAmount,      
    };
  }
}


/** payment Settings*/
class PaymentSetting {
  constructor(
    id,    
    companyId,
    paypalKey,
    strip,
    coinPayment,
    mastercard,
    visa,
    dankort,
    cash,
    paypal,
    americanExpress,
    maestro,
    bitcoin
    
  ) {
    this.id = id;
    this.companyId = companyId;       
    this.paypalKey = paypalKey; 
    this.strip = strip; 
    this.coinPayment = coinPayment; 
    this.mastercard = mastercard; 
    this.visa = visa;
    this.dankort = dankort;
    this.cash = cash; 
    this.paypal = paypal; 
    this.americanExpress = americanExpress; 
    this.maestro = maestro;
    this.bitcoin = bitcoin; 
  }

  static fromDBModel(model) {
    return new PaymentSetting(
      model.id,     
      model.company_id,
      model.paypal_key,
      model.strip,
      model.coin_payment,
      model.mastercard,
      model.visa,
      model.dankort,
      model.cash,
      model.paypal,
      model.american_express,
      model.maestro,
      model.bitcoin
    );
  }

  static toDBModel(payments) {
    return {
      company_id:payments.companyId,  
      paypal_key:payments.paypalKey,
      strip:payments.strip,
      coin_payment:payments.coinPayment,
      mastercard:payments.mastercard,
      visa:payments.visa,
      dankort:payments.dankort,
      cash:payments.cash,
      paypal:payments.paypal,
      american_express:payments.americanExpress,
      maestro:payments.maestro,
      bitcoin:payments.bitcoin,
    
    };
  }
}

module.exports = { 
  Payment,
  Payments,
  PaymentSetting
};


