class GiftCard {
  constructor(
    id,
    code,
    businessId,
    startBalance,
    availableBalance,
    createdBy,
    createdOn,
    active,
    deleted
   
  ) {
    this.id = id;
    this.code=code;
    this.businessId = businessId;
    this.startBalance=startBalance;
    this.availableBalance=availableBalance;
    this.createdBy=createdBy;
    this.createdOn=createdOn;
    this.active=active;
    this.deleted=deleted;    
  }

  static fromDBModel(model) {
    return new GiftCard(
      model.id,
      model.code,
      model.business_id,
      model.start_balance,
      model.available_balance,
      model.created_by,
      model.created_on,
      model.active,
      model.deleted
    );
  }

  static toDBModel(terms) {
    return {
      // id: employee.id,
      business_id: terms.businessId,
      code:terms.code,
      start_balance:terms.startBalance,
      available_balance:terms.availableBalance,
      created_by:terms.createdBy,
      created_on:terms.createdOn,
      active:terms.active,
      deleted:terms.deleted
    };
  }
}

class BookingGiftCardsRelation {
  constructor(
    id,
    bookingId,
    giftCardId,
    giftCardAmountUsed
   
  ) {
    this.id = id;
    this.bookingId=bookingId,
    this.giftCardId=giftCardId,
    this.giftCardAmountUsed=giftCardAmountUsed
  }

  static fromDBModel(model) {
    return new BookingGiftCardsRelation(
      model.id,
      model.booking_id,
      model.gift_card_id,
      model.gift_card_amount_used     
    );
  }

  static toDBModel(terms) {
    return {
      // id: employee.id,
      booking_id: terms.bookingId,
      gift_card_id:terms.giftCardId,
      gift_card_amount_used:terms.giftCardAmountUsed
    };
  }
}

module.exports = { 
  GiftCard,
  BookingGiftCardsRelation
};
