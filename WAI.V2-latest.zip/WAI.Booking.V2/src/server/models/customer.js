
class Customer {
  constructor(
    id,
    password,
    //phoneCountryCode,
    phone,
    firstName,
    lastName,
    gender,
    note,
    createdOn,
    lastPasswordReset,
    zipCode,
    city,
    address1,
    address2,
    phoneWork,
    birthday,
    email,
    countryId,
    type,
    anonymously
  ) {
    this.id = id;    
    this.password = password;
    //this.phoneCountryCode = phoneCountryCode;
    this.phone = phone;
    this.firstName = firstName;
    this.lastName = lastName;
    this.gender = gender;
    this.note = note;
    this.createdOn = createdOn;
    this.lastPasswordReset = lastPasswordReset;
    this.zipCode = zipCode;
    this.city = city;
    this.address1 = address1;
    this.address2 = address2;
    this.phoneWork = phoneWork;
    this.birthday = birthday;
    this.email=email;
    this.countryId=countryId;
    this.type=type;
    this.anonymously=anonymously;
  }

  static fromDBModel(model) {
    return new Customer(
      model.id,
      model.password,
     // model.phone_country_code,
      model.phone,
      model.first_name,
      model.last_name,
      model.gender,
      model.note,
      model.created_on,
      model.last_password_reset,
      model.zip_code,
      model.city,
      model.address1,
      model.address2,
      model.phone_work,
      model.birthday,
      model.email,
      model.country_id,
      model.type,
      model.anonymously
    );
  }

  static toDBModel(customer) {
   
    return {
      // id: customer.id, // don't need to map id
      password: customer.password,
      //phone_country_code: customer.phoneCountryCode,
      phone: customer.phone,
      first_name: customer.firstName,
      last_name: customer.lastName,
      gender: customer.gender,
      note: customer.note,
      created_on: customer.createdOn,
      last_password_reset: customer.lastPasswordReset,
      zip_code: customer.zipCode,
      city: customer.city,
      address1: customer.address1,
      address2: customer.address2,
      phone_work: customer.phoneWork,
      birthday: customer.birthday,
      email:customer.email,
      country_id:customer.countryId,
      type:customer.type,
      anonymously:customer.anonymously
    };
  }

  validPassword(password) {
    return password === this.password;
  }

  static get Type() {
    return 'customer';
  }
}

class CustomerVersion {
  constructor(
    id,
    password,
    customerId,
    phone,
    firstName,
    lastName,
    gender,
    note,
    createdOn,
    lastPasswordReset,
    zipCode,
    city,
    address1,
    address2,
    phoneWork,
    birthday,
    email,
    countryId,
    type,
    anonymously
  ) {
    this.id = id;    
    this.password = password;
    this.customerId = customerId;
    this.phone = phone;
    this.firstName = firstName;
    this.lastName = lastName;
    this.gender = gender;
    this.note = note;
    this.createdOn = createdOn;
    this.lastPasswordReset = lastPasswordReset;
    this.zipCode = zipCode;
    this.city = city;
    this.address1 = address1;
    this.address2 = address2;
    this.phoneWork = phoneWork;
    this.birthday = birthday;
    this.email=email;
    this.countryId=countryId;
    this.type=type;
    this.anonymously=anonymously;
  }

  static fromDBModel(model) {
    return new CustomerVersion(
      model.id,
      model.password,
      model.customer_id,
      model.phone,
      model.first_name,
      model.last_name,
      model.gender,
      model.note,
      model.created_on,
      model.last_password_reset,
      model.zip_code,
      model.city,
      model.address1,
      model.address2,
      model.phone_work,
      model.birthday,
      model.email,
      model.country_id,
      model.type,
      model.anonymously
    );
  }

  static toDBModel(customer) {
   
    return {
      // id: customer.id, // don't need to map id
      password: customer.password,
      customer_id:customer.customerId,
      phone: customer.phone,
      first_name: customer.firstName,
      last_name: customer.lastName,
      gender: customer.gender,
      note: customer.note,
      created_on: customer.createdOn,
      last_password_reset: customer.lastPasswordReset,
      zip_code: customer.zipCode,
      city: customer.city,
      address1: customer.address1,
      address2: customer.address2,
      phone_work: customer.phoneWork,
      birthday: customer.birthday,
      email:customer.email,
      country_id:customer.countryId,
      type:customer.type,
      anonymously:customer.anonymously
    };
  }  
}

module.exports = {
  Customer,
  CustomerVersion
};
