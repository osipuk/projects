class Images {
  constructor(
    id,
    companyId,
    image1,
    image2,
    image3,
    image4,
    image5
  ) {
    this.id = id;
    this.companyId = companyId;
    this.image1=image1;
    this.image2=image2;
    this.image3=image3;
    this.image4=image4;
    this.image5=image5;
  }

  static fromDBModel(model) {
    return new Images(
      model.id,
      model.company_id,
      model.image_1,
      model.image_2,
      model.image_3,
      model.image_4,
      model.image_5,
    );
  }

  static toDBModel(images) {
    return {
      // id: employee.id,
      company_id: images.companyId,
      image_1: images.image1,
      image_2: images.image2,
      image_3: images.image3,
      image_4: images.image4,
      image_5: images.image5,
    };
  }
}

module.exports = Images;
