const bcrypt = require('bcrypt-nodejs');

class Company {
  constructor(
    id,
    versionId,
    rootId,
    cvr,
    companyName,
    zipCode,
    city,
    address,
    acceptBookingAutomatically,
    lockBookingXHourBefore,
    bookLatestXHourBefore,
    paymentUpfront,
    smsSenderName,
    countryId,
    interval,
    customUrl,  
    description,
    facebook,
    instagram,
    twitter,
    website,
    lat,
    lng,
    bussinessEmail
  ) {
    this.id = id;
    this.type = Company.Type;
    this.versionId = versionId;
    this.rootId = rootId; 
    this.cvr = cvr;
    this.companyName = companyName; 
    this.zipCode = zipCode;
    this.city = city;
    this.address = address;
    this.acceptBookingAutomatically = acceptBookingAutomatically;
    this.lockBookingXHourBefore = lockBookingXHourBefore;
    this.bookLatestXHourBefore = bookLatestXHourBefore;
    this.paymentUpfront = paymentUpfront;
    this.smsSenderName = smsSenderName;
    this.countryId= countryId;
    this.interval=interval;
    this.customUrl=customUrl;  
    this.description=description;
    this.facebook=facebook;
    this.instagram=instagram;
    this.twitter=twitter;
    this.website=website;
    this.lat=lat;
    this.lng=lng;
    this.bussinessEmail=bussinessEmail;
  }

  static fromDBModel(model) {
    return new Company(
      model.id,
      model.version_id,
      model.root_id,   
      model.cvr,
      model.company_name,    
      model.zip_code,
      model.city,
      model.address,
      model.accept_booking_automatically === 1,
      model.lock_booking_xhour_before,
      model.book_latest_xhour_before,
      model.payment_upfront === 1,
      model.sms_sender_name,
      model.country_id,
      model.interval,
      model.custom_url,    
      model.description,
      model.facebook,
      model.instagram,
      model.twitter,
      model.website,    
      model.lat,
      model.lng,
      model.bussiness_email
    );
  }

  static toDBModel(company) {
   
    return {
      // id: company.id, // don't need to map id
      version_id: company.versionId,
      root_id: company.rootId,   
     // password: company.password,
     // phone: company.phone,
      cvr: company.cvr,
      company_name: company.companyName,
     // first_name: company.firstName,
//last_name: company.lastName,
      zip_code: company.zipCode,
      city: company.city,
      address: company.address,
      accept_booking_automatically: company.acceptBookingAutomatically ? 1 : 0,
      lock_booking_xhour_before: company.lockBookingXHourBefore,
      book_latest_xhour_before: company.bookLatestXHourBefore,
      payment_upfront: company.paymentUpfront ? 1 : 0,
      sms_sender_name: company.smsSenderName,
      country_id:company.countryId,
      interval:company.interval,
      custom_url:company.customUrl,
      //email_veryfied:company.emailVeryfied,
      description:company.description,
      facebook:company.facebook,
      instagram:company.instagram,
      twitter:company.twitter,
      website:company.website,
      //verify_code:company.verifyCode,
     // phone_veryfied:company.phoneVeryfied,
     // email_token:company.emailToken,
      lat:company.lat,
      lng:company.lng,
      bussiness_email:company.bussinessEmail
    };
  }

  validPassword(password) {
    return bcrypt.compareSync(password, this.password);
  }

  static get Type() {
    return 'company';
  }
}


class CompanyVersion {
  constructor(
    id,
    versionId,
    rootId,       
    cvr,
    companyName,   
    zipCode,
    city,
    address,
    acceptBookingAutomatically,
    lockBookingXHourBefore,
    bookLatestXHourBefore,
    paymentUpfront,
    smsSenderName,
    countryId,
    companyId,
    interval,
    customUrl,  
    description,
    facebook,
    instagram,
    twitter,
    website,
    lat,
    lng,
    bussinessEmail
  ) {
    this.id = id;
    this.type = Company.Type;
    this.versionId = versionId;
    this.rootId = rootId;  
    this.cvr = cvr;
    this.companyName = companyName;
    this.zipCode = zipCode;
    this.city = city;
    this.address = address;
    this.acceptBookingAutomatically = acceptBookingAutomatically;
    this.lockBookingXHourBefore = lockBookingXHourBefore;
    this.bookLatestXHourBefore = bookLatestXHourBefore;
    this.paymentUpfront = paymentUpfront;
    this.smsSenderName = smsSenderName;
    this.countryId= countryId;
    this.companyId=companyId;
    this.interval=interval;
    this.customUrl=customUrl;   
    this.description=description;
    this.facebook=facebook;
    this.instagram=instagram;
    this.twitter=twitter;
    this.website=website;  
    this.lat=lat;
    this.lng=lng;
    this.bussinessEmail=bussinessEmail;
  }

  static fromDBModel(model) {
    return new CompanyVersion(
      model.id,
      model.version_id,
      model.root_id,     
      model.cvr,
      model.company_name,     
      model.zip_code,
      model.city,
      model.address,
      model.accept_booking_automatically === 1,
      model.lock_booking_xhour_before,
      model.book_latest_xhour_before,
      model.payment_upfront === 1,
      model.sms_sender_name,
      model.country_id,
      model.company_id,
      model.interval,
      model.custom_url,    
      model.description,
      model.facebook,
      model.instagram,
      model.twitter,
      model.website,   
      model.lat,
      model.lng,
      model.bussiness_email
    );
  }

  static toDBModel(company) {
    return {
      // id: company.id, // don't need to map id
      version_id: company.versionId,
      root_id: company.rootId,     
      cvr: company.cvr,
      company_name: company.companyName,
      first_name: company.firstName,
      last_name: company.lastName,
      zip_code: company.zipCode,
      city: company.city,
      address: company.address,
      accept_booking_automatically: company.acceptBookingAutomatically ? 1 : 0,
      lock_booking_xhour_before: company.lockBookingXHourBefore,
      book_latest_xhour_before: company.bookLatestXHourBefore,
      payment_upfront: company.paymentUpfront ? 1 : 0,
      sms_sender_name: company.smsSenderName,
      country_id:company.countryId,
      company_id:company.companyId,
      interval:company.interval,
      custom_url:company.customUrl,     
      description:company.description,
      facebook:company.facebook,
      instagram:company.instagram,
      twitter:company.twitter,
      website:company.website,     
      lat:company.lat,
      lng:company.lng,
      bussiness_email:company.bussinessEmail
    };
  }
  static get Type() {
    return 'company';
  }
}


module.exports = {
  Company,
  CompanyVersion,  
};

