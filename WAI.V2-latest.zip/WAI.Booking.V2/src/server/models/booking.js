class Booking {
  constructor(
    id,
    versionId,
    rootId,
    //employeeId,
    customerId,
    companyId,
    //serviceId,
    recipe,
    note,
    bookFrom,
    bookTo,
    createdOn,
    approvedOn,
    status,
    duration,
    paid,
    discountId
    //price,
    

  ) {
    this.id = id;
    this.versionId = versionId;
    this.rootId = rootId;
    //this.employeeId = employeeId;
    this.customerId = customerId;
    this.companyId = companyId;
    //this.serviceId = serviceId;
    this.recipe = recipe;
    this.note = note;
    this.bookFrom = bookFrom;
    this.bookTo = bookTo;
    this.createdOn = createdOn;
    this.approvedOn = approvedOn;
    this.status = status;
    this.duration=duration;
    this.paid=paid;
    this.discountId=discountId;
    //this.price=price;
  }

  static fromDBModel(model) {
    return new Booking(
      model.id,
      model.version_id,
      model.root_id,
      //model.employee_id,
      model.customer_id,
      model.company_id,
      //model.service_id,
      model.recipe,
      model.note,
      model.book_from,
      model.book_to,
      model.created_on,
      model.approved_on,
      model.status,
      model.duration,
      model.paid,
      model.discount_id
      ///model.price
    );
  }

  static toDBModel(booking) {
    return {
      // id: booking.id,
      version_id: booking.versionId,
      root_id: booking.rootId,
      //employee_id: booking.employeeId,
      customer_id: booking.customerId,
      company_id: booking.companyId,
      //service_id: booking.serviceId,
      recipe: booking.recipe || null,
      note: booking.note || null,
      book_from: booking.bookFrom,
      book_to: booking.bookTo,
      created_on: booking.createdOn,
      approved_on: booking.approvedOn || null,
      status: booking.status,
      duration:booking.duration,
      paid:booking.paid,
      discount_id:booking.discountId
      //price:booking.price
    };
  }

  static get PENDING_STATUS() {
    return 'AWAITING RESPONSE';
  }

  static get ACCEPTED_STATUS() {
    return 'ACCEPTED';
  }

  static get REJECTED_STATUS() {
    return 'REJECTED';
  }

  static get CANCELLED_STATUS() {
    return 'CANCELLED BY COMPANY';
  }
  
  static get CANCELLED_STATUS_CUSTOMER(){
    return 'CANCELLED BY CUSTOMER';
  }
  
  static get COMPLETED_STATUS() {
    return 'COMPLETED';
  }

  static get STAYED_AWAY_STATUS() {
    return 'STAYED AWAY';
  }

  
  static get ALL_STATUSES() {
    return [this.PENDING_STATUS, this.ACCEPTED_STATUS, this.REJECTED_STATUS, this.CANCELLED_STATUS];
  }
}
class BookingVersion {
  constructor(
    id,
    versionId,
    rootId,
    //employeeId,
    customerId,
    companyId,
   // serviceId,
    recipe,
    note,
    bookFrom,
    bookTo,
    createdOn,
    approvedOn,
    status,
    duration, 
    bookingId,
    paid
  ) {
    this.id = id;
    this.versionId = versionId;
    this.rootId = rootId;
    //this.employeeId = employeeId;
    this.customerId = customerId;
    this.companyId = companyId;
    //this.serviceId = serviceId;
    this.recipe = recipe;
    this.note = note;
    this.bookFrom = bookFrom;
    this.bookTo = bookTo;
    this.createdOn = createdOn;
    this.approvedOn = approvedOn;
    this.status = status;
    this.duration=duration;   
    this.bookingId=bookingId;
    this.paid=paid;
  }

  static fromDBModel(model) {
    return new Booking(
      model.id,
      model.version_id,
      model.root_id,
      //model.employee_id,
      model.customer_id,
      model.company_id,
     // model.service_id,
      model.recipe,
      model.note,
      model.book_from,
      model.book_to,
      model.created_on,
      model.approved_on,
      model.status,
      model.duration,    
      model.booking_id,
      model.paid
    );
  }

  static toDBModel(booking) {
    return {
      // id: booking.id,
      version_id: booking.versionId,
      root_id: booking.rootId,
      //employee_id: booking.employeeId,
      customer_id: booking.customerId,
      company_id: booking.companyId,
      //service_id: booking.serviceId,
      recipe: booking.recipe || null,
      note: booking.note || null,
      book_from: booking.bookFrom,
      book_to: booking.bookTo,
      created_on: booking.createdOn,
      approved_on: booking.approvedOn || null,
      status: booking.status,
      duration:booking.duration,     
      booking_id:booking.bookingId,
      paid:booking.paid
    };
  }  
}

class BookingExtra {
  constructor(
    id,//booking id
    bookingId,
    serviceExtraId,
    customerId,   
    name,
    price,
    duration,
    eid,//extra id   
    serviceId,
    employeeId,
    deleted,

  ) {
    this.id = id;
    this.eid
    this.bookingId = bookingId;
    this.serviceExtraId = serviceExtraId;
    this.customerId = customerId;
    this.name=name;
    this.price=price;
    this.duration=duration;
    this.eid=eid;
    this.serviceId=serviceId;
    this.employeeId=employeeId;
    this.deleted=deleted;
  }

  static fromDBModel(model) {   
    return new BookingExtra(
      model.id,
      model.booking_id,
      model.service_extra_id,
      model.customer_id,
      model.name,
      model.price,
      model.duration,
      model.eid,
      model.service_id,
      model.employee_id,
      model.deleted
    );
  }

  static toDBModel(extra) {
    return {
      // id: extra.id,
      booking_id: extra.bookingId,
      service_extra_id: extra.serviceExtraId,
      customer_id: extra.customerId,
      service_id:extra.serviceId,
      employee_id:extra.employeeId,
      deleted:extra.deleted
    };
  }
}

class BookingService {
  constructor(
    id,
    bookingId,
    serviceId,
    customerId,
    employeeId,
    deleted    
  ) {
    this.id = id;  
    this.bookingId = bookingId;
    this.serviceId = serviceId;
    this.customerId = customerId;
    this.employeeId=employeeId;
    this.deleted=deleted;
  }

  static fromDBModel(model) {    
    return new BookingService(
      model.id,
      model.booking_id,
      model.service_id,
      model.customer_id,
      model.employee_id,
      model.deleted 
    );
  }

  static toDBModel(service) {
    return {
      // id: extra.id,
      booking_id: service.bookingId,
      service_id: service.serviceId,
      customer_id: service.customerId,
      employee_id:service.employeeId,
      deleted:service.deleted
    };
  }
}

class BookingItem {
  constructor(
    id,
    bookingId,
    employeeId,    
    serviceId,
    extraId,
    isServeExtra,
    deleted     
  ) {
    this.id = id;  
    this.bookingId = bookingId;
    this.employeeId=employeeId;
    this.serviceId = serviceId;
    this.extraId=extraId;
    this.isServeExtra=isServeExtra;
    this.deleted = deleted;   
  }

  static fromDBModel(model) {    
    return new BookingItem(
      model.id,
      model.booking_id,
      model.employee_id,
      model.service_id,
      model.extra_id,
      model.is_service_extra,
      model.deleted     
    );
  }

  static toDBModel(model) {
    return {
      // id: extra.id,
      booking_id: model.bookingId,
      employee_id:model.employeeId,
      service_id:model.serviceId,
      extra_id:model.extraId,
      is_service_extra:model.isServeExtra,
      deleted:model.deleted

    };
  }
}


class BookingHours {
  constructor(
    id,
    companyId,
    employeeId,
    mondayIsOpen,
    tuesdayIsOpen,
    wednesdayIsOpen,
    thursdayIsOpen,
    fridayIsOpen,
    saturdayIsOpen,
    sundayIsOpen,
    mondayOpenAt,
    tuesdayOpenAt,
    wednesdayOpenAt,
    thursdayOpenAt,
    fridayOpenAt,
    saturdayOpenAt,
    sundayOpenAt,
    mondayCloseAt,
    tuesdayCloseAt,
    wednesdayCloseAt,
    thursdayCloseAt,
    fridayCloseAt,
    saturdayCloseAt,
    sundayCloseAt,
  ) {
    this.id = id;
    this.companyId = companyId;
    this.employeeId = employeeId;
    this.mondayIsOpen = mondayIsOpen;
    this.tuesdayIsOpen = tuesdayIsOpen;
    this.wednesdayIsOpen = wednesdayIsOpen;
    this.thursdayIsOpen = thursdayIsOpen;
    this.fridayIsOpen = fridayIsOpen;
    this.saturdayIsOpen = saturdayIsOpen;
    this.sundayIsOpen = sundayIsOpen;
    this.mondayOpenAt = mondayOpenAt;
    this.tuesdayOpenAt = tuesdayOpenAt;
    this.wednesdayOpenAt = wednesdayOpenAt;
    this.thursdayOpenAt = thursdayOpenAt;
    this.fridayOpenAt = fridayOpenAt;
    this.saturdayOpenAt = saturdayOpenAt;
    this.sundayOpenAt = sundayOpenAt;
    this.mondayCloseAt = mondayCloseAt;
    this.tuesdayCloseAt = tuesdayCloseAt;
    this.wednesdayCloseAt = wednesdayCloseAt;
    this.thursdayCloseAt = thursdayCloseAt;
    this.fridayCloseAt = fridayCloseAt;
    this.saturdayCloseAt = saturdayCloseAt;
    this.sundayCloseAt = sundayCloseAt;
  }

  static fromDBModel(model) {
    return new BookingHours(
      model.id,
      model.company_id,
      model.employee_id,
      model.monday_is_open === 1,
      model.tuesday_is_open === 1,
      model.wednesday_is_open === 1,
      model.thursday_is_open === 1,
      model.friday_is_open === 1,
      model.saturday_is_open === 1,
      model.sunday_is_open === 1,
      model.monday_open_at,
      model.tuesday_open_at,
      model.wednesday_open_at,
      model.thursday_open_at,
      model.friday_open_at,
      model.saturday_open_at,
      model.sunday_open_at,
      model.monday_close_at,
      model.tuesday_close_at,
      model.wednesday_close_at,
      model.thursday_close_at,
      model.friday_close_at,
      model.saturday_close_at,
      model.sunday_close_at
    );
  }

  static toDBModel(hours) {
    return {
      // id: hours.id,
      company_id: hours.companyId,
      employee_id: hours.employeeId,
      monday_is_open: hours.mondayIsOpen ? 1 : 0,
      tuesday_is_open: hours.tuesdayIsOpen ? 1 : 0,
      wednesday_is_open: hours.wednesdayIsOpen ? 1 : 0,
      thursday_is_open: hours.thursdayIsOpen ? 1 : 0,
      friday_is_open: hours.fridayIsOpen ? 1 : 0,
      saturday_is_open: hours.saturdayIsOpen ? 1 : 0,
      sunday_is_open: hours.sundayIsOpen ? 1 : 0,
      monday_open_at: hours.mondayOpenAt,
      tuesday_open_at: hours.tuesdayOpenAt,
      wednesday_open_at: hours.wednesdayOpenAt,
      thursday_open_at: hours.thursdayOpenAt,
      friday_open_at: hours.fridayOpenAt,
      saturday_open_at: hours.saturdayOpenAt,
      sunday_open_at: hours.sundayOpenAt,
      monday_close_at: hours.mondayCloseAt,
      tuesday_close_at: hours.tuesdayCloseAt,
      wednesday_close_at: hours.wednesdayCloseAt,
      thursday_close_at: hours.thursdayCloseAt,
      friday_close_at: hours.fridayCloseAt,
      saturday_close_at: hours.saturdayCloseAt,
      sunday_close_at: hours.sundayCloseAt
    };
  }
}

module.exports = {
  Booking,
  BookingExtra,
  BookingHours,
  BookingVersion,
  BookingService,
  BookingItem
};
