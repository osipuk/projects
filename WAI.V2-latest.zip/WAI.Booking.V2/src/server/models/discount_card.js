class DiscountCard {
  constructor(
    id,
    businessId,
    numberOfServices,
    price,
    serviceId,
    serviceExtraId,
    serviceType,
    createdOn,
    createdBy,
    active,
    deleted
  ) {
    this.id = id;
    this.businessId = businessId;
    this.numberOfServices=numberOfServices;
    this.price=price;
    this.serviceId=serviceId;
    this.serviceExtraId=serviceExtraId;
    this.serviceType=serviceType;
    this.createdOn=createdOn;
    this.createdBy=createdBy;
    this.active=active;
    this.deleted=deleted;
  }

  static fromDBModel(model) {
    return new DiscountCard(
      model.id,
      model.business_id,
      model.number_of_services,
      model.price,
      model.service_id,
      model.service_extra_id,
      model.service_type,
      model.created_on,
      model.created_by,
      model.active,
      model.deleted
    );
  }

  static toDBModel(terms) {
    return {
      // id: employee.id,
      business_id: terms.businessId,
      number_of_services:terms.numberOfServices,
      price:terms.price,
      service_id:terms.serviceId,
      service_extra_id:terms.serviceExtraId,
      service_type:terms.serviceType,
      created_on:terms.createdOn,
      created_by:terms.createdBy,
      active:terms.active,
      deleted:terms.deleted
    };
  }
}


class DiscountCardUserRelation {
  constructor(
    id,
    discountCardId,
    used,
    userId,
    createdOn,
    createdBy
  ) {
    this.id = id;
    this.discountCardId = discountCardId;
    this.used=used,
    this.userId=userId,
    this.createdOn=createdOn,
    this.createdBy=createdBy    
  }

  static fromDBModel(model) {
    return new DiscountCardUserRelation(
      model.id,
      model.discount_card_id,
      model.used,
      model.user_id,
      model.created_on,
      model.created_by

    );
  }

  static toDBModel(terms) {
    return {
      // id: employee.id,      
      discount_card_id:terms.discountCardId,
      used:terms.used,
      user_id:terms.userId,
      created_on:terms.createdOn,
      created_by:terms.createdBy

    };
  }
}

class BookingDiscountCardsRelation {
  constructor(
    id,
    bookingId,
    discountCardUserRelationId
  ) {
    this.id = id;
    this.bookingId=bookingId;
    this.discountCardUserRelationId=discountCardUserRelationId;
  }

  static fromDBModel(model) {
    return new DiscountCardUserRelation(
      model.id,
      model.booking_id,
      model.discount_card_user_relation_id

    );
  }

  static toDBModel(terms) {
    return {
      // id: employee.id,      
      booking_id:terms.bookingId,
      discount_card_user_relation_id:terms.discountCardUserRelationId
     

    };
  }
}

module.exports = { 
  DiscountCard,
  DiscountCardUserRelation,
  BookingDiscountCardsRelation
};
