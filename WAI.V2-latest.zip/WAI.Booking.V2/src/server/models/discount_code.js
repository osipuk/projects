class DiscountCode {
  constructor(
    id,
    businessId,
    code,
    type,
    amount,
    percentage,
    allServices,
    allServiceExtras,
    validFrom,
    validTo,
    requirePaymentUpfront,
    used,
    limit,
    createdBy,
    createdOn,
    active,
    deleted
  ) {
    this.id = id;
    this.businessId = businessId;
    this.code=code;
    this.type=type;
    this.amount=amount;
    this.percentage=percentage;
    this.allServices=allServices;
    this.allServiceExtras=allServiceExtras;
    this.validFrom=validFrom;
    this.validTo=validTo;
    this.requirePaymentUpfront=requirePaymentUpfront;
    this.used=used;
    this.limit=limit;
    this.createdBy=createdBy;
    this.createdOn=createdOn;
    this.active=active;
    this.deleted=deleted;    
  }

  static fromDBModel(model) {
    return new DiscountCode(
      model.id,
      model.business_id,
      model.code,
      model.type,
      model.amount,
      model.percentage,
      model.all_services,
      model.all_service_extras,
      model.valid_from,
      model.valid_to,
      model.require_payment_upfront,
      model.used,
      model.limit,
      model.created_by,
      model.created_on,
      model.active,
      model.deleted
      
    );
  }

  static toDBModel(terms) {
    return {
      // id: employee.id,
      business_id: terms.businessId,
      code:terms.code,
      type:terms.code,
      amount:terms.amount,
      percentage:terms.percentage,
      all_services:terms.allServices,
      all_service_extras:terms.allServiceExtras,
      valid_from:terms.validFrom,
      valid_to:terms.validTo,
      require_payment_upfront:terms.requirePaymentUpfront,
      used:terms.used,
      limit:terms.limit,
      created_by:terms.createdBy,
      created_on:terms.createdOn,
      active:terms.active,
      deleted:terms.deleted     
    };
  }
}


class DiscountServiceRelation {
  constructor(
    id,
    serviceId,
    discountId
    
  ) {
    this.id = id;
    this.serviceId = serviceId;
    this.discountId=discountId;
      
  }

  static fromDBModel(model) {
    return new DiscountServiceRelation(
      model.id,
      model.service_id,
      model.discount_id     
    );
  }

  static toDBModel(terms) {
    return {
      // id: employee.id,
      service_id: terms.serviceId,
      discount_id:terms.discountId         
    };
  }
}


class DiscountServiceExtrasRelation {
  constructor(
    id,
    serviceExtraId,
    discountId
    
  ) {
    this.id = id;
    this.serviceExtraId = serviceExtraId;
    this.discountId=discountId;
      
  }

  static fromDBModel(model) {
    return new DiscountServiceExtrasRelation(
      model.id,
      model.service_extra_id,
      model.discount_id
      
    );
  }

  static toDBModel(terms) {
    return {
      // id: employee.id,
      service_extra_id: terms.serviceExtraId,
      discount_id:terms.discountId
         
    };
  }
}


module.exports = { 
  DiscountCode ,
  DiscountServiceRelation,
  DiscountServiceExtrasRelation
};
