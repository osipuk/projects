class Payment {
  constructor(
    id,
    companyId,
    customerId,
    bookingId,
    paymentMethodId,
    txid,
    totalAmount,
    paymentAmount,
    cashAmount,
    status,
    createdOn,
    paymentType
  ) {
    this.id = id;
    this.companyId = companyId;
    this.customerId = customerId;
    this.bookingId = bookingId;
    this.paymentMethodId = paymentMethodId;
    this.txid = txid;
    this.totalAmount = totalAmount;
    this.paymentAmount=paymentAmount;
    this.cashAmount=cashAmount;
    this.status=status;
    this.createdOn = createdOn;
    this.paymentType=paymentType;
  }

  static fromDBModel(model) {
    return new Payment(
      model.id,
      model.company_id,
      model.customer_id,
      model.booking_id,
      model.payment_method_id,
      model.txid,
      model.total_amount,
      model.payment_amount,
      model.cash_amount,
      model.status,
      model.created_on,
      model.payment_type
    );
  }

  static toDBModel(payment) {
    return {
      // id: payment.id,
      company_id: payment.companyId,
      customer_id: payment.customerId,
      booking_id: payment.bookingId,
      payment_method_id: payment.paymentMethodId,
      txid: payment.txid,
      total_amount: payment.totalAmount,
      payment_amount:payment.paymentAmount,
      cash_amount:payment.cashAmount,
      status:payment.status,
      created_on: payment.createdOn,
      payment_type:payment.paymentType
    };
  }
}

module.exports = Payment;
