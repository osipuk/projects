class Notifications {
  constructor(
    id,
    notifyType,
    toUser,
    content,
    roleType,
    status,
    createdAt
  ) {
    this.id = id;
    this.notifyType=notifyType;
    this.toUser=toUser;
    this.content=content;
    this.roleType=roleType;
    this.status=status;
    this.createdAt=createdAt;
  }

  static fromDBModel(model) {
    return new Notifications(
      model.id,
      model.notify_type,
      model.to_user,
      model.content,
      model.role_type,
      model.status,
      model.created_at,
    );
  }

  static toDBModel(model) {
    return {
      // id: serviceCategory.id,
      notify_type: model.notifyType,
      to_user: model.toUser,
      content:model.content,
      role_type: model.roleType,
      status: model.status,
      created_at:model.createdAt
    };
  }
}

module.exports = { 
  Notifications
};
