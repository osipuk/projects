class BookingNotify {
  constructor(
    id,
    companyId,
    bookingId,
    customerId,
    createdAt,
    seen,
    eventType
  ) {
    this.id = id;
    this.companyId=companyId;
    this.bookingId=bookingId;
    this.customerId=customerId;
    this.createdAt=createdAt;
    this.seen=seen;    
    this.eventType=eventType;
  }

  static fromDBModel(model) {
    return new BookingNotify(
      model.id,
      model.company_id,
      model.booking_id,
      model.customer_id,
      model.created_at,
      model.seen,
      model.event_type
    );
  }

  static toDBModel(model) {
    return {
      // id: serviceCategory.id,
      company_id: model.companyId,
      booking_id: model.bookingId,
      customer_id: model.customerId,
      created_at: model.createdAt,
      seen:model.seen,
      event_type:model.eventType
    };
  }
}

module.exports = { 
  BookingNotify
};
