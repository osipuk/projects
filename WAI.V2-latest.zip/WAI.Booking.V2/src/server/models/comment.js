class Comment {
  constructor(
    id,
    companyId,
    customerId,
    comment,
    createdAt,
    modifiedAt
  ) {
    this.id = id;
    this.companyId = companyId;
    this.customerId = customerId;
    this.comment=comment;
    this.createdAt = createdAt;
    this.modifiedAt = modifiedAt;
  }

  static fromDBModel(model) {
    return new Comment(
      model.id,
      model.company_id,
      model.customer_id,
      model.comment,
      model.created_at,
      model.modified_at     
    );
  }

  static toDBModel(comment) {
    return {
      // id: payment.id,
      company_id: comment.companyId,
      customer_id: comment.customerId,
      comment: comment.comment,
      created_at: comment.createdAt,
      modified_at: comment.modifiedAt,
     
    };
  }
}


module.exports = { 
  Comment,  
};


