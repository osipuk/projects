const passport = require('passport');
const JSONStrategy = require('passport-json').Strategy;

const errors = require('../../common/error_codes');
const AppError = require('../errors/app_error');

const { Customer,User } = require('../models');

const CompanyController = require('../controllers').Company;
const CustomerController = require('../controllers').Customer;
const UserController=require('../controllers').User;

passport.serializeUser((user, done) => { 
 
  done(null, {
    id: user.id,
    type: user.type,
    email:user.email,
    phone:user.phone
    
  });
});

passport.deserializeUser((meta, done) => {
  const { type, id,email,phone } = meta;  
  let find = null;
  var key=null; 
  if (type === User.Type) {
  // find = UserController.findByEmail;
    find=UserController.findByEmailWithCompany;
    key=email;

  } else if (type === Customer.Type) {
    find = CustomerController.findById;
    key=id;
  } else {
    done(new AppError(errors.INCORRECT_USER_TYPE), null);
    return;
  }


  find(key).then((user) => {  
    done(null, user);
  }).catch((err) => {
    done(err, null);
  });
  
});

const init = () => {
  passport.use('company', new JSONStrategy({
    usernameProp: 'user[email]',
    passwordProp: 'user[password]'
  }, (email, password, done) => {
      //findByEmail
    UserController.findByEmail(email).then(async(company) => {      
      if (!company) {       
        return done(new AppError(errors.INCORRECT_USERNAME), null);
      }    
      if (!company.validPassword(password)) {       
        return done(new AppError(errors.INCORRECT_PASSWORD), null);
      }     
      
      const exstCompany = await UserController.findByEmailWithCompany(email);
      exstCompany.type="company";     
      return done(null, exstCompany);
    }).catch((err) => {
      done(err, null);
    });
  }));

  passport.use('customer', new JSONStrategy({
    usernameProp: 'user[phone]',
    passwordProp: 'user[password]'
  }, (phone, password, done) => {  
    CustomerController.findByPhone(phone).then((customer) => {
      if (!customer) {
        return done(new AppError(errors.INCORRECT_USERNAME), null);
      }
      
      if (!customer.validPassword(password)) {
        return done(new AppError(errors.INCORRECT_PASSWORD), null);
      }

      return done(null, customer);
    }).catch((err) => {
      done(err, null);
    });
  }));
};

module.exports = init;
