const init = require('./init');

module.exports = {
  init
};
