## Recomended tools to use

- [nvm] (https://github.com/creationix/nvm)
- [yarn] (https://yarnpkg.com/)

## Setup development environment

### Install nodejs v10.14.1

```bash
nvm install v10.14.1

nvm use v10.14.1
```

# Quick start

```bash
# Install dependencies
yarn (or npm install)

# Start development server
yarn dev (or npm run dev)

# Build for production
yarn build (or npm run build)

# Start production server
yarn start ( or npm start)
```
