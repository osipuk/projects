import * as CONSTS from '../constants/const';

export default (state = { loading: true }, action) => {
	switch (action.type) {
		case CONSTS.GET_ALL_NOTIFICATION:
			console.log(false,'false');
			return { ...state, allnotifications: action.payload, loading: false };
		default:
			return state;
	}
};
