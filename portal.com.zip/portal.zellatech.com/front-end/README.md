#### React Redux Starter Template

This project contains a boilerplate template created from the create-react-app library and configured along with redux.