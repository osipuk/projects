module.exports = {
  remoteUrl: "mongodb://157.245.235.132:27017/messaging",
  localUrl: "mongodb://localhost:27017/messaging"
};
